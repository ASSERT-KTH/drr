
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     java.lang.String var10 = var2.nextHexString(95);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var12 = var2.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.2249507567515314d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "007f09333f8e296e07838fb0df60f79b2062a5e7a9aec7c5b831dd3baceca9e7c835c30c8cfdad1d54f4f1522988c2b"+ "'", var10.equals("007f09333f8e296e07838fb0df60f79b2062a5e7a9aec7c5b831dd3baceca9e7c835c30c8cfdad1d54f4f1522988c2b"));
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
    double[] var26 = null;
    double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var26, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
    double[] var50 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var54 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var50, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var45, var54);
    double[] var57 = null;
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var54, var57);
    double[] var62 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var66 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var70 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var62, var71);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var54, var62);
    double var74 = org.apache.commons.math3.util.MathArrays.distance1(var34, var54);
    double[] var78 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var82 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var78, var82);
    double[] var87 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var91 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var87, var91);
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var82, var91);
    double var94 = org.apache.commons.math3.util.MathArrays.distance(var54, var82);
    double[] var95 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var54);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var50 = var47.cumulativeProbability(4979382.8531437665d, 1.3621815434775926d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextZipf(52, 7.4087361194955745d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var2.nextInt(1, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 10.0d};
//     double[] var6 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var10 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var11 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var10);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var10, var19);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     java.lang.Object[] var26 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var27 = new org.apache.commons.math3.exception.MathInternalError(var24, var26);
//     org.apache.commons.math3.util.Pair var28 = new org.apache.commons.math3.util.Pair((java.lang.Object)var23, (java.lang.Object)var24);
//     double var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var23);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 0.3127635608371082d);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 0.5769815473378194d);
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var2);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var7 = var6.getStrict();
    boolean var8 = var6.getStrict();
    boolean var9 = var6.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.24000830538393497d, (java.lang.Number)(-1.4656370140315509d), 10, var10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var5 = var1.nextFloat();
//     double var6 = var1.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9861216570226956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2258418083910485966L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.38306463f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1499743121005248d);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)9705.882352941177d, (java.lang.Number)1.6814095371639417E-9d, true);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1983603608));

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var50 = var47.cumulativeProbability(1.7320508075688772d, 0.9304525547601544d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var2.nextUniform(1.5603122607175668d, (-0.9286380078653282d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.28509338646268934d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeed();
//     var0.reSeed((-3200518016629555151L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextBeta((-9.743086442592038E10d), 0.021333908748968344d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     double var3 = var2.nextGaussian();
//     byte[] var5 = new byte[] { (byte)10};
//     var2.nextBytes(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var10 = null;
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
//     int[] var15 = new int[] { 100, 10, (-1)};
//     var11.setSeed(var15);
//     int[] var17 = new int[] { };
//     var11.setSeed(var17);
//     int[] var19 = null;
//     int var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var19);
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 66);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 0);
//     var9.setSeed(var24);
//     int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
//     var2.setSeed(var24);
//     int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var24);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     long var18 = var0.nextLong(0L, 12L);
//     double var21 = var0.nextBeta(0.4429300278176235d, 23.255333405607846d);
//     int var25 = var0.nextHypergeometric(42904144, 51, 87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.9113736934824805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7287380405385424d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "b7b820a040b749b297cd68b537dfa8624f9a5e408416d56a69f0f5ca177a41"+ "'", var12.equals("b7b820a040b749b297cd68b537dfa8624f9a5e408416d56a69f0f5ca177a41"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.004153842959937124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     double var9 = var0.nextBeta(0.5684335790811075d, 0.06469997385775762d);
//     double var11 = var0.nextChiSquare(20.104252970797198d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3684979190325392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "d7cd41e777053cc16572b4"+ "'", var4.equals("d7cd41e777053cc16572b4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f04cf1cbff5919913e9c6b06c2c5d336016a345ff681084a5a24f10ca4d154d5e7942c3808717e29bf6c8510"+ "'", var6.equals("f04cf1cbff5919913e9c6b06c2c5d336016a345ff681084a5a24f10ca4d154d5e7942c3808717e29bf6c8510"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21.548086997382512d);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var50 = var47.inverseCumulativeProbability(1.3621815434775926d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.47423001622272043d, 0.2384880170596717d, 0.7470195516521267d, (-0.08515379833665031d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.04948662394421241d);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextExponential((-0.32577132027868605d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7715668440846906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1e5366a5578b215fcfc5e80f45c1e46927141116e542a9a763710ec39366244f306b56ae520defc76b25803"+ "'", var8.equals("1e5366a5578b215fcfc5e80f45c1e46927141116e542a9a763710ec39366244f306b56ae520defc76b25803"));
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var5 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    double[] var6 = null;
    double[] var10 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var14 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var6, var14);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var21 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var21, var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 88);
    double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var30);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var41 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var42 = var41.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = var41.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var45 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var43, true);
    boolean var47 = org.apache.commons.math3.util.MathArrays.isMonotonic(var14, var43, false);
    double[] var51 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var55 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var59 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var59);
    double var61 = org.apache.commons.math3.util.MathArrays.distance1(var51, var60);
    double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var60, 88);
    double[] var67 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var71 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var67, var71);
    double[] var76 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var80 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var81 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var76, var80);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var71, var80);
    double[] var83 = null;
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var80, var83);
    double[][] var85 = new double[][] { var80};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var60, var85);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var43, var85);
    org.apache.commons.math3.exception.MathInternalError var88 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var12 = var10.nextPoisson(1.327000036267693d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var10.nextPoisson((-0.9866057353036886d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5631469209154678d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var14 = var2.nextCauchy(0.8364867927003998d, 2.755734400837643d);
//     double var17 = var2.nextBeta(0.021333908748968344d, 5842551.508144901d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var2.nextSecureLong(14L, 10L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.01255294192316d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.014462660392479898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.2496847188154452E-9d);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(25);
//     org.apache.commons.math3.distribution.IntegerDistribution var5 = null;
//     int var6 = var0.nextInversionDeviate(var5);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    double[] var1 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    double[] var5 = null;
    double[] var9 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var13 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var9, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var5, var13);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var13, var20);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var1, var13);
    double[] var31 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var31, var40);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var40, 0.0d);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var13, var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var40);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 199.04522099261766d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var4, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-0.08824970291025913d), var6);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var6);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var45 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var42, var45);
    double[] var50 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var50, var59);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var42, var50);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var50);
    double[] var64 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, 0.3144255808443382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextGaussian((-934295.5483625216d), (-19533.05988397774d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 551.5616252326815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.09131771257087437d);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    boolean var54 = var47.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var56 = var47.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     double var8 = var0.nextGaussian(54745.822302454384d, 0.50527176291182d);
//     double var11 = var0.nextGaussian(1.0252073473582036E-4d, 0.721992367247368d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextSecureInt(83, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "eb347fc2c8b60c37748c73cb7c977f9e8d03b967785dc3861e39b80920a6048347b20820c163877f60fd3bb"+ "'", var5.equals("eb347fc2c8b60c37748c73cb7c977f9e8d03b967785dc3861e39b80920a6048347b20820c163877f60fd3bb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 54746.56537260168d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.9638164464431926d));
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     var6.reSeed(14L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var6.nextGamma((-0.9922628678456615d), (-1.2829807006931007d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.8510306171447826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextExponential((-1462729.2793687023d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.18278718387837145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5972374.456627345d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100.0d, (java.lang.Number)(byte)100, 10);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)6.715731317427124E-9d);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     double var13 = var1.nextF(7.500930705661022d, 0.7985880262649143d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var1.nextSample(var14, 42);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
//     double[] var19 = null;
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var19, var27);
//     double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
//     double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var34);
//     boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var12, var34);
//     double[] var42 = null;
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var42);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform(5.2935374176612715d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextChiSquare((-1.5189910320170308d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9.05024167890474d);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    double[] var13 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[][] var15 = new double[][] { var13};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var15);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    long[] var23 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var23);
    long[][] var25 = new long[][] { var23};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var25);
    org.apache.commons.math3.exception.MathIllegalArgumentException var27 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var19, (java.lang.Object[])var25);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var25);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var25);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var25);
    org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException(var18, (java.lang.Object[])var25);
    var17.addSuppressed((java.lang.Throwable)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     java.lang.String var8 = var2.nextSecureHexString(2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var2.nextPascal(1, (-334.56309673916184d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2d"+ "'", var8.equals("2d"));
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.00116063972331892d), 0.6787523281640638d, (-0.3643230061371656d), (-0.05475404077564316d), 0.06935538164368933d, (-0.36834119618796374d), 0.5650594787118064d, 0.03923033899682219d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.015781400485699374d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    float[] var1 = new float[] { 10.0f};
    float[] var4 = new float[] { 0.0f, (-1.0f)};
    float[] var7 = new float[] { 0.0f, 100.0f};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var7);
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var1, var7);
    float[] var11 = new float[] { 10.0f};
    float[] var14 = new float[] { 0.0f, (-1.0f)};
    float[] var17 = new float[] { 0.0f, 100.0f};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var11, var17);
    float[] var22 = new float[] { (-1.0f), 1.0f};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var22);
    float[] var24 = new float[] { };
    float[] var27 = new float[] { 0.0f, (-1.0f)};
    float[] var30 = new float[] { 0.0f, 100.0f};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var24, var27);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var11, var27);
    float[] var34 = new float[] { };
    float[] var37 = new float[] { 0.0f, (-1.0f)};
    float[] var40 = new float[] { 0.0f, 100.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    float[] var45 = new float[] { 0.0f, (-1.0f)};
    float[] var48 = new float[] { 0.0f, 100.0f};
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var45, var48);
    float[] var50 = null;
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var48, var50);
    float[] var53 = new float[] { 10.0f};
    float[] var56 = new float[] { 0.0f, (-1.0f)};
    float[] var59 = new float[] { 0.0f, 100.0f};
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var56, var59);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var53, var59);
    float[] var64 = new float[] { (-1.0f), 1.0f};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var64);
    float[] var66 = new float[] { };
    float[] var69 = new float[] { 0.0f, (-1.0f)};
    float[] var72 = new float[] { 0.0f, 100.0f};
    boolean var73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var69, var72);
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var53, var69);
    boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var50, var53);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var50);
    boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var11, var37);
    boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var7, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     java.lang.Object var18 = var17.getSecond();
//     org.apache.commons.math3.util.Pair var19 = new org.apache.commons.math3.util.Pair(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.582405715592023d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(52);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.3127635608371082d, (-0.8258598346981539d), 0.0d, 1.5408118860052713d, (-1.5604020878665839d), 0.41369546662642837d, (-1096.3767627294947d), 0.4188489407275768d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-460.120075840096d));

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.6245596043465632d, (java.lang.Number)16, true);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NotANumberException var6 = new org.apache.commons.math3.exception.NotANumberException();
//     java.lang.Throwable[] var7 = var6.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var7);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     int var7 = var0.nextInt(0, 100);
//     int var11 = var0.nextHypergeometric(39, 15, 31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextLong(374001257020227328L, 4L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.928619402826067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var11 = var0.nextUniform((-0.4148741153049867d), (-0.19811647941323907d), false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 42.31367559886426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.016472212340922554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.246370835615301d));
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextInt(71, 44);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.333386846060918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.44261472968836585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var15);
    double[] var25 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.linearCombination(var21, var34);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-9896.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     long var8 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var9.nextSample(var10, 0);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(25);
//     double var7 = var0.nextWeibull(4.645762949836714d, 0.08430081831437178d);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var0.nextInversionDeviate(var8);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextZipf(52, 7.4087361194955745d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var2.nextInversionDeviate(var10);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextWeibull(6.785854381629338d, 4736077.9249220705d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("31468e72d42753c63314152d86d49f92548619a1228db5906658286598e8433e4d2d49c32aae8bbd91b25e52", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.35262462436440334d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5555564.496327115d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.8033964351615121E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4955414.248644063d);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure(1L);
//     var2.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var2.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7673656893797507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 0);
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 55);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
//     java.util.List var17 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var18 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var16, var17);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)21.869847397459292d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    int var6 = var3.getIndex();
    boolean var7 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var20, (-1102768644));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)9.49251188161346d);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     var0.reSeed((-56139359032789495L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextGaussian((-1096.3767627294947d), (-8.977615667280723d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2024.7744881380897d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4L);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     int var14 = var2.nextInt(61, 98);
//     int[] var17 = var2.nextPermutation(493, 33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.3266536173720751d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)4.7504964382589865d, (java.lang.Number)31, true);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-61.09525665040872d), (java.lang.Object)(-0.45868556584517606d));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.6044871530760823d));
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    double var8 = var2.nextGaussian(1.3621815434775926d, 0.9692669377133449d);
    int var11 = var2.nextInt(0, 5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextPascal(73, (-0.08812772856076337d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1054197636303182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var45 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var42, var45);
    double[] var50 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var50, var59);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var42, var50);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var50);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var66 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var67 = var66.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var68 = var66.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var69 = var66.getDirection();
    boolean var71 = org.apache.commons.math3.util.MathArrays.isMonotonic(var50, var69, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)426.15711861793085d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 28, 31);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     var0.reSeedSecure();
//     int var18 = var0.nextZipf(31, 0.9045563448629151d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9121014567833772d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8192683144254117d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.6356013683006906d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.167626206119096d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 8);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)7.4087361194955745d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }
// 
// 
//     org.apache.commons.math3.util.Pair var0 = null;
//     org.apache.commons.math3.util.Pair var1 = new org.apache.commons.math3.util.Pair(var0);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     var0.reSeedSecure(8026008374386375277L);
//     double var11 = var0.nextUniform(0.33140457057801864d, 10.0d);
//     double var13 = var0.nextChiSquare(0.843086155639615d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextPascal(513, (-0.6001566413360179d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-50123.487614049656d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "50ca8cc2e9de4223a54e03"+ "'", var4.equals("50ca8cc2e9de4223a54e03"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f941578ef4eb92f8aed8854749175978ff78f5d9855539d4d9de7b5f1f95b808a6af2714db20deee37751cec"+ "'", var6.equals("f941578ef4eb92f8aed8854749175978ff78f5d9855539d4d9de7b5f1f95b808a6af2714db20deee37751cec"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.8038989946897079d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.002943435235146444d);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.7985880262649143d, (java.lang.Number)(-0.831485025744287d), false);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("b360632613b5d44873bbd6738fb4411849e0be47820f45d7b15df983c0d124f0fb61c3a3d43667f114c5336", "74e192614f1761290dbb69ed21103f20b92b48dfec4a735dfe809dd2bd1f51de8c2b5e4608df0e58eae8");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.60548037091785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "f1eacf89705ce010eaf4271bf4cbacc42675bb5b6d93781"+ "'", var10.equals("f1eacf89705ce010eaf4271bf4cbacc42675bb5b6d93781"));
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     var0.reSeed(0L);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var0.nextSample(var15, 43);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var14 = var0.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     java.lang.String var16 = var0.nextSecureHexString(93);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("b360632613b5d44873bbd6738fb4411849e0be47820f45d7b15df983c0d124f0fb61c3a3d43667f114c5336", "97fe9802f9fa87b18441fb1b8791df75cb6fdd5f9544c121069eef39b8efe7ec40872d9347da9e17d72e762");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.923065576441755E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.222968184582252E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.06704320096680189d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.036373226346626875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "50a8037408efcb62d8f743a6fc791ccf129d10980b42445c22d726b645fab02913ad83175b0197ab3732738dd48a5"+ "'", var16.equals("50a8037408efcb62d8f743a6fc791ccf129d10980b42445c22d726b645fab02913ad83175b0197ab3732738dd48a5"));
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     var0.reSeedSecure();
//     int var9 = var0.nextZipf(99, 0.10832690038004085d);
//     long var12 = var0.nextSecureLong((-56139359032789495L), 5804136433509186560L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian(0.0698963835083768d, (-0.8211092390774544d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-19.717225443535092d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.040364570420400585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3802143405454956544L);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextChiSquare((-3924.0955234387598d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.48482155289878515d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7e2d63103df3cf33ddf61e"+ "'", var4.equals("7e2d63103df3cf33ddf61e"));
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var8 = var1.nextInt(18);
//     int var10 = var1.nextInt(54);
//     var1.setSeed(54);
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var13.nextZipf(93, (-370.93054277619296d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3349894608358866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "c5c7894b709468e2f0fd355b25b699546915529a3207059c47e9162bc2296111ed95dd3c02bc37089c5d9e7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.656932251639059d);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.2112813576399155d, (java.lang.Number)(-0.5883540186360512d), true);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     long var12 = var2.nextSecureLong(14L, 24L);
//     var2.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var2.nextGamma(1.934238008197349E-9d, (-0.08515379833665031d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "cf058286d233427ac961bdbbece1b"+ "'", var9.equals("cf058286d233427ac961bdbbece1b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 20L);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(93);
    double var2 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.826033334337134d));

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextCauchy(0.8987000150098532d, (-0.6609347937459655d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5200942197446503d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b4ee68ec926feb5b8fd3afac544498db8040cdbfec5af7f337f3fb70233dbaf9b62e96d6fb6520feb503461"+ "'", var8.equals("b4ee68ec926feb5b8fd3afac544498db8040cdbfec5af7f337f3fb70233dbaf9b62e96d6fb6520feb503461"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20.055240302709965d);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var11 = var8.nextWeibull(0.31568577999507896d, 6.813639406926573E-7d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var8.nextChiSquare((-0.4148817263771911d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9773733990269199d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.0274366783790892E-5d);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(42904144, 6);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance1(var4, var13);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var13, 0.0d);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     double[] var21 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var22 = org.apache.commons.math3.util.MathArrays.safeNorm(var21);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var30 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var31 = var30.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var32 = var30.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var34 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var32, true);
//     boolean var36 = org.apache.commons.math3.util.MathArrays.isMonotonic(var21, var32, true);
//     double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeAdd(var21, var40);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var13, var46);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var0, var47);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.03745130196627389d, (-0.292640940848738d), (-7.247207337058009d), (-5.144340331950409E15d), 1.6128523808130044d, 1.0252073473582036E-4d, 0.6639432937569401d, 0.09455763871444445d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.7282100998034432E16d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 21.869847397459292d);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var33 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[][] var35 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var41 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var41, var50);
    double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 88);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var50);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var54);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var54);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextBinomial((-1), 3.117875532018103d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 58.36490399537623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.10775778605452756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong(1L, 8026008374386375277L);
//     var2.reSeedSecure(7L);
//     int var10 = var2.nextPascal(50, 0.0d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var2.nextSample(var11, 8);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     var12.reSeed();
//     int var16 = var12.nextZipf(18, 0.10832690038004085d);
//     double var18 = var12.nextT(11.36369913641775d);
//     int[] var21 = var12.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var9);
//     double var25 = var24.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.254866143501413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "b759e4888d0efe85ae0247"+ "'", var4.equals("b759e4888d0efe85ae0247"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2250023356852043E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.5918607522488695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.9222814965959991d);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-14.653067499081518d), 12.952468230884172d, 0.7470195516521267d, 23.255333405607846d, 2.1874856059935905d, (-0.29358390686045066d), 0.37924661998448883d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-173.06341310308545d));

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 39);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var38 = null;
    double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var38, var46);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var53);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var31, var53);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double[][] var62 = new double[][] { var31};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var62);
    double[] var64 = null;
    double[] var68 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var72 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var68, var72);
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var64, var72);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var72);
    double[] var79 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var83 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var87 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var83, var87);
    double var89 = org.apache.commons.math3.util.MathArrays.distance1(var79, var88);
    double[] var91 = org.apache.commons.math3.util.MathArrays.copyOf(var88, 88);
    double var92 = org.apache.commons.math3.util.MathArrays.distanceInf(var72, var88);
    double var93 = org.apache.commons.math3.util.MathArrays.distance1(var8, var88);
    double[] var97 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var98 = org.apache.commons.math3.util.MathArrays.safeNorm(var97);
    double var99 = org.apache.commons.math3.util.MathArrays.distance1(var88, var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 194.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 111.0d);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var8 = var1.nextInt(18);
//     float var9 = var1.nextFloat();
//     int var11 = var1.nextInt(95);
//     int var13 = var1.nextInt(22);
//     float var14 = var1.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2.1345464470505116d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.28523564f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.27849174f);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double[] var50 = var47.sample(318);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var53 = var47.cumulativeProbability(1.1646934545521657d, (-0.3643230061371656d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextCauchy(29.538354013273814d, (-61.09525665040872d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3563449564802126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.18710699505074366d);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     double var3 = org.apache.commons.math3.util.MathArrays.distance(var0, var2);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     int var10 = var1.nextBinomial(42, 0.13950886311666869d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.96011880749921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     double var10 = var0.nextT(0.4573684520296781d);
//     double var13 = var0.nextWeibull(2.5601423343889373d, 10.52791259447133d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("97fe9802f9fa87b18441fb1b8791df75cb6fdd5f9544c121069eef39b8efe7ec40872d9347da9e17d72e762", "31468e72d42753c63314152d86d49f92548619a1228db5906658286598e8433e4d2d49c32aae8bbd91b25e52");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4449288942756051d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0074429469060689E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.4396698560897343d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.666127099488856d);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var7.nextZipf(88, (-36464.24236834751d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     boolean var10 = var1.nextBoolean();
//     var1.setSeed((-3200518016629555151L));
//     int var13 = var1.nextInt();
//     java.util.List var14 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var15 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var14);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 21.869847397459292d);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var33 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[][] var35 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var41 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var41, var50);
    double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 88);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var50);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var54);
    java.lang.Number var56 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var62 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var63 = var62.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = var62.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var66 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var56, (java.lang.Number)0.8055186938534216d, 60, var64, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var69 = org.apache.commons.math3.util.MathArrays.checkOrder(var54, var64, true, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextChiSquare((-0.09154513481168484d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.875871890567762d);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(100L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6697181400437264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "11773af5b9d306ddfefcba05beaa8d0bf1edb414ae276c10b85bc5b5417d83beafb50789da2f6aa61b34e10"+ "'", var8.equals("11773af5b9d306ddfefcba05beaa8d0bf1edb414ae276c10b85bc5b5417d83beafb50789da2f6aa61b34e10"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 17.856688078913905d);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)6.251783231069299d, false);
//     java.lang.Number var5 = var4.getMax();
//     java.lang.Number var6 = var4.getMax();
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var12 = var9.nextPermutation(66, 20);
    long var14 = var9.nextPoisson(0.18726212538835552d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var9.nextF((-1462729.2793687023d), 1.6445632382959425E-9d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0L);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var25, var34);
//     double[] var37 = null;
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
//     double[] var42 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
//     double var52 = org.apache.commons.math3.util.MathArrays.distance1(var42, var51);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var34, var42);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var34);
//     double[] var56 = new double[] { 10.0d};
//     double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
//     double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var73);
//     double[] var77 = org.apache.commons.math3.util.MathArrays.normalizeArray(var73, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var78 = null;
//     java.lang.Object[] var80 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var81 = new org.apache.commons.math3.exception.MathInternalError(var78, var80);
//     org.apache.commons.math3.util.Pair var82 = new org.apache.commons.math3.util.Pair((java.lang.Object)var77, (java.lang.Object)var78);
//     double var83 = org.apache.commons.math3.util.MathArrays.distanceInf(var56, var77);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var77);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var87 = var84.cumulativeProbability(34.08534215706243d, 0.50527176291182d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.18447063220955595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 87.05882352941177d);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     int var14 = var0.nextInt(0, 14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("40f23200f83ba9bbed680d", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.06530017743582484d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cc9d282e2f03a8979d5e83672bc8af8afb1a3e93b0319d8bb17b46f130eeef1fad831eb7d19700b5ed43b3a"+ "'", var8.equals("cc9d282e2f03a8979d5e83672bc8af8afb1a3e93b0319d8bb17b46f130eeef1fad831eb7d19700b5ed43b3a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 23.991292876676315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 13);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(5507950371326924800L);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 34);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 27);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextSecureHexString(52);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var2.nextUniform(1.105027158046092E-9d, (-3917.2097398377805d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "3d3483696c2dd444856afa6f2c7317d508f940a9b20bc6d61ca4"+ "'", var4.equals("3d3483696c2dd444856afa6f2c7317d508f940a9b20bc6d61ca4"));
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    java.lang.Throwable[] var1 = var0.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
//     double var19 = org.apache.commons.math3.util.MathArrays.distance1(var9, var13);
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
//     double[] var39 = null;
//     double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
//     boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var39, var47);
//     double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
//     double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var47, var54);
//     boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var32, var54);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
//     double[][] var63 = new double[][] { var32};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var9, var63);
//     org.apache.commons.math3.exception.MathIllegalStateException var65 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var63);
//     java.lang.String var66 = var65.toString();
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var14 = var0.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextExponential((-173.06341310308545d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.5646087070751091E17d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.008461901765359573d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.5112464877811225d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.09317203662716068d);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     var0.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextPascal(16, (-4.229807354382433d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.5354455740550907d);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     long var8 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.List var10 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var11 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     int var18 = var0.nextZipf(36, 0.002575717853305201d);
//     int var21 = var0.nextSecureInt(15, 18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.7919754259875305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7554181709939505d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "0c65a26117dd5579af77b823d756f2d7a94fcd1987b421929c63319bb988c0"+ "'", var12.equals("0c65a26117dd5579af77b823d756f2d7a94fcd1987b421929c63319bb988c0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 17);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform(5.2935374176612715d, 10.0d);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)13.589650696693303d);
//     boolean var7 = var5.equals((java.lang.Object)(short)10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.604624584640234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var11 = var8.nextWeibull(0.31568577999507896d, 6.813639406926573E-7d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var8.nextHypergeometric(15, 22, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.8638088292550443d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.0274366783790892E-5d);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    java.lang.String var5 = var3.toString();
    boolean var6 = var3.getStrict();
    boolean var7 = var3.getStrict();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     int var18 = var0.nextZipf(36, 0.002575717853305201d);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 90);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
    double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
    double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
    double[] var41 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[][] var43 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var32, var43);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    double[] var49 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var49, var58);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var58, 88);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var32, var58);
    double[] var66 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var70 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var70);
    double[] var75 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var75);
    double[][] var77 = new double[][] { var75};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var66, var77);
    double var79 = org.apache.commons.math3.util.MathArrays.safeNorm(var66);
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var62, var66);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var24, var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var62);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     int[] var12 = null;
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     int[] var17 = new int[] { 100, 10, (-1)};
//     var13.setSeed(var17);
//     int[] var19 = new int[] { };
//     var13.setSeed(var19);
//     int[] var21 = null;
//     int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var21);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 66);
//     int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
//     int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 44);
//     int var28 = org.apache.commons.math3.util.MathArrays.distance1(var11, var24);
//     int[] var29 = new int[] { };
//     int[] var30 = null;
//     int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var30);
//     int[] var32 = new int[] { };
//     int[] var33 = null;
//     int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var33);
//     int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var29);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.6191435860322954d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 499);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 13, 78);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     var0.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-30.85316060276213d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.012115282842360003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.358935884484011d);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, var1, 13);
    int var4 = var3.getIndex();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     java.lang.Object var18 = var17.getSecond();
//     java.lang.Object var19 = var17.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7540468555448316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var11 = var2.nextPermutation(1, 24);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }
// 
// 
//     org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
//     java.lang.Object var3 = var2.getSecond();
//     java.lang.Object var4 = var2.getFirst();
//     double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
//     org.apache.commons.math3.random.RandomDataGenerator var14 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var17 = var14.nextInt(10, 100);
//     double var20 = var14.nextUniform((-1.0d), 1.0d);
//     var14.reSeedSecure();
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var14);
//     boolean var23 = var2.equals((java.lang.Object)var14);
//     java.lang.Object var24 = var2.getValue();
//     boolean var26 = var2.equals((java.lang.Object)"d051970ae47550f154d0cd2ca1c745d9f69c39ef88aebc13a13e6ef739403083709e103144647d619db6438");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.6489035278636153d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + 10.0d+ "'", var24.equals(10.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var56 = var47.probability(3.4785048692046914d, (-0.08824970291025913d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var0.nextPermutation(66, 67);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var2.nextWeibull(0.3328432771849152d, (-0.33126975303273d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8769815200663562d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextF(0.5648114822631072d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.311464983339376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.002468290600562425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.940479551280649d);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)5507950371326924800L, (java.lang.Number)1.4276096462825826E-9d, (java.lang.Number)12);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NotANumberException var7 = new org.apache.commons.math3.exception.NotANumberException();
//     java.lang.Throwable[] var8 = var7.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)100.0d, (java.lang.Object[])var8);
//     var4.addSuppressed((java.lang.Throwable)var9);
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     java.lang.Throwable[] var17 = var16.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var12, (java.lang.Object[])var17);
//     java.lang.Throwable[] var19 = var18.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var11, (java.lang.Object[])var19);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    java.lang.String var5 = var3.toString();
    boolean var6 = var3.getStrict();
    boolean var7 = var3.getStrict();
    boolean var8 = var3.getStrict();
    boolean var9 = var3.getStrict();
    boolean var10 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var9 = var6.nextLong(1L, 5804136433509186560L);
//     var6.reSeed(6149568864592168549L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1761598406267697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2371042799620495360L);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(0L);
//     double var11 = var7.nextT(199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6355819563518119d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.4611404247083613d));
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.31568577999507896d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var7, var17);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var8 = var0.nextGaussian(1.6200204638860117E-8d, 0.1289083935957991d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextSecureInt(85, 52);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12.736219834281926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.12292169977684547d));
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 18, 96);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     var0.reSeedSecure(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("b9950a9722b12544c9c9d813430dff6f4efe0d094b0f37082fce7c34a48e68db17bfdb2e9b23229665c8594", "deb772f721dfb96b0426e0e140dc9fc7f121740c5c9d574328ead75f71cb9326deedae66b8e84c39dc79ae2");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.293667355852855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.004063698978236867d);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.10659341427742133d), 0.8835017553608111d, (-0.01498759451409439d), 3.3718048487453802d, 9705.882352941177d, 6.219562570799601d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 60366.19788822483d);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var5 = var3.nextT(0.1431715674774945d);
//     double var8 = var3.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var11 = var3.nextPermutation(83, 33);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     var1.setSeed(var12);
//     int[] var14 = null;
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
//     int[] var19 = new int[] { 100, 10, (-1)};
//     var15.setSeed(var19);
//     int[] var21 = new int[] { };
//     var15.setSeed(var21);
//     int[] var23 = null;
//     int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = org.apache.commons.math3.util.MathArrays.distance1(var12, var21);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6839064267538659d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 16.04330476304321d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8714754996252182d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("e00d2de4cc6b7a30e300091e51798c1b48dd055bbc27fa3bf3274b0be930cf0f892423c44a5007", "7ef9a8ba1a464dfa57ae086e20dfc62a7c8325b9ab12504daa3a4029d45ee");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.nextBeta((-334.73040418701044d), 0.013754611873402173d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.5753819820845707d, false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    org.apache.commons.math3.exception.NullArgumentException var1 = new org.apache.commons.math3.exception.NullArgumentException();
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.1891493406396207d, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var52 = var47.getSupportUpperBound();
    double var54 = var47.density((-19533.05988397774d));
    double var55 = var47.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 9705.882352941177d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-3200518016629555151L), (java.lang.Number)6758353113347147164L, false);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int[] var5 = var2.nextPermutation(318, 63);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var8 = var6.nextT(0.1431715674774945d);
//     double var11 = var6.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var14 = var6.nextPermutation(83, 33);
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var14);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.7432631318163687d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.7746739930280905E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 93, 80);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var5 = var0.nextLong(2563274223793255424L, (-5787431229102719808L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 95.5023770883108d);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.38306463f);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("f67f", "bc6c20d2766e22cd4330bb3881fa02762e21e9c603d8b355a1cf37");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    boolean var54 = var47.isSupportConnected();
    double var55 = var47.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var57 = var47.inverseCumulativeProbability((-4.223479475728832d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 9705.882352941177d);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     int var12 = var0.nextSecureInt(0, 29);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextF((-0.7839959865176689d), (-0.6087410776433462d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.873724155255792d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0011029960131372224d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 23);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeedSecure(100L);
    java.lang.String var9 = var2.nextHexString(53);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextWeibull(4.307681584078219E-5d, (-0.9494870679461207d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "662ab224c609e5c9ef47e16ab5a751468d6b7db870cac522c8500"+ "'", var9.equals("662ab224c609e5c9ef47e16ab5a751468d6b7db870cac522c8500"));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextInt(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(1.1761598406267697d, 1.2472467189160535E-9d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.1819512550573963d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0029893230543150437d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 55);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     int var7 = var0.nextSecureInt((-1), 15);
//     java.lang.String var9 = var0.nextHexString(78);
//     double var12 = var0.nextBeta(0.4337155679007866d, 0.4841123961597962d);
//     double var15 = var0.nextCauchy(0.8835017553608111d, 9.49251188161346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.666606011498951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "2678c9bc53f05f77253a7ee51ac262e601cb1543c96a9382c85975df80153f09d9f16b5c48f7bf"+ "'", var9.equals("2678c9bc53f05f77253a7ee51ac262e601cb1543c96a9382c85975df80153f09d9f16b5c48f7bf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.8903759925545637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-10.849168435251086d));
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var13 = var0.nextExponential(103.56915419683993d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextBeta(24.00401720365219d, (-0.18598915314788322d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8720328993147746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.0679850894955547d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.865381627724363d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 38.712090884032676d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(17);
    long var2 = var1.nextLong();
    float var3 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5885824031410116532L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9367908f);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var4 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(51);
    float var2 = var1.nextFloat();
    int[] var3 = null;
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var8 = new int[] { 100, 10, (-1)};
    var4.setSeed(var8);
    int[] var10 = new int[] { };
    var4.setSeed(var10);
    int[] var12 = null;
    int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var12);
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 66);
    var1.setSeed(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.50112605f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 0.0d);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var8, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextZipf(0, 24.00401720365219d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.09859014780548625d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "24cac8e9e17809cc014b3353d3bc972b921c36591bfa37fcf4609fbc2038d12835c4b14852986a9780db5a5"+ "'", var8.equals("24cac8e9e17809cc014b3353d3bc972b921c36591bfa37fcf4609fbc2038d12835c4b14852986a9780db5a5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9.090697037587981d);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 30);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var11, (java.lang.Number)10.0d, (java.lang.Number)(short)1, (java.lang.Number)(-0.32577132027868605d));
    java.lang.Number var16 = var15.getHi();
    var10.addSuppressed((java.lang.Throwable)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-0.32577132027868605d)+ "'", var16.equals((-0.32577132027868605d)));

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     long var18 = var0.nextLong(0L, 12L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var21 = var0.nextPermutation(90, 99);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.39729767935306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5940043777234918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "cba6783d018933dc7edcd229c8d7e278e2f78b00f3f38533048d9b05b2dc81"+ "'", var12.equals("cba6783d018933dc7edcd229c8d7e278e2f78b00f3f38533048d9b05b2dc81"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextBeta((-1.088619555944748d), 0.017370781226939247d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6362471543764738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.061361829412967174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     var0.reSeed(12L);
//     int var20 = var0.nextInt(19, 75);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextZipf(22, (-1.3245036052768728d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 33.40601651801522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7354733985683938d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 31);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextGaussian(12.952468230884172d, (-1.5189910320170308d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-679.7841048171373d));
    java.lang.Number var2 = var1.getMin();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     double var16 = var0.nextExponential(0.6591014616866876d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextHypergeometric(7, 499, 66);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.61558626168532d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.438843584493713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.7955914255748807d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.8794994431143155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.26505450553421617d);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    double[] var3 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var4 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var13 = var12.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = var12.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var14, true);
    boolean var18 = org.apache.commons.math3.util.MathArrays.isMonotonic(var3, var14, true);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var22);
    double[] var30 = new double[] { 10.0d};
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var38, var47);
    double[] var51 = org.apache.commons.math3.util.MathArrays.normalizeArray(var47, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var52 = null;
    java.lang.Object[] var54 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var55 = new org.apache.commons.math3.exception.MathInternalError(var52, var54);
    org.apache.commons.math3.util.Pair var56 = new org.apache.commons.math3.util.Pair((java.lang.Object)var51, (java.lang.Object)var52);
    double var57 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var51);
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var30, 0.3127635608371082d);
    double[] var64 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var68 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var72 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var68, var72);
    double var74 = org.apache.commons.math3.util.MathArrays.distance1(var64, var73);
    double[] var76 = org.apache.commons.math3.util.MathArrays.normalizeArray(var73, 0.0d);
    double[] var77 = org.apache.commons.math3.util.MathArrays.copyOf(var73);
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var30, var77);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var79 = org.apache.commons.math3.util.MathArrays.ebeAdd(var22, var30);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 12.0d);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 13);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.setSeed(108L);
//     boolean var10 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8062237388966609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     long var13 = var2.nextPoisson(0.5117876358710434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5232223581285713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.2670644661794837d, (java.lang.Number)0.843086155639615d, 69);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(47, 58);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 100);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var14 = var2.nextGamma(1.22705655817319d, 1.487086298741032E-9d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var2.nextGamma((-5699.4358864984715d), 0.6032779273078988d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.228907003123193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.37742209387277E-9d);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.5601423343889373d);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextExponential((-9.743086442592038E10d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-11675.85142757487d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.8709985184248673E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.8170662921628897d);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.2472467189160535E-9d, (java.lang.Number)6118812665134684913L, (java.lang.Number)24);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)529.9961815694902d);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(25);
//     double var7 = var0.nextWeibull(4.645762949836714d, 0.08430081831437178d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextBeta(0.9999999989253456d, (-0.20511952442607093d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-17.988066398676526d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "47eababcb6940992eff2f1ca0"+ "'", var4.equals("47eababcb6940992eff2f1ca0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.10738687501309531d);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextChiSquare((-2.1252493435396733d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 24433.398506455724d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "309b0b0918a41a7e35aeb6"+ "'", var4.equals("309b0b0918a41a7e35aeb6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "5808d9e2266f58a851a145d84f1441af114d9bcc05dbd567ba908f9b39c65fd468cac8f9d3e68de24a227df8"+ "'", var6.equals("5808d9e2266f58a851a145d84f1441af114d9bcc05dbd567ba908f9b39c65fd468cac8f9d3e68de24a227df8"));
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0, (java.lang.Number)(-0.14097693123713528d), 87);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    long[] var9 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    long[][] var11 = new long[][] { var9};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var11);
    java.lang.Throwable[] var17 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2142147742, 34);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.0923773846537261d), (java.lang.Number)3, (java.lang.Number)0.22134555248470017d);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1.0923773846537261d)+ "'", var4.equals((-1.0923773846537261d)));

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.031186714079133728d, (java.lang.Number)(-0.08824970291025913d), (java.lang.Number)53);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.08824970291025913d), 0.1431715674774945d, 1.5603122607175668d, 0.8421355648684861d, 0.5528914374062783d, (-0.6346046533769326d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9504921197652423d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.4301403036978695d);
    java.lang.Number var2 = var1.getMin();
    java.lang.Number var3 = var1.getMin();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.33126975303273d), (java.lang.Number)0.28523564f, false);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextLong(0L, (-5787431229102719808L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9226640256872511d);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var6.nextSample(var8, 34);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var54 = var47.cumulativeProbability(1.1646934545521657d, (-0.847626798399463d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }
// 
// 
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var4 = var3.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException(var6, (java.lang.Number)5507950371326924800L, (java.lang.Number)1.4276096462825826E-9d, (java.lang.Number)12);
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.NotANumberException var13 = new org.apache.commons.math3.exception.NotANumberException();
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var11, (java.lang.Number)100.0d, (java.lang.Object[])var14);
//     var10.addSuppressed((java.lang.Throwable)var15);
//     var3.addSuppressed((java.lang.Throwable)var10);
//     org.apache.commons.math3.exception.util.Localizable var18 = null;
//     org.apache.commons.math3.exception.util.Localizable var19 = null;
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math3.exception.NotFiniteNumberException var24 = new org.apache.commons.math3.exception.NotFiniteNumberException(var20, (java.lang.Number)1L, var23);
//     org.apache.commons.math3.exception.MathInternalError var25 = new org.apache.commons.math3.exception.MathInternalError(var19, var23);
//     org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var18, var23);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.1780686035080814d, 343.34893171523254d, 0.4337155679007866d, 0.2384880170596717d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 61.243100752279624d);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var7);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var11 = var8.nextWeibull(0.31568577999507896d, 6.813639406926573E-7d);
//     long var14 = var8.nextLong(508515618537942016L, 8026008374386375277L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var8.nextSecureInt(52, 41);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.3029152228965382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.0274366783790892E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2022582015419129856L);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     double var11 = var2.nextT(81.560782738241d);
//     java.lang.String var13 = var2.nextHexString(27);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var2.nextLong(2022582015419129856L, 374001257020227328L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "27e2947dee93c22357a53cb4ce949"+ "'", var9.equals("27e2947dee93c22357a53cb4ce949"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.7110563084721201d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "685639e4a20eacd2e00e09a64d7"+ "'", var13.equals("685639e4a20eacd2e00e09a64d7"));
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    var2.reSeed(39L);
    double var14 = var2.nextCauchy(1.7451931429974368d, 4979382.8531437665d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("e8bc16db853efd510cb9ac7c593c7e63811209df3091e789b5dd2c65b2a1de0111465ade06d86efc53893fbc4646e", "662ab224c609e5c9ef47e16ab5a751468d6b7db870cac522c8500");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0521385758460062E7d));

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     java.lang.String var7 = var0.nextHexString(53);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextT((-61.09525665040872d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "50cd2928a6769dc6104633741e7bd89dc644877ef0e690242c3b4f9b98424c6589c4a71db75bdf94f410498"+ "'", var5.equals("50cd2928a6769dc6104633741e7bd89dc644877ef0e690242c3b4f9b98424c6589c4a71db75bdf94f410498"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "51433dc9b1970f35e3b2650de1bb222b9a23c8dc8102ac6a77f3e"+ "'", var7.equals("51433dc9b1970f35e3b2650de1bb222b9a23c8dc8102ac6a77f3e"));
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     var0.reSeedSecure(27192867108684266L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextWeibull((-1462729.2793687023d), 0.7540468555448316d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(66, 95);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     int var12 = var0.nextSecureInt(0, 29);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(27192867108684266L, (-509399413869688601L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8995546149281113d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3029048203098748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.8820876449002348d, (java.lang.Number)0.6245596043465632d, false);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     int[] var17 = null;
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
//     double var19 = var18.nextGaussian();
//     byte[] var21 = new byte[] { (byte)10};
//     var18.nextBytes(var21);
//     org.apache.commons.math3.random.RandomDataGenerator var23 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var18);
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var26 = null;
//     org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var26);
//     int[] var31 = new int[] { 100, 10, (-1)};
//     var27.setSeed(var31);
//     int[] var33 = new int[] { };
//     var27.setSeed(var33);
//     int[] var35 = null;
//     int var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var35);
//     int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 66);
//     int[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 0);
//     var25.setSeed(var40);
//     int[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
//     var18.setSeed(var40);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var44 = org.apache.commons.math3.util.MathArrays.distance(var16, var40);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.390989341895445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.016055362969999914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.7834433158008349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     int var7 = var0.nextInt(0, 100);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.8935057127361157d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 73);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     long var13 = var9.nextPoisson(0.9304525547601544d);
//     double[] var17 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
//     org.apache.commons.math3.util.Pair var28 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var17);
//     java.lang.Object var29 = var28.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.22698094673450123d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + 0L+ "'", var29.equals(0L));
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Object[] var7 = new java.lang.Object[] { true};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var7);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)25.05052606779598d, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeed();
//     java.lang.String var11 = var0.nextSecureHexString(83);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextCauchy(23.562469870696063d, (-0.8782782965603144d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-7.013837947146912E9d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.565389990510013E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.809005481522551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "52999867e44b1f2e063c077cfc873f6082d6d68c7cf99ad327136948297212bbd100fc375e5496e77c4"+ "'", var11.equals("52999867e44b1f2e063c077cfc873f6082d6d68c7cf99ad327136948297212bbd100fc375e5496e77c4"));
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var13 = var0.nextExponential(103.56915419683993d);
//     double var16 = var0.nextGamma(0.31568577999507896d, 0.5960140519829674d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var18 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9908813467262934d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3160040880474939d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8903987953744075d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 275.0961150940187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.5672667819799382d);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 40, 3);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Object[] var7 = new java.lang.Object[] { true};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-0.9438041885292305d), var7);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    double var9 = var2.nextGaussian(4.218937231588664d, 0.9692669377133449d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var2.nextBeta(0.0d, 0.19193457678938466d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.641195788033711d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var8, false);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var16 = var15.getStrict();
    java.lang.String var17 = var15.toString();
    boolean var18 = var15.getStrict();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var23 = var22.getStrict();
    var15.addSuppressed((java.lang.Throwable)var22);
    var11.addSuppressed((java.lang.Throwable)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var17.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var2 = null;
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    int[] var7 = new int[] { 100, 10, (-1)};
    var3.setSeed(var7);
    int[] var9 = new int[] { };
    var3.setSeed(var9);
    int[] var11 = null;
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var11);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 66);
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 0);
    var1.setSeed(var16);
    int[] var18 = null;
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var18);
    int[] var23 = new int[] { 100, 10, (-1)};
    var19.setSeed(var23);
    int[] var25 = new int[] { };
    var19.setSeed(var25);
    int[] var27 = null;
    int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var27);
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 66);
    int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var30);
    int[] var35 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var37 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var35);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    java.lang.Object var7 = var6.getValue();
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var9 = var8.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextExponential((-9896.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.915455861070358d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.06137654400255913d);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    int[] var9 = null;
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
    int[] var16 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var16);
    int[] var19 = null;
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    int[] var24 = new int[] { 100, 10, (-1)};
    var20.setSeed(var24);
    int[] var26 = new int[] { };
    var20.setSeed(var26);
    int[] var28 = null;
    int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var28);
    int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 66);
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var26);
    var18.setSeed(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var34 = org.apache.commons.math3.util.MathArrays.distance(var12, var26);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)6.251783231069299d, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    boolean var7 = var4.getBoundIsAllowed();
    boolean var8 = var4.getBoundIsAllowed();
    java.lang.Number var9 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 6.251783231069299d+ "'", var6.equals(6.251783231069299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 6.251783231069299d+ "'", var9.equals(6.251783231069299d));

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     var12.reSeed();
//     int var16 = var12.nextZipf(18, 0.10832690038004085d);
//     double var18 = var12.nextT(11.36369913641775d);
//     int[] var21 = var12.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var21, (-1));
//       fail("Expected exception of type java.lang.NegativeArraySizeException");
//     } catch (java.lang.NegativeArraySizeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1654543644549076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c233e2de73c1b159c96ab8"+ "'", var4.equals("c233e2de73c1b159c96ab8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.897697362942826E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.045437168217485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 18);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var49 = var47.inverseCumulativeProbability((-0.9286380078653282d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextWeibull(6.785854381629338d, 4736077.9249220705d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextInt(85, 2);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.7665591192007168d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4198352.2198628895d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4955414.248644063d);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    var1.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var5.nextSecureInt(74, 40);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("04a56f499539c9cbbc32e9", "deb772f721dfb96b0426e0e140dc9fc7f121740c5c9d574328ead75f71cb9326deedae66b8e84c39dc79ae2");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.02412325282344708d);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotANumberException var2 = new org.apache.commons.math3.exception.NotANumberException();
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var10 = var1.nextBoolean();
    var1.setSeed((-3200518016629555151L));
    int var13 = var1.nextInt();
    var1.clear();
    int[] var15 = null;
    var1.setSeed(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 42904144);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
//     double[][] var14 = new double[][] { var12};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var14);
//     double[] var16 = null;
//     double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var16, var24);
//     double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
//     double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var31);
//     double var38 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var37);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var37, (-0.2469924126740568d));
//     double[] var41 = null;
//     double var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var40, var41);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextSecureHexString(52);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var2.nextBeta(1.1381989852119745d, (-0.7110563084721201d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "8eeb61f56472542df9c6dd339e18a9b1358235d85eb651c071c6"+ "'", var4.equals("8eeb61f56472542df9c6dd339e18a9b1358235d85eb651c071c6"));
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var9);
//     int[] var12 = new int[] { };
//     int[] var13 = null;
//     int var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var13);
//     int[] var15 = new int[] { };
//     int[] var16 = null;
//     int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var16);
//     int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = org.apache.commons.math3.util.MathArrays.distance(var9, var12);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9142.349728099904d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    var2.reSeed(39L);
    int var14 = var2.nextInt(81, 2142147742);
    var2.reSeed();
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 301405723);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)6.251783231069299d, false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    boolean var7 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 6.251783231069299d+ "'", var5.equals(6.251783231069299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 6.251783231069299d+ "'", var6.equals(6.251783231069299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var6, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(-0.08824970291025913d), var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)39L, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-9896.0d), var8);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Number var3 = null;
//     java.lang.Comparable[] var5 = new java.lang.Comparable[] { (short)1};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, false);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var9, false);
//     org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Object[])var5);
//     java.lang.Number var13 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var20 = var19.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var21 = var19.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var13, (java.lang.Number)0.8055186938534216d, 60, var21, true);
//     boolean var25 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var21, true);
//     org.apache.commons.math3.exception.NullArgumentException var26 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.NotFiniteNumberException var27 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1.487086298741032E-9d, (java.lang.Object[])var5);
//     java.lang.Throwable var28 = null;
//     var27.addSuppressed(var28);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    int var4 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    double var8 = var2.nextGaussian(1.3621815434775926d, 0.9692669377133449d);
    int var11 = var2.nextInt(0, 5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextSecureInt(92, (-848192168));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1054197636303182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.30767857782779273d, 0.0d, 7.3680139234192845d, 0.4841123961597962d, 0.5650594787118064d, 8.110362096038457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.149783853556736d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12L);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    boolean var5 = var3.getStrict();
    java.lang.Number var6 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var5 = var1.nextFloat();
//     double var6 = var1.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var8);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-33.09969221746897d), (java.lang.Number)5245371591720513309L, 61);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     java.lang.Object var18 = var17.getKey();
//     java.lang.Object var19 = var17.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.35157687396973936d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(byte)0);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)"));

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextWeibull(0.13950886311666869d, (-0.8940079763882589d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.354941820327258d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2dac2de5729b681b194b8ca73ded71851e6338f194b3f8a"+ "'", var10.equals("2dac2de5729b681b194b8ca73ded71851e6338f194b3f8a"));
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var12 = var9.nextUniform((-1.2829807006931007d), 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var9.nextGamma(0.0d, (-0.5015644110639155d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.2247256460433116d));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextPoisson((-0.05475404077564316d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.433539191909245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "fc5184a79083d759ee666a21d957a2865634463b54f9dc0"+ "'", var10.equals("fc5184a79083d759ee666a21d957a2865634463b54f9dc0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "189fbcc68be0243cebd2bc8646599a3"+ "'", var12.equals("189fbcc68be0243cebd2bc8646599a3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "6f2ef3a7a70dbf5073c5a8be0f3f247c7e18af593345f403ba3a122775cbc"+ "'", var14.equals("6f2ef3a7a70dbf5073c5a8be0f3f247c7e18af593345f403ba3a122775cbc"));
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.3557079741617218d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var6 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    long[][] var8 = new long[][] { var6};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     var2.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var2.nextInversionDeviate(var9);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 88);
    double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var23, var32);
    double[] var35 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double[][] var37 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var43 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
    double var53 = org.apache.commons.math3.util.MathArrays.distance1(var43, var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var52, 0.0d);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var12);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     long var8 = var0.nextSecureLong(5507950371326924800L, 8026008374386375277L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("31468e72d42753c63314152d86d49f92548619a1228db5906658286598e8433e4d2d49c32aae8bbd91b25e52", "6e");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1048.6120775738234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.86181320307849E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7368184267467527168L);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double var8 = var7.nextGaussian();
//     byte[] var10 = new byte[] { (byte)10};
//     var7.nextBytes(var10);
//     org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var7);
//     int var14 = var7.nextInt(18);
//     float var15 = var7.nextFloat();
//     int var17 = var7.nextInt(95);
//     int var19 = var7.nextInt(22);
//     double[] var21 = new double[] { 0.0d};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
//     boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var21, var22, false);
//     double[] var26 = new double[] { 10.0d};
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double[] var39 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var43 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var43);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var34, var43);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var43, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var48 = null;
//     java.lang.Object[] var50 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var51 = new org.apache.commons.math3.exception.MathInternalError(var48, var50);
//     org.apache.commons.math3.util.Pair var52 = new org.apache.commons.math3.util.Pair((java.lang.Object)var47, (java.lang.Object)var48);
//     double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var47);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26);
//     double[] var56 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, 0.3127635608371082d);
//     double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, 0.5769815473378194d);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, 79558.81471209228d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var61 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var7, var21, var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var62 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var61);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.08721086521580827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0029157192225139E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.09873843401243952d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.33160162f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 87.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.05475404077564316d), 1.2863809000314061E-9d, 0.8421355648684861d, (-0.5883540186360512d), 8.110362096038457d, (-17.52647517823177d), 87.05882352941177d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-142.64153380658698d));

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextGamma((-1.6280715749761139d), (-0.5903111221322579d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextCauchy(0.0d, (-1.5189910320170308d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.995326757187314d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "5298a8a865b82979c59c6fcb4984f6a06af3b8e9c881327"+ "'", var10.equals("5298a8a865b82979c59c6fcb4984f6a06af3b8e9c881327"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "64a9f7ecbe07c0408c8daadb79d4f89"+ "'", var12.equals("64a9f7ecbe07c0408c8daadb79d4f89"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "c8f35410707530433926bd5e08b279fe14568d1d12bf91d5818172464307c"+ "'", var14.equals("c8f35410707530433926bd5e08b279fe14568d1d12bf91d5818172464307c"));
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var4.nextSample(var5, 69);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     var0.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var9 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.61157954260703d);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)16);
    java.lang.Number var3 = var2.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 16+ "'", var3.equals(16));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var52 = var47.getSupportUpperBound();
    double var54 = var47.density((-19533.05988397774d));
    double var56 = var47.probability(1.6200204638860117E-8d);
    double var57 = var47.getNumericalMean();
    boolean var58 = var47.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.016870356106681826d, (java.lang.Number)(-0.08824970291025913d), false);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var14 = var2.nextCauchy(0.8364867927003998d, 2.755734400837643d);
//     double var17 = var2.nextBeta(0.021333908748968344d, 5842551.508144901d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var2.nextBeta((-5699.4358864984715d), 1.039714152746848d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.7420687452786701d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-4.529754053872564d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.3537512045105007E-9d);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.1259987554121422d, 1774884.4601956457d, (-0.5101467848093691d), 0.8029923457054005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1998517.2835366856d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var5, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var3, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100.0d, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.05475404077564316d), var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     double var13 = var0.nextExponential(0.1431715674774945d);
//     var0.reSeed();
//     int var17 = var0.nextPascal(30, 0.0d);
//     int var20 = var0.nextSecureInt(15, 40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9020353599735187d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "eedd9e8a6182cd7e2a02249f7a0db5174586c9dc1efedfd5a3bcc103aaa831a0005b963670e7df3498405fc"+ "'", var8.equals("eedd9e8a6182cd7e2a02249f7a0db5174586c9dc1efedfd5a3bcc103aaa831a0005b963670e7df3498405fc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6820613662622005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.1565992163160207d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 21);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     var0.reSeedSecure();
//     var0.reSeed((-671931455001934447L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("9823745b64a94fdc8d1dbb05f77b05c2817a433f521397fba063c48cc17f9f2fa9622f00e0c8370c8cca7ee", "1d3f645d507ca87ab93a00aec5b29c0a62e216d8599b7603e66c102353e93ce79b56521f80f1a3682df9190817c26bc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.037641423787575956d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.17352490418175412d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.5656889737033913d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 14.62972092458065d);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     double var8 = var2.nextGaussian(0.2408323783466006d, 0.5410607118838238d);
//     double var10 = var2.nextT(54745.822302454384d);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var2.nextInversionDeviate(var11);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    double var7 = var2.nextExponential(25.05052606779598d);
    double var9 = var2.nextT(0.2384880170596717d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextHypergeometric(40, 78, 42904144);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 7.084194643041131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 459.9918162621926d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed(100L);
    double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
    var2.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var2.nextF(0.9856631769662858d, (-5.144340331950409E15d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-334.73040418701044d));

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(-0.6323492715198475d), var5);
    var2.addSuppressed((java.lang.Throwable)var6);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    java.lang.String var5 = var3.toString();
    boolean var6 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var3.getDirection();
    java.lang.String var8 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var8.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 1);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 18, 0);
    int var4 = var3.getDimension();
    int var5 = var3.getDimension();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextUniform(1.0188444560689377E-9d, (-370.93054277619296d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextBeta(0.0d, (-1.2829807006931007d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9143165959602588d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b768ebdf8815752147616344cfc7f3c35c1d67886f13b484fbd43ba1279c2a3e00beb36ac563fc483337264"+ "'", var8.equals("b768ebdf8815752147616344cfc7f3c35c1d67886f13b484fbd43ba1279c2a3e00beb36ac563fc483337264"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-6.326452979864264d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "cc3bfc42ff542bba8d08a94c8a8ff036a"+ "'", var16.equals("cc3bfc42ff542bba8d08a94c8a8ff036a"));
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.5903111221322579d), (java.lang.Number)0.0013537737958193104d, (java.lang.Number)60);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7470195516521267d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 61, 73);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 73);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }


    float[] var2 = new float[] { 0.0f, (-1.0f)};
    float[] var5 = new float[] { 0.0f, 100.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var5);
    float[] var7 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var5, var7);
    float[] var10 = new float[] { 10.0f};
    float[] var13 = new float[] { 0.0f, (-1.0f)};
    float[] var16 = new float[] { 0.0f, 100.0f};
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var13, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    float[] var21 = new float[] { (-1.0f), 1.0f};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var21);
    float[] var23 = new float[] { };
    float[] var26 = new float[] { 0.0f, (-1.0f)};
    float[] var29 = new float[] { 0.0f, 100.0f};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var23, var26);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var10, var26);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var7, var10);
    float[] var34 = new float[] { };
    float[] var37 = new float[] { 0.0f, (-1.0f)};
    float[] var40 = new float[] { 0.0f, 100.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var10, var34);
    float[] var44 = null;
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var10, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var1.nextPermutation(68, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.2278683892121145d);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     var12.reSeed();
//     int var16 = var12.nextZipf(18, 0.10832690038004085d);
//     double var18 = var12.nextT(11.36369913641775d);
//     int[] var21 = var12.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
//     int[] var24 = null;
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
//     int[] var29 = new int[] { 100, 10, (-1)};
//     var25.setSeed(var29);
//     int[] var31 = new int[] { };
//     var25.setSeed(var31);
//     org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(var31);
//     int[] var34 = null;
//     int var35 = org.apache.commons.math3.util.MathArrays.distance1(var31, var34);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var31);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-3.0787771808120192d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "0f0f12d2b3f2c4dcba7b1f"+ "'", var4.equals("0f0f12d2b3f2c4dcba7b1f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.6213410134813131E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1.2689628033789258d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var9.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     int var20 = var0.nextHypergeometric(73, 18, 12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextSecureInt(82, 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6880686895462d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "9ef7e642060ee8a0ed6a738a0f67aa0ed07068552de629ae0f03043ad1fd80c138abe8c08fda1a19841ea6b"+ "'", var8.equals("9ef7e642060ee8a0ed6a738a0f67aa0ed07068552de629ae0f03043ad1fd80c138abe8c08fda1a19841ea6b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.31431680025980685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "858b696c311f1dc58410da70e88687c05"+ "'", var16.equals("858b696c311f1dc58410da70e88687c05"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.density(0.0d);
    double[] var55 = var47.sample(95);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var55);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    long[] var8 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    long[][] var10 = new long[][] { var8};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)3.4785048692046914d, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var10);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     boolean var10 = var1.nextBoolean();
//     boolean var11 = var1.nextBoolean();
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
//     double[] var31 = null;
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var28, var31);
//     double[] var36 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
//     double var46 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
//     boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var28, var36);
//     double[] var48 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var49 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var36, var48);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.7976263262879755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "ff78084eadf344969dd73f"+ "'", var4.equals("ff78084eadf344969dd73f"));
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.setSeed(17);
//     int var5 = var1.nextInt(53);
//     long var6 = var1.nextLong();
//     int var7 = var1.nextInt();
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var8);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.4045570878980136d, false);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 87);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    java.lang.Comparable[] var16 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var17, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var16);
    java.lang.Comparable[] var22 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    boolean var25 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var22, var23, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var22, var26, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var22, var29, false);
    double[] var35 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var44 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var45 = var44.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = var44.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var48 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var46, true);
    boolean var50 = org.apache.commons.math3.util.MathArrays.isMonotonic(var35, var46, true);
    boolean var52 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var22, var46, true);
    java.lang.Comparable[] var54 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var55 = null;
    boolean var57 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var54, var55, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = null;
    boolean var60 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var54, var58, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    boolean var63 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var54, var61, false);
    double[] var67 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var68 = org.apache.commons.math3.util.MathArrays.safeNorm(var67);
    double[] var69 = org.apache.commons.math3.util.MathArrays.copyOf(var67);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var76 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var77 = var76.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var78 = var76.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var80 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var78, true);
    boolean var82 = org.apache.commons.math3.util.MathArrays.isMonotonic(var67, var78, true);
    boolean var84 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var54, var78, true);
    boolean var86 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var22, var78, false);
    boolean var88 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var78, false);
    boolean var90 = org.apache.commons.math3.util.MathArrays.isMonotonic(var3, var78, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     double var8 = var0.nextExponential(0.11681967467915401d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextPoisson((-0.6035130712076411d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.5339066376896439E10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "51965603f2fe64eb50eac1"+ "'", var4.equals("51965603f2fe64eb50eac1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.08718683294489468d);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     long var19 = var9.nextPoisson(1.0676463229789268d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var9.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6275537089061256d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0L);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var2.nextCauchy((-30.443553573156947d), (-0.4628858931836466d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.18300114000102374d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.33126975303273d), (java.lang.Number)0.69278264f, true);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.clear();
//     double var3 = var1.nextDouble();
//     int[] var4 = null;
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
//     int[] var9 = new int[] { 100, 10, (-1)};
//     var5.setSeed(var9);
//     int[] var11 = new int[] { };
//     var5.setSeed(var11);
//     int[] var13 = null;
//     int var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var13);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 66);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 0);
//     var1.setSeed(var18);
//     int[] var20 = new int[] { };
//     int[] var21 = null;
//     int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var21);
//     int[] var23 = new int[] { };
//     int[] var24 = null;
//     int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var23, var24);
//     int var26 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var24);
//     org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var20);
//     var1.setSeed(var20);
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var31 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var30);
//     var31.reSeed();
//     int var35 = var31.nextZipf(18, 0.10832690038004085d);
//     double var37 = var31.nextT(11.36369913641775d);
//     int[] var40 = var31.nextPermutation(33, 31);
//     int[] var41 = null;
//     org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var41);
//     int[] var46 = new int[] { 100, 10, (-1)};
//     var42.setSeed(var46);
//     int[] var48 = new int[] { };
//     var42.setSeed(var48);
//     int[] var50 = null;
//     int var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var48, var50);
//     int[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 66);
//     int[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var53);
//     int[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 44);
//     int var57 = org.apache.commons.math3.util.MathArrays.distance1(var40, var53);
//     org.apache.commons.math3.random.Well19937c var58 = new org.apache.commons.math3.random.Well19937c(var53);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance(var20, var53);
//     org.apache.commons.math3.random.Well19937c var60 = new org.apache.commons.math3.random.Well19937c(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.6862627241836179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1.9364609538571054d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 483);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     double[] var6 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
//     double[] var8 = null;
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var8, var16);
//     double var19 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
//     double[] var23 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var27 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var31 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var32 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var27, var31);
//     double var33 = org.apache.commons.math3.util.MathArrays.distance1(var23, var32);
//     double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 88);
//     double var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var32);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var44 = var43.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var45 = var43.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var45, true);
//     boolean var49 = org.apache.commons.math3.util.MathArrays.isMonotonic(var16, var45, false);
//     double[] var53 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var57 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var61 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var57, var61);
//     double var63 = org.apache.commons.math3.util.MathArrays.distance1(var53, var62);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var62, 88);
//     double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
//     double[] var78 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var82 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var83 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var78, var82);
//     double[] var84 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var73, var82);
//     double[] var85 = null;
//     boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var82, var85);
//     double[][] var87 = new double[][] { var82};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var62, var87);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var45, var87);
//     org.apache.commons.math3.exception.NullArgumentException var90 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var87);
//     org.apache.commons.math3.exception.NullArgumentException var91 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var87);
//     org.apache.commons.math3.exception.MathArithmeticException var92 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var87);
//     org.apache.commons.math3.exception.MathInternalError var93 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var92);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     double var12 = var0.nextUniform(0.3694532899986669d, 3.5918607522488695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5222764000296207d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3b25c4e16182423bff7c1331a787451866ce4bdc92fc93ac6e74b56c67b3f8ce6193f053b410f8987e5bde6"+ "'", var8.equals("3b25c4e16182423bff7c1331a787451866ce4bdc92fc93ac6e74b56c67b3f8ce6193f053b410f8987e5bde6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.647057137704281d);
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     int var12 = var0.nextBinomial(33, 0.0918198137196493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.579922211411195d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b5c6f760aa7a1e543c7920a5b479e70de936de005a660467d10784a4d8efcf640eac6046422ccc41e9c21f7"+ "'", var8.equals("b5c6f760aa7a1e543c7920a5b479e70de936de005a660467d10784a4d8efcf640eac6046422ccc41e9c21f7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var38 = null;
    double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var38, var46);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var53);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var31, var53);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double[][] var62 = new double[][] { var31};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var62);
    double[] var65 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, (-0.9451161353496818d));
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var13 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var13);
    int var16 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    int[] var17 = null;
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
    int[] var22 = new int[] { 100, 10, (-1)};
    var18.setSeed(var22);
    int[] var24 = new int[] { };
    var18.setSeed(var24);
    int[] var26 = null;
    int var27 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var26);
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 66);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var31 = org.apache.commons.math3.util.MathArrays.distance1(var13, var24);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextCauchy(1.4387505701387593d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 26.92927070472479d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.1794976536079724E-7d);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var9 = var6.nextLong(1L, 5804136433509186560L);
//     int var12 = var6.nextZipf(82, 1.182480876835637d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var6.nextPascal(0, 10.85683902370118d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.278515304062642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5188557757080944640L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 77);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.setSecureAlgorithm("", "3f9f5e201d1469e5ec21121dd7c7a05a3543bc17f1308d8f6dbe61dc8611f443c47be59d25f90ef04e252a5");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2585783563674076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    boolean var6 = var2.equals((java.lang.Object)(short)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var4, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var2, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100.0d, var6);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var0.nextPermutation(499, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.12782217554637887d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5792794.974664037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.7702918381465956E-9d);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var3 = var1.nextLong();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-5787431229102719808L));

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }
// 
// 
//     int[] var3 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     int[] var11 = new int[] { 100, 10, (-1)};
//     var7.setSeed(var11);
//     int[] var13 = new int[] { };
//     var7.setSeed(var13);
//     org.apache.commons.math3.random.RandomDataGenerator var15 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var7);
//     byte[] var18 = new byte[] { (byte)100, (byte)(-1)};
//     var7.nextBytes(var18);
//     var5.nextBytes(var18);
//     java.util.List var21 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var22 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var5, var21);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var11 = var0.nextUniform((-0.4148741153049867d), (-0.19811647941323907d), false);
//     double var13 = var0.nextT(3.4785048692046914d);
//     java.lang.String var15 = var0.nextHexString(54);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextInt(33, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 19.227526645304852d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.1983801091076234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.23107535796700818d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.24825426733429845d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "de5c54ac7d7ad44ea88e3859e963090059cbe8c859ed4e2aaaf9c1"+ "'", var15.equals("de5c54ac7d7ad44ea88e3859e963090059cbe8c859ed4e2aaaf9c1"));
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.7465868124512771d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)(-1.8884359076523125d), (java.lang.Number)(-0.3679940107460315d));

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var9 = var0.nextExponential(0.41369546662642837d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(9705.88235159202d, 1.9364609538571054d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.5197876938539938d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5912451687021338d);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var1.nextF((-0.07526435577864454d), (-173.06341310308545d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.2546967403862834d);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     double var14 = var0.nextChiSquare(0.002060832934925295d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(6.785854381629338d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.0361162590947375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2677554523856398d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "b5d4556ef77c5aed8fa45b8960f1638224a744f34766b5c0af72d459308938"+ "'", var12.equals("b5d4556ef77c5aed8fa45b8960f1638224a744f34766b5c0af72d459308938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.5466604375223327E-9d);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    double var11 = var2.nextT(23.562469870696063d);
    double var14 = var2.nextGamma(12.0d, 6189129.90146287d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.08515379833665031d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 7.829777967556679E7d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    int var5 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1347491339));

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextZipf(52, 7.4087361194955745d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var2.nextSample(var10, 53);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure(1L);
//     double var16 = var2.nextBeta(1.4392153051361142E-9d, 54746.28386276295d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("d9b2cd5db08bb31b2957a2c8206b4ab8e69a235ae28e1077f946e7b1337b9", "15fe817537eff44e312ded7c558e961");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.6676294852103613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.7712786924064507E-9d);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double[] var50 = var47.sample(318);
//     double var51 = var47.sample();
//     double var53 = var47.density((-14.359298331536461d));
//     double var56 = var47.cumulativeProbability(1.1134826426846463E-9d, 2.264115422511676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0.0d);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var52 = var47.getSupportUpperBound();
    double var54 = var47.density((-19533.05988397774d));
    double var57 = var47.cumulativeProbability((-0.918253960875775d), 0.0d);
    double var58 = var47.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1774884.4601956457d);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     var0.reSeed((-56139359032789495L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextSecureInt(0, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8143253963731549d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "02d50858b6b8feb4bc136f7e94a9d3188efb2f201b8a09e1cdc4ecd038489191f34edd8853de05855e80ccc"+ "'", var8.equals("02d50858b6b8feb4bc136f7e94a9d3188efb2f201b8a09e1cdc4ecd038489191f34edd8853de05855e80ccc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-5.307323015425399d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "bbbce839cf2c5c8e0f6e3b06991a42d5d"+ "'", var16.equals("bbbce839cf2c5c8e0f6e3b06991a42d5d"));
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)6.251783231069299d, false);
//     boolean var5 = var4.getBoundIsAllowed();
//     java.lang.Number var6 = var4.getMax();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, (java.lang.Object[])var14);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.0f, (java.lang.Object)10.099504938362077d);
    java.lang.Object var3 = var2.getValue();
    java.lang.Object var4 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.099504938362077d+ "'", var3.equals(10.099504938362077d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     long var8 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var9.nextPermutation(0, 34);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.2239783944062248d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-671931455001934447L));
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double[] var50 = var47.sample(318);
    double[] var52 = var47.sample(69);
    var47.reseedRandomGenerator((-1L));
    double var57 = var47.cumulativeProbability((-1.0012833206155702d), 0.12417449842427546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var14 = var0.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(0.0d, (-0.6323492715198475d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2928.1219947295544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.13396281878924743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.418719813962021d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.007489979004961769d);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     long var12 = var2.nextSecureLong(14L, 24L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("4baecf8ac5b27e384280db", "d272e1c188ef7c99541ca1");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "e41c00ac2e20f4aa4a62293288993"+ "'", var9.equals("e41c00ac2e20f4aa4a62293288993"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 16L);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)(short)1, (java.lang.Number)(-0.32577132027868605d));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    java.lang.Throwable[] var7 = var4.getSuppressed();
    java.lang.Number var8 = var4.getHi();
    java.lang.Number var9 = var4.getHi();
    java.lang.Number var10 = var4.getLo();
    java.lang.Number var11 = var4.getLo();
    java.lang.Number var12 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.32577132027868605d)+ "'", var5.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.32577132027868605d)+ "'", var6.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-0.32577132027868605d)+ "'", var8.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-0.32577132027868605d)+ "'", var9.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)1+ "'", var10.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (short)1+ "'", var11.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)1+ "'", var12.equals((short)1));

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextChiSquare(1.0840550494843473E-9d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextInt(85, 84);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.2755893646883842E-9d);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    long[] var9 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    long[][] var11 = new long[][] { var9};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)513, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)483, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var8, false);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, 21.869847397459292d);
    double[] var36 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var40 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var36, var40);
    double[] var45 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var46 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    double[][] var47 = new double[][] { var45};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var36, var47);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var36);
    double[] var53 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var57 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var61 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var57, var61);
    double var63 = org.apache.commons.math3.util.MathArrays.distance1(var53, var62);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var62, 88);
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var36, var62);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var66);
    double[] var71 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var72 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var71);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var80 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var81 = var80.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = var80.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var84 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var82, true);
    boolean var86 = org.apache.commons.math3.util.MathArrays.isMonotonic(var71, var82, true);
    boolean var89 = org.apache.commons.math3.util.MathArrays.checkOrder(var66, var82, false, false);
    boolean var91 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var82, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == true);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextF(0.1565992163160207d, (-0.36834119618796374d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-98.19542420680015d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.6328682869880325E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.086092722061177d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextT(1.818331372129114d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var2.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.1440400422066794d));

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var8, false);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     double var16 = var0.nextExponential(0.6591014616866876d);
//     double var19 = var0.nextGamma(0.50527176291182d, 0.5951250420414592d);
//     int var22 = var0.nextSecureInt(9, 47);
//     long var25 = var0.nextLong((-671931455001934447L), 6758353113347147164L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.520164840297991d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.541046733434104d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.09687866174310211d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.680504855120242d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.42638113883362433d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.5616149515417377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2585270482073165824L);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 77, 90);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var12 = var9.nextPermutation(66, 20);
    long var14 = var9.nextPoisson(0.18726212538835552d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var9.nextGamma(1.2863809000314061E-9d, (-6.598279732603494d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0L);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    var1.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var8 = var5.nextPascal(49, 0.10832690038004085d);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var25);
    double[] var29 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var30 = null;
    java.lang.Object[] var32 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var33 = new org.apache.commons.math3.exception.MathInternalError(var30, var32);
    org.apache.commons.math3.util.Pair var34 = new org.apache.commons.math3.util.Pair((java.lang.Object)var29, (java.lang.Object)var30);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var42, var51);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var29, var51);
    boolean var57 = var56.isSupportConnected();
    double var59 = var56.density((-30.443553573156947d));
    double var60 = var56.getSupportUpperBound();
    double var62 = var56.cumulativeProbability(0.03603256163404128d);
    double var63 = var5.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var56);
    double var64 = var56.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 318);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 9705.88235142365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 97.05882352941177d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1123394720));
    var1.setSeed(75);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var9);
//     int[] var12 = null;
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     int[] var17 = new int[] { 100, 10, (-1)};
//     var13.setSeed(var17);
//     int[] var19 = new int[] { };
//     var13.setSeed(var19);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var19);
//     int[] var25 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var25);
//     org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var25);
//     int var28 = org.apache.commons.math3.util.MathArrays.distance1(var19, var25);
//     int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var25);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.478836465660621d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0345028299124155E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.1125016028479662d), (java.lang.Number)6.790436471693312E7d, false);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
    java.lang.String var3 = var2.toString();
    int var4 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 0 != 1"+ "'", var3.equals("org.apache.commons.math3.exception.DimensionMismatchException: 0 != 1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     java.lang.Object var18 = null;
//     boolean var19 = var17.equals(var18);
//     java.lang.Object var20 = var17.getFirst();
//     java.lang.Object var21 = var17.getFirst();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.739343345540624d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = new int[] { };
//     int[] var2 = null;
//     int var3 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var2);
//     int[] var4 = new int[] { };
//     int[] var5 = null;
//     int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var5);
//     int var7 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var5);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var1);
//     double var9 = org.apache.commons.math3.util.MathArrays.distance(var0, var1);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2.125285173880562d, var2, false);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)79558.81471209228d, var2, false);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     int[] var17 = null;
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
//     int[] var22 = new int[] { 100, 10, (-1)};
//     var18.setSeed(var22);
//     int[] var24 = new int[] { };
//     var18.setSeed(var24);
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var24);
//     int[] var30 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(var30);
//     org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var30);
//     int var33 = org.apache.commons.math3.util.MathArrays.distance1(var24, var30);
//     int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var35 = org.apache.commons.math3.util.MathArrays.distance1(var16, var30);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.364469239574887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.18214678880737975d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextInt(61, 34);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.860779939440733d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5544840608202627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "4de26189ef6a88a2358491bd72aed1fafe82bcbf9c27df5600567338e50e20"+ "'", var12.equals("4de26189ef6a88a2358491bd72aed1fafe82bcbf9c27df5600567338e50e20"));
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)25);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, (java.lang.Number)(-0.6044871530760823d));
    var1.addSuppressed((java.lang.Throwable)var4);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextWeibull(6.785854381629338d, 4736077.9249220705d);
//     double var20 = var0.nextChiSquare(0.4188489407275768d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var25 = var0.nextLong(5245371591720513309L, (-4605170805750505266L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.7124622381379737d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4099870.0369321685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4955414.248644063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.11235981905790325d);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
    double[] var31 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var28, var31);
    double[] var36 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var28, var36);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var8, var28);
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var65);
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var28, var56);
    double[] var70 = org.apache.commons.math3.util.MathArrays.normalizeArray(var28, 0.1052381769160073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var30, var34);
    double[] var41 = null;
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var41, var49);
    double var52 = org.apache.commons.math3.util.MathArrays.safeNorm(var49);
    double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var56);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var34, var56);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var56);
    double[] var65 = null;
    double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var65, var73);
    double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var80 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var84 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var85 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var80, var84);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var73, var80);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var80);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var87, 54);
    double[] var90 = null;
    boolean var91 = org.apache.commons.math3.util.MathArrays.equals(var89, var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt(13, 49);
//     org.apache.commons.math3.distribution.IntegerDistribution var6 = null;
//     int var7 = var0.nextInversionDeviate(var6);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var2.nextChiSquare((-0.00116063972331892d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "e2170b7125641f68f011cd43006af"+ "'", var9.equals("e2170b7125641f68f011cd43006af"));
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 19);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7247668141114612d);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 96, (-1));
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     long var13 = var9.nextPoisson(0.9304525547601544d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var9.nextBeta(0.0d, 0.6827027911507197d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8166533574556268d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.3562534814201879d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(0.19193457678938466d, 67399.51573302031d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var7.nextPermutation(20, 47);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.019759701317168046d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 89439.3517567197d);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    float[] var2 = new float[] { 0.0f, (-1.0f)};
    float[] var5 = new float[] { 0.0f, 100.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var5);
    float[] var7 = null;
    float[] var9 = new float[] { 10.0f};
    float[] var12 = new float[] { 0.0f, (-1.0f)};
    float[] var15 = new float[] { 0.0f, 100.0f};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var9, var15);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var7, var9);
    float[] var21 = new float[] { 0.0f, (-1.0f)};
    float[] var24 = new float[] { 0.0f, 100.0f};
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var24);
    float[] var26 = null;
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var24, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var26);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var5, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.05077457481457559d), 1.2076392260501028d, 0.0d, 3.577208239390972d, 357.60346728709703d, 6.231264947207621d, 20.833429203024522d, 6.813639406926573E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2228.2606475329103d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }
// 
// 
//     int[] var3 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var3);
//     float var6 = var5.nextFloat();
//     java.lang.Object var7 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var12 = var11.getMin();
//     org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair(var7, (java.lang.Object)var11);
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var19 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var14, var19);
//     boolean var21 = var13.equals((java.lang.Object)var19);
//     int[] var22 = null;
//     org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
//     double var24 = var23.nextGaussian();
//     byte[] var26 = new byte[] { (byte)10};
//     var23.nextBytes(var26);
//     org.apache.commons.math3.random.RandomDataGenerator var28 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var23);
//     byte[] var30 = new byte[] { (byte)1};
//     var23.nextBytes(var30);
//     boolean var32 = var13.equals((java.lang.Object)var30);
//     var5.nextBytes(var30);
//     var5.setSeed((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var36 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var39 = var36.nextWeibull((-14.653067499081518d), 25.05052606779598d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4987576f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + 1.0d+ "'", var12.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.5483426283593056d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     java.lang.String var8 = var2.nextHexString(95);
//     double var11 = var2.nextGaussian((-0.09070155974923377d), 0.4429300278176235d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextBeta((-1096.3767627294947d), 1.6445632382959425E-9d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5c543327d2789266353bef0ec92cb6e784eb88d6537b2399cc6936dbe42f09085b3b9f7de5326bd1e9353ff4cd02bc9"+ "'", var8.equals("5c543327d2789266353bef0ec92cb6e784eb88d6537b2399cc6936dbe42f09085b3b9f7de5326bd1e9353ff4cd02bc9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.2677135316887365d);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextWeibull(6.785854381629338d, 4736077.9249220705d);
//     double var20 = var0.nextChiSquare(0.4188489407275768d);
//     var0.reSeedSecure(0L);
//     java.util.Collection var23 = null;
//     java.lang.Object[] var25 = var0.nextSample(var23, (-1));
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 34);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    double var7 = var2.nextExponential(25.05052606779598d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextSecureInt(145, 78);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 7.084194643041131d);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     var0.reSeedSecure(2L);
//     long var13 = var0.nextLong(79L, 6758353113347147164L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14.499947257311428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.2504496629349004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4582272873445202432L);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c5c7894b709468e2f0fd355b25b699546915529a3207059c47e9162bc2296111ed95dd3c02bc37089c5d9e7", "a4a6f352066b7548b4d7c47cf5559d666b60159c87b957dbc5689f93f1d156392a989d54aaac45f08cc029d");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.835790054319888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.4946093865930997d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "02bb09a5c5ca9ff47bd1f558d559eaf75ada539951baf3ce9ece4c5b789d32"+ "'", var12.equals("02bb09a5c5ca9ff47bd1f558d559eaf75ada539951baf3ce9ece4c5b789d32"));
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextWeibull(2.5601423343889373d, 0.6283537634336418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.12755738702589525d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7650759.52402304d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.16602369564258115d);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getKey();
    java.lang.Object var6 = var2.getValue();
    java.lang.Object var7 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)100+ "'", var5.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0d+ "'", var6.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)100+ "'", var7.equals((short)100));

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
    double[] var26 = null;
    double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var26, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
    double[] var50 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var54 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var50, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var45, var54);
    double[] var57 = null;
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var54, var57);
    double[] var62 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var66 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var70 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var62, var71);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var54, var62);
    double var74 = org.apache.commons.math3.util.MathArrays.distance1(var34, var54);
    double[] var78 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var82 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var78, var82);
    double[] var87 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var91 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var87, var91);
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var82, var91);
    double var94 = org.apache.commons.math3.util.MathArrays.distance(var54, var82);
    double[] var95 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var54);
    double var96 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 100.00999950005d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var7 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var9 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)73, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    long[] var11 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    long[][] var13 = new long[][] { var11};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var13);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var2, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)2228.2606475329103d, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.clear();

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 33, 80);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     var0.reSeed((-56139359032789495L));
//     java.lang.String var12 = var0.nextHexString(86);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextWeibull((-4.223479475728832d), 2.96011880749921d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4053.3512607075077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 41L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "1e4b704f36207af65b8989a5606c41911b053a8bf044b408de72621ed65b0dcc34ab829f8b4902be92bfa7"+ "'", var12.equals("1e4b704f36207af65b8989a5606c41911b053a8bf044b408de72621ed65b0dcc34ab829f8b4902be92bfa7"));
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.7454450602699914d, 10.491932419793976d, (-1.8884359076523125d), 0.7287380405385424d, (-0.08812772856076337d), 0.8919503851172442d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 6.366378550567545d);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     var1.reSeedSecure(4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.4926778407161656d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "f0052b7c368d0ec336f889a781e55d653cef8fe21ef8a79"+ "'", var10.equals("f0052b7c368d0ec336f889a781e55d653cef8fe21ef8a79"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "a722eab7e44e9b5de09748b34cbe9ea"+ "'", var12.equals("a722eab7e44e9b5de09748b34cbe9ea"));
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    double var8 = var2.nextGaussian(1.3621815434775926d, 0.9692669377133449d);
    int var11 = var2.nextInt(0, 5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var2.nextHypergeometric(26, 0, 59);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1054197636303182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }
// 
// 
//     double[] var0 = null;
//     java.lang.Number var4 = null;
//     java.lang.Comparable[] var6 = new java.lang.Comparable[] { (short)1};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
//     boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var7, false);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
//     boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var10, false);
//     org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Object[])var6);
//     java.lang.Number var14 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var21 = var20.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var22 = var20.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var14, (java.lang.Number)0.8055186938534216d, 60, var22, true);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var22, true);
//     java.lang.Number var27 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var33 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var34 = var33.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var35 = var33.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var27, (java.lang.Number)0.8055186938534216d, 60, var35, true);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var35, false);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var41 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.1440400422066794d), (java.lang.Number)(-4.967808516060075d), 70, var35, false);
//     boolean var44 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var35, false, true);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2863332373763964d, (java.lang.Number)(-0.02654597230134237d), true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.02654597230134237d)+ "'", var4.equals((-0.02654597230134237d)));

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    double var9 = var2.nextGaussian(4.218937231588664d, 0.9692669377133449d);
    var2.reSeedSecure(8026008374386375277L);
    var2.reSeed(4L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var2.nextUniform(0.7493393541476548d, (-0.04211151663022905d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.641195788033711d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    boolean var5 = var3.equals((java.lang.Object)(short)(-1));
    java.lang.Object var6 = var3.getKey();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var3);
    java.lang.Object var8 = var3.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.10659341427742133d));

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     int var11 = var1.nextInt(15, 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6224543031156315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 34);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.String var1 = var0.toString();
    java.lang.Throwable[] var2 = var0.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.MathIllegalStateException: illegal state"+ "'", var1.equals("org.apache.commons.math3.exception.MathIllegalStateException: illegal state"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    long[][] var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkRectangular(var0);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 4, 99);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 99);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var1, true);
//     java.lang.Number var4 = var3.getMin();
//     boolean var5 = var3.getBoundIsAllowed();
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double var8 = var7.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var11 = var9.nextT(0.1431715674774945d);
//     double var14 = var9.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var17 = var9.nextPermutation(83, 33);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     var7.setSeed(var18);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 0);
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var21);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
//     java.lang.Object var24 = null;
//     boolean var25 = var23.equals(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4265583850978061d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-45.59936984080702d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     double var7 = var0.nextExponential(0.4301403036978695d);
//     double var10 = var0.nextCauchy((-9.743086442592038E10d), 0.10684763416654564d);
//     double var13 = var0.nextWeibull(0.167626206119096d, 1.1608312127045663E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.586298775570087E7d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.5801859272774326E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.5987553781231536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-9.743086442772452E10d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.873194720677289E-12d);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     double var18 = var1.nextUniform(0.10431629821572952d, 0.17463647001913052d, false);
//     double var21 = var1.nextGamma(0.41369546662642837d, 199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.56713999217801d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "ca15a382ae704fab6e86a607d5c75f9cc9642ac604cb818"+ "'", var10.equals("ca15a382ae704fab6e86a607d5c75f9cc9642ac604cb818"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "e20060564d623cecb70402970c58a45"+ "'", var12.equals("e20060564d623cecb70402970c58a45"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "e3d1df82ecd167600a855e7af06fa35be21294c667a89f790a87cd203ded2"+ "'", var14.equals("e3d1df82ecd167600a855e7af06fa35be21294c667a89f790a87cd203ded2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.1579741219220147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 135.34632918764086d);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var10 = var1.nextBoolean();
    double var11 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.3328432771849152d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 57);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var8.nextExponential(0.6012895846489683d);
    var8.reSeedSecure(24L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.9354117217009348d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    java.lang.String var2 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"+ "'", var2.equals("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"));

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     double var13 = var0.nextUniform((-4261.583317386363d), 0.7089838642239309d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextCauchy((-0.918253960875775d), (-0.08824970291025913d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.15002579179083186d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "be32338b73d03bf1fbe7394411b04b345dacbd22ae3954a2af8f5d5afaa4e39d89feb96d93a7a10281d608e"+ "'", var8.equals("be32338b73d03bf1fbe7394411b04b345dacbd22ae3954a2af8f5d5afaa4e39d89feb96d93a7a10281d608e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2689.0476767199543d));
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(22, 18);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Number var4 = var2.getArgument();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(100);
    var6.clear();
    var6.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    var10.reSeedSecure(2563274223793255424L);
    org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var10.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 22+ "'", var4.equals(22));

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-7.995755104491544d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "0ee08472f40b07d5d4e469"+ "'", var4.equals("0ee08472f40b07d5d4e469"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0790379673570207E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextSecureLong(212521969303929120L, (-1092428417482140062L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.9666535979102253d);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var10 = var0.nextF(102.0d, 9900.0d);
//     double var12 = var0.nextT(223.0d);
//     long var15 = var0.nextLong(5L, 212521969303929120L);
//     int var18 = var0.nextBinomial(0, 0.1752504341123254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 33.84123869527165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.627090691749143d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0716282575829514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.1201592503399119d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 177811999939543264L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     int var8 = var0.nextZipf(70, 0.6245596043465632d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 55);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.33140457057801864d, (java.lang.Number)0.38306463f, false);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
    double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var23, var32);
    double[] var36 = org.apache.commons.math3.util.MathArrays.normalizeArray(var23, 21.869847397459292d);
    double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
    double[] var49 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var49);
    double[][] var51 = new double[][] { var49};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var40, var51);
    double var53 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    double[] var57 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double var67 = org.apache.commons.math3.util.MathArrays.distance1(var57, var66);
    double[] var69 = org.apache.commons.math3.util.MathArrays.copyOf(var66, 88);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var40, var66);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var70);
    double[] var75 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var75);
    double[] var77 = org.apache.commons.math3.util.MathArrays.copyOf(var75);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var84 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var85 = var84.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var86 = var84.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var88 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var86, true);
    boolean var90 = org.apache.commons.math3.util.MathArrays.isMonotonic(var75, var86, true);
    boolean var93 = org.apache.commons.math3.util.MathArrays.checkOrder(var70, var86, false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var12, var86, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 48);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var14 = var10.nextUniform(0.3777487957046537d, 79558.81471209228d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var10.nextPascal(18, 3.367537023715106d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1628835614948379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 17903.350283595042d);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     int var11 = var0.nextSecureInt(32, 57);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextLong(10L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.6460397048563606d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.710653908234744E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 49);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    java.lang.Object var26 = var25.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-671931455001934447L), 0L);
    double var7 = var2.nextChiSquare(0.1499743121005248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-210809944227644864L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.003197245082548439d);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextZipf(499, (-33988.90347597093d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-31.93281523779279d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.244291740390264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "4c082cb25e2b44a7c7f370761e9ee57ea1d8b868ffacc2466085a7249b8f2f"+ "'", var12.equals("4c082cb25e2b44a7c7f370761e9ee57ea1d8b868ffacc2466085a7249b8f2f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 58);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     int var20 = var0.nextHypergeometric(73, 18, 12);
//     double var23 = var0.nextCauchy(0.1565992163160207d, 0.5978698531423667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.48159756358892114d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ba225433a090e72b4e2621ada8044b745aee05e74d4acb84a4f5adb967d11c2cdb1c247c743b28939aacbe4"+ "'", var8.equals("ba225433a090e72b4e2621ada8044b745aee05e74d4acb84a4f5adb967d11c2cdb1c247c743b28939aacbe4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.8138862480316373d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "a9c0598549de66d63375d81543ce62740"+ "'", var16.equals("a9c0598549de66d63375d81543ce62740"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-1.0082709451782454d));
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     var0.reSeed((-1L));
//     double var10 = var0.nextUniform(1.0676463229789268d, 1.3621815434775926d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("d9b2cd5db08bb31b2957a2c8206b4ab8e69a235ae28e1077f946e7b1337b9", "dc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.670112125755275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1381989852119745d);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9635745263191828d, (java.lang.Number)0.11367407310899982d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.setSeed(17);
//     int var5 = var1.nextInt(53);
//     java.util.List var6 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var7 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var6);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextZipf(301405723, (-0.8940079763882589d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     int var14 = var0.nextInt(0, 14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextHypergeometric(23, 32, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7919223409112104d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5a9c803bcbc4db8d305bea9eb7fb837eaaa3c94becd94a2bd10b7136436db8d5f9d5dc5fb0c4b79dadb9cc3"+ "'", var8.equals("5a9c803bcbc4db8d305bea9eb7fb837eaaa3c94becd94a2bd10b7136436db8d5f9d5dc5fb0c4b79dadb9cc3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 19.58266998112745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(18);
//     int[] var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
//     int[] var7 = new int[] { 100, 10, (-1)};
//     var3.setSeed(var7);
//     int[] var9 = new int[] { };
//     var3.setSeed(var9);
//     org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     float var12 = var3.nextFloat();
//     int[] var13 = null;
//     org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
//     int[] var18 = new int[] { 100, 10, (-1)};
//     var14.setSeed(var18);
//     int[] var20 = new int[] { };
//     var14.setSeed(var20);
//     org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var14);
//     boolean var23 = var14.nextBoolean();
//     var14.setSeed((-3200518016629555151L));
//     int[] var26 = null;
//     org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var26);
//     int[] var31 = new int[] { 100, 10, (-1)};
//     var27.setSeed(var31);
//     int[] var33 = new int[] { };
//     var27.setSeed(var33);
//     org.apache.commons.math3.random.RandomDataGenerator var35 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var27);
//     byte[] var38 = new byte[] { (byte)100, (byte)(-1)};
//     var27.nextBytes(var38);
//     var14.nextBytes(var38);
//     var3.nextBytes(var38);
//     var1.nextBytes(var38);
//     double var43 = var1.nextGaussian();
//     java.util.List var44 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var45 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var44);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     var0.reSeed(12L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextUniform(25.05052606779598d, 23.255333405607846d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.54753506502416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.2331288264622064d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    double[] var1 = new double[] { 10.0d};
    double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
    double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var9, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    java.lang.Object[] var25 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var23, var25);
    org.apache.commons.math3.util.Pair var27 = new org.apache.commons.math3.util.Pair((java.lang.Object)var22, (java.lang.Object)var23);
    double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var31 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.3127635608371082d);
    double[] var32 = null;
    boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.setSeed(17);
    int var5 = var1.nextInt(53);
    var1.setSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 34);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     java.lang.String var3 = var1.nextHexString(44);
//     var1.reSeedSecure();
//     var1.reSeed(3657790713701999616L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7e6fb219607ed82ac2c7a88136cc88ba2c71005bafd6"+ "'", var3.equals("7e6fb219607ed82ac2c7a88136cc88ba2c71005bafd6"));
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeedSecure(100L);
//     java.lang.String var9 = var2.nextHexString(53);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var2.nextInversionDeviate(var10);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    double[] var0 = null;
    java.lang.Number var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var7, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Object[])var3);
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var18 = var17.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = var17.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var21 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var11, (java.lang.Number)0.8055186938534216d, 60, var19, true);
    boolean var23 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var19, true);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    double[] var37 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var41 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var37, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
    double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
    double var62 = org.apache.commons.math3.util.MathArrays.distance1(var52, var56);
    double[] var63 = null;
    double[] var67 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var71 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var67, var71);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var63, var71);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[] var78 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var82 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var78, var82);
    double[] var84 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var71, var78);
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var56, var78);
    double[] var86 = org.apache.commons.math3.util.MathArrays.copyOf(var56);
    double[][] var87 = new double[][] { var56};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var33, var87);
    org.apache.commons.math3.exception.MathIllegalStateException var89 = new org.apache.commons.math3.exception.MathIllegalStateException(var24, (java.lang.Object[])var87);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var19, var87);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var25, var34);
//     double[] var37 = null;
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
//     double[] var42 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
//     double var52 = org.apache.commons.math3.util.MathArrays.distance1(var42, var51);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var34, var42);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var34);
//     double[] var56 = new double[] { 10.0d};
//     double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
//     double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var73);
//     double[] var77 = org.apache.commons.math3.util.MathArrays.normalizeArray(var73, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var78 = null;
//     java.lang.Object[] var80 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var81 = new org.apache.commons.math3.exception.MathInternalError(var78, var80);
//     org.apache.commons.math3.util.Pair var82 = new org.apache.commons.math3.util.Pair((java.lang.Object)var77, (java.lang.Object)var78);
//     double var83 = org.apache.commons.math3.util.MathArrays.distanceInf(var56, var77);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var77);
//     java.lang.Number var86 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var88 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.5691554178840348d, var86, 62);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var89 = var88.getDirection();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.util.MathArrays.checkOrder(var8, var89, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
//     } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.20257756073596367d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 87.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.6052885422141174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.543193802056087E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     var0.reSeedSecure();
//     double var9 = var0.nextBeta(0.3777487957046537d, 0.7578669481310135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.1872465414747062d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.3869970032066744E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9259186455910856d);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)103.56915419683993d, (-1), var3, true);
    int var6 = var5.getIndex();
    boolean var7 = var5.getStrict();
    java.lang.Number var8 = var5.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    double var9 = var2.nextGaussian(4.218937231588664d, 0.9692669377133449d);
    var2.reSeedSecure(8026008374386375277L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var2.nextT((-0.56750319853339d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.641195788033711d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    long[] var8 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    long[][] var10 = new long[][] { var8};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var10);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)73, (java.lang.Object[])var10);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.setSeed(17);
    int var5 = var1.nextInt(53);
    long var6 = var1.nextLong();
    int var7 = var1.nextInt();
    double var8 = var1.nextDouble();
    double var9 = var1.nextGaussian();
    double var10 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 6149568864592168549L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1983603608));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.543107492877348d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2654294451828049d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.7383509432994655d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var2, (java.lang.Number)6.785854381629338d, 58);
    java.lang.Number var6 = var5.getPrevious();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-33988.90347597093d), (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 6.785854381629338d+ "'", var6.equals(6.785854381629338d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var8 = var1.nextInt(18);
//     float var9 = var1.nextFloat();
//     int var11 = var1.nextInt(95);
//     int var13 = var1.nextInt(22);
//     double[] var15 = new double[] { 0.0d};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
//     boolean var18 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var16, false);
//     double[] var20 = new double[] { 10.0d};
//     double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
//     double[] var33 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var37 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var33, var37);
//     double[] var39 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var28, var37);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var37, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var42 = null;
//     java.lang.Object[] var44 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var45 = new org.apache.commons.math3.exception.MathInternalError(var42, var44);
//     org.apache.commons.math3.util.Pair var46 = new org.apache.commons.math3.util.Pair((java.lang.Object)var41, (java.lang.Object)var42);
//     double var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var41);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var20);
//     double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 0.3127635608371082d);
//     double[] var52 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 0.5769815473378194d);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 79558.81471209228d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var55 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var15, var20);
//     double[] var59 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var63 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var59, var63);
//     double[] var68 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var72 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var68, var72);
//     double var74 = org.apache.commons.math3.util.MathArrays.distance1(var64, var68);
//     double[] var78 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var82 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var86 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var87 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var82, var86);
//     double var88 = org.apache.commons.math3.util.MathArrays.distance1(var78, var87);
//     double[] var90 = org.apache.commons.math3.util.MathArrays.normalizeArray(var87, 0.0d);
//     double[] var91 = org.apache.commons.math3.util.MathArrays.copyOf(var87);
//     double var92 = org.apache.commons.math3.util.MathArrays.distance1(var64, var87);
//     double[] var94 = org.apache.commons.math3.util.MathArrays.normalizeArray(var64, 2784.9275671086507d);
//     double[] var96 = org.apache.commons.math3.util.MathArrays.normalizeArray(var64, 0.11433830816137684d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var97 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var15, var64);
//       fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
//     } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3239343241369569d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.73459494f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 87.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 102.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(22, 18);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Number var4 = var2.getArgument();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(100);
    var6.clear();
    var6.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    var10.reSeedSecure(2563274223793255424L);
    org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var10.nextWeibull((-1887.9453533696599d), 223.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 22+ "'", var4.equals(22));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var12 = var9.nextPermutation(66, 20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var9.nextUniform(0.453750973967793d, (-0.8211092390774544d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextWeibull(0.5232223581285713d, 6.352641136275383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4908024973580418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7563568.026539223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12.76198980593372d);
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var11 = var0.nextUniform((-0.4148741153049867d), (-0.19811647941323907d), false);
//     double var13 = var0.nextT(3.4785048692046914d);
//     java.lang.String var15 = var0.nextHexString(54);
//     var0.reSeedSecure();
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var0.nextSample(var17, 62);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, true);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    boolean var51 = var47.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     double var15 = var0.nextChiSquare(2.95900240642029d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextSecureInt(55, 50);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.49249384586145917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5475820.631070212d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.4350876587997712E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.347106761271093d);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    var1.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var8 = var5.nextPascal(49, 0.10832690038004085d);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var25);
    double[] var29 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var30 = null;
    java.lang.Object[] var32 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var33 = new org.apache.commons.math3.exception.MathInternalError(var30, var32);
    org.apache.commons.math3.util.Pair var34 = new org.apache.commons.math3.util.Pair((java.lang.Object)var29, (java.lang.Object)var30);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var42, var51);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var29, var51);
    boolean var57 = var56.isSupportConnected();
    double var59 = var56.density((-30.443553573156947d));
    double var60 = var56.getSupportUpperBound();
    double var62 = var56.cumulativeProbability(0.03603256163404128d);
    double var63 = var5.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var56);
    double var64 = var56.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 318);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 9705.88235142365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 9705.882352941177d);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     java.lang.Object var18 = null;
//     boolean var19 = var17.equals(var18);
//     java.lang.Object var20 = var17.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.4423815046747017d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var10 = var1.nextBoolean();
    var1.setSeed((-3200518016629555151L));
    int[] var13 = null;
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    int[] var18 = new int[] { 100, 10, (-1)};
    var14.setSeed(var18);
    int[] var20 = new int[] { };
    var14.setSeed(var20);
    org.apache.commons.math3.random.RandomDataGenerator var22 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var14);
    byte[] var25 = new byte[] { (byte)100, (byte)(-1)};
    var14.nextBytes(var25);
    var1.nextBytes(var25);
    int var28 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-690853845));

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
    int var3 = var2.getDimension();
    int var4 = var2.getDimension();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Object[] var13 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, (java.lang.Number)1L, var13);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var9, var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, var8, var13);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var6, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var5, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
//     double var19 = org.apache.commons.math3.util.MathArrays.distance1(var9, var13);
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
//     double[] var39 = null;
//     double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
//     boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var39, var47);
//     double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
//     double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var47, var54);
//     boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var32, var54);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
//     double[][] var63 = new double[][] { var32};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var9, var63);
//     double[] var65 = null;
//     double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
//     boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var65, var73);
//     double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
//     double[] var80 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var84 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var88 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var89 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var84, var88);
//     double var90 = org.apache.commons.math3.util.MathArrays.distance1(var80, var89);
//     double[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var89, 88);
//     double var93 = org.apache.commons.math3.util.MathArrays.distanceInf(var73, var89);
//     double var94 = org.apache.commons.math3.util.MathArrays.distance1(var9, var89);
//     double[] var95 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var9);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
//     double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     org.apache.commons.math3.random.RandomDataGenerator var38 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var41 = var38.nextInt(10, 100);
//     double var44 = var38.nextUniform((-1.0d), 1.0d);
//     var38.reSeedSecure();
//     org.apache.commons.math3.util.Pair var46 = new org.apache.commons.math3.util.Pair((java.lang.Object)var37, (java.lang.Object)var38);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var37);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 54);
//     double[] var62 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var66 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var70 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var71 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var70);
//     double var72 = org.apache.commons.math3.util.MathArrays.distance1(var62, var71);
//     double var73 = org.apache.commons.math3.util.MathArrays.distance(var56, var62);
//     boolean var74 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.9255748744099641d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 149.7631463344704d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     double var13 = var0.nextExponential(0.1431715674774945d);
//     int var16 = var0.nextInt(41, 76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8919126322855746d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "909bbe8b4cb46403d3f868a3aa29bb6846b3454697035e92de90d37867b953816e92ec674394647a45740f5"+ "'", var8.equals("909bbe8b4cb46403d3f868a3aa29bb6846b3454697035e92de90d37867b953816e92ec674394647a45740f5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.823490725760317d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.04249342030462068d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 73);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.33140457057801864d, 7.636418016556065d, 0.7383509432994655d, 1.459730034507154d, 6.219562570799601d, 1.3095039686745036d, 18.645523731903864d, 61.243100752279624d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1153.6627672433626d);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }
// 
// 
//     int[] var3 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var3);
//     int var6 = var5.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var5, var8);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    double[] var1 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    java.lang.Number var5 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var15 = var14.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = var14.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var8, (java.lang.Number)0.8055186938534216d, 60, var16, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var5, (java.lang.Number)14L, 3, var16, true);
    boolean var23 = org.apache.commons.math3.util.MathArrays.checkOrder(var1, var16, true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    boolean var54 = var47.isSupportUpperBoundInclusive();
    double var55 = var47.sample();
    double var57 = var47.probability(6.813639406926573E-7d);
    double var58 = var47.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 9705.882352941177d);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     double var13 = var7.nextUniform(1.3095039686745036d, 20.087570183274988d, false);
//     int var16 = var7.nextZipf(43, 0.4201726638330996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0447953703468075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.676115923038391d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.1565992163160207d, (java.lang.Number)49, var3);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    double var9 = var2.nextGaussian(4.218937231588664d, 0.9692669377133449d);
    var2.reSeedSecure(8026008374386375277L);
    double var14 = var2.nextCauchy(0.0d, 0.6032779273078988d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.641195788033711d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.2424216574211187d));

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var11 = var0.nextUniform((-0.4148741153049867d), (-0.19811647941323907d), false);
//     double var14 = var0.nextUniform((-0.5015644110639155d), 0.16642488433902802d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.987797904821823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.21857298558359475d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.2542182344498413d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.12092237563577336d));
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     int var9 = var0.nextInt(32, 53);
//     double var12 = var0.nextBeta(2.125285173880562d, 0.1802716703931467d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var0.nextPermutation((-1123394720), 27);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-10.41788585640087d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.89295520957446d);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 54);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)14, (java.lang.Object)0.4265583850978061d);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     int var20 = var0.nextHypergeometric(73, 18, 12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextUniform(0.49289801685947066d, (-11.813380827737387d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.5350387465425492d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a432b5ad694ad5546e671e764371068a4d98cb4f0042c21adc82984b5bce02c8a0920308a1811479df69cc0"+ "'", var8.equals("a432b5ad694ad5546e671e764371068a4d98cb4f0042c21adc82984b5bce02c8a0920308a1811479df69cc0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-17.881518511365584d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "270fef55eb4cbd5b20b45fb54c1dc23f0"+ "'", var16.equals("270fef55eb4cbd5b20b45fb54c1dc23f0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    double[] var1 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    double[] var5 = null;
    double[] var9 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var13 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var9, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var5, var13);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var13, var20);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var1, var13);
    double[] var31 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var31, var40);
    double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var40, 0.0d);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var13, var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var40);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 199.04522099261766d);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     int var7 = var0.nextSecureInt((-1), 15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextF(0.0d, 4979382.8531437665d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.2683804372175134d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 15);
// 
//   }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     int[] var11 = new int[] { 100, 10, (-1)};
//     var7.setSeed(var11);
//     int[] var13 = new int[] { };
//     var7.setSeed(var13);
//     int[] var15 = null;
//     int var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var15);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 66);
//     var1.setSeed(var18);
//     java.util.List var20 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var21 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var20);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     int var18 = var0.nextPascal(79, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var21 = var0.nextPermutation(145, 42904144);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14.094918907937098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0856374827143571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.setSeed(77);
//     boolean var9 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6801050005582245d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var15 = var2.nextUniform((-0.45868556584517606d), 3.117875532018103d, true);
//     var2.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.7775145056694182d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.1841990012655926d));
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10L, var1, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)4097752537538055884L, (java.lang.Number)20.833429203024522d, true);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var52 = var47.getSupportUpperBound();
    double var54 = var47.density((-19533.05988397774d));
    double var56 = var47.probability(1.6200204638860117E-8d);
    double var59 = var47.cumulativeProbability((-5699.4358864984715d), 1.254866143501413d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var61 = var47.inverseCumulativeProbability((-0.10659341427742133d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)1L, var8);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var4, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, var3, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     int var11 = var0.nextZipf(51, 0.20851425337288942d);
//     java.lang.String var13 = var0.nextHexString(24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-930705.9973575061d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 70L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "44345c79a2377221a7a93c31"+ "'", var13.equals("44345c79a2377221a7a93c31"));
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
    double[] var31 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var28, var31);
    double[] var36 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var28, var36);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var8, var28);
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var65);
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var28, var56);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var56);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     var0.reSeedSecure(0L);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var25);
//     double[] var29 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var30 = null;
//     java.lang.Object[] var32 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var33 = new org.apache.commons.math3.exception.MathInternalError(var30, var32);
//     org.apache.commons.math3.util.Pair var34 = new org.apache.commons.math3.util.Pair((java.lang.Object)var29, (java.lang.Object)var30);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var42, var51);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var29, var51);
//     boolean var57 = var56.isSupportConnected();
//     double var59 = var56.density((-30.443553573156947d));
//     double var60 = var56.getSupportLowerBound();
//     double[] var62 = var56.sample(7);
//     double var63 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var56);
//     double var64 = var56.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var67 = var56.cumulativeProbability(5101966.867045672d, (-0.56750319853339d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1138455.2495205782d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "bc7a8b93a0d161e5a5db9f"+ "'", var4.equals("bc7a8b93a0d161e5a5db9f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 9705.88235159202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 9705.882352941177d);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int[] var6 = new int[] { 100, 10, (-1)};
//     var2.setSeed(var6);
//     int[] var8 = new int[] { };
//     var2.setSeed(var8);
//     int[] var10 = null;
//     int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 66);
//     int var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var13);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.4175817110841148d, (java.lang.Object)"c6e2709dc5af");

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(63, 18);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 18);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextSecureInt(22, 54);
//     int[] var12 = var2.nextPermutation(53, 24);
//     var2.reSeed();
//     double var17 = var2.nextUniform((-0.003914182498881762d), 0.13710330393787307d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.05672318083457417d);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int[] var5 = var2.nextPermutation(318, 63);
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double var8 = var7.nextGaussian();
//     byte[] var10 = new byte[] { (byte)10};
//     var7.nextBytes(var10);
//     org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var7);
//     byte[] var14 = new byte[] { (byte)1};
//     var7.nextBytes(var14);
//     org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
//     var16.reSeedSecure();
//     java.lang.String var19 = var16.nextHexString(86);
//     int var22 = var16.nextBinomial(44, 0.11681967467915401d);
//     int[] var25 = var16.nextPermutation(54, 37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = org.apache.commons.math3.util.MathArrays.distance1(var5, var25);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7834615598688859d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "a7431a18897ce99604ddbfe492829b922041e1feba77c47d4d99b786dc9dca17125131440db428051bdd06"+ "'", var19.equals("a7431a18897ce99604ddbfe492829b922041e1feba77c47d4d99b786dc9dca17125131440db428051bdd06"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
//     double[] var22 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
//     double var32 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 0.0d);
//     double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance1(var8, var31);
//     double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, 0.0d);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var47 = var46.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var48 = var46.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var50 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var48, true);
//     boolean var52 = org.apache.commons.math3.util.MathArrays.isMonotonic(var8, var48, false);
//     double[] var53 = null;
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var53);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.7785726358444499d), (java.lang.Number)1.22705655817319d, (java.lang.Number)2.873194720677289E-12d);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     int[] var9 = null;
//     int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 44);
//     org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var18 = var16.nextT(0.1431715674774945d);
//     double var21 = var16.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var24 = var16.nextPermutation(83, 33);
//     int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = org.apache.commons.math3.util.MathArrays.distance1(var15, var25);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 682.2999473004031d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.8714778881597607E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     java.lang.String var10 = var2.nextHexString(95);
//     int var14 = var2.nextHypergeometric(499, 69, 61);
//     var2.reSeed(5804136433509186560L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.7453954223562798d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "ccc187c52f6e348003a10dddb27766313ebcad72a73aa7d13228d1077d2ead676900c4e42db5ff9a5d3546c6e77b6a6"+ "'", var10.equals("ccc187c52f6e348003a10dddb27766313ebcad72a73aa7d13228d1077d2ead676900c4e42db5ff9a5d3546c6e77b6a6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeedSecure(100L);
    java.lang.String var9 = var2.nextHexString(53);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextLong(0L, (-1092428417482140062L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "662ab224c609e5c9ef47e16ab5a751468d6b7db870cac522c8500"+ "'", var9.equals("662ab224c609e5c9ef47e16ab5a751468d6b7db870cac522c8500"));

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var1, true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 66+ "'", var4.equals(66));

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    boolean var4 = var2.equals((java.lang.Object)(short)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var14 = var2.nextGamma(1.22705655817319d, 1.487086298741032E-9d);
//     var2.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var2.nextLong(6599722114787805860L, 4L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.1266813743629274d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.3297271153553544E-9d);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(100L);
    var2.reSeedSecure(1L);
    int[] var9 = var2.nextPermutation(100, 18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextSecureInt(301405723, 22);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     var7.reSeedSecure(39L);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var7.nextSample(var12, 17);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2142147742);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var10 = var0.nextF(102.0d, 9900.0d);
//     double var12 = var0.nextT(223.0d);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var0.nextSample(var13, 33);
// 
//   }

}
