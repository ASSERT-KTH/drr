
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     int var7 = var0.nextInt(0, 100);
//     int var11 = var0.nextHypergeometric(39, 15, 31);
//     double var13 = var0.nextT(0.03349382385542734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.3645060472848733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.3532188936284664E13d));
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     int var7 = var0.nextSecureInt(16, 34);
//     double var10 = var0.nextBeta(13.589650696693303d, 8.509279159644674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8.762030458096847E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "63676e2e125436b45a2b92"+ "'", var4.equals("63676e2e125436b45a2b92"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.6641860870364441d);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    float[] var0 = null;
    float[] var2 = new float[] { 10.0f};
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var8 = new float[] { 0.0f, 100.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
    float[] var13 = new float[] { (-1.0f), 1.0f};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var13);
    float[] var15 = new float[] { };
    float[] var18 = new float[] { 0.0f, (-1.0f)};
    float[] var21 = new float[] { 0.0f, 100.0f};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var21);
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var15, var18);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var2, var18);
    float[] var27 = new float[] { 0.0f, (-1.0f)};
    float[] var30 = new float[] { 0.0f, 100.0f};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var30);
    float[] var32 = null;
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var30, var32);
    float[] var35 = new float[] { 10.0f};
    float[] var38 = new float[] { 0.0f, (-1.0f)};
    float[] var41 = new float[] { 0.0f, 100.0f};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var35, var41);
    float[] var46 = new float[] { (-1.0f), 1.0f};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var46);
    float[] var48 = new float[] { };
    float[] var51 = new float[] { 0.0f, (-1.0f)};
    float[] var54 = new float[] { 0.0f, 100.0f};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var54);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var48, var51);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var35, var51);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    float[] var59 = new float[] { };
    float[] var62 = new float[] { 0.0f, (-1.0f)};
    float[] var65 = new float[] { 0.0f, 100.0f};
    boolean var66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var65);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var59, var62);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var35, var59);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var18, var59);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var0, var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getSupportUpperBound();
    double var53 = var47.density(0.6938061358177889d);
    boolean var54 = var47.isSupportConnected();
    double var56 = var47.density((-0.7110563084721201d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var59 = var47.cumulativeProbability(1.3495680748265906E-9d, (-1.1982929092738202d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)68.58227366955163d, (java.lang.Number)1.2943594672842019E-6d, true);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getNumericalMean();
//     double var53 = var47.probability(2.641195788033711d);
//     boolean var54 = var47.isSupportUpperBoundInclusive();
//     double var55 = var47.sample();
//     double[] var57 = var47.sample(26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03349382385542734d);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     int var14 = var10.nextSecureInt(39, 93);
//     double var17 = var10.nextGamma(6.785854381629338d, 0.6245596043465632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3653387198348668d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.722170011050812d);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.density(0.0d);
    double[] var55 = var47.sample(95);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(45);
    int var5 = var1.nextInt(86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 43);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     int var11 = var0.nextSecureInt(32, 57);
//     var0.reSeed(9L);
//     double var15 = var0.nextChiSquare(0.1052381769160073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6287375740881604d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1583894735230253d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.12798250930416136d);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.5951250420414592d, (java.lang.Number)0.6188765767602198d, (java.lang.Number)0.9139770319308758d);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     var0.reSeed(12L);
//     java.lang.String var19 = var0.nextSecureHexString(90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8560295214393543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.010126826108688286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "3769aceb547153fb7132b3d8be72a81271b8dc2f02ffbc6276f20c969f92a1363f7ea439553dad0a04c69534f3"+ "'", var19.equals("3769aceb547153fb7132b3d8be72a81271b8dc2f02ffbc6276f20c969f92a1363f7ea439553dad0a04c69534f3"));
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.clear();
//     double var3 = var1.nextDouble();
//     int[] var4 = null;
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
//     int[] var9 = new int[] { 100, 10, (-1)};
//     var5.setSeed(var9);
//     int[] var11 = new int[] { };
//     var5.setSeed(var11);
//     int[] var13 = null;
//     int var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var13);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 66);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 0);
//     var1.setSeed(var18);
//     int[] var20 = new int[] { };
//     int[] var21 = null;
//     int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var21);
//     int[] var23 = new int[] { };
//     int[] var24 = null;
//     int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var23, var24);
//     int var26 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var24);
//     org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var20);
//     var1.setSeed(var20);
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var31 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var30);
//     var31.reSeed();
//     int var35 = var31.nextZipf(18, 0.10832690038004085d);
//     double var37 = var31.nextT(11.36369913641775d);
//     int[] var40 = var31.nextPermutation(33, 31);
//     int[] var41 = null;
//     org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var41);
//     int[] var46 = new int[] { 100, 10, (-1)};
//     var42.setSeed(var46);
//     int[] var48 = new int[] { };
//     var42.setSeed(var48);
//     int[] var50 = null;
//     int var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var48, var50);
//     int[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 66);
//     int[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var53);
//     int[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 44);
//     int var57 = org.apache.commons.math3.util.MathArrays.distance1(var40, var53);
//     org.apache.commons.math3.random.Well19937c var58 = new org.apache.commons.math3.random.Well19937c(var53);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance(var20, var53);
//     org.apache.commons.math3.random.Well19937c var61 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var62 = null;
//     org.apache.commons.math3.random.Well19937c var63 = new org.apache.commons.math3.random.Well19937c(var62);
//     int[] var67 = new int[] { 100, 10, (-1)};
//     var63.setSeed(var67);
//     int[] var69 = new int[] { };
//     var63.setSeed(var69);
//     int[] var71 = null;
//     int var72 = org.apache.commons.math3.util.MathArrays.distanceInf(var69, var71);
//     int[] var74 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 66);
//     int[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 0);
//     var61.setSeed(var76);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var78 = org.apache.commons.math3.util.MathArrays.distance1(var53, var76);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.6862627241836179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.7259235126546729d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 516);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var13 = var10.nextGamma(32.408412718428444d, 1.2786735854696036d);
//     var10.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var10.nextHypergeometric(69, 0, 483);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7195516781288396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 44.61193296899044d);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.6989809774046034d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var12 = var9.nextPermutation(66, 20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var9.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 7, 71);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.892067858120859d), (java.lang.Number)0.7643965057948721d, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var11 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var11);
//     java.lang.Throwable[] var13 = var12.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var13);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.setSeed(0L);
    int var4 = var1.nextInt();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1102768644));

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)55);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     var0.reSeedSecure(2L);
//     double var13 = var0.nextUniform((-1.8965324332131883d), 5.9113736934824805d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextSecureLong(177811999939543264L, 7L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.938666753308636d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.41554918345402164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.152749770355439d);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)1L, var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, var5);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     double var16 = var0.nextExponential(0.6591014616866876d);
//     double var19 = var0.nextGamma(0.50527176291182d, 0.5951250420414592d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextGamma(0.0d, (-0.44242633786421587d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.34628905934771836d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.036692964132921425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5059185916173232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 56.0123251808397d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.19880242637267745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.18281160910963007d);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var9 = var0.nextChiSquare(12.720236844771842d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.00861222729424549d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.7878692515803762d);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextGaussian(1.697156835772471d, (-0.19811647941323907d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.07366777391460877d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4778837.634911011d);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 61, 20);
    int var4 = var3.getDimension();
    int var5 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 20);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     int var18 = var0.nextPascal(79, 0.0d);
//     double var21 = var0.nextGaussian((-173.06341310308545d), 4849783.690117682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.0662967001270545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.2344507198063365d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-3527625.702778368d));
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)23.255333405607846d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    long[] var8 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    long[][] var10 = new long[][] { var8};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var10);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var10);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)513, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var18.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)10.0d, (java.lang.Number)(short)1, (java.lang.Number)(-0.32577132027868605d));
    java.lang.Number var6 = var5.getHi();
    java.lang.Number var7 = var5.getHi();
    java.lang.Throwable[] var8 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.32577132027868605d)+ "'", var6.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-0.32577132027868605d)+ "'", var7.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var7.nextUniform(0.904566922318453d, 0.09750373895602457d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4697051344400381d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextSecureHexString(11);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextGaussian(1.1646934545521657d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.110391454105426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0619580610646306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "743317e028b"+ "'", var12.equals("743317e028b"));
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var13 = var10.nextInt(10, 100);
//     double var16 = var10.nextUniform((-1.0d), 1.0d);
//     var10.reSeedSecure();
//     org.apache.commons.math3.util.Pair var18 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, (java.lang.Object)var10);
//     double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
//     double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var26, var35);
//     double[] var38 = null;
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var35, var38);
//     double[] var43 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double var53 = org.apache.commons.math3.util.MathArrays.distance1(var43, var52);
//     boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var35, var43);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var35);
//     double[] var59 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var63 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var67 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var63, var67);
//     double var69 = org.apache.commons.math3.util.MathArrays.distance1(var59, var68);
//     double[] var71 = org.apache.commons.math3.util.MathArrays.copyOf(var68, 88);
//     double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var68);
//     double[] var73 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var72);
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     long var13 = var0.nextPoisson(10.0d);
//     long var16 = var0.nextLong(7L, 24L);
//     long var18 = var0.nextPoisson(1.4276096462825826E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.062117049046509276d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "76019bd938b6e3b8c21120c09eca18a63a757dd6c647490f196914035bba4cc33c6227c9180eb55069c3040"+ "'", var8.equals("76019bd938b6e3b8c21120c09eca18a63a757dd6c647490f196914035bba4cc33c6227c9180eb55069c3040"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.63323150528981d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0L);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(483);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2784.9275671086507d, (java.lang.Number)37, (java.lang.Number)64);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 37+ "'", var5.equals(37));

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     var0.reSeedSecure(0L);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var25);
//     double[] var29 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var30 = null;
//     java.lang.Object[] var32 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var33 = new org.apache.commons.math3.exception.MathInternalError(var30, var32);
//     org.apache.commons.math3.util.Pair var34 = new org.apache.commons.math3.util.Pair((java.lang.Object)var29, (java.lang.Object)var30);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var42, var51);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var29, var51);
//     boolean var57 = var56.isSupportConnected();
//     double var59 = var56.density((-30.443553573156947d));
//     double var60 = var56.getSupportLowerBound();
//     double[] var62 = var56.sample(7);
//     double var63 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var56);
//     double var64 = var56.sample();
//     double var66 = var56.inverseCumulativeProbability(0.8595671400578583d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 36769.59719869868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "914ea64f295b0ac5485e4c"+ "'", var4.equals("914ea64f295b0ac5485e4c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 9705.88235159202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 9705.882352941177d);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     java.util.List var3 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var4 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var3);
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var11 = var0.nextUniform((-0.4148741153049867d), (-0.19811647941323907d), false);
//     double var13 = var0.nextT(3.4785048692046914d);
//     var0.reSeedSecure(179L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextPoisson((-1887.9453533696599d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 31.07451483197522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.20136719454881116d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.24462390346638796d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.201413015132264d);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     long var9 = var2.nextSecureLong((-1092428417482140062L), 27192867108684266L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-187350727499901440L));
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var19 = null;
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var19, var27);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var34);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var12, var34);
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var58);
    double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var58, 9900.0d);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var62);
    double[] var67 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var71 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var75 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var71, var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distance1(var67, var76);
    double[] var79 = org.apache.commons.math3.util.MathArrays.normalizeArray(var76, 0.0d);
    double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var76);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var62, var76);
    double[] var82 = org.apache.commons.math3.util.MathArrays.copyOf(var62);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var62);
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextWeibull(1.0252073473582036E-4d, 0.14521388384019507d);
//     var0.reSeedSecure();
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var0.nextSample(var8, 32);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    int[] var2 = new int[] { };
    int[] var3 = null;
    int var4 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var3);
    var1.setSeed(var2);
    double var6 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.24066015601429158d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var18);
//     var19.reSeed();
//     int var23 = var19.nextZipf(18, 0.10832690038004085d);
//     double var25 = var19.nextT(11.36369913641775d);
//     int[] var28 = var19.nextPermutation(33, 31);
//     int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 0);
//     int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 55);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var33 = org.apache.commons.math3.util.MathArrays.distance1(var16, var30);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.1083989321644365d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.08549339154362764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.5257205790215015d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     double var20 = var9.nextGaussian((-0.8745685632141509d), 0.6787523281640638d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var9.nextUniform(3.4785048692046914d, 0.9168562901633759d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7463972471343663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1.3179842784873004d));
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.8957593931545116d, (-0.29358390686045066d), 0.6682025531487382d, (-0.7188757561542878d), 0.5753819820845707d, (-0.3266536173720751d), 3.6052885422141174d, 6.813639406926573E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.9312833072133039d));

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     org.apache.commons.math3.random.RandomDataGenerator var35 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var38 = var35.nextInt(10, 100);
//     double var41 = var35.nextUniform((-1.0d), 1.0d);
//     var35.reSeedSecure();
//     org.apache.commons.math3.util.Pair var43 = new org.apache.commons.math3.util.Pair((java.lang.Object)var34, (java.lang.Object)var35);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var60);
//     double[] var63 = null;
//     boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
//     double[] var68 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
//     boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var60, var68);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var34, var60);
//     double var81 = org.apache.commons.math3.util.MathArrays.distance(var8, var60);
//     double var82 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var83 = null;
//     double var84 = org.apache.commons.math3.util.MathArrays.distance(var8, var83);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.601552f, (java.lang.Object)(-0.6001566413360179d));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.6001566413360179d), (java.lang.Number)(-1L), (java.lang.Number)5.704309058613993d);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    java.lang.Number var6 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotANumberException var3 = new org.apache.commons.math3.exception.NotANumberException();
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-1.3566897441869925d), (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var8);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 10);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(99, 92);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextSecureInt(22, 54);
//     int[] var12 = var2.nextPermutation(53, 24);
//     java.lang.String var14 = var2.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("54dcefc214f024a7d17463dd1098b49ad780902eef09409", "2ed0e3077352a69d7d19fc4d7d852b2e358780d0cf542f0740dfe3");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "ca71de927b"+ "'", var14.equals("ca71de927b"));
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    boolean var54 = var47.isSupportUpperBoundInclusive();
    boolean var55 = var47.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(84);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation(7, 99);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.611566590046992d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "c430f30dd8d0381592e96728021b7e977b1955c076789f348a9a2d1c0ccc916024946ec43c61adcdb5d1"+ "'", var8.equals("c430f30dd8d0381592e96728021b7e977b1955c076789f348a9a2d1c0ccc916024946ec43c61adcdb5d1"));
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.3645060472848733d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    var1.clear();
    int var3 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 818120085);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)103.56915419683993d, (-1), var3, true);
    int var6 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var8 = null;
    java.lang.Comparable[] var10 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var11, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var14, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, (java.lang.Object[])var10);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = var5.getDirection();
    java.lang.String var20 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -2 and -1 are not strictly decreasing (103.569 <= null)"+ "'", var20.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -2 and -1 are not strictly decreasing (103.569 <= null)"));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.density(0.0d);
    double[] var55 = var47.sample(95);
    double[] var56 = null;
    double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var56, var64);
    double var67 = org.apache.commons.math3.util.MathArrays.safeNorm(var64);
    double[] var71 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var75 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var71, var75);
    double[] var77 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var71);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var78 = org.apache.commons.math3.util.MathArrays.distance1(var55, var71);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextWeibull(6.785854381629338d, 4736077.9249220705d);
//     double var20 = var0.nextChiSquare(0.4188489407275768d);
//     var0.reSeedSecure(0L);
//     var0.reSeed(4L);
//     long var27 = var0.nextLong(3657790713701999616L, 6149568864592168549L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7939480026149619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5862237.10570773d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.4947694406448346E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4955414.248644063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.11235981905790325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 3771079338555689984L);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var24);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
//     boolean var31 = org.apache.commons.math3.util.MathArrays.isMonotonic(var24, var29, true);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
//     double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
//     double[] var18 = null;
//     double var19 = org.apache.commons.math3.util.MathArrays.distance1(var12, var18);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 0.0d);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var8, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, 0.0d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var47 = var46.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var48 = var46.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var50 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var48, true);
    boolean var52 = org.apache.commons.math3.util.MathArrays.isMonotonic(var8, var48, false);
    double[] var56 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var57 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var56);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var65 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var66 = var65.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var67 = var65.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var69 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var67, true);
    boolean var71 = org.apache.commons.math3.util.MathArrays.isMonotonic(var56, var67, true);
    double[] var75 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var79 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var75, var79);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var56, var80);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var85 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Number var86 = var85.getPrevious();
    java.lang.Number var87 = var85.getArgument();
    java.lang.Number var88 = var85.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var89 = var85.getDirection();
    boolean var91 = org.apache.commons.math3.util.MathArrays.isMonotonic(var80, var89, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var8, var89, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var86 + "' != '" + 0.0f+ "'", var86.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var87 + "' != '" + (-1)+ "'", var87.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + 0.0f+ "'", var88.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     double var13 = var0.nextExponential(0.1431715674774945d);
//     var0.reSeed();
//     double var16 = var0.nextChiSquare(1.934238008197349E-9d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5154314740964967d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "64181d4616c75e65930c124be52fb519d72f339a24ae68f24c52ff5eca3c2124d51733bebfb64d9e63475bf"+ "'", var8.equals("64181d4616c75e65930c124be52fb519d72f339a24ae68f24c52ff5eca3c2124d51733bebfb64d9e63475bf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.73175034111229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.039100719281359095d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     long var7 = var0.nextSecureLong(7L, 508515618537942016L);
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)103.56915419683993d, (-1), var3, true);
    java.lang.Number var6 = var5.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 48, 49);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)36789.62528311121d);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 65);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var8 = var1.nextInt(18);
//     int var10 = var1.nextInt(54);
//     var1.setSeed(54);
//     var1.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.24927329225278022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 51);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed(100L);
    double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var2.nextBeta((-460.120075840096d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-334.73040418701044d));

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 0);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation(5, 63);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.073488026422035d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d725"+ "'", var8.equals("d725"));
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextPascal(14, 6356522.032707067d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6920242006905086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "f33b6ddb6e1f48f670fb2e32d5ffe9ae165c9f43526ecee"+ "'", var10.equals("f33b6ddb6e1f48f670fb2e32d5ffe9ae165c9f43526ecee"));
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int var15 = var0.nextInt(81, 87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 22.293534398663915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.6380437494760822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 81);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    boolean var54 = var47.isSupportUpperBoundInclusive();
    var47.reseedRandomGenerator(9L);
    double[] var58 = var47.sample(71);
    var47.reseedRandomGenerator(6992985943769857466L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var0.nextSample(var7, 47);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(3.3718048487453802d, (-0.292640940848738d), 12.76198980593372d, 12.211458734486403d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 154.85578374180056d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var30, var34);
    double[] var41 = null;
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var41, var49);
    double var52 = org.apache.commons.math3.util.MathArrays.safeNorm(var49);
    double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var56);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var34, var56);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var56);
    double[] var65 = null;
    double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var65, var73);
    double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var80 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var84 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var85 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var80, var84);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var73, var80);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var80);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var87, 54);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var89);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var1, (java.lang.Number)103.56915419683993d, (-1), var4, true);
    int var7 = var6.getIndex();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Number var9 = null;
    java.lang.Comparable[] var11 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    boolean var14 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var11, var12, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var11, var15, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var9, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.0d), (java.lang.Number)0.20851425337288942d, 11);
    boolean var4 = var3.getStrict();
    boolean var5 = var3.getStrict();
    java.lang.Number var6 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.20851425337288942d+ "'", var6.equals(0.20851425337288942d));

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    int var10 = var2.nextHypergeometric(87, 55, 86);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextZipf(48, (-0.09154513481168484d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 54);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.6040101945254669d);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     var0.reSeed((-56139359032789495L));
//     double var12 = var0.nextExponential(0.6040101945254669d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial(17, 5.2935374176612715d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-3.788422054428021d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 91L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.37722610582968d);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     int var18 = var0.nextPascal(79, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextZipf(818120085, (-1.6302376483479237d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.403720726363954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.46044262742578285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     double var5 = var0.nextT(23.562469870696063d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("8f880b9512aafa8b708e5fc0f94cc789d099523fd37746cf3670c32d0ad993274b275e726dbe50996f35ca6", "9e90aee0c32bce38148f2b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.04651973270504904d);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }
// 
// 
//     java.lang.Object var0 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(100);
//     var2.setSeed(0L);
//     int var5 = var2.nextInt();
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var5);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var8);
//     var9.reSeedSecure(100L);
//     var9.reSeedSecure(1L);
//     java.lang.String var15 = var9.nextSecureHexString(2);
//     double var18 = var9.nextGamma(0.08430081831437178d, 26.7909048614082d);
//     var9.reSeedSecure();
//     boolean var20 = var6.equals((java.lang.Object)var9);
//     org.apache.commons.math3.distribution.IntegerDistribution var21 = null;
//     int var22 = var9.nextInversionDeviate(var21);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(84);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(25, 318, 57);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9432194560308087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3c1f745ffc9db972cc424054bb064bf401468322af25a4e1395425cffbcf65a58fbd5153db3679b19f5d"+ "'", var8.equals("3c1f745ffc9db972cc424054bb064bf401468322af25a4e1395425cffbcf65a58fbd5153db3679b19f5d"));
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 0.0d);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var8, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.6346046533769326d), (java.lang.Number)29, (java.lang.Number)99.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed(100L);
    double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
    var2.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("c4df61a16bac421db45e5de39555df977b7a195c7e8c94347abe", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-334.73040418701044d));

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }


    int[] var0 = new int[] { };
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var52 = var47.getSupportUpperBound();
    double var54 = var47.density((-19533.05988397774d));
    boolean var55 = var47.isSupportConnected();
    double var57 = var47.density(0.0d);
    double var58 = var47.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 9517.474048442906d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.5553573059120609d, (java.lang.Number)380.3232183455007d, var3);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.6245596043465632d, (java.lang.Number)16, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     var0.reSeed();
//     java.lang.String var14 = var0.nextSecureHexString(9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextInt(48, 35);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.2816879135095447d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a96b9a75481a3a64175d37a14a90b9634760a0cacd2664fff3aeabc58854fac730d91f52f37c280fc1038c6"+ "'", var8.equals("a96b9a75481a3a64175d37a14a90b9634760a0cacd2664fff3aeabc58854fac730d91f52f37c280fc1038c6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 23.48223567355643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "e44511def"+ "'", var14.equals("e44511def"));
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-4.223479475728832d));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextT(1.818331372129114d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextBeta((-0.720542025285428d), (-5.144340331950409E15d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.1440400422066794d));

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double[] var16 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var20 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var11, var20);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 9900.0d);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var29 = var28.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var30 = var28.getDirection();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var31 = var28.getDirection();
//     boolean var33 = org.apache.commons.math3.util.MathArrays.isMonotonic(var24, var31, false);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var35 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5650594787118064d, (java.lang.Number)1.524696304927174d, 0, var31, true);
//     boolean var37 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var31, true);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     var0.reSeedSecure(27192867108684266L);
//     double var8 = var0.nextUniform((-37807.751602013566d), 0.44364892021138247d);
//     double var11 = var0.nextCauchy(0.21939587151237389d, 21.869847397459292d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-13705.432458791129d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 19.30933480309633d);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.05475404077564316d), var1, (java.lang.Number)0.8055186938534216d);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//     int[] var10 = null;
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
//     double var12 = var11.nextGaussian();
//     int[] var15 = new int[] { 0, 1};
//     var11.setSeed(var15);
//     double var17 = var11.nextGaussian();
//     var11.clear();
//     org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     long var21 = var19.nextPoisson(0.6989809774046034d);
//     long var23 = var19.nextPoisson(0.9304525547601544d);
//     double[] var27 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var27, var36);
//     org.apache.commons.math3.util.Pair var38 = new org.apache.commons.math3.util.Pair((java.lang.Object)var23, (java.lang.Object)var27);
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double[] var57 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var55);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.normalizeArray(var46, 21.869847397459292d);
//     double[] var64 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var68 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var69 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var64, var68);
//     double[] var73 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
//     double[][] var75 = new double[][] { var73};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var64, var75);
//     org.apache.commons.math3.exception.NotFiniteNumberException var77 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var75);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var59, var75);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var9, var27, var59);
//     double var81 = var79.cumulativeProbability(0.12710308070472615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.451831387477975E12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.2145858084374752d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 10.099504938362077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0.0d);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100L, (java.lang.Number)(-1L), (java.lang.Number)0.1431715674774945d);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)var6);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var7);
    java.lang.Object var9 = var8.getFirst();
    java.lang.Object var10 = var8.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     var7.reSeedSecure(39L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var7.nextF(2.6432653329682987d, (-2.2977813241100553d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.21112600774266985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     long var8 = var0.nextSecureLong(5507950371326924800L, 8026008374386375277L);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 100);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     var6.reSeed(14L);
//     double var13 = var6.nextCauchy((-37807.751602013566d), 1.0510230604516366d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var6.nextUniform(0.24556052843519588d, 0.02409261825292752d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.056084904859655525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-37811.76303061528d));
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    boolean var5 = var3.getStrict();
    boolean var6 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var3.getDirection();
    int var8 = var3.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var3.getDirection();
    int var10 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(15, 499);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9.219544457292887d, (java.lang.Number)6.604624584640234d, false);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.6245596043465632d, (java.lang.Number)1L, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1L+ "'", var4.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     double var5 = var0.nextT(23.562469870696063d);
//     double var8 = var0.nextCauchy(0.11433830816137684d, 1.2349020409310291E-9d);
//     long var11 = var0.nextSecureLong((-1092428417482140062L), (-43986082236993568L));
//     double var13 = var0.nextChiSquare(3.4785048692046914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.8196927716049274d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.11433830967697113d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-696871096713307008L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.186744492510037d);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     double var12 = var0.nextUniform((-334.73040418701044d), 0.41193635261539896d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("338c339", "e0cbce2783c65392e0bebc069a4ff74a7783598abf1f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.29738594888673464d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.8149246377820132E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.051785042891469d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-195.43850435698818d));
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getSupportUpperBound();
//     double var52 = var47.sample();
//     double var55 = var47.cumulativeProbability((-988.6092885864007d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 0.0d);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double[] var50 = var47.sample(318);
    double var51 = var47.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var54 = var47.probability(7.829777967556679E7d, 0.049321626654843825d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 97.05882352941177d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(7530142578955372636L);
    float var2 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6261916f);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)1L, var7);
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var3, var7);
//     org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var2, var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var13 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var16 = var13.nextInt(10, 100);
//     double var18 = var13.nextExponential(10.0d);
//     double var20 = var13.nextExponential(0.407741687198951d);
//     var13.reSeed();
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 12.078476007117347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.9585663155112759d);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed(5804136433509186560L);
//     int var7 = var2.nextSecureInt(7, 96);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var2.nextInversionDeviate(var8);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.5426948042942312d), (java.lang.Number)25.798688668862965d, (java.lang.Number)(-0.04382736477013571d));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getValue();
    java.lang.Object var5 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10.0d+ "'", var4.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     java.lang.String var3 = var1.nextHexString(44);
//     var1.reSeedSecure();
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var1.nextSample(var5, 67);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    double[] var20 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var20, var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 88);
    double[] var36 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var40 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var36, var40);
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var40, var49);
    double[] var52 = null;
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var49, var52);
    double[][] var54 = new double[][] { var49};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var29, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[] var60 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var64 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var68 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var64, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var60, var69);
    double[] var72 = org.apache.commons.math3.util.MathArrays.normalizeArray(var69, 0.0d);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var72);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var72);
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var16, var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 99.04039579888602d);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     var0.reSeed();
//     java.lang.String var14 = var0.nextSecureHexString(9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextInt(97, 34);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.23537016175437353d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "95af3cc4c97d939fdf46699eac29e489a9739650eb17bbcc6cb944d17d7d135fd580c5414559dbfaceb5039"+ "'", var8.equals("95af3cc4c97d939fdf46699eac29e489a9739650eb17bbcc6cb944d17d7d135fd580c5414559dbfaceb5039"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 23.439922637577954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "a662f4fbd"+ "'", var14.equals("a662f4fbd"));
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)1L, var5);
//     org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var1, var5);
//     org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, var5);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     java.lang.Comparable[] var12 = new java.lang.Comparable[] { (short)1};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
//     boolean var15 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var12, var13, false);
//     org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var12);
//     double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var33);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.normalizeArray(var24, 21.869847397459292d);
//     double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
//     double[] var50 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
//     double[][] var52 = new double[][] { var50};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var41, var52);
//     double var54 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
//     double[] var58 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var62 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var66 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var62, var66);
//     double var68 = org.apache.commons.math3.util.MathArrays.distance1(var58, var67);
//     double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var67, 88);
//     double[] var71 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var41, var67);
//     boolean var72 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var71);
//     double[] var76 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var76);
//     double[] var78 = org.apache.commons.math3.util.MathArrays.copyOf(var76);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var85 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var86 = var85.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var87 = var85.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var89 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var87, true);
//     boolean var91 = org.apache.commons.math3.util.MathArrays.isMonotonic(var76, var87, true);
//     boolean var94 = org.apache.commons.math3.util.MathArrays.checkOrder(var71, var87, false, false);
//     boolean var96 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var12, var87, false);
//     org.apache.commons.math3.exception.MathIllegalStateException var97 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, (java.lang.Object[])var12);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    int[] var9 = null;
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    int[] var15 = null;
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
    int[] var20 = new int[] { 100, 10, (-1)};
    var16.setSeed(var20);
    int[] var22 = new int[] { };
    var16.setSeed(var22);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var22);
    int[] var25 = null;
    int var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var7, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var10 = var1.nextBoolean();
    var1.setSeed((-3200518016629555151L));
    int[] var13 = null;
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    int[] var18 = new int[] { 100, 10, (-1)};
    var14.setSeed(var18);
    int[] var20 = new int[] { };
    var14.setSeed(var20);
    org.apache.commons.math3.random.RandomDataGenerator var22 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var14);
    byte[] var25 = new byte[] { (byte)100, (byte)(-1)};
    var14.nextBytes(var25);
    var1.nextBytes(var25);
    double var28 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.45559865774692204d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[][] var14 = new double[][] { var12};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var14);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var20 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var20, var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 88);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var33);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.999999958158147d, (java.lang.Number)1.280760084747073d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var7 = var6.getSecond();
    java.lang.Object var8 = var6.getValue();
    boolean var9 = var3.equals((java.lang.Object)var6);
    java.lang.Object var10 = var6.getKey();
    java.lang.Object var11 = var6.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0d+ "'", var7.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0d+ "'", var8.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)100+ "'", var10.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (short)100+ "'", var11.equals((short)100));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var2.nextSecureLong(8026008374386375277L, 2371042799620495360L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var2.getValue();
    java.lang.Object var6 = var2.getFirst();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var2);
    boolean var9 = var2.equals((java.lang.Object)(-0.4148741153049867d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var18 = null;
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var18, var26);
    double[] var32 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var36 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var40 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var36, var40);
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var32, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var26, var41);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var12, var41);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 99.04039579888602d);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(2.264115422511676d, 0.3653387198348668d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextZipf(0, (-1.0082709451782454d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.134982946335417d);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.8965324332131883d), (java.lang.Number)84, 22);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 76);
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
//     double[] var31 = null;
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var28, var31);
//     double[] var36 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
//     double var46 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
//     boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var28, var36);
//     double var48 = org.apache.commons.math3.util.MathArrays.distance1(var8, var28);
//     double[] var49 = null;
//     double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
//     boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var49, var57);
//     double var60 = org.apache.commons.math3.util.MathArrays.safeNorm(var57);
//     double[] var64 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var68 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var72 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var68, var72);
//     double var74 = org.apache.commons.math3.util.MathArrays.distance1(var64, var73);
//     double[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var73, 88);
//     double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var73);
//     double[] var81 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var85 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var86 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var81, var85);
//     org.apache.commons.math3.random.RandomDataGenerator var87 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var90 = var87.nextInt(10, 100);
//     double var93 = var87.nextUniform((-1.0d), 1.0d);
//     var87.reSeedSecure();
//     org.apache.commons.math3.util.Pair var95 = new org.apache.commons.math3.util.Pair((java.lang.Object)var86, (java.lang.Object)var87);
//     double[] var96 = org.apache.commons.math3.util.MathArrays.ebeAdd(var57, var86);
//     double[] var97 = org.apache.commons.math3.util.MathArrays.ebeAdd(var28, var96);
//     double[] var98 = null;
//     double[] var99 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var96, var98);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextInt(0, 100);
//     var0.reSeedSecure(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextGamma(2.522863501319761d, (-0.3834644921249093d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.3493287759913861d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 55);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.407741687198951d, (java.lang.Number)66, 18);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var9, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var11);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var7, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100.0d, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.05475404077564316d), var11);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var11);
    org.apache.commons.math3.exception.util.ExceptionContext var18 = var17.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
//     double[] var26 = null;
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var8, var26);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     java.lang.String var13 = var0.nextSecureHexString(82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.7394571392980132d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0020606021630394833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.671953236430061d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "ffd7a9bbe3760ba22b9f6e23e34bd3ca2214770f2c42eeafcfa5714ca7181391ebcc03e45706f765f2"+ "'", var13.equals("ffd7a9bbe3760ba22b9f6e23e34bd3ca2214770f2c42eeafcfa5714ca7181391ebcc03e45706f765f2"));
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 0);
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var16 = var14.nextT(0.1431715674774945d);
//     double var19 = var14.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var22 = var14.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var14.reSeedSecure();
//     var14.reSeedSecure(7741999113339246307L);
//     double var28 = var14.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     var14.reSeedSecure();
//     int[] var32 = var14.nextPermutation(94, 25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var32);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3910446009799302d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 25.470844163143283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.8529388814383416E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-0.11423323440153024d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.020715596726225558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9705.882351884546d, (java.lang.Number)(-0.9392255482827288d), false);
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var5, true);
    java.lang.Number var8 = var7.getMin();
    var3.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var10 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-0.9392255482827288d)+ "'", var10.equals((-0.9392255482827288d)));

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double[] var50 = var47.sample(318);
    double[] var52 = var47.sample(69);
    double var54 = var47.cumulativeProbability(0.11407385423536498d);
    var47.reseedRandomGenerator(14L);
    double var58 = var47.cumulativeProbability(2.185145629027406d);
    double var59 = var47.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 9705.882352941177d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var1, true);
    java.lang.Number var4 = var3.getMin();
    boolean var5 = var3.getBoundIsAllowed();
    java.lang.String var6 = var3.toString();
    java.lang.Number var7 = var3.getMin();
    java.lang.String var8 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 66 is smaller than the minimum (null)"+ "'", var6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 66 is smaller than the minimum (null)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 66 is smaller than the minimum (null)"+ "'", var8.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 66 is smaller than the minimum (null)"));

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var5 = var1.nextExponential(9.49251188161346d);
//     double var7 = var1.nextChiSquare(1.1259987554121422d);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var1.nextInversionDeviate(var8);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }
// 
// 
//     int[] var3 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     int var5 = var4.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var8);
//     var9.reSeed();
//     int var13 = var9.nextZipf(18, 0.10832690038004085d);
//     double var15 = var9.nextT(11.36369913641775d);
//     int[] var18 = var9.nextPermutation(33, 31);
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 0);
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 55);
//     org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var20);
//     int[] var27 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(var27);
//     org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var27);
//     int[] var30 = null;
//     org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(var30);
//     int[] var35 = new int[] { 100, 10, (-1)};
//     var31.setSeed(var35);
//     int[] var37 = new int[] { };
//     var31.setSeed(var37);
//     org.apache.commons.math3.random.RandomDataGenerator var39 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var31);
//     byte[] var42 = new byte[] { (byte)100, (byte)(-1)};
//     var31.nextBytes(var42);
//     var29.nextBytes(var42);
//     var23.nextBytes(var42);
//     var4.nextBytes(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2142147742);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.08475665778672267d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    int[] var9 = null;
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    org.apache.commons.math3.util.Pair var16 = new org.apache.commons.math3.util.Pair((java.lang.Object)0, (java.lang.Object)1.6445632382959425E-9d);
    java.lang.Object var17 = var16.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 0+ "'", var17.equals(0));

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.175632373499613d);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextLong(7530142578955372636L, 18L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 37.03565473733894d);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.2058173601229263d));

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    boolean var5 = var3.equals((java.lang.Object)(short)(-1));
    java.lang.Object var6 = var3.getKey();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var3);
    java.lang.Object var8 = var3.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.016071546142839d));

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     org.apache.commons.math3.random.RandomDataGenerator var35 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var38 = var35.nextInt(10, 100);
//     double var41 = var35.nextUniform((-1.0d), 1.0d);
//     var35.reSeedSecure();
//     org.apache.commons.math3.util.Pair var43 = new org.apache.commons.math3.util.Pair((java.lang.Object)var34, (java.lang.Object)var35);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var60);
//     double[] var63 = null;
//     boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
//     double[] var68 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
//     boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var60, var68);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var34, var60);
//     double var81 = org.apache.commons.math3.util.MathArrays.distance(var8, var60);
//     double[] var85 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var89 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var93 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var94 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var89, var93);
//     double var95 = org.apache.commons.math3.util.MathArrays.distance1(var85, var94);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.distribution.DiscreteRealDistribution var96 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var94);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-0.6049757262150761d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == 223.0d);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     long var10 = var6.nextPoisson(1.3431861837677899d);
//     var6.reSeedSecure(179L);
//     java.lang.String var14 = var6.nextSecureHexString(83);
//     double var17 = var6.nextF(3.6052885422141174d, 0.5035492993096757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9404740718036851d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "fc1729a1fe357b328d4ecd95e15fc55bed1b62be451f61d444ba2b9f140374e341a7dfa5610834a1550"+ "'", var14.equals("fc1729a1fe357b328d4ecd95e15fc55bed1b62be451f61d444ba2b9f140374e341a7dfa5610834a1550"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 22.988985373182516d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)4.153051775837393d, (java.lang.Number)1.0440477515732167d, 67);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-15.395419745105334d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.080589784077458E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.740215980645052d);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     int var14 = var0.nextZipf(31, 20.087570183274988d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7587161733389545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "44f9c65eb1bb4ca39d52430e2e2e8f5ee7a4716b1df4d2cee511dfa5862ad34d87c8ca7f2b885b4d859691b"+ "'", var8.equals("44f9c65eb1bb4ca39d52430e2e2e8f5ee7a4716b1df4d2cee511dfa5862ad34d87c8ca7f2b885b4d859691b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21.77197252270551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 0.7111154558159436d);
//     var0.reSeed(61L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.40937073317029693d);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     boolean var3 = var1.nextBoolean();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var5.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1462552260341392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure(1L);
//     var2.reSeed();
//     double var17 = var2.nextWeibull(105.12656948481559d, 0.08430081831437178d);
//     org.apache.commons.math3.distribution.IntegerDistribution var18 = null;
//     int var19 = var2.nextInversionDeviate(var18);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var15);
//     double[] var22 = null;
//     double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var22, var30);
//     double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var30);
//     double[] var37 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
//     double var47 = org.apache.commons.math3.util.MathArrays.distance1(var37, var46);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 88);
//     double var50 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var46);
//     double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
//     org.apache.commons.math3.random.RandomDataGenerator var60 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var63 = var60.nextInt(10, 100);
//     double var66 = var60.nextUniform((-1.0d), 1.0d);
//     var60.reSeedSecure();
//     org.apache.commons.math3.util.Pair var68 = new org.apache.commons.math3.util.Pair((java.lang.Object)var59, (java.lang.Object)var60);
//     double[] var69 = org.apache.commons.math3.util.MathArrays.ebeAdd(var30, var59);
//     boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var59);
//     double[] var72 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 570.8733363614718d);
//     double[] var74 = org.apache.commons.math3.util.MathArrays.copyOf(var72, 53);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.util.MathArrays.checkOrder(var74);
//       fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
//     } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 0.19908796527428274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     var0.reSeed();
//     java.lang.String var14 = var0.nextSecureHexString(9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial(21, 74.28997240543302d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.21855297155333941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "595bd8ee612be1310b7aca6de11bc6a63ac39847689c079e13b742b9a638af7db3f0583ee89e7ad80b74515"+ "'", var8.equals("595bd8ee612be1310b7aca6de11bc6a63ac39847689c079e13b742b9a638af7db3f0583ee89e7ad80b74515"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20.72344731565882d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "ace4f45f0"+ "'", var14.equals("ace4f45f0"));
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)103.56915419683993d, (-1), var3, true);
    int var6 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var8 = null;
    java.lang.Comparable[] var10 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var11, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var14, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var21 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var19, (java.lang.Number)10.0d);
    var5.addSuppressed((java.lang.Throwable)var21);
    int var23 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1));

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    var2.reSeedSecure(7L);
    int var10 = var2.nextPascal(50, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextPascal(0, (-6.755317488693713d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2147483647);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0f+ "'", var5.equals(0.0f));

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     long var8 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var11 = var9.nextT(426.15711861793085d);
//     int var14 = var9.nextZipf(483, 8.9163268927436E-4d);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var9.nextInversionDeviate(var15);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 0.7111154558159436d);
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double[] var16 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var20 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var11, var20);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var25 = null;
//     java.lang.Object[] var27 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var28 = new org.apache.commons.math3.exception.MathInternalError(var25, var27);
//     org.apache.commons.math3.util.Pair var29 = new org.apache.commons.math3.util.Pair((java.lang.Object)var24, (java.lang.Object)var25);
//     double[] var33 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var37 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var33, var37);
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var37, var46);
//     double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var46, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var51 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var24, var46);
//     boolean var52 = var51.isSupportConnected();
//     double var54 = var51.density((-30.443553573156947d));
//     double var55 = var51.getNumericalMean();
//     var51.reseedRandomGenerator((-509399413869688601L));
//     double var58 = var51.getSupportUpperBound();
//     double var59 = var51.getNumericalVariance();
//     double var60 = var51.getSupportLowerBound();
//     double var61 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var51);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("ae9f78b28f4acd62234573e4c3573bbe49738d817c50ba197f009a0999137d0ef14badd244fa84386ed8fa", "7b146d7aa9e547a8d5daf7566");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.399633551360354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1774884.4601956457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 9705.882352941177d);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var10 = null;
//     double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var10, var18);
//     double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
//     double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var18, var25);
//     double[] var35 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var39 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var43 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var43);
//     double var45 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
//     double var46 = org.apache.commons.math3.util.MathArrays.linearCombination(var31, var44);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var44);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.normalizeArray(var4, (-0.05559908654827428d));
//     double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
//     double[] var62 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var66 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var62, var66);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var57, var66);
//     double[] var69 = null;
//     boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var66, var69);
//     double[] var74 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var78 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var82 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var83 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var78, var82);
//     double var84 = org.apache.commons.math3.util.MathArrays.distance1(var74, var83);
//     boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var66, var74);
//     double[] var86 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var74);
//     double var87 = org.apache.commons.math3.util.MathArrays.distance1(var0, var86);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var7 = var6.getSecond();
    java.lang.Object var8 = var6.getValue();
    boolean var9 = var3.equals((java.lang.Object)var6);
    java.lang.Object var10 = var6.getFirst();
    java.lang.Object var11 = var6.getKey();
    java.lang.Object var12 = var6.getFirst();
    java.lang.Object var13 = var6.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0d+ "'", var7.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0d+ "'", var8.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)100+ "'", var10.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (short)100+ "'", var11.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)100+ "'", var12.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (short)100+ "'", var13.equals((short)100));

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     var0.reSeedSecure(27192867108684266L);
//     double var8 = var0.nextF(0.0014097406670412482d, 0.8835017553608111d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 75);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     int var9 = var0.nextBinomial(62, 0.10431629821572952d);
//     double var13 = var0.nextUniform((-5.891344771123487d), 0.0d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextPascal(72, 19.537851347363357d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 105.23076047250697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "4c45d1d9f9125ccda8ec7f"+ "'", var4.equals("4c45d1d9f9125ccda8ec7f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "44b5f15a382638b94364541c67a452496d9b0335a375e732ca6b19a92d4d80c6e8cc05b94f916e192b0dca48"+ "'", var6.equals("44b5f15a382638b94364541c67a452496d9b0335a375e732ca6b19a92d4d80c6e8cc05b94f916e192b0dca48"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.429688587065059d));
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextZipf(46, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 53.96751090231367d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "9a32603d7a904758ab685a"+ "'", var4.equals("9a32603d7a904758ab685a"));
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    java.lang.String var5 = var3.toString();
    java.lang.Number var6 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(69);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     long var8 = var0.nextPoisson(0.636769707396945d);
//     double var11 = var0.nextGaussian((-0.8258598346981539d), 454.7733245704089d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextInt(62, 56);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.40303106004611655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c37431a1d7ef09fdc72041"+ "'", var4.equals("c37431a1d7ef09fdc72041"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 529.9961815694902d);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    double[] var20 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var30 = var29.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = var29.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var33 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var31, true);
    boolean var35 = org.apache.commons.math3.util.MathArrays.isMonotonic(var20, var31, true);
    double[] var39 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var43 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var43);
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeAdd(var20, var39);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var45);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    double[] var50 = new double[] { 1.0d, 10.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var50);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 9.219544457292887d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     var0.reSeed(6149568864592168549L);
//     int var12 = var0.nextSecureInt(43, 49);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextInt(47, 7);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.18301888994718718d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 46);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(305.5180962292538d, 60366.19788822483d, 0.27700885299431915d, 61.243100752279624d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.8442982820289943E7d);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var5 = var1.nextExponential(9.49251188161346d);
//     double var8 = var1.nextGaussian(1.22705655817319d, 6.790436471693312E7d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(301405723, 7319.324289638869d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.0657250383056134d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.372163450776338E7d);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 45);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.6989809774046034d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(100L);
    var2.reSeedSecure(1L);
    int[] var9 = var2.nextPermutation(100, 18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextHypergeometric(33, (-1), 493);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-6.755317488693713d), (java.lang.Number)135.34632918764086d, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     int[] var3 = null;
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var8 = new int[] { 100, 10, (-1)};
//     var4.setSeed(var8);
//     int[] var10 = new int[] { };
//     var4.setSeed(var10);
//     org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
//     byte[] var15 = new byte[] { (byte)100, (byte)(-1)};
//     var4.nextBytes(var15);
//     var1.nextBytes(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7444303383960063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     int var7 = var0.nextSecureInt(16, 34);
//     int var10 = var0.nextPascal(61, 0.5976979528047165d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextSecureInt(63, 48);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-25.36810988301228d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "82bf72df4b5febdb0e9de4"+ "'", var4.equals("82bf72df4b5febdb0e9de4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 30);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NotPositiveException var13 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-679.7841048171373d));
    java.lang.Number var14 = var13.getMin();
    java.lang.Throwable[] var15 = var13.getSuppressed();
    double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var23, var32);
    double[] var35 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double[] var40 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var48 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var44, var48);
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var40, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var32, var40);
    double[] var52 = null;
    double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var52, var60);
    double var63 = org.apache.commons.math3.util.MathArrays.safeNorm(var60);
    double[] var67 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var71 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var67, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var60, var67);
    double var74 = org.apache.commons.math3.util.MathArrays.distance(var40, var67);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var67);
    org.apache.commons.math3.util.Pair var76 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var67);
    var11.addSuppressed((java.lang.Throwable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 0+ "'", var14.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 101.99509792141973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1.7320508075688772d);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     java.lang.String var8 = var2.nextSecureHexString(2);
//     double var11 = var2.nextGamma(0.08430081831437178d, 26.7909048614082d);
//     org.apache.commons.math3.distribution.RealDistribution var12 = null;
//     double var13 = var2.nextInversionDeviate(var12);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     java.lang.String var8 = var2.nextSecureHexString(2);
//     double var11 = var2.nextGamma(0.08430081831437178d, 26.7909048614082d);
//     var2.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var2.nextGaussian(0.3557079741617218d, (-2.651556632561712d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6e"+ "'", var8.equals("6e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.44231465887983695d);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.520164840297991d, 0.7287380405385424d, 4813.795537938105d, 0.5055053666141864d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2433.7785421176122d);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     java.lang.String var13 = var10.nextHexString(86);
//     int var17 = var10.nextHypergeometric(80, 18, 43);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var10.nextUniform(0.7470195516521267d, 0.01130088519190461d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4823561516572956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "3317f7357db2287b3ba7261a9ee87d2ad9ced10aa3f3b9fc71b93b6fc9a81cd9de7b3f8bfd87e4261cb8e1"+ "'", var13.equals("3317f7357db2287b3ba7261a9ee87d2ad9ced10aa3f3b9fc71b93b6fc9a81cd9de7b3f8bfd87e4261cb8e1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 8);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.sample();
    boolean var52 = var47.isSupportConnected();
    double var54 = var47.probability((-8.189177418063434d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotANumberException var1 = new org.apache.commons.math3.exception.NotANumberException();
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 99);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeed();
//     double var12 = var0.nextGaussian(4.307681584078219E-5d, 0.636769707396945d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(1586855928750372914L, 8L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1562624.0865335849d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.02200166251649733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.783842913570831d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.3976480732253776d);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     int var11 = var6.nextSecureInt(20, 71);
//     long var14 = var6.nextLong(0L, 10L);
//     var6.reSeedSecure(6149568864592168549L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var19 = var6.nextPermutation(67, 94);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5973397154110478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100.0d, (java.lang.Number)(byte)100, 10);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(short)100, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     java.lang.String var10 = var2.nextHexString(95);
//     int var14 = var2.nextHypergeometric(499, 69, 61);
//     double var17 = var2.nextCauchy(0.7493393541476548d, 7.084194643041131d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var2.nextZipf(10, (-0.18598915314788322d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.6137029101429248d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "f232a4e0b19a2a9bf80a602c120760116efccc149b88f7ca9e46d3e4f10b12fefe9e4fd188d21ca91cf8ab4f8b090fb"+ "'", var10.equals("f232a4e0b19a2a9bf80a602c120760116efccc149b88f7ca9e46d3e4f10b12fefe9e4fd188d21ca91cf8ab4f8b090fb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.9638680307280357d));
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 0);
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 55);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
//     int[] var20 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var20);
//     int[] var23 = null;
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
//     int[] var28 = new int[] { 100, 10, (-1)};
//     var24.setSeed(var28);
//     int[] var30 = new int[] { };
//     var24.setSeed(var30);
//     org.apache.commons.math3.random.RandomDataGenerator var32 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var24);
//     byte[] var35 = new byte[] { (byte)100, (byte)(-1)};
//     var24.nextBytes(var35);
//     var22.nextBytes(var35);
//     var16.nextBytes(var35);
//     var16.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4901774594717982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     java.lang.Number var5 = var4.getPrevious();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var4.getDirection();
//     boolean var8 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var6, false);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var6 = var1.nextUniform((-0.32577132027868605d), 4.713414225479933d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextCauchy(8.981043557653793d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.7723156614599562E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3245602600410909d);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     double var12 = var1.nextChiSquare(3.4189499648925503d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextPascal(91, 89439.3517567197d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.569601774305423d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "6fe39e0013ef809e42aaf69b9f66f17deeedf35783a476e"+ "'", var10.equals("6fe39e0013ef809e42aaf69b9f66f17deeedf35783a476e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.631038272954807d);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var9, false);
    double[] var15 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var25 = var24.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var24.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var26, true);
    boolean var30 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var26, true);
    boolean var32 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var26, true);
    java.lang.Comparable[] var34 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var34, var35, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    boolean var40 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var34, var38, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    boolean var43 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var34, var41, false);
    double[] var47 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
    double[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var47);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var56 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var57 = var56.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = var56.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var60 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var58, true);
    boolean var62 = org.apache.commons.math3.util.MathArrays.isMonotonic(var47, var58, true);
    boolean var64 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var34, var58, true);
    boolean var66 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var58, false);
    org.apache.commons.math3.exception.MathIllegalArgumentException var67 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     long var9 = var2.nextPoisson(100.00999950005d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var2.nextInversionDeviate(var10);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     java.lang.String var13 = var10.nextHexString(86);
//     int var17 = var10.nextHypergeometric(80, 18, 43);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var10.nextInt(78, 12);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8918341592742606d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "b943d07a8856e5136ece0d6b6fa44a5facba48f85fb0fac689513a25e765f48fd3a64199f7c6cafa192d01"+ "'", var13.equals("b943d07a8856e5136ece0d6b6fa44a5facba48f85fb0fac689513a25e765f48fd3a64199f7c6cafa192d01"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 61, 20);
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(15, 43);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 43);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getSupportUpperBound();
    double var52 = var47.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 9517.474048442906d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.9986805069326656d, (java.lang.Number)7.829777967556679E7d, (java.lang.Number)181812683989767776L);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     double var10 = var0.nextT(0.4573684520296781d);
//     var0.reSeedSecure((-56139359032789495L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian(0.3425019720115997d, (-0.0050643263516287895d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-121.91935650182825d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.01592063473958623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.1205051676684374d);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    double[] var8 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var10 = null;
    double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var10, var18);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var25 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var34, 88);
    double var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var34);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var45 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var46 = var45.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = var45.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var49 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var47, true);
    boolean var51 = org.apache.commons.math3.util.MathArrays.isMonotonic(var18, var47, false);
    double[] var55 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var59 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var63 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var59, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var55, var64);
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 88);
    double[] var71 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var75 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var71, var75);
    double[] var80 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var84 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var85 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var80, var84);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var75, var84);
    double[] var87 = null;
    boolean var88 = org.apache.commons.math3.util.MathArrays.equals(var84, var87);
    double[][] var89 = new double[][] { var84};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var64, var89);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var47, var89);
    org.apache.commons.math3.exception.NullArgumentException var92 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var89);
    org.apache.commons.math3.exception.NullArgumentException var93 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var89);
    org.apache.commons.math3.exception.MathArithmeticException var94 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var89);
    org.apache.commons.math3.exception.MathInternalError var95 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var89);
    org.apache.commons.math3.exception.MathInternalError var96 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed(100L);
    double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
    var2.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var17 = var2.nextSecureLong(6992985943769857466L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-334.73040418701044d));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 88);
    double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var23, var32);
    double[] var35 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double[][] var37 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var43 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
    double var53 = org.apache.commons.math3.util.MathArrays.distance1(var43, var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var52, 0.0d);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var55);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var15);
//     double[] var22 = null;
//     boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var8, var22);
//     double[] var25 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, 0.2344507198063365d);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     double var11 = var1.nextCauchy(2.197786777139258d, 0.018830280094064424d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextF((-0.9601111364018918d), 6356522.032707067d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.181597213034259d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.208991751817187d);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)66, var1, true);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     java.lang.Object var18 = null;
//     boolean var19 = var17.equals(var18);
//     org.apache.commons.math3.util.Pair var20 = new org.apache.commons.math3.util.Pair(var17);
//     org.apache.commons.math3.util.Pair var21 = new org.apache.commons.math3.util.Pair(var20);
//     java.lang.Object var22 = var20.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.22526909835657793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = null;
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    int[] var14 = new int[] { 100, 10, (-1)};
    var10.setSeed(var14);
    int[] var16 = new int[] { };
    var10.setSeed(var16);
    int[] var18 = null;
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var18);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 66);
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 0);
    var8.setSeed(var23);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 21);
    var1.setSeed(var25);
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.509158546181673E-9d, true);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    double[] var13 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[][] var15 = new double[][] { var13};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var4);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var22 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var31 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var32 = var31.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = var31.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var35 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var33, true);
    boolean var37 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var33, true);
    double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var22, var41);
    double[] var48 = null;
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var48, var56);
    double var59 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    double[] var63 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var67 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var63, var67);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var63);
    double var70 = org.apache.commons.math3.util.MathArrays.safeNorm(var63);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var63);
    double[] var73 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, 33.84123869527165d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var74 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var73);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var15);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    var47.reseedRandomGenerator((-1092428417482140062L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 'a'};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
//     org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.2796849f, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    java.lang.Throwable[] var1 = var0.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    java.lang.Object var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var4, (java.lang.Object)var8);
    var0.addSuppressed((java.lang.Throwable)var8);
    boolean var12 = var8.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1.0d+ "'", var9.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
    double[] var31 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var28, var31);
    double[] var36 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var28, var36);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var8, var28);
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var65);
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var28, var56);
    double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
    double[] var81 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var82 = org.apache.commons.math3.util.MathArrays.safeNorm(var81);
    double[][] var83 = new double[][] { var81};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var72, var83);
    double var85 = org.apache.commons.math3.util.MathArrays.safeNorm(var72);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeAdd(var28, var72);
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double[] var89 = org.apache.commons.math3.util.MathArrays.normalizeArray(var28, 0.6756233570174912d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.7702917311619408E23d, (java.lang.Number)0.03639122315246257d, false);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//     boolean var10 = var9.nextBoolean();
//     int var12 = var9.nextInt(65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 150.911402257192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 41);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.6128523808130044d, (-0.01498759451409439d), 10.099504938362077d, 0.5684335790811075d, 0.0d, (-1416.0671783870412d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5.716724961565759d);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     java.lang.String var8 = var2.nextSecureHexString(2);
//     double var11 = var2.nextGamma(0.08430081831437178d, 26.7909048614082d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("dc", "7155d402917702dfbfbc77");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "55"+ "'", var8.equals("55"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.44231465887983695d);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    long[] var9 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    long[][] var11 = new long[][] { var9};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var19 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.31568577999507896d, (java.lang.Number)22.44102686025421d, false);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    double var54 = var47.getSupportUpperBound();
    double var55 = var47.getNumericalVariance();
    double var56 = var47.getSupportLowerBound();
    double var59 = var47.probability(0.22166504688122088d, 1.3621815434775926d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1774884.4601956457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[][] var14 = new double[][] { var12};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var14);
    double[] var16 = null;
    double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var16, var24);
    double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var31);
    double var38 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var37);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var43 = var42.getStrict();
    boolean var44 = var42.getStrict();
    boolean var45 = var42.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = var42.getDirection();
    boolean var48 = org.apache.commons.math3.util.MathArrays.isMonotonic(var37, var46, false);
    double[] var49 = null;
    double[] var51 = new double[] { 10.0d};
    double[] var55 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var59 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var59);
    double[] var64 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var68 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var64, var68);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var59, var68);
    double[] var72 = org.apache.commons.math3.util.MathArrays.normalizeArray(var68, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var73 = null;
    java.lang.Object[] var75 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var76 = new org.apache.commons.math3.exception.MathInternalError(var73, var75);
    org.apache.commons.math3.util.Pair var77 = new org.apache.commons.math3.util.Pair((java.lang.Object)var72, (java.lang.Object)var73);
    double var78 = org.apache.commons.math3.util.MathArrays.distanceInf(var51, var72);
    org.apache.commons.math3.util.MathArrays.checkOrder(var51);
    double[] var81 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 0.3127635608371082d);
    double[] var83 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 0.5769815473378194d);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var83);
    boolean var85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)1L, var8);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var4, var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var3, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var8);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var1, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)8.722155002891563d, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     var12.reSeed();
//     int var16 = var12.nextZipf(18, 0.10832690038004085d);
//     double var18 = var12.nextT(11.36369913641775d);
//     int[] var21 = var12.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var9, (-848192168));
//       fail("Expected exception of type java.lang.NegativeArraySizeException");
//     } catch (java.lang.NegativeArraySizeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8006129148517891d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "97229285052c3832838046"+ "'", var4.equals("97229285052c3832838046"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.1012374517182915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 23);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
//     double[] var16 = null;
//     double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var16, var24);
//     double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
//     double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var31);
//     double[] var38 = null;
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var38, var46);
//     double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
//     double[] var53 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var57 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var61 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var57, var61);
//     double var63 = org.apache.commons.math3.util.MathArrays.distance1(var53, var62);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var62, 88);
//     double var66 = org.apache.commons.math3.util.MathArrays.distanceInf(var46, var62);
//     double[] var70 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var74 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var70, var74);
//     org.apache.commons.math3.random.RandomDataGenerator var76 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var79 = var76.nextInt(10, 100);
//     double var82 = var76.nextUniform((-1.0d), 1.0d);
//     var76.reSeedSecure();
//     org.apache.commons.math3.util.Pair var84 = new org.apache.commons.math3.util.Pair((java.lang.Object)var75, (java.lang.Object)var76);
//     double[] var85 = org.apache.commons.math3.util.MathArrays.ebeAdd(var46, var75);
//     boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var75);
//     double var87 = org.apache.commons.math3.util.MathArrays.distance1(var15, var75);
//     double[] var88 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     double[] var89 = null;
//     double var90 = org.apache.commons.math3.util.MathArrays.distance(var88, var89);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var52 = var47.getSupportUpperBound();
    double var54 = var47.density((-19533.05988397774d));
    boolean var55 = var47.isSupportConnected();
    double var57 = var47.density(0.0d);
    double var59 = var47.inverseCumulativeProbability(0.9635745263191828d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 9705.882352941177d);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var5 = var3.nextT(0.1431715674774945d);
//     double var8 = var3.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var11 = var3.nextPermutation(83, 33);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     var1.setSeed(var12);
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 0);
//     int[] var19 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = org.apache.commons.math3.util.MathArrays.distance(var12, var19);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5892169629497175d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-2.8445398170181107d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3498134039179893E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     java.lang.String var13 = var10.nextHexString(86);
//     int var16 = var10.nextBinomial(44, 0.11681967467915401d);
//     double var18 = var10.nextExponential(0.543107492877348d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var20 = var10.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1897523839058597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "26e4a07232f0860ccb2942f48d46cd9c1fee0d136e9409be9d34d26d2bff744f3b2ff2bc6ce5076b0b1866"+ "'", var13.equals("26e4a07232f0860ccb2942f48d46cd9c1fee0d136e9409be9d34d26d2bff744f3b2ff2bc6ce5076b0b1866"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.36915937110970576d);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var14 = var2.nextCauchy(0.8364867927003998d, 2.755734400837643d);
//     double var17 = var2.nextBeta(0.021333908748968344d, 5842551.508144901d);
//     java.lang.String var19 = var2.nextSecureHexString(19);
//     double var22 = var2.nextWeibull(0.44887116257137516d, 9.451831387477975E12d);
//     var2.reSeed(4097752537538055884L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.6627999971503533d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.8384984424541218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "3289823721704c43400"+ "'", var19.equals("3289823721704c43400"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 7.371301706260508E11d);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var1.nextInt();
    int[] var6 = null;
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var11 = new int[] { 100, 10, (-1)};
    var7.setSeed(var11);
    int[] var13 = new int[] { };
    var7.setSeed(var13);
    int[] var15 = null;
    int var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var15);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 66);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 0);
    var1.setSeed(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1347491339));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.3980143371708322d, (java.lang.Number)2.755734400837643d, true);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 0.398 is larger than the maximum (2.756)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 0.398 is larger than the maximum (2.756)"));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    float[] var2 = new float[] { 0.0f, (-1.0f)};
    float[] var5 = new float[] { 0.0f, 100.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var5);
    float[] var7 = new float[] { };
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var5, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Object[] var12 = new java.lang.Object[] { true};
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var12);
    boolean var14 = var6.equals((java.lang.Object)var12);
    java.lang.Object var15 = var6.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(78);
//     java.lang.Object var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var7 = var6.getMin();
//     org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var2, (java.lang.Object)var6);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var14 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, var14);
//     boolean var16 = var8.equals((java.lang.Object)var14);
//     int[] var17 = null;
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
//     double var19 = var18.nextGaussian();
//     byte[] var21 = new byte[] { (byte)10};
//     var18.nextBytes(var21);
//     org.apache.commons.math3.random.RandomDataGenerator var23 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var18);
//     byte[] var25 = new byte[] { (byte)1};
//     var18.nextBytes(var25);
//     boolean var27 = var8.equals((java.lang.Object)var25);
//     var1.nextBytes(var25);
//     long var29 = var1.nextLong();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + 1.0d+ "'", var7.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.5231741506251779d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-2199134974129785394L));
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var6.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.96542301597492d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var53 = var47.cumulativeProbability(0.2080200843690793d, 7.500930705661022d);
    double var54 = var47.getSupportUpperBound();
    double var57 = var47.probability((-1.1982929092738202d), 2.755734400837643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     double var48 = var47.sample();
//     double var49 = var47.getSupportUpperBound();
//     var47.reseedRandomGenerator(14L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 9705.882352941177d);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var7 = var4.nextZipf(96, 1.1594185848885774E-9d);
//     var4.reSeedSecure(14L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var4.nextLong(1730706259609335040L, (-4605170805750505266L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.33328896373051653d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-7845390693883980325L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 92);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.7342126418328947d), (java.lang.Number)454.7733245704089d, false);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var9 = null;
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var9, var17);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var17, var24);
    double[] var34 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var34, var43);
    double var45 = org.apache.commons.math3.util.MathArrays.linearCombination(var30, var43);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var43);
    double[] var48 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, (-0.05559908654827428d));
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var65);
    double[] var68 = null;
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var65, var68);
    double[] var73 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var77 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var81 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var77, var81);
    double var83 = org.apache.commons.math3.util.MathArrays.distance1(var73, var82);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var65, var73);
    double[] var85 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var73);
    double[] var86 = org.apache.commons.math3.util.MathArrays.copyOf(var85);
    double var87 = org.apache.commons.math3.util.MathArrays.safeNorm(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-9896.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.14177446878757827d);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     double var10 = var0.nextT(0.4573684520296781d);
//     double var13 = var0.nextWeibull(2.5601423343889373d, 10.52791259447133d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform((-1.6280715749761139d), (-1.7453954223562798d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6032831388376801d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.4133459082982899E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.47404421132404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.515200852345993d);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.0047114012705982925d);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     long var13 = var9.nextPoisson(5117965.756713317d);
//     var9.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.06663240453975589d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5113320L);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var5 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var5);
    double[] var7 = null;
    double[] var11 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var15 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var11, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var7, var15);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    double[] var22 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 88);
    double var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var31);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var43 = var42.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var44 = var42.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var44, true);
    boolean var48 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var44, false);
    double[] var52 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
    double var62 = org.apache.commons.math3.util.MathArrays.distance1(var52, var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 88);
    double[] var68 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var72 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var68, var72);
    double[] var77 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var81 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var77, var81);
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var72, var81);
    double[] var84 = null;
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var81, var84);
    double[][] var86 = new double[][] { var81};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var61, var86);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var44, var86);
    org.apache.commons.math3.exception.NotFiniteNumberException var89 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-1.9948769173016636d), (java.lang.Object[])var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 0.7111154558159436d);
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double[] var16 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var20 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var11, var20);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var25 = null;
//     java.lang.Object[] var27 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var28 = new org.apache.commons.math3.exception.MathInternalError(var25, var27);
//     org.apache.commons.math3.util.Pair var29 = new org.apache.commons.math3.util.Pair((java.lang.Object)var24, (java.lang.Object)var25);
//     double[] var33 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var37 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var33, var37);
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var37, var46);
//     double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var46, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var51 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var24, var46);
//     boolean var52 = var51.isSupportConnected();
//     double var54 = var51.density((-30.443553573156947d));
//     double var55 = var51.getNumericalMean();
//     var51.reseedRandomGenerator((-509399413869688601L));
//     double var58 = var51.getSupportUpperBound();
//     double var59 = var51.getNumericalVariance();
//     double var60 = var51.getSupportLowerBound();
//     double var61 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var51);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var63 = var0.nextExponential((-5.718953743793954d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.24750258672946154d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1774884.4601956457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 9705.882352941177d);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, (-0.4628858931836466d), 0.4908024973580418d, 9705.882351513406d, (-0.5903111221322579d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4763.20841129294d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    java.lang.Number var3 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var9, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Object[])var5);
    java.lang.Number var13 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var20 = var19.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = var19.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var13, (java.lang.Number)0.8055186938534216d, 60, var21, true);
    boolean var25 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var21, true);
    java.lang.Number var26 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var32 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var33 = var32.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = var32.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var36 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var26, (java.lang.Number)0.8055186938534216d, 60, var34, true);
    boolean var38 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var34, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.1440400422066794d), (java.lang.Number)(-4.967808516060075d), 70, var34, false);
    java.lang.Number var41 = var40.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + (-4.967808516060075d)+ "'", var41.equals((-4.967808516060075d)));

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }


    float[] var0 = null;
    float[] var2 = new float[] { 10.0f};
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var8 = new float[] { 0.0f, 100.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
    float[] var13 = new float[] { (-1.0f), 1.0f};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var13);
    float[] var15 = new float[] { };
    float[] var18 = new float[] { 0.0f, (-1.0f)};
    float[] var21 = new float[] { 0.0f, 100.0f};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var21);
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var15, var18);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var2, var18);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var0, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextBinomial(0, 79558.81471209228d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-13785.386848083988d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 24L);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    boolean var5 = var3.equals((java.lang.Object)(short)(-1));
    java.lang.Object var6 = var3.getKey();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var3);
    java.lang.Object var8 = var7.getValue();
    java.lang.Object var9 = var7.getFirst();
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    double[] var19 = null;
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var19, var27);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var34);
    double[] var44 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var48 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var52 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var48, var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var44, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.linearCombination(var40, var53);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeAdd(var13, var53);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var13, (-0.05559908654827428d));
    boolean var59 = var7.equals((java.lang.Object)var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (short)(-1)+ "'", var9.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-9896.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 45);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.7561452518058729d));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)4.124408130986206d, (java.lang.Number)2.098007078947557d, false);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextWeibull(1.0252073473582036E-4d, 0.14521388384019507d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextWeibull(0.0d, 5.704309058613993d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(100.0d, 4.218937231588664d, 199.04522099261766d, 0.0d, 0.00861222729424549d, 358.15927791552303d, (-25.154249961380902d), (-0.9507563531917054d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 448.89383522837284d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    boolean var27 = var25.equals((java.lang.Object)"a4a6f352066b7548b4d7c47cf5559d666b60159c87b957dbc5689f93f1d156392a989d54aaac45f08cc029d");
    java.lang.Object var28 = var25.getSecond();
    java.lang.Object var29 = var25.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     java.lang.String var3 = var1.nextHexString(44);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextF((-0.08812772856076337d), 0.012115282842360003d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "2e6e12e75c080c7ac73e26bc2c563011d7d652312afd"+ "'", var3.equals("2e6e12e75c080c7ac73e26bc2c563011d7d652312afd"));
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var8 = var1.nextInt(18);
//     float var9 = var1.nextFloat();
//     int var11 = var1.nextInt(95);
//     long var12 = var1.nextLong();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.19822259547632215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9170532f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7990687926232058883L);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var52 = var47.probability(1.1995433318140165d);
    double var54 = var47.density((-1462729.2793687023d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var0.nextPermutation(0, 62);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.1232944503717746d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.253366688104259d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "6d94eb01a7f15d49bd1183e087e8b2321bfff1ff54b159a6d94598c904d687"+ "'", var12.equals("6d94eb01a7f15d49bd1183e087e8b2321bfff1ff54b159a6d94598c904d687"));
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)6.231264947207621d, (java.lang.Number)2.098007078947557d, false);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextWeibull(2.666606011498951d, 8.217285785081735d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.080677969422242d);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
//     double[][] var15 = new double[][] { var13};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var15);
//     boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var4);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     double[] var19 = null;
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var19);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    boolean var54 = var47.isSupportUpperBoundInclusive();
    var47.reseedRandomGenerator(9L);
    double[] var58 = var47.sample(97);
    double var60 = var47.inverseCumulativeProbability(0.2665124189813681d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 9705.882351267377d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 3.7512412731960527d, 0.0d, (-0.04211151663022905d), 1.7191379869897692E-5d, 1.5379104635140908d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.6438802984161168E-5d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    int var10 = var2.nextHypergeometric(87, 55, 86);
    var2.reSeedSecure();
    int var14 = var2.nextPascal(16, 1.6445632382959425E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2147483647);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var12 = var10.nextPoisson(1.327000036267693d);
//     double var15 = var10.nextUniform((-0.6509646211185096d), 0.020711320705185013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9510726758454745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.5294051648965188d));
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     double var1 = var0.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.6931598121030484d);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)100L, (java.lang.Number)(-1L), (java.lang.Number)0.1431715674774945d);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)var11);
    org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair(var12);
    boolean var14 = var2.equals((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var9, var13);
    double[] var23 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var31 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var27, var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var23, var32);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var32, 0.0d);
    double[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var9, var32);
    double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var9, 2784.9275671086507d);
    double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var9, 0.11433830816137684d);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(4, 26);
//     var0.reSeed(5507950371326924800L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextGaussian(0.0d, (-0.9866057353036886d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 25);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var1.nextT(0.1431715674774945d);
//     double var6 = var1.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var9 = var1.nextPermutation(83, 33);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
//     int[] var11 = null;
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
//     double var13 = var12.nextGaussian();
//     int[] var16 = new int[] { 0, 1};
//     var12.setSeed(var16);
//     double var18 = var12.nextGaussian();
//     var12.clear();
//     org.apache.commons.math3.random.RandomDataImpl var20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
//     long var22 = var20.nextPoisson(0.6989809774046034d);
//     long var24 = var20.nextPoisson(0.9304525547601544d);
//     double[] var28 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var28, var37);
//     org.apache.commons.math3.util.Pair var39 = new org.apache.commons.math3.util.Pair((java.lang.Object)var24, (java.lang.Object)var28);
//     double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
//     double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
//     double[] var58 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var47, var56);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var47, 21.869847397459292d);
//     double[] var65 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var69 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var70 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var65, var69);
//     double[] var74 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
//     double[][] var76 = new double[][] { var74};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var65, var76);
//     org.apache.commons.math3.exception.NotFiniteNumberException var78 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var76);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var60, var76);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var80 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var10, var28, var60);
//     double[] var81 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var28);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)6.813639406926573E-7d, (java.lang.Number)4979382.8531437665d, false);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     long var13 = var9.nextPoisson(0.9304525547601544d);
//     double[] var17 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
//     org.apache.commons.math3.util.Pair var28 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var17);
//     org.apache.commons.math3.util.Pair var29 = new org.apache.commons.math3.util.Pair(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.7597387624790177d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 223.0d);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(22, 18);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 18);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.6961371316133027d, 0.6218765702520308d, (-4.223479475728832d), 0.543107492877348d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.2390154071972241d));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var7 = var6.getSecond();
    java.lang.Object var8 = var6.getValue();
    boolean var9 = var3.equals((java.lang.Object)var6);
    java.lang.Object var10 = var6.getKey();
    java.lang.Object var11 = var6.getSecond();
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var13 = var6.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0d+ "'", var7.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0d+ "'", var8.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)100+ "'", var10.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 10.0d+ "'", var11.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextInt(0, 100);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var0.nextPermutation(53, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 88010.68647110916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.267191653786546E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 62);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.setSeed(17);
    int var5 = var1.nextInt(53);
    float var6 = var1.nextFloat();
    var1.setSeed(13L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.33336878f);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var17);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.normalizeArray(var17, 9900.0d);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
//     double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
//     double var41 = org.apache.commons.math3.util.MathArrays.distance1(var31, var35);
//     double[] var42 = null;
//     double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
//     boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var42, var50);
//     double var53 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
//     double[] var57 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var61 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var57, var61);
//     double[] var63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var50, var57);
//     boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var35, var57);
//     boolean var65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var57);
//     double[] var66 = null;
//     double[] var70 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var74 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var70, var74);
//     boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var66, var74);
//     double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
//     double[] var81 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var85 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var86 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var81, var85);
//     double[] var87 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var74, var81);
//     double[] var88 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var57, var81);
//     boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var0, var57);
//     double[] var90 = null;
//     double var91 = org.apache.commons.math3.util.MathArrays.distance(var57, var90);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     var6.reSeed(14L);
//     double var13 = var6.nextCauchy((-37807.751602013566d), 1.0510230604516366d);
//     var6.reSeedSecure();
//     java.lang.String var16 = var6.nextHexString(73);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var6.nextSample(var17, 0);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var5 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var14 = var13.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = var13.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var15, true);
//     boolean var19 = org.apache.commons.math3.util.MathArrays.isMonotonic(var4, var15, true);
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var23);
//     double[] var33 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var37 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var41 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var42 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var37, var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance1(var33, var42);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var42, 88);
//     double[] var49 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var53 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var49, var53);
//     double[] var58 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var62 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var63 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var58, var62);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var53, var62);
//     double[] var65 = null;
//     boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var62, var65);
//     double[][] var67 = new double[][] { var62};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var42, var67);
//     double var69 = org.apache.commons.math3.util.MathArrays.safeNorm(var42);
//     double[] var73 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var77 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var81 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var82 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var77, var81);
//     double var83 = org.apache.commons.math3.util.MathArrays.distance1(var73, var82);
//     double[] var85 = org.apache.commons.math3.util.MathArrays.normalizeArray(var82, 0.0d);
//     boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var85);
//     double var87 = org.apache.commons.math3.util.MathArrays.linearCombination(var23, var42);
//     double[] var88 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
//     double[] var89 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var0, var88);
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     int var14 = var0.nextInt(0, 14);
//     int var17 = var0.nextSecureInt(0, 43);
//     java.lang.String var19 = var0.nextHexString(31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.37594772250202135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "082b4df2584819324bf9bf381f4962ac5844bec11b693a0e6b49e953a26278639d2e026a2227c8ea7ce389a"+ "'", var8.equals("082b4df2584819324bf9bf381f4962ac5844bec11b693a0e6b49e953a26278639d2e026a2227c8ea7ce389a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20.421980900845956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "43a3bfde8a0c7fc1cd7e575c3799676"+ "'", var19.equals("43a3bfde8a0c7fc1cd7e575c3799676"));
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var14 = var2.nextGamma(1.22705655817319d, 1.487086298741032E-9d);
//     var2.reSeed();
//     long var18 = var2.nextLong(0L, 212521969303929120L);
//     var2.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.4363699300879357d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.4907274832091147E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 30471231430370696L);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     long var10 = var6.nextPoisson(1.3431861837677899d);
//     var6.reSeedSecure(179L);
//     java.lang.String var14 = var6.nextSecureHexString(83);
//     int var17 = var6.nextInt(44, 85);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var6.nextBinomial(22, (-142.64153380658698d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.2536099458099861d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "6af3b13020137984f6d247b82aa9a7a6a99fe00370c38452b461986293f7ac178474345f69330b04891"+ "'", var14.equals("6af3b13020137984f6d247b82aa9a7a6a99fe00370c38452b461986293f7ac178474345f69330b04891"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 57);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     long var12 = var2.nextSecureLong(14L, 24L);
//     var2.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var2.nextF((-0.1347493249251439d), (-1.7342126418328947d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "e0533b029b53cb7752a919ba9b36c"+ "'", var9.equals("e0533b029b53cb7752a919ba9b36c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 15L);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
//     double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     org.apache.commons.math3.random.RandomDataGenerator var38 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var41 = var38.nextInt(10, 100);
//     double var44 = var38.nextUniform((-1.0d), 1.0d);
//     var38.reSeedSecure();
//     org.apache.commons.math3.util.Pair var46 = new org.apache.commons.math3.util.Pair((java.lang.Object)var37, (java.lang.Object)var38);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var37);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double[] var60 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var60);
//     double[][] var62 = new double[][] { var60};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var51, var62);
//     double var64 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
//     double[] var68 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 88);
//     double[] var81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var77);
//     double[] var82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var37, var51);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.util.MathArrays.checkOrder(var51);
//       fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
//     } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-0.21447713276246638d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 10.099504938362077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1.7320508075688772d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(11);
    boolean var2 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var6 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    long[][] var8 = new long[][] { var6};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)3.4785048692046914d, (java.lang.Object[])var8);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     int var7 = var0.nextInt(0, 100);
//     int var11 = var0.nextHypergeometric(39, 15, 31);
//     double var14 = var0.nextF(9517.474048442906d, 4813.795537938105d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextSecureInt(27, 5);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.079904488445383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9401403688309904d);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)63504.196447431874d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }


    float[] var0 = null;
    float[] var1 = null;
    float[] var3 = new float[] { 10.0f};
    float[] var6 = new float[] { 0.0f, (-1.0f)};
    float[] var9 = new float[] { 0.0f, 100.0f};
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var9);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var3, var9);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var1, var3);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
    float[] var14 = null;
    float[] var16 = new float[] { 10.0f};
    float[] var19 = new float[] { 0.0f, (-1.0f)};
    float[] var22 = new float[] { 0.0f, 100.0f};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var16, var22);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var14, var16);
    float[] var28 = new float[] { 0.0f, (-1.0f)};
    float[] var31 = new float[] { 0.0f, 100.0f};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var31);
    float[] var33 = null;
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var31, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var33);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var14 = var0.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     var0.reSeedSecure();
//     int[] var18 = var0.nextPermutation(94, 25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextBinomial(23, (-0.4148741153049867d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.331860534539502d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.2489601232073776E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.4924187586890005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.08472240376109232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     boolean var10 = var1.nextBoolean();
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
//     var13.reSeed();
//     int var17 = var13.nextZipf(18, 0.10832690038004085d);
//     double var19 = var13.nextT(11.36369913641775d);
//     int[] var22 = var13.nextPermutation(33, 31);
//     int[] var23 = null;
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
//     int[] var28 = new int[] { 100, 10, (-1)};
//     var24.setSeed(var28);
//     int[] var30 = new int[] { };
//     var24.setSeed(var30);
//     int[] var32 = null;
//     int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var32);
//     int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 66);
//     int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
//     int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 44);
//     int var39 = org.apache.commons.math3.util.MathArrays.distance1(var22, var35);
//     var1.setSeed(var35);
//     org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var43 = null;
//     org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(var43);
//     int[] var48 = new int[] { 100, 10, (-1)};
//     var44.setSeed(var48);
//     int[] var50 = new int[] { };
//     var44.setSeed(var50);
//     int[] var52 = null;
//     int var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var50, var52);
//     int[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 66);
//     int[] var57 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 0);
//     var42.setSeed(var57);
//     int[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var57);
//     int[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var59, 21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var35, var61);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.586387747005711d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 487);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var8.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.33191851469254335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 54);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 99.04039579888602d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed(100L);
    double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
    double var15 = var2.nextWeibull(2.2419551077422692d, 0.8055186938534216d);
    double var17 = var2.nextChiSquare(68.58227366955163d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-334.73040418701044d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.6283537634336418d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 76.26635650433543d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(65, 28);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.045867076597532204d, (java.lang.Number)(-3.3532188936284664E13d), true);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextHypergeometric(30, 82, 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4085879392202707d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1a946e56f6e0eb13d32df3a076c6b584d82c3ae24711141c7c528511b54713d216a079c94737ed9c4635e43"+ "'", var8.equals("1a946e56f6e0eb13d32df3a076c6b584d82c3ae24711141c7c528511b54713d216a079c94737ed9c4635e43"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 13.653998664210334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 62);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    java.lang.Object var7 = var6.getValue();
    boolean var9 = var6.equals((java.lang.Object)3.367537023715106d);
    java.lang.Object var10 = var6.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.038131683497646396d, (java.lang.Number)0.21548915f, true);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var10 = var0.nextF(102.0d, 9900.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric(19, 10, (-1347491339));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.4906181951789677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.06131929979775567d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8402050572693673d);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)100.0f, (java.lang.Number)(-64.64786300193721d), true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var14 = var2.nextCauchy(0.8364867927003998d, 2.755734400837643d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("83", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9592411005871491d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-24.10049215669652d));
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 10};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9304525547601544d, (java.lang.Number)(-1612642752), false);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)103.56915419683993d, (-1), var3, true);
    int var6 = var5.getIndex();
    boolean var7 = var5.getStrict();
    int var8 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var8.nextExponential(0.6012895846489683d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var13 = var8.nextSecureLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.9354117217009348d);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test326"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeed();
//     double var10 = var0.nextCauchy(0.0d, 0.0427783828805389d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(1.697156835772471d, (-0.2769976643007776d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.0019886865033334716d));
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test327"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     int[] var15 = var0.nextPermutation(43, 10);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var18);
//     var19.reSeed();
//     int var23 = var19.nextZipf(18, 0.10832690038004085d);
//     double var25 = var19.nextT(11.36369913641775d);
//     int[] var28 = var19.nextPermutation(33, 31);
//     int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 0);
//     int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 55);
//     double var33 = org.apache.commons.math3.util.MathArrays.distance(var16, var32);
//     int[] var34 = null;
//     org.apache.commons.math3.random.Well19937c var35 = new org.apache.commons.math3.random.Well19937c(var34);
//     double var36 = var35.nextGaussian();
//     int[] var39 = new int[] { 0, 1};
//     var35.setSeed(var39);
//     org.apache.commons.math3.random.RandomDataGenerator var41 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var35);
//     org.apache.commons.math3.random.RandomDataImpl var42 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var35);
//     int[] var45 = new int[] { 1, 0};
//     int[] var46 = null;
//     org.apache.commons.math3.random.Well19937c var47 = new org.apache.commons.math3.random.Well19937c(var46);
//     double var48 = var47.nextGaussian();
//     int[] var51 = new int[] { 0, 1};
//     var47.setSeed(var51);
//     double var53 = org.apache.commons.math3.util.MathArrays.distance(var45, var51);
//     int[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var51);
//     int[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var54, 98);
//     var35.setSeed(var54);
//     org.apache.commons.math3.random.RandomDataGenerator var58 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var61 = var58.nextInt(10, 100);
//     double var63 = var58.nextExponential(10.0d);
//     double var65 = var58.nextExponential(0.407741687198951d);
//     var58.reSeed();
//     int var70 = var58.nextHypergeometric(75, 0, 3);
//     int[] var73 = var58.nextPermutation(43, 10);
//     int var74 = org.apache.commons.math3.util.MathArrays.distance1(var54, var73);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var75 = org.apache.commons.math3.util.MathArrays.distance(var32, var73);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 16.95157540830207d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.13421303121959102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.07537536726360398d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 89.65489389877163d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.5438028050290115d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-0.224990704031801d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1.4142135623730951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 6.2817810021263565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 0.728048653380705d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 7);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test328"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var1, true);
//     java.lang.Number var4 = var3.getMin();
//     boolean var5 = var3.getBoundIsAllowed();
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double var8 = var7.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var11 = var9.nextT(0.1431715674774945d);
//     double var14 = var9.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var17 = var9.nextPermutation(83, 33);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     var7.setSeed(var18);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 0);
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var21);
//     org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var21);
//     int[] var24 = null;
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
//     double var26 = var25.nextGaussian();
//     byte[] var28 = new byte[] { (byte)10};
//     var25.nextBytes(var28);
//     org.apache.commons.math3.random.RandomDataGenerator var30 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var25);
//     byte[] var32 = new byte[] { (byte)1};
//     var25.nextBytes(var32);
//     var23.nextBytes(var32);
//     float var35 = var23.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5164030806457092d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-7.327182109143085E12d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.041890666530442995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.4674738597395427d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.88943887f);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test329"); }


    double[] var6 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var10 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var11 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var10);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var10, var19);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, 9900.0d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var27 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var28 = var27.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = var27.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = var27.getDirection();
    boolean var32 = org.apache.commons.math3.util.MathArrays.isMonotonic(var23, var30, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var34 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5650594787118064d, (java.lang.Number)1.524696304927174d, 0, var30, true);
    boolean var35 = var34.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test330"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 12, 33);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test331"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.String var1 = var0.toString();
    java.lang.Throwable[] var2 = var0.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.MathIllegalStateException: illegal state"+ "'", var1.equals("org.apache.commons.math3.exception.MathIllegalStateException: illegal state"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test332"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)"bcb82b93dec11999aad154f12a1702198c9dac1065701809392c824b74ef0b906696604b558e79370bc4b2d0ba967bc", var1);
    java.lang.Object var3 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     double var13 = var0.nextExponential(0.1431715674774945d);
//     var0.reSeed();
//     int var17 = var0.nextZipf(25, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextWeibull((-1.5292628765521852d), 6306020.951293601d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.009147548116849702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8f11b60df755cc7147e96595d77e9c696f17e994af65eaadc8ed19373a4aac58af39fe83f67e5fd01426d49"+ "'", var8.equals("8f11b60df755cc7147e96595d77e9c696f17e994af65eaadc8ed19373a4aac58af39fe83f67e5fd01426d49"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-11.524280697778488d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.07738864496385947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test334"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getSupportLowerBound();
    double[] var53 = var47.sample(7);
    double var54 = var47.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1774884.4601956457d);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextWeibull(6.785854381629338d, 4736077.9249220705d);
//     double var20 = var0.nextChiSquare(0.4188489407275768d);
//     var0.reSeed(0L);
//     long var25 = var0.nextSecureLong(12L, 100L);
//     java.util.Collection var26 = null;
//     java.lang.Object[] var28 = var0.nextSample(var26, 47);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test336"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    java.lang.Number var5 = var3.getPrevious();
    java.lang.String var6 = var3.toString();
    int var7 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0f+ "'", var5.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var6.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test337"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(88);
//     var1.setSeed(0L);
//     int[] var7 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var7);
//     int[] var10 = null;
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
//     int[] var15 = new int[] { 100, 10, (-1)};
//     var11.setSeed(var15);
//     int[] var17 = new int[] { };
//     var11.setSeed(var17);
//     org.apache.commons.math3.random.RandomDataGenerator var19 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var11);
//     byte[] var22 = new byte[] { (byte)100, (byte)(-1)};
//     var11.nextBytes(var22);
//     var9.nextBytes(var22);
//     var1.nextBytes(var22);
//     int[] var26 = null;
//     org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var26);
//     double var28 = var27.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var29 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var31 = var29.nextT(0.1431715674774945d);
//     double var34 = var29.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var37 = var29.nextPermutation(83, 33);
//     int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var37);
//     var27.setSeed(var38);
//     var27.clear();
//     int[] var41 = null;
//     org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var41);
//     int[] var46 = new int[] { 100, 10, (-1)};
//     var42.setSeed(var46);
//     int[] var48 = new int[] { };
//     var42.setSeed(var48);
//     org.apache.commons.math3.random.RandomDataImpl var50 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var42);
//     boolean var51 = var42.nextBoolean();
//     var42.setSeed((-3200518016629555151L));
//     int[] var54 = null;
//     org.apache.commons.math3.random.Well19937c var55 = new org.apache.commons.math3.random.Well19937c(var54);
//     int[] var59 = new int[] { 100, 10, (-1)};
//     var55.setSeed(var59);
//     int[] var61 = new int[] { };
//     var55.setSeed(var61);
//     org.apache.commons.math3.random.RandomDataGenerator var63 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var55);
//     byte[] var66 = new byte[] { (byte)100, (byte)(-1)};
//     var55.nextBytes(var66);
//     var42.nextBytes(var66);
//     var27.nextBytes(var66);
//     var1.nextBytes(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.04331867628029151d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-2.307987183853192d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1.1789142398678598E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test338"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getSupportLowerBound();
    double[] var53 = var47.sample(7);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 318);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeed();
//     java.lang.String var11 = var0.nextSecureHexString(83);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextSecureLong(0L, (-1092428417482140062L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-385.7699017099769d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.599318699317034E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.7295538263135803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "03b3d84c4aad05145f8c3d46d636eb43cd934dd6c748034be3af6dfc88fc3dcdfad0d7ee9f36c08fbe2"+ "'", var11.equals("03b3d84c4aad05145f8c3d46d636eb43cd934dd6c748034be3af6dfc88fc3dcdfad0d7ee9f36c08fbe2"));
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test340"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     long var12 = var2.nextSecureLong(14L, 24L);
//     double var15 = var2.nextCauchy(0.0d, 6.785854381629338d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var2.nextBeta((-0.5656549367602338d), 0.8761303575900902d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "922f2d17439f9604ddec1e8bf9ab9"+ "'", var9.equals("922f2d17439f9604ddec1e8bf9ab9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 23L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-7.247207337058009d));
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test341"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)1L, var9);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, var9);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var4, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.7493393541476548d, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.18229160718674411d, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test342"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var26, var35);
    double[] var38 = null;
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var35, var38);
    double[] var43 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
    double var53 = org.apache.commons.math3.util.MathArrays.distance1(var43, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var35, var43);
    double[] var55 = null;
    double[] var59 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var63 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var59, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var55, var63);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var63);
    double[] var70 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var74 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var70, var74);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var63, var70);
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var43, var70);
    double var78 = org.apache.commons.math3.util.MathArrays.safeNorm(var70);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 101.99509792141973d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test343"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    int[] var9 = null;
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    org.apache.commons.math3.util.Pair var16 = new org.apache.commons.math3.util.Pair((java.lang.Object)0, (java.lang.Object)1.6445632382959425E-9d);
    java.lang.Object var17 = var16.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 1.6445632382959425E-9d+ "'", var17.equals(1.6445632382959425E-9d));

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test344"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextChiSquare((-1.1342587622980802d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test345"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    var2.reSeedSecure(7L);
    long var10 = var2.nextLong(374001257020227328L, 508515618537942016L);
    double var12 = var2.nextExponential(24.15687141640004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 460278515774591104L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.7276839739173364d);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var13 = var0.nextExponential(103.56915419683993d);
//     double var16 = var0.nextGamma(0.31568577999507896d, 0.5960140519829674d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextBeta((-0.09860007964583915d), (-0.21490689726247014d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7134766695725703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.2673831682362362d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.1669977493880568d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 80.06506422588772d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.4788775675653849d);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test347"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-2.9581954732912705d));

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test348"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 59, 94);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.8560295214393543d, (java.lang.Number)2.6467807810289345d, (java.lang.Number)9673.110537554716d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test350"); }


    java.lang.Comparable[] var4 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var8, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var11, false);
    double[] var17 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var26 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var27 = var26.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = var26.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var30 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var28, true);
    boolean var32 = org.apache.commons.math3.util.MathArrays.isMonotonic(var17, var28, true);
    boolean var34 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var28, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var36 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5769815473378194d, (java.lang.Number)11, 30, var28, false);
    java.lang.Throwable[] var37 = var36.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test351"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var7 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var9 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)3.4785048692046914d, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test352"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(25);
//     double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
//     double[] var17 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var21 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var17, var21);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var12, var21);
//     double[] var25 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     java.lang.Object[] var28 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var26, var28);
//     org.apache.commons.math3.util.Pair var30 = new org.apache.commons.math3.util.Pair((java.lang.Object)var25, (java.lang.Object)var26);
//     double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
//     double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var38, var47);
//     double[] var51 = org.apache.commons.math3.util.MathArrays.normalizeArray(var47, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var52 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var25, var47);
//     boolean var53 = var52.isSupportConnected();
//     double var55 = var52.density((-30.443553573156947d));
//     var52.reseedRandomGenerator((-3200518016629555151L));
//     double var58 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var52);
//     double var60 = var52.cumulativeProbability(0.6311099675418692d);
//     double var61 = var52.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.3222145808573507E7d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1a22a232a9f585766e4a31384"+ "'", var4.equals("1a22a232a9f585766e4a31384"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 9705.882351314169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 9517.474048442906d);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test353"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.17069745843135298d, (java.lang.Number)1.8442982820289943E7d, false);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test354"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.018830280094064424d, (java.lang.Number)0.045405984f, true);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("769fe0036e", "4c6860fbc64b1a5f7bc32cf4ad96d090bd675000a5f44f3321fa668d2b7820a436c2e54f6857821667cd5af6");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8398087853543506d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1cab24b80b2a81f8c5a784a029a21933148b0a952c68e7720e2c09a9ec8e0125c4e1f4007b6dae9972c403a"+ "'", var8.equals("1cab24b80b2a81f8c5a784a029a21933148b0a952c68e7720e2c09a9ec8e0125c4e1f4007b6dae9972c403a"));
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test356"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     double var11 = var2.nextT(81.560782738241d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextBinomial(18, 3.3718048487453802d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "660d63d41b674a1af0c85188f3ca3"+ "'", var9.equals("660d63d41b674a1af0c85188f3ca3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.7110563084721201d));
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test357"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var11 = var0.nextUniform((-0.4148741153049867d), (-0.19811647941323907d), false);
//     double var13 = var0.nextT(3.4785048692046914d);
//     var0.reSeedSecure(179L);
//     long var18 = var0.nextSecureLong(11L, 2585270482073165824L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.23259330864049d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.6332824900977948d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.39922864172230094d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1519138336492716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1806912871407335936L);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test358"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var5 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var14 = var13.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = var13.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var15, true);
//     boolean var19 = org.apache.commons.math3.util.MathArrays.isMonotonic(var4, var15, true);
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var4, var28);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var33 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     java.lang.Number var34 = var33.getPrevious();
//     java.lang.Number var35 = var33.getArgument();
//     java.lang.Number var36 = var33.getPrevious();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var37 = var33.getDirection();
//     boolean var39 = org.apache.commons.math3.util.MathArrays.isMonotonic(var28, var37, false);
//     double var40 = org.apache.commons.math3.util.MathArrays.distance(var0, var28);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test359"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)103.56915419683993d, (-1), var3, true);
    int var6 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var8 = null;
    java.lang.Comparable[] var10 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var11, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var14, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, (java.lang.Object[])var10);
    java.lang.String var19 = var5.toString();
    boolean var20 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -2 and -1 are not strictly decreasing (103.569 <= null)"+ "'", var19.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -2 and -1 are not strictly decreasing (103.569 <= null)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test360"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, (java.lang.Number)1L, (java.lang.Number)0);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getHi();
    java.lang.Number var8 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0+ "'", var6.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0+ "'", var7.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0+ "'", var8.equals(0));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test361"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)6.785854381629338d, 58);
    java.lang.Number var4 = var3.getPrevious();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var3.getDirection();
    int var7 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 6.785854381629338d+ "'", var4.equals(6.785854381629338d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 58);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test362"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    boolean var5 = var3.getStrict();
    boolean var6 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var3.getDirection();
    int var8 = var3.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var3.getDirection();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test363"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var9 = var6.nextLong(1L, 5804136433509186560L);
//     int var12 = var6.nextZipf(82, 1.182480876835637d);
//     long var15 = var6.nextLong(1806912871407335936L, 7030608607747463866L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.4523170714609886d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4480418217597325824L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1919570930604823808L);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test364"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     var6.reSeed(14L);
//     double var13 = var6.nextCauchy((-37807.751602013566d), 1.0510230604516366d);
//     var6.reSeedSecure();
//     java.lang.String var16 = var6.nextHexString(73);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var19 = var6.nextPermutation(301405723, (-690853845));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.3082404402070716d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-37811.76303061528d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "128ed5c83776160d5c367c693ab2045ddb12c77b8096115d2235c49c11fe921ac37522a62"+ "'", var16.equals("128ed5c83776160d5c367c693ab2045ddb12c77b8096115d2235c49c11fe921ac37522a62"));
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeed();
//     java.lang.String var11 = var0.nextSecureHexString(83);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(7530142578955372636L, 2258418083910485966L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2626.690924176487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.11858393563838596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6347394040585459d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "bc8e5d6ee9486ddd6eb000e089c90048d7dabc5357af6615e01f9ca0952c1e816959c8d98d42cf83fbe"+ "'", var11.equals("bc8e5d6ee9486ddd6eb000e089c90048d7dabc5357af6615e01f9ca0952c1e816959c8d98d42cf83fbe"));
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test366"); }
// 
// 
//     org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(22, 18);
//     org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
//     java.lang.Number var4 = var2.getArgument();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(100);
//     var6.clear();
//     var6.setSeed(1L);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
//     var10.reSeedSecure(2563274223793255424L);
//     org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var10);
//     long var16 = var10.nextSecureLong((-210809944227644864L), 27192867108684266L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var10.nextSecureLong(7030608607747463866L, 7030608607747463866L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + 22+ "'", var4.equals(22));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-206667759001548544L));
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     double var13 = var0.nextExponential(0.1431715674774945d);
//     var0.reSeed();
//     double var16 = var0.nextChiSquare(1.934238008197349E-9d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextZipf(9, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.518353197557067d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "993eebc26a9d77da0bba9c6b64383d9907dfccb87aa480a9479109aa72e60227a83b367fd75acb5043e0b32"+ "'", var8.equals("993eebc26a9d77da0bba9c6b64383d9907dfccb87aa480a9479109aa72e60227a83b367fd75acb5043e0b32"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.080418648871042d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.23410937247866004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     long var18 = var0.nextLong(0L, 12L);
//     double var21 = var0.nextBeta(0.4429300278176235d, 23.255333405607846d);
//     var0.reSeedSecure(7765006300557716338L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.20851500973744d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2214853058609145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "71713b6c980e4ce42b68fdaac32280ac2ce4a7011b4bd72dee49cee3769b2a"+ "'", var12.equals("71713b6c980e4ce42b68fdaac32280ac2ce4a7011b4bd72dee49cee3769b2a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0024004543037950076d);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test369"); }


    long[] var3 = new long[] { 0L, 100L, (-1L)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test370"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     int[] var9 = null;
//     int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var7);
//     int[] var14 = null;
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
//     int[] var19 = new int[] { 100, 10, (-1)};
//     var15.setSeed(var19);
//     int[] var21 = new int[] { };
//     var15.setSeed(var21);
//     double var23 = org.apache.commons.math3.util.MathArrays.distance(var7, var21);
//     org.apache.commons.math3.random.RandomDataImpl var24 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var26 = var24.nextT(0.1431715674774945d);
//     double var29 = var24.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var32 = var24.nextPermutation(83, 33);
//     int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
//     int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
//     double var35 = org.apache.commons.math3.util.MathArrays.distance(var21, var34);
//     org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-1.1508302345324257d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.017638629970939526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.0d);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test371"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.1583894735230253d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test372"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var12 = var9.nextPermutation(66, 20);
    double var15 = var9.nextBeta(4.124408130986206d, 1.8727261569983433d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var9.nextCauchy(0.3398307785317276d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5237619704844522d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextInt(0, 100);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextLong(4582272873445202432L, 2L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-571.7564834419142d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.9239670595101046E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 20);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test374"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    double var54 = var47.getSupportUpperBound();
    double var55 = var47.getNumericalVariance();
    double var56 = var47.getSupportLowerBound();
    double[] var58 = var47.sample(60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var61 = var47.cumulativeProbability(0.0026224007688764057d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1774884.4601956457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test375"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 21, 0);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     double var9 = var1.nextT(223.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextHypergeometric(61, 78, 663);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.1637963663544473d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2.7361258212475272d));
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test377"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-161.3169897931843d), (java.lang.Number)98, 86);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test378"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test379"); }
// 
// 
//     int[] var2 = new int[] { 1, 0};
//     int[] var3 = null;
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     double var5 = var4.nextGaussian();
//     int[] var8 = new int[] { 0, 1};
//     var4.setSeed(var8);
//     double var10 = org.apache.commons.math3.util.MathArrays.distance(var2, var8);
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 98);
//     int[] var14 = null;
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
//     int[] var19 = new int[] { 100, 10, (-1)};
//     var15.setSeed(var19);
//     int[] var21 = new int[] { };
//     var15.setSeed(var21);
//     int[] var23 = null;
//     int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance(var11, var23);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test380"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.9999999989253456d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test381"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.4276096462825826E-9d, (java.lang.Number)0.1431715674774945d, true);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.1431715674774945d+ "'", var5.equals(0.1431715674774945d));

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test382"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     long var13 = var9.nextPoisson(0.9304525547601544d);
//     double[] var17 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
//     org.apache.commons.math3.util.Pair var28 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var17);
//     java.lang.Object var29 = var28.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.31256173992139125d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test383"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
//     double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     org.apache.commons.math3.random.RandomDataGenerator var38 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var41 = var38.nextInt(10, 100);
//     double var44 = var38.nextUniform((-1.0d), 1.0d);
//     var38.reSeedSecure();
//     org.apache.commons.math3.util.Pair var46 = new org.apache.commons.math3.util.Pair((java.lang.Object)var37, (java.lang.Object)var38);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var37);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double[] var60 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var60);
//     double[][] var62 = new double[][] { var60};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var51, var62);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var37, var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0.8197151370980817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 10.099504938362077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test384"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var19 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var24 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var24, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var16, var24);
    java.lang.Number var36 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var39 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var36, (java.lang.Number)(byte)100, 69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = var39.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var24, var40, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test385"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.05672318083457417d, (java.lang.Number)(-0.7178347843564555d), true);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test386"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var17, var26);
    double[] var30 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var31 = null;
    java.lang.Object[] var33 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var34 = new org.apache.commons.math3.exception.MathInternalError(var31, var33);
    org.apache.commons.math3.util.Pair var35 = new org.apache.commons.math3.util.Pair((java.lang.Object)var30, (java.lang.Object)var31);
    double[] var39 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var43 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var43);
    double[] var48 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var52 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var48, var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var43, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.normalizeArray(var52, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var57 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var30, var52);
    boolean var58 = var57.isSupportConnected();
    double var60 = var57.density((-30.443553573156947d));
    double var61 = var57.getNumericalMean();
    double var63 = var57.density(0.0d);
    double[] var65 = var57.sample(95);
    double var66 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 9705.882351723583d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test387"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)14, (java.lang.Number)54745.822302454384d, true);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test388"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)1L, var6);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var2, var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, var6);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test389"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     var2.reSeed(100L);
//     double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
//     double var15 = var2.nextWeibull(2.2419551077422692d, 0.8055186938534216d);
//     var2.reSeedSecure();
//     org.apache.commons.math3.distribution.IntegerDistribution var17 = null;
//     int var18 = var2.nextInversionDeviate(var17);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test390"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var38 = null;
    double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var38, var46);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var53);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var31, var53);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double[][] var62 = new double[][] { var31};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var62);
    double[] var65 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, (-0.9451161353496818d));
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 58);
    double[] var69 = org.apache.commons.math3.util.MathArrays.copyOf(var67, 84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test391"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     double var48 = var47.sample();
//     double var49 = var47.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 97.05882352941177d);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test392"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-1416.0671783870412d), 89439.3517567197d, 4.8065019061902365d, 712.9249743109224d, 0.5684335790811075d, 0.8197151370980817d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.2664870333770251E8d));

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     int var12 = var0.nextSecureInt((-1), 7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("bc6c20d2766e22cd4330bb3881fa02762e21e9c603d8b355a1cf37", "fd704f2491966f644743deaec27f7c6bc7e1c4208c3d0a5");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 22.252416450199988d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "66a811b0a83895622e4d69"+ "'", var4.equals("66a811b0a83895622e4d69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.6011193926940122E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test394"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     int var17 = var1.nextInt((-1), 96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.251325027829018d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "3959082c6091a6961af78d88b93acee34df129efad86280"+ "'", var10.equals("3959082c6091a6961af78d88b93acee34df129efad86280"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "103dd25c37c74fc90dd58fff4bbf92d"+ "'", var12.equals("103dd25c37c74fc90dd58fff4bbf92d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "3d40d0de7e057458e59e983aa54f86dab7c4981bb65a806e84ca18d4cbc4a"+ "'", var14.equals("3d40d0de7e057458e59e983aa54f86dab7c4981bb65a806e84ca18d4cbc4a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 90);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     java.lang.String var7 = var0.nextHexString(53);
//     double var10 = var0.nextBeta(485082.4042097862d, 2.052251320618775d);
//     java.lang.String var12 = var0.nextHexString(60);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextSecureLong(70L, 3L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "3cd820c19014731d542db7db8f7e320b2ff3880dd9f6f28d41fe298ab12d89967f86fba36769bafa60b7ecc"+ "'", var5.equals("3cd820c19014731d542db7db8f7e320b2ff3880dd9f6f28d41fe298ab12d89967f86fba36769bafa60b7ecc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "33ff6f81f8cd2f346126338f6d80f8704bbbbf52bb92983a9c116"+ "'", var7.equals("33ff6f81f8cd2f346126338f6d80f8704bbbbf52bb92983a9c116"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9999915684705126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "6ad2abab430b7b77f9d8dff1c44684dbda912ab4bf1d56cc28a1cc13d968"+ "'", var12.equals("6ad2abab430b7b77f9d8dff1c44684dbda912ab4bf1d56cc28a1cc13d968"));
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test396"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.07526435577864454d), 1.1054197636303182d, 0.9255748744099641d, 2.873194720677289E-12d, (-0.6001566413360179d), (-0.4523170714609886d), 6.540316540242818d, (-10.849168435251086d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-70.76873337689796d));

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test397"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int[] var11 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var11);
//     float var14 = var13.nextFloat();
//     java.lang.Object var15 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var20 = var19.getMin();
//     org.apache.commons.math3.util.Pair var21 = new org.apache.commons.math3.util.Pair(var15, (java.lang.Object)var19);
//     org.apache.commons.math3.exception.util.Localizable var22 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var26 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var27 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException(var22, var27);
//     boolean var29 = var21.equals((java.lang.Object)var27);
//     int[] var30 = null;
//     org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(var30);
//     double var32 = var31.nextGaussian();
//     byte[] var34 = new byte[] { (byte)10};
//     var31.nextBytes(var34);
//     org.apache.commons.math3.random.RandomDataGenerator var36 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var31);
//     byte[] var38 = new byte[] { (byte)1};
//     var31.nextBytes(var38);
//     boolean var40 = var21.equals((java.lang.Object)var38);
//     var13.nextBytes(var38);
//     var1.nextBytes(var38);
//     boolean var43 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.20757231485787325d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.4987576f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + 1.0d+ "'", var20.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.651647734894505d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test398"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
    double[] var19 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var19, var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.normalizeArray(var28, 0.0d);
    double var32 = org.apache.commons.math3.util.MathArrays.distance(var15, var31);
    double[] var36 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var40 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var36, var40);
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var41, var45);
    double[] var55 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var59 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var63 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var59, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var55, var64);
    double[] var67 = org.apache.commons.math3.util.MathArrays.normalizeArray(var64, 0.0d);
    double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var64);
    double var69 = org.apache.commons.math3.util.MathArrays.distance1(var41, var64);
    double var70 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var72 = org.apache.commons.math3.util.MathArrays.normalizeArray(var41, 0.0d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var79 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var80 = var79.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var81 = var79.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var81, true);
    boolean var85 = org.apache.commons.math3.util.MathArrays.isMonotonic(var41, var81, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var86 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var31, var41);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test399"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)11.880886259153524d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     double var14 = var0.nextCauchy(0.0d, 0.6989809774046034d);
//     int[] var17 = var0.nextPermutation(42904144, 22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NotPositiveException: 0 is smaller than the minimum (0)", "35d7421a6bcc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7444255407975833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7fdbf5871291516b0a664b6047d1563e8d5fc7fe0870b170e4f20b4fc9b19de9cc34cc641124a3626b16f2b"+ "'", var8.equals("7fdbf5871291516b0a664b6047d1563e8d5fc7fe0870b170e4f20b4fc9b19de9cc34cc641124a3626b16f2b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21.41161289407843d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.07146415217344258d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test401"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.918253960875775d), (java.lang.Number)(-0.739343345540624d), false);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test402"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 0);
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 55);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var17.nextCauchy(3.7282100998034432E16d, (-1.5411942829991334d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8116838362256936d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     int var14 = var0.nextInt(0, 14);
//     var0.reSeed(5507950371326924800L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextCauchy(1.0041411468916963d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.32390367600468917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "165d24816c13b0abbce4b47373848be7418e7df1ef3b2ba4f087cc977684ce3633f563acddf99daca316636"+ "'", var8.equals("165d24816c13b0abbce4b47373848be7418e7df1ef3b2ba4f087cc977684ce3633f563acddf99daca316636"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21.662272451024847d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 13);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test404"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1347491339));

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test405"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.setSeed(108L);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var12 = var10.nextPoisson(0.47423001622272043d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var10.nextHypergeometric((-690853845), 27, 25);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.06001338638766688d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test406"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    var47.reseedRandomGenerator(24L);
    double var57 = var47.probability(0.7133992414976418d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextGaussian(106.0d, 20.087570183274988d);
//     double var20 = var0.nextExponential(0.23554175056057947d);
//     int var23 = var0.nextSecureInt(0, 84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.858522490549253d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5924095.886286657d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 105.12656948481559d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.26486958771577074d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 33);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test408"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     double var13 = var0.nextUniform((-4261.583317386363d), 0.7089838642239309d, true);
//     long var15 = var0.nextPoisson(5.704309058613993d);
//     int var18 = var0.nextSecureInt(13, 46);
//     int var21 = var0.nextBinomial(23, 5.359686076457877E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.5863447701263156d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3883c601bf205bc26cbc34a5ef91e7f75de1e16542c319bf4560bfe4bffcc0eff065de08fc13962026037a8"+ "'", var8.equals("3883c601bf205bc26cbc34a5ef91e7f75de1e16542c319bf4560bfe4bffcc0eff065de08fc13962026037a8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3504.7444361169146d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     var1.reSeed();
//     double var17 = var1.nextExponential(0.029336411166028985d);
//     int var20 = var1.nextZipf(10, 1.1761827992407105E-9d);
//     int var23 = var1.nextZipf(41, 28.46111736987342d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextExponential((-0.21490689726247014d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.608641861357164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "434cb5991c7ba6ed64ac4a0f961836d2acae45bcd162e8d"+ "'", var10.equals("434cb5991c7ba6ed64ac4a0f961836d2acae45bcd162e8d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "60e7d480cd55e73a930903c5dc85d24"+ "'", var12.equals("60e7d480cd55e73a930903c5dc85d24"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "64a143eb23289f3a4250d597df309e0221ed220d0e00898e1421a235e7096"+ "'", var14.equals("64a143eb23289f3a4250d597df309e0221ed220d0e00898e1421a235e7096"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.022654809279125554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     var0.reSeedSecure(8L);
//     var0.reSeed(508515618537942016L);
//     int var13 = var0.nextBinomial(58, 0.062380395238400776d);
//     double var16 = var0.nextGaussian(0.10431629821572952d, 0.7859222898052044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 22670.475274987974d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "16a91013e4d72569315291"+ "'", var4.equals("16a91013e4d72569315291"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.3133348264043305d);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test411"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var1, true);
//     java.lang.Number var4 = var3.getMin();
//     boolean var5 = var3.getBoundIsAllowed();
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double var8 = var7.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var11 = var9.nextT(0.1431715674774945d);
//     double var14 = var9.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var17 = var9.nextPermutation(83, 33);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     var7.setSeed(var18);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 0);
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var21);
//     org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var21);
//     int[] var24 = null;
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
//     double var26 = var25.nextGaussian();
//     byte[] var28 = new byte[] { (byte)10};
//     var25.nextBytes(var28);
//     org.apache.commons.math3.random.RandomDataGenerator var30 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var25);
//     byte[] var32 = new byte[] { (byte)1};
//     var25.nextBytes(var32);
//     var23.nextBytes(var32);
//     double var35 = var23.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.15318289051885725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.7911673263691172d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.1361943172125468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.8894389697993161d);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test412"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var9.nextHypergeometric(39, 22, 94);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.787617138767641d);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeed(10L);
//     var0.reSeedSecure((-1952321163872933406L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(0, 3.3645060472848733d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8859843383682198d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test414"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.1125016028479662d), (-6.598282045045631E11d), 0.0d, 0.7963844317155382d, 0.06815970294742058d, 0.0d, (-0.6411459810667139d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.340599351156221E11d);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test415"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     double var10 = var0.nextT(0.4265583850978061d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3133213586876644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.3543589320363E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-367.46593494387736d));
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextLong(11L, (-5787431229102719808L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.5775337246471928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.5237522836216473d);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test417"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     double var14 = var0.nextCauchy(0.0d, 0.6989809774046034d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextZipf(97, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3829611178631307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cd2f41f10d3979817b3d14e90efdb88e965bc31c2852a8804fea228f760d213b6ade9375f5c2652c5533890"+ "'", var8.equals("cd2f41f10d3979817b3d14e90efdb88e965bc31c2852a8804fea228f760d213b6ade9375f5c2652c5533890"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 26.6065631867271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.12225743940614053d);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test418"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.824062541754132E-9d, 357.60346728709703d, (-934295.5483625216d), 3.7363554398252974E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-349.08602480059557d));

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test419"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var7.nextSample(var8, 6);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test420"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 47);
// 
//   }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test421"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 14, 0);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test422"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var19 = null;
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var19, var27);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var34);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var12, var34);
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var58);
    double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var58, 9900.0d);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var62);
    double[] var67 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var71 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var67, var71);
    double[] var76 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var76);
    double[][] var78 = new double[][] { var76};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var67, var78);
    double var80 = org.apache.commons.math3.util.MathArrays.safeNorm(var67);
    double[] var84 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var88 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var92 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var88, var92);
    double var94 = org.apache.commons.math3.util.MathArrays.distance1(var84, var93);
    double[] var96 = org.apache.commons.math3.util.MathArrays.copyOf(var93, 88);
    double[] var97 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var67, var93);
    double[] var98 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test423"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(24L);
    var1.setSeed(35);
    var1.clear();

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test424"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(54, 71);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test425"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     java.lang.Object var18 = var17.getValue();
//     java.lang.Object var19 = var17.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.016825009147201975d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test426"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 483, 0);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test427"); }
// 
// 
//     org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(22, 18);
//     org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
//     java.lang.Number var4 = var2.getArgument();
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(100);
//     var6.clear();
//     var6.setSeed(1L);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
//     var10.reSeedSecure(2563274223793255424L);
//     org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var10);
//     java.lang.String var15 = var10.nextSecureHexString(6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + 22+ "'", var4.equals(22));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "d65d66"+ "'", var15.equals("d65d66"));
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test428"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(4076121792065851015L);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test429"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 18, 0);
    int var4 = var3.getDimension();
    int var5 = var3.getDimension();
    int var6 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test430"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var6 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    long[][] var8 = new long[][] { var6};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test431"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getSupportUpperBound();
//     double var53 = var47.density(0.6938061358177889d);
//     double var55 = var47.cumulativeProbability((-0.5344395467201206d));
//     double var57 = var47.cumulativeProbability(1.4387505701387593d);
//     double var58 = var47.sample();
//     double var60 = var47.cumulativeProbability(8.326984277559745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.0d);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt(13, 49);
//     int var8 = var0.nextPascal(84, 0.3934606808571868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4854521983352234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 122);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test433"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     var0.reSeed();
//     double var13 = var0.nextBeta(4.847943602659273d, 2.6467807810289345d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextLong(2585270482073165824L, (-4689457396990028655L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-4530.389028105527d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "6a4ea3cbfca397d61f739d"+ "'", var4.equals("6a4ea3cbfca397d61f739d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.395052307252951d);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test434"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var15);
    double[] var23 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = null;
    boolean var26 = org.apache.commons.math3.util.MathArrays.isMonotonic(var23, var24, false);
    double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 54);
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var23, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test435"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { (short)1};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, true);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
//     java.lang.String var10 = var9.toString();
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test436"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)1.0f, 81);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test437"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)10.0f);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test438"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.9494870679461207d), (-0.142898778301125d), (-0.6057477678686467d), 0.09687866174310211d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.07699650891723214d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test439"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    var1.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var8 = var5.nextPascal(49, 0.10832690038004085d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setSecureAlgorithm("a9320f472044c1883c7cb605142356b933ada2882c2b2561e5810df2602a4ded633e6731bce161d05dfc841", "7b146d7aa9e547a8d5daf7566");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 318);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test440"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, var1, 13);
    boolean var4 = var3.getStrict();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test441"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     org.apache.commons.math3.random.RandomDataGenerator var21 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var24 = var21.nextInt(10, 100);
//     double var27 = var21.nextUniform((-1.0d), 1.0d);
//     var21.reSeedSecure();
//     org.apache.commons.math3.util.Pair var29 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var33 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var37 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var33, var37);
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var37, var46);
//     double[] var49 = null;
//     boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var46, var49);
//     double[] var54 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var58 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var62 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var63 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var58, var62);
//     double var64 = org.apache.commons.math3.util.MathArrays.distance1(var54, var63);
//     boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var46, var54);
//     double[] var66 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var46);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var20);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var71 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var72 = var71.getStrict();
//     boolean var73 = var71.getStrict();
//     boolean var74 = var71.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var75 = var71.getDirection();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       boolean var78 = org.apache.commons.math3.util.MathArrays.checkOrder(var67, var75, true, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
//     } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-0.48746283539720103d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test442"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var7 = var4.nextZipf(96, 1.1594185848885774E-9d);
//     var4.reSeedSecure(14L);
//     java.lang.String var11 = var4.nextHexString(13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.11255642846027802d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2031598329881905043L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "5232de3c07207"+ "'", var11.equals("5232de3c07207"));
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test443"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(4, (-2.211098025267261d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 355590.7961125522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.038290302968095E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test444"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3.7276839739173364d);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test445"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//     int[] var10 = null;
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
//     double var12 = var11.nextGaussian();
//     int[] var15 = new int[] { 0, 1};
//     var11.setSeed(var15);
//     double var17 = var11.nextGaussian();
//     var11.clear();
//     org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     long var21 = var19.nextPoisson(0.6989809774046034d);
//     long var23 = var19.nextPoisson(0.9304525547601544d);
//     double[] var27 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var27, var36);
//     org.apache.commons.math3.util.Pair var38 = new org.apache.commons.math3.util.Pair((java.lang.Object)var23, (java.lang.Object)var27);
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double[] var57 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var55);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.normalizeArray(var46, 21.869847397459292d);
//     double[] var64 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var68 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var69 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var64, var68);
//     double[] var73 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
//     double[][] var75 = new double[][] { var73};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var64, var75);
//     org.apache.commons.math3.exception.NotFiniteNumberException var77 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var75);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var59, var75);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var9, var27, var59);
//     double var80 = var79.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6453351130608931d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.13551511571105487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 10.099504938362077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 100.0d);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     var0.reSeedSecure();
//     double var18 = var0.nextWeibull(9517.474048442906d, 0.9045563448629151d);
//     int var21 = var0.nextBinomial(0, 0.11433830816137684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6273533993924403d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.07714237313258787d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.6629995728960584d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 79131.45897238354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.9044761972103151d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test447"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(82, 1077317343);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test448"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     java.lang.String var8 = var2.nextHexString(95);
//     long var10 = var2.nextPoisson(0.6639432937569401d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var2.nextPascal(42, 34.08534215706243d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "84ec6928591af0cf2f288e1c2fcae96df7b6457d644f7e1bdc043ef518cf297b51c71a76f8ca3ce2768f2be918bee58"+ "'", var8.equals("84ec6928591af0cf2f288e1c2fcae96df7b6457d644f7e1bdc043ef518cf297b51c71a76f8ca3ce2768f2be918bee58"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test449"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var10 = var1.nextFloat();
//     double var11 = var1.nextGaussian();
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var14 = var12.nextPoisson(194.0d);
//     int var17 = var12.nextSecureInt(0, 87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var12.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.045405984f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.3328432771849152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 179L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 39);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test450"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    var3.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var5.getContext();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0, (java.lang.Number)(-0.14097693123713528d), 87);
    var5.addSuppressed((java.lang.Throwable)var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var13.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0d+ "'", var4.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test451"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextInt(0, 100);
//     var0.reSeedSecure(1L);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var0.nextSample(var11, 17);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test452"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var4 = var3.getStrict();
    int var5 = var3.getIndex();
    int var6 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test453"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.6224543031156315d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test454"); }


    int[] var3 = new int[] { 0, 10, (-1)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, (-1347491339));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7111154558159436d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test456"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 23, 34);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test457"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var8 = var1.nextInt(18);
//     float var9 = var1.nextFloat();
//     var1.setSeed(8026008374386375277L);
//     int var12 = var1.nextInt();
//     int var13 = var1.nextInt();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.3868929201818669d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.11925638f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1077317343);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 570720782);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test458"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var1, var9);
//     double var12 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
//     double[] var16 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var20 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var9, var16);
//     double[] var26 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var35);
//     double[] var38 = null;
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var38, var46);
//     double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
//     double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var53);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeAdd(var22, var46);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var64 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var65 = var64.getStrict();
//     boolean var66 = var64.getStrict();
//     boolean var67 = var64.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var68 = var64.getDirection();
//     boolean var70 = org.apache.commons.math3.util.MathArrays.isMonotonic(var60, var68, true);
//     boolean var73 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var68, true, true);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test459"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextWeibull(6.785854381629338d, 4736077.9249220705d);
//     double var20 = var0.nextChiSquare(0.4188489407275768d);
//     var0.reSeedSecure(0L);
//     int var26 = var0.nextHypergeometric(663, 60, 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.4678329995014394d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7764071.38173366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.8123061105007993E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4955414.248644063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.11235981905790325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test460"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    double var9 = var2.nextGaussian(4.218937231588664d, 0.9692669377133449d);
    var2.reSeedSecure(8026008374386375277L);
    long var14 = var2.nextLong(39L, 108L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.641195788033711d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 65L);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test461"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var45 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var42, var45);
    double[] var50 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var50, var59);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var42, var50);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var50);
    double[] var64 = org.apache.commons.math3.util.MathArrays.normalizeArray(var62, 60366.19788822483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test462"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var5 = var1.nextFloat();
//     double var6 = var1.nextDouble();
//     int[] var7 = null;
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var9.nextZipf(0, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3508677903655575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-5291718078546328793L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6732751f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6807389696417399d);
// 
//   }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test463"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var2.nextInversionDeviate(var9);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test464"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var7 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var9 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)513, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test465"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextSecureInt(22, 54);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var2.nextF((-0.5481103407087482d), 0.07699650891723214d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 42);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test466"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.4816172379584784d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test467"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var38 = null;
    double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var38, var46);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var53);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var31, var53);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double[][] var62 = new double[][] { var31};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var62);
    double[] var65 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, (-0.9451161353496818d));
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test468"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var11 = var8.nextF(7.3680139234192845d, 17.156919794860045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2.154442163660898d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.3447546248512551d);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test469"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     org.apache.commons.math3.random.RandomDataGenerator var35 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var38 = var35.nextInt(10, 100);
//     double var41 = var35.nextUniform((-1.0d), 1.0d);
//     var35.reSeedSecure();
//     org.apache.commons.math3.util.Pair var43 = new org.apache.commons.math3.util.Pair((java.lang.Object)var34, (java.lang.Object)var35);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var60);
//     double[] var63 = null;
//     boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
//     double[] var68 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
//     boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var60, var68);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var34, var60);
//     double var81 = org.apache.commons.math3.util.MathArrays.distance(var8, var60);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.util.MathArrays.checkOrder(var60);
//       fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
//     } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.09450807677785278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0.0d);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test470"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var4 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test471"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.4301403036978695d);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 0.43 is smaller than the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotPositiveException: 0.43 is smaller than the minimum (0)"));

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test472"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     var2.reSeedSecure();
//     long var9 = var2.nextPoisson(14.499947257311428d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var2.nextInt(97, 41);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 28L);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test473"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var5 = var3.nextT(0.1431715674774945d);
//     double var8 = var3.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var11 = var3.nextPermutation(83, 33);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     var1.setSeed(var12);
//     var1.clear();
//     int[] var15 = null;
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     int[] var20 = new int[] { 100, 10, (-1)};
//     var16.setSeed(var20);
//     int[] var22 = new int[] { };
//     var16.setSeed(var22);
//     int[] var24 = null;
//     int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var24);
//     int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 66);
//     int[] var28 = null;
//     int var29 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
//     var1.setSeed(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6756056344330648d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 87.83762787375889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test474"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(2585270482073165824L);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test475"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    long var9 = var2.nextPoisson(100.00999950005d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextWeibull(529.9961815694902d, (-3924.0955234387598d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 108L);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test476"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)15.351008710209738d, (java.lang.Number)43, (java.lang.Number)4L);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test477"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)6599722114787805860L, (java.lang.Number)1378478.4521755187d, (java.lang.Number)1.2315628961738314d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test478"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.7373746625949142d, (java.lang.Number)0.19193457678938466d, false);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test479"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var10 = null;
//     double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var10, var18);
//     double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
//     double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var18, var25);
//     double[] var35 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var39 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var43 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var43);
//     double var45 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
//     double var46 = org.apache.commons.math3.util.MathArrays.linearCombination(var31, var44);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var44);
//     double[] var49 = new double[] { 10.0d};
//     double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
//     double[] var62 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var66 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var62, var66);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var57, var66);
//     double[] var70 = org.apache.commons.math3.util.MathArrays.normalizeArray(var66, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var71 = null;
//     java.lang.Object[] var73 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var74 = new org.apache.commons.math3.exception.MathInternalError(var71, var73);
//     org.apache.commons.math3.util.Pair var75 = new org.apache.commons.math3.util.Pair((java.lang.Object)var70, (java.lang.Object)var71);
//     double var76 = org.apache.commons.math3.util.MathArrays.distanceInf(var49, var70);
//     double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var70);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var0, var44);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test480"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     var0.reSeed(12L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextWeibull((-1096.3767627294947d), 0.24732190236186335d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3058341831481872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9643925907937037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.7931587342502832d));
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test481"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.03603256163404128d, 0.0d, (-0.4423815046747017d), 3.9573274866452017d, 0.8631044481961425d, 4.218937231588664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.8907350032118353d);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test482"); }


    org.apache.commons.math3.exception.MathArithmeticException var1 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    java.lang.Throwable[] var4 = var1.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-370.93054277619296d), (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     double var14 = var0.nextChiSquare(0.002060832934925295d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextBeta((-0.8342606859998907d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.564560366017893d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2445634836193176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "af3bfa885b7713d693ff48a007fbbe565dffb4ce9a8509f3865a15bd1f7987"+ "'", var12.equals("af3bfa885b7713d693ff48a007fbbe565dffb4ce9a8509f3865a15bd1f7987"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test484"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)16);
//     java.lang.Number var3 = var2.getArgument();
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test485"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)6L, (java.lang.Number)0.21548915f, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.21548915f+ "'", var5.equals(0.21548915f));

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test486"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     int var20 = var0.nextHypergeometric(73, 18, 12);
//     double var23 = var0.nextGamma(0.6862627241836179d, 0.40937073317029693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6783852588377042d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d70e54b8a09bf63013f9605573f86524f5438a215c7e53af9ee42618e4ca9a245e45f6459db2d61ee2b7f34"+ "'", var8.equals("d70e54b8a09bf63013f9605573f86524f5438a215c7e53af9ee42618e4ca9a245e45f6459db2d61ee2b7f34"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-12.760568237062643d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "c3672e3afa3354ae7096c159bc90b6ba1"+ "'", var16.equals("c3672e3afa3354ae7096c159bc90b6ba1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.07051176549638416d);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test487"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)6.251783231069299d, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
    java.lang.Number var8 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 6.251783231069299d+ "'", var6.equals(6.251783231069299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 6.251783231069299d+ "'", var8.equals(6.251783231069299d));

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test488"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextUniform(0.012774969105543068d, 21.869847397459292d);
//     double var9 = var2.nextUniform((-0.9020353599735187d), 4.437566042721068d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.663838091870783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2706977602334426d);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test489"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getNumericalMean();
//     double var53 = var47.probability(2.641195788033711d);
//     boolean var54 = var47.isSupportUpperBoundInclusive();
//     double var55 = var47.getSupportLowerBound();
//     double var56 = var47.getSupportUpperBound();
//     double var57 = var47.sample();
//     boolean var58 = var47.isSupportUpperBoundInclusive();
//     double var59 = var47.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 97.05882352941177d);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test490"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     double var13 = var0.nextExponential(0.1431715674774945d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextSecureLong(8026008374386375277L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.2624278124474757d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "be2f5c68666945520e6f9735c91d7a2f37d5514708262bf649a2c559c3ec1fdf630ef4d9ac228fe420b79f8"+ "'", var8.equals("be2f5c68666945520e6f9735c91d7a2f37d5514708262bf649a2c559c3ec1fdf630ef4d9ac228fe420b79f8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-6.646264571118667d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.7927269718707756d);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test491"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var9 = var6.nextLong(1L, 5804136433509186560L);
//     int var12 = var6.nextZipf(82, 1.182480876835637d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var6.nextHypergeometric(56, 1028812019, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.23818358748867133d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5013150827074091008L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test492"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     int[] var9 = var2.nextPermutation(100, 18);
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 15);
//     int[] var12 = null;
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     int[] var17 = new int[] { 100, 10, (-1)};
//     var13.setSeed(var17);
//     int[] var19 = new int[] { };
//     var13.setSeed(var19);
//     int[] var21 = null;
//     int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var21);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 66);
//     int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 43);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var9, var24);
//     int[] var28 = null;
//     org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var28);
//     double var30 = var29.nextDouble();
//     long var31 = var29.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var32 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var29);
//     float var33 = var29.nextFloat();
//     long var34 = var29.nextLong();
//     java.lang.Number var36 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var38 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var36, true);
//     java.lang.Number var39 = var38.getMin();
//     boolean var40 = var38.getBoundIsAllowed();
//     int[] var41 = null;
//     org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var41);
//     double var43 = var42.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var44 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var46 = var44.nextT(0.1431715674774945d);
//     double var49 = var44.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var52 = var44.nextPermutation(83, 33);
//     int[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var52);
//     var42.setSeed(var53);
//     int[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 0);
//     org.apache.commons.math3.util.Pair var57 = new org.apache.commons.math3.util.Pair((java.lang.Object)var38, (java.lang.Object)var56);
//     var29.setSeed(var56);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var59 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var56);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 267.9776110050987d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.040351517874395615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-1087382509700557843L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.10783124f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 8051779305172189455L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0.2644488376998073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0.8109152861899408d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1.1412420118871842E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test493"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-80.55475932170346d), (java.lang.Number)0.24556052843519588d, true);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test494"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     double var11 = var2.nextT(81.560782738241d);
//     double var14 = var2.nextUniform(0.2670644661794837d, 5.63323150528981d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var2.nextWeibull((-5.891344771123487d), 20.104252970797198d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "26b4d027f79f4d63eb846ca366ec6"+ "'", var9.equals("26b4d027f79f4d63eb846ca366ec6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.7110563084721201d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.378440202981227d);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test495"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeedSecure(1730706259609335040L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextSecureInt(8, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 48);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     double var9 = var0.nextGamma(24.00401720365219d, 8.762030458096847E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6181200288655326E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "27aa2e4fabd06f1c025ddf"+ "'", var4.equals("27aa2e4fabd06f1c025ddf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "14e71180f6068a1c3d3dfa7e3403823da1db6e43857becc8822f9ed0952ac8c74e53d5c4db2f5f37cf9cd64d"+ "'", var6.equals("14e71180f6068a1c3d3dfa7e3403823da1db6e43857becc8822f9ed0952ac8c74e53d5c4db2f5f37cf9cd64d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.6617558384851792E9d);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test497"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
//     double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     org.apache.commons.math3.random.RandomDataGenerator var38 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var41 = var38.nextInt(10, 100);
//     double var44 = var38.nextUniform((-1.0d), 1.0d);
//     var38.reSeedSecure();
//     org.apache.commons.math3.util.Pair var46 = new org.apache.commons.math3.util.Pair((java.lang.Object)var37, (java.lang.Object)var38);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var37);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double[] var60 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var60);
//     double[][] var62 = new double[][] { var60};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var51, var62);
//     double var64 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
//     double[] var68 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 88);
//     double[] var81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var77);
//     double[] var82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var37, var51);
//     double[] var86 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var90 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var91 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var86, var90);
//     double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var82, var91);
//     double[] var94 = org.apache.commons.math3.util.MathArrays.normalizeArray(var91, 7.636418016556065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-0.6759049083070825d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 10.099504938362077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1.7320508075688772d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test498"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)81, (java.lang.Number)7, true);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test499"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(42);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var2.nextPermutation(63, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test500"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 570720782, (-1983603608));
// 
//   }

}
