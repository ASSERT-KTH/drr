
import junit.framework.*;

public class RandoopTest6 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     var0.reSeedSecure(8026008374386375277L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.07863625210050806d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "92dfc1734e6b05e219176e"+ "'", var4.equals("92dfc1734e6b05e219176e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e6a5f989f7809fd6244e732f960fbcd8edaf50d75ebc9cea5d62b6b798e8cca84d64ec886502ab09f368eb8f"+ "'", var6.equals("e6a5f989f7809fd6244e732f960fbcd8edaf50d75ebc9cea5d62b6b798e8cca84d64ec886502ab09f368eb8f"));
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test2"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    double var7 = var2.nextExponential(25.05052606779598d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextBeta(0.1499743121005248d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 7.084194643041131d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test3"); }


    int[] var3 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var3);
    int var6 = var5.nextInt();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    var7.reSeed(3449014497143393280L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2142147742);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test4"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.040136781194513915d), (java.lang.Number)59L, false);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test5"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int[] var12 = var9.nextPermutation(66, 20);
//     double var15 = var9.nextBeta(4.124408130986206d, 1.8727261569983433d);
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var23, var32);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.normalizeArray(var32, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var37 = null;
//     java.lang.Object[] var39 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var40 = new org.apache.commons.math3.exception.MathInternalError(var37, var39);
//     org.apache.commons.math3.util.Pair var41 = new org.apache.commons.math3.util.Pair((java.lang.Object)var36, (java.lang.Object)var37);
//     double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
//     double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var58);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var58, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var63 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var36, var58);
//     boolean var64 = var63.isSupportConnected();
//     double var66 = var63.density((-30.443553573156947d));
//     double var67 = var63.getSupportUpperBound();
//     double var69 = var63.density(0.6938061358177889d);
//     double var71 = var63.cumulativeProbability((-0.5344395467201206d));
//     double var73 = var63.cumulativeProbability(1.4387505701387593d);
//     double var74 = var63.sample();
//     var63.reseedRandomGenerator(4021181619849658368L);
//     double var77 = var9.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var63);
//     org.apache.commons.math3.distribution.IntegerDistribution var78 = null;
//     int var79 = var9.nextInversionDeviate(var78);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test6"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getNumericalMean();
//     double var53 = var47.probability(2.641195788033711d);
//     boolean var54 = var47.isSupportUpperBoundInclusive();
//     double var55 = var47.sample();
//     double var57 = var47.probability(6.813639406926573E-7d);
//     double var58 = var47.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1774884.4601956457d);
// 
//   }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test7"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getSupportUpperBound();
//     double var52 = var47.sample();
//     boolean var53 = var47.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == true);
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test8"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(369960311448764288L);
//     java.util.List var2 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var3 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextExponential(0.6888245262954816d);
//     var1.reSeedSecure((-509399413869688601L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0712697925161785d);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test10"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     int var9 = var0.nextBinomial(62, 0.10431629821572952d);
//     double var13 = var0.nextUniform((-5.891344771123487d), 0.0d, true);
//     var0.reSeedSecure(4076121792065851015L);
//     var0.reSeed();
//     double var18 = var0.nextExponential(4.0504120856865145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 695878.0151338676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f521adb1a2871332d5c8b1"+ "'", var4.equals("f521adb1a2871332d5c8b1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "36014dff89478a9ef1cf24120ecd1372d93d1170d933aaa8fb3f1e61bbe3ef22e9825f381e2a78f2ccb9a57e"+ "'", var6.equals("36014dff89478a9ef1cf24120ecd1372d93d1170d933aaa8fb3f1e61bbe3ef22e9825f381e2a78f2ccb9a57e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.5793464066563074d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 7.2063601450008905d);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     var0.reSeed(10L);
//     long var9 = var0.nextPoisson(0.0028269929560076706d);
//     java.lang.String var11 = var0.nextHexString(83);
//     int var14 = var0.nextBinomial(66, 0.8495550674416402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.6119198417757956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2"+ "'", var11.equals("0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 60);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test12"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5.010509386443536d, (java.lang.Number)(-0.041921746632880216d), false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.041921746632880216d)+ "'", var5.equals((-0.041921746632880216d)));

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test13"); }
// 
// 
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var13 = var10.nextInt(10, 100);
//     double var16 = var10.nextUniform((-1.0d), 1.0d);
//     var10.reSeedSecure();
//     org.apache.commons.math3.util.Pair var18 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, (java.lang.Object)var10);
//     double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
//     double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var26, var35);
//     double[] var38 = null;
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var35, var38);
//     double[] var43 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double var53 = org.apache.commons.math3.util.MathArrays.distance1(var43, var52);
//     boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var35, var43);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var35);
//     double[] var57 = new double[] { 10.0d};
//     double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
//     double[] var70 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var74 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var70, var74);
//     double[] var76 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var65, var74);
//     double[] var78 = org.apache.commons.math3.util.MathArrays.normalizeArray(var74, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var79 = null;
//     java.lang.Object[] var81 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var82 = new org.apache.commons.math3.exception.MathInternalError(var79, var81);
//     org.apache.commons.math3.util.Pair var83 = new org.apache.commons.math3.util.Pair((java.lang.Object)var78, (java.lang.Object)var79);
//     double var84 = org.apache.commons.math3.util.MathArrays.distanceInf(var57, var78);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var85 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var9, var78);
//     double[] var87 = var85.sample(69);
//     org.apache.commons.math3.util.Pair var88 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.8067855390308518d, (java.lang.Object)var85);
//     double var89 = var85.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.3987510968179535d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 87.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == (-99.0d));
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test14"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed((-3642957619909372473L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test15"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)10.0f, (java.lang.Number)(-1.0d), false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1.0d)+ "'", var6.equals((-1.0d)));

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test16"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     var0.reSeedSecure(8L);
//     int var12 = var0.nextHypergeometric(64, 32, 0);
//     org.apache.commons.math3.distribution.RealDistribution var13 = null;
//     double var14 = var0.nextInversionDeviate(var13);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test17"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)10L, 63, var3, false);
    int var6 = var5.getIndex();
    java.lang.Number var7 = var5.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test18"); }


    long[] var3 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 0.7111154558159436d);
//     java.lang.String var5 = var0.nextHexString(32523703);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.0484106728812221d));
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test20"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
//     double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     org.apache.commons.math3.random.RandomDataGenerator var38 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var41 = var38.nextInt(10, 100);
//     double var44 = var38.nextUniform((-1.0d), 1.0d);
//     var38.reSeedSecure();
//     org.apache.commons.math3.util.Pair var46 = new org.apache.commons.math3.util.Pair((java.lang.Object)var37, (java.lang.Object)var38);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var37);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.normalizeArray(var47, 0.7881276094947616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-0.17304612251815454d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test21"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)53, (java.lang.Number)2.264115422511676d, 22);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test22"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     long var10 = var6.nextPoisson(1.3431861837677899d);
//     var6.reSeedSecure(179L);
//     java.lang.String var14 = var6.nextSecureHexString(83);
//     var6.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1019654337279325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "be0d52fb2dd1b9910b042c0021550e9b205fecccfc5e802967aa59c96d145494e2a926d977a6bd4c781"+ "'", var14.equals("be0d52fb2dd1b9910b042c0021550e9b205fecccfc5e802967aa59c96d145494e2a926d977a6bd4c781"));
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     var0.reSeedSecure(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextBeta((-1.0484106728812221d), (-0.35429237862306834d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.28844283252759d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7767705170468143d);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test24"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    double var54 = var47.getSupportUpperBound();
    var47.reseedRandomGenerator(0L);
    boolean var57 = var47.isSupportUpperBoundInclusive();
    double var58 = var47.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var61 = var47.cumulativeProbability(12.952468230884172d, (-2.596289776741364E7d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 9517.474048442906d);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     double var5 = var0.nextT(23.562469870696063d);
//     double var8 = var0.nextCauchy(0.11433830816137684d, 1.2349020409310291E-9d);
//     long var11 = var0.nextSecureLong((-1092428417482140062L), (-43986082236993568L));
//     double var14 = var0.nextGamma(8.9163268927436E-4d, 970782.3529411765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.3494081304709247d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.11433831029980439d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-644916536123436160L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test26"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     var0.reSeedSecure(11L);
//     var0.reSeed(23L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 11.325956774167905d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.06375067856639073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test27"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var8.nextT(0.9585663155112759d);
    long var13 = var8.nextLong(0L, 54L);
    double var17 = var8.nextUniform(3.7512412731960527d, 9673.110537554716d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-2.091009886486545d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 32L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1474.8131958053573d);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test28"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     double var13 = var0.nextUniform((-4261.583317386363d), 0.7089838642239309d, true);
//     long var15 = var0.nextPoisson(5.704309058613993d);
//     int var18 = var0.nextZipf(68, 0.6938061358177889d);
//     java.lang.String var20 = var0.nextSecureHexString(13);
//     var0.reSeed((-7353218008567596187L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7751535885406518d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f8d5f4184b28c7cabc2e46bfdbec5b09f7e969f66268f9656ad68561ebd085138dc6512397a5e3ec9881b25"+ "'", var8.equals("f8d5f4184b28c7cabc2e46bfdbec5b09f7e969f66268f9656ad68561ebd085138dc6512397a5e3ec9881b25"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1169.9336683106364d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "c742594580331"+ "'", var20.equals("c742594580331"));
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test29"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     int var14 = var10.nextSecureInt(39, 93);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var10.nextInversionDeviate(var15);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test30"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0, (java.lang.Number)(-0.14097693123713528d), 87);
    java.lang.Number var4 = var3.getPrevious();
    java.lang.Number var5 = var3.getPrevious();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.14097693123713528d)+ "'", var4.equals((-0.14097693123713528d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.14097693123713528d)+ "'", var5.equals((-0.14097693123713528d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test31"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
//     int[] var7 = new int[] { 100, 10, (-1)};
//     var3.setSeed(var7);
//     int[] var9 = new int[] { };
//     var3.setSeed(var9);
//     int[] var11 = null;
//     int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var11);
//     int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 66);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 0);
//     var1.setSeed(var16);
//     int[] var18 = null;
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var18);
//     int[] var23 = new int[] { 100, 10, (-1)};
//     var19.setSeed(var23);
//     int[] var25 = new int[] { };
//     var19.setSeed(var25);
//     int[] var27 = null;
//     int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var27);
//     int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 66);
//     int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var30);
//     int[] var32 = null;
//     org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(var32);
//     double var34 = var33.nextGaussian();
//     byte[] var36 = new byte[] { (byte)10};
//     var33.nextBytes(var36);
//     org.apache.commons.math3.random.RandomDataGenerator var38 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var33);
//     byte[] var40 = new byte[] { (byte)1};
//     var33.nextBytes(var40);
//     org.apache.commons.math3.random.RandomDataImpl var42 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var33);
//     var42.reSeedSecure();
//     java.lang.String var45 = var42.nextHexString(86);
//     long var47 = var42.nextPoisson(2.666606011498951d);
//     int[] var50 = var42.nextPermutation(111852252, 90);
//     double var51 = org.apache.commons.math3.util.MathArrays.distance(var16, var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.27559526043992566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "bbdcafeb98ec1f01c97a598e8cb1f4b8adf9e1d25547af001d42b4b3c7b7902da270872e0b3fb25a1e5052"+ "'", var45.equals("bbdcafeb98ec1f01c97a598e8cb1f4b8adf9e1d25547af001d42b4b3c7b7902da270872e0b3fb25a1e5052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0.0d);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test32"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.17463647001913052d, (java.lang.Number)0.07271097936070778d, 1590605);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test33"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)10.75688961352351d, (java.lang.Number)1.096288209891887d, false);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(4);
//     double var10 = var0.nextChiSquare(7319.324289638869d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9098943251447347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "55cc"+ "'", var8.equals("55cc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7169.270743166832d);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test35"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    int[] var9 = null;
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var7);
    var13.setSeed(5700823902786177024L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     double var13 = var0.nextUniform(0.02372282606752782d, 1.327000036267693d);
//     double var15 = var0.nextT(12.353608498975962d);
//     java.lang.String var17 = var0.nextHexString(46);
//     double var20 = var0.nextBeta(1.3811978976192093E-9d, 0.6245596043465632d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextBinomial(37, 5.056526352980463d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2308129111953905d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8749060440138621d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.6049480927608548d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.021615691815948617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "ee2c88d8ee347d6196b435782adc0ea2bd2e16f997ac67"+ "'", var17.equals("ee2c88d8ee347d6196b435782adc0ea2bd2e16f997ac67"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     long var13 = var0.nextPoisson(10.0d);
//     long var16 = var0.nextLong(7L, 24L);
//     double var18 = var0.nextT(3.4189499648925503d);
//     double var20 = var0.nextExponential(288.24623869977563d);
//     double var23 = var0.nextGaussian((-13.07313284741762d), 11162.246588731135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8571932067894261d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bb24a288b369fd12f1a6143d29c865a2b28b901132a22dba3876e4179a2fdd6f56e290de2194df8feeaca49"+ "'", var8.equals("bb24a288b369fd12f1a6143d29c865a2b28b901132a22dba3876e4179a2fdd6f56e290de2194df8feeaca49"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-4.797856869269483d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-4.104584647095991d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 62.722120492304704d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 5459.811703617076d);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test38"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.cumulativeProbability((-0.6001566413360179d));
    boolean var54 = var47.isSupportLowerBoundInclusive();
    double var55 = var47.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 9517.474048442906d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test39"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getSupportUpperBound();
    double var53 = var47.density(0.6938061358177889d);
    double var55 = var47.cumulativeProbability((-0.5344395467201206d));
    double var57 = var47.cumulativeProbability(1.4387505701387593d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var60 = var47.probability(135.34632918764086d, 2.7511511602509198d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test40"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var5 = var1.nextFloat();
//     double var6 = var1.nextDouble();
//     int[] var7 = null;
//     var1.setSeed(var7);
//     long var9 = var1.nextLong();
//     float var10 = var1.nextFloat();
//     var1.clear();
//     double var12 = var1.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.06718398836427064d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-836644583646359365L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.031630397f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6260425412440871d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1239325836194842715L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9546454f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.08009436773703205d);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test41"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var5 = var3.nextT(0.1431715674774945d);
//     double var8 = var3.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var11 = var3.nextPermutation(83, 33);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     var1.setSeed(var12);
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 0);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     org.apache.commons.math3.random.RandomDataGenerator var17 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var20 = var17.nextInt(10, 100);
//     double var23 = var17.nextUniform((-1.0d), 1.0d);
//     var17.reSeedSecure();
//     double var27 = var17.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var29 = var17.nextT(0.1479328506264807d);
//     int[] var32 = var17.nextPermutation(2248, 8);
//     int var33 = org.apache.commons.math3.util.MathArrays.distance1(var15, var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4397036348371006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0757420257393141d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9758237560631358d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.47324156589543653d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 7818483.463789499d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 5.609979157445942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test42"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    var1.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var8 = var5.nextPascal(49, 0.10832690038004085d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var5.nextBinomial(1590605, 2.2419551077422692d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 318);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test43"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    double[] var13 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
    double[][] var15 = new double[][] { var13};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var4);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, (-0.43512212088793156d));
    double[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var29, var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.normalizeArray(var38, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var43 = null;
    java.lang.Object[] var45 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var46 = new org.apache.commons.math3.exception.MathInternalError(var43, var45);
    org.apache.commons.math3.util.Pair var47 = new org.apache.commons.math3.util.Pair((java.lang.Object)var42, (java.lang.Object)var43);
    double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
    double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var55, var64);
    double[] var68 = org.apache.commons.math3.util.MathArrays.normalizeArray(var64, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var69 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var42, var64);
    boolean var70 = var69.isSupportConnected();
    double var72 = var69.density((-30.443553573156947d));
    double var73 = var69.getNumericalMean();
    double var75 = var69.density(0.0d);
    double[] var77 = var69.sample(95);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var78 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var77);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test44"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var13 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var13);
    int var16 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.exception.NumberIsTooSmallException var20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var21 = var20.getMin();
    org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError();
    var20.addSuppressed((java.lang.Throwable)var22);
    org.apache.commons.math3.exception.util.ExceptionContext var24 = var22.getContext();
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)var24);
    java.lang.Object var26 = var25.getKey();
    java.lang.Object var27 = var25.getFirst();
    boolean var29 = var25.equals((java.lang.Object)(-2.5987082551847793d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 1.0d+ "'", var21.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test45"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     java.lang.String var13 = var10.nextHexString(86);
//     long var15 = var10.nextPoisson(2.666606011498951d);
//     double var18 = var10.nextCauchy(3.2407643781923445d, 0.06128789602549813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.5977938008933518d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "567ec01fee604121ff82e18c0e3dd22b83e9fea7631558953b3d32d4848571a8d16061ea5ac79e486ce700"+ "'", var13.equals("567ec01fee604121ff82e18c0e3dd22b83e9fea7631558953b3d32d4848571a8d16061ea5ac79e486ce700"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.2799855741410533d);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test46"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var17, var26);
    double[] var30 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var31 = null;
    java.lang.Object[] var33 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var34 = new org.apache.commons.math3.exception.MathInternalError(var31, var33);
    org.apache.commons.math3.util.Pair var35 = new org.apache.commons.math3.util.Pair((java.lang.Object)var30, (java.lang.Object)var31);
    double[] var39 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var43 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var43);
    double[] var48 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var52 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var48, var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var43, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.normalizeArray(var52, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var57 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var30, var52);
    boolean var58 = var57.isSupportConnected();
    double var60 = var57.density((-30.443553573156947d));
    double var61 = var57.getSupportLowerBound();
    double[] var63 = var57.sample(7);
    boolean var64 = var57.isSupportConnected();
    double var65 = var9.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 9705.882351851997d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test47"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.2665124189813681d, (java.lang.Object)0.05016002369058579d);
    java.lang.Object var3 = null;
    boolean var4 = var2.equals(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test48"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var7);
//     int[] var10 = null;
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
//     double var12 = var11.nextGaussian();
//     int[] var15 = new int[] { 0, 1};
//     var11.setSeed(var15);
//     org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var15);
//     double var18 = var17.nextDouble();
//     double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
//     double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var26, var35);
//     double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, 21.869847397459292d);
//     double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
//     double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
//     double[] var58 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var47, var56);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var47, 21.869847397459292d);
//     double[] var65 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var69 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var70 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var65, var69);
//     double[] var74 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
//     double[][] var76 = new double[][] { var74};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var65, var76);
//     org.apache.commons.math3.exception.NotFiniteNumberException var78 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var76);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var60, var76);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var80 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var17, var26, var60);
//     org.apache.commons.math3.exception.NumberIsTooSmallException var84 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var85 = var84.getMin();
//     org.apache.commons.math3.exception.MathInternalError var86 = new org.apache.commons.math3.exception.MathInternalError();
//     var84.addSuppressed((java.lang.Throwable)var86);
//     org.apache.commons.math3.exception.util.ExceptionContext var88 = var86.getContext();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var92 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0, (java.lang.Number)(-0.14097693123713528d), 87);
//     var86.addSuppressed((java.lang.Throwable)var92);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var94 = var92.getDirection();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var95 = var92.getDirection();
//     boolean var97 = org.apache.commons.math3.util.MathArrays.isMonotonic(var26, var95, true);
//     double[] var98 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.3074133936609127d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.07277703352123166d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 10.099504938362077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var85 + "' != '" + 1.0d+ "'", var85.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var97 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var98);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test49"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
//     double var19 = org.apache.commons.math3.util.MathArrays.distance1(var9, var13);
//     double[] var20 = null;
//     double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
//     boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var20, var28);
//     double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
//     double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var28, var35);
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var13, var35);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var45 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var13);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test50"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var9.reSeed(108L);
    double var14 = var9.nextWeibull(194.0d, 0.22333706539912798d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var9.nextChiSquare((-0.7188072570711248d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.22157721196667501d);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     long var7 = var0.nextSecureLong(7L, 508515618537942016L);
//     var0.reSeedSecure();
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 76);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     int var12 = var0.nextSecureInt((-1), 7);
//     int var15 = var0.nextZipf(21, 7.829777967556679E7d);
//     int var18 = var0.nextSecureInt(33, 663);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-39.946915676764355d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "03c11feded69fa666b430b"+ "'", var4.equals("03c11feded69fa666b430b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.195085334906829E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 483);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test53"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     var0.reSeed(10L);
//     double var9 = var0.nextChiSquare(0.0339842858777826d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.3598129538332504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3016475555473488E-9d);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test54"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)(short)1, (java.lang.Number)(-0.32577132027868605d));
    java.lang.Number var5 = var4.getHi();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.32577132027868605d)+ "'", var5.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test55"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var1, true);
//     java.lang.Number var4 = var3.getMin();
//     boolean var5 = var3.getBoundIsAllowed();
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double var8 = var7.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var11 = var9.nextT(0.1431715674774945d);
//     double var14 = var9.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var17 = var9.nextPermutation(83, 33);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     var7.setSeed(var18);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 0);
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var21);
//     java.lang.Object var23 = var22.getFirst();
//     java.lang.Object var24 = var22.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.46173746679671956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.5272164448345604d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.1828989526485037E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test56"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(0.19193457678938466d, 67399.51573302031d);
//     var7.reSeed();
//     long var14 = var7.nextSecureLong((-7896991160906754626L), 13L);
//     int var17 = var7.nextZipf(87, 2.135615013808996d);
//     long var19 = var7.nextPoisson(1.1242241680828247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.08112343929279706d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 89439.3517567197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-3397635115857484800L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1L);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test57"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    double var48 = var47.sample();
    boolean var49 = var47.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test58"); }


    float[] var0 = null;
    float[] var2 = new float[] { 10.0f};
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var8 = new float[] { 0.0f, 100.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    float[] var13 = new float[] { 10.0f};
    float[] var16 = new float[] { 0.0f, (-1.0f)};
    float[] var19 = new float[] { 0.0f, 100.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var13, var19);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var2, var13);
    float[] var23 = null;
    float[] var26 = new float[] { 0.0f, (-1.0f)};
    float[] var29 = new float[] { 0.0f, 100.0f};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var29);
    float[] var31 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var29, var31);
    float[] var34 = new float[] { 10.0f};
    float[] var37 = new float[] { 0.0f, (-1.0f)};
    float[] var40 = new float[] { 0.0f, 100.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var34, var40);
    float[] var45 = new float[] { (-1.0f), 1.0f};
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var45);
    float[] var47 = new float[] { };
    float[] var50 = new float[] { 0.0f, (-1.0f)};
    float[] var53 = new float[] { 0.0f, 100.0f};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var47, var50);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var34, var50);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var31, var34);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var34);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var2, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test59"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var5);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
//     int var10 = var7.nextInt(34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.48218886302439307d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test60"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var8, false);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var19 = var18.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = var18.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = var18.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)24L, (java.lang.Number)6, 86, var21, true);
    boolean var25 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var21, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test61"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     long var7 = var0.nextSecureLong(7L, 508515618537942016L);
//     var0.reSeedSecure();
//     int var12 = var0.nextHypergeometric(26, 0, 3);
//     double var15 = var0.nextGamma(0.014085309936184101d, 1.5603122607175668d);
//     double var17 = var0.nextExponential(0.01522953096080718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.05832631766491675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "8ef86dc00c41e487da13fa"+ "'", var4.equals("8ef86dc00c41e487da13fa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 248674986259040512L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.009487370400012685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.019103409201022232d);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test62"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    double var9 = var2.nextGaussian(4.218937231588664d, 0.9692669377133449d);
    var2.reSeedSecure();
    var2.reSeed(2243596510044315136L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.641195788033711d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     var0.reSeed(10L);
//     long var9 = var0.nextPoisson(0.0028269929560076706d);
//     double var13 = var0.nextUniform((-0.8342606859998907d), 100.0d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.22303966733128888d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 95.44393634217865d);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test64"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)1.1054197636303182d, 200911654);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test65"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError();
    var4.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var6.getContext();
    var0.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test66"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = null;
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    int[] var14 = new int[] { 100, 10, (-1)};
    var10.setSeed(var14);
    int[] var16 = new int[] { };
    var10.setSeed(var16);
    int[] var18 = null;
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var18);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 66);
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 0);
    var8.setSeed(var23);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 21);
    var1.setSeed(var25);
    org.apache.commons.math3.random.RandomDataImpl var29 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var32 = var29.nextSecureInt(112, 88);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test67"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test68"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     boolean var3 = var1.nextBoolean();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var8 = var5.nextGaussian((-0.142898778301125d), 0.8820876449002348d);
//     java.lang.String var10 = var5.nextSecureHexString(7);
//     long var13 = var5.nextLong((-6539308756510265595L), 7860854L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5412671349129086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.2674537567168004d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "345f52e"+ "'", var10.equals("345f52e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3912829382276002816L));
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextCauchy(0.3360744140567591d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.37207374587577347d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "69658ee9ca9e5b96712782d401ff2f6b38cdf7bc48305fdbbeae4bb03d89fb10281d39b0f087ef8866ca473"+ "'", var8.equals("69658ee9ca9e5b96712782d401ff2f6b38cdf7bc48305fdbbeae4bb03d89fb10281d39b0f087ef8866ca473"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 23.322519501295226d);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test70"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     java.lang.String var13 = var10.nextHexString(86);
//     var10.reSeed(0L);
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var23, var32);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.normalizeArray(var32, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var37 = null;
//     java.lang.Object[] var39 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var40 = new org.apache.commons.math3.exception.MathInternalError(var37, var39);
//     org.apache.commons.math3.util.Pair var41 = new org.apache.commons.math3.util.Pair((java.lang.Object)var36, (java.lang.Object)var37);
//     double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
//     double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var58);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var58, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var63 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var36, var58);
//     boolean var64 = var63.isSupportConnected();
//     double[] var66 = var63.sample(318);
//     double var69 = var63.probability(4.577822368915567d, 24.00401720365219d);
//     double var70 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var63);
//     double var71 = var63.getSupportUpperBound();
//     boolean var72 = var63.isSupportUpperBoundInclusive();
//     boolean var73 = var63.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1481944333226402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "75e4fb303cc81c7bb0a336aa6a8731f59d24ac8b22254d3c73bbd61755c6f5c1184000ba391c43315a3314"+ "'", var13.equals("75e4fb303cc81c7bb0a336aa6a8731f59d24ac8b22254d3c73bbd61755c6f5c1184000ba391c43315a3314"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == true);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test71"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var5 = var1.nextFloat();
//     double var6 = var1.nextDouble();
//     int[] var7 = null;
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     int[] var12 = new int[] { 100, 10, (-1)};
//     var8.setSeed(var12);
//     int[] var14 = new int[] { };
//     var8.setSeed(var14);
//     org.apache.commons.math3.random.RandomDataGenerator var16 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var8);
//     boolean var17 = var8.nextBoolean();
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(78);
//     java.lang.Object var20 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var24 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var25 = var24.getMin();
//     org.apache.commons.math3.util.Pair var26 = new org.apache.commons.math3.util.Pair(var20, (java.lang.Object)var24);
//     org.apache.commons.math3.exception.util.Localizable var27 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var31 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var32 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var33 = new org.apache.commons.math3.exception.MathIllegalStateException(var27, var32);
//     boolean var34 = var26.equals((java.lang.Object)var32);
//     int[] var35 = null;
//     org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(var35);
//     double var37 = var36.nextGaussian();
//     byte[] var39 = new byte[] { (byte)10};
//     var36.nextBytes(var39);
//     org.apache.commons.math3.random.RandomDataGenerator var41 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var36);
//     byte[] var43 = new byte[] { (byte)1};
//     var36.nextBytes(var43);
//     boolean var45 = var26.equals((java.lang.Object)var43);
//     var19.nextBytes(var43);
//     var8.nextBytes(var43);
//     var1.nextBytes(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9749593362070783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1875860842036450180L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.70171964f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8402559505597098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + 1.0d+ "'", var25.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-1.5146895460315901d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test72"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     double var14 = var2.nextCauchy(0.8364867927003998d, 2.755734400837643d);
//     var2.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var2.nextBeta((-13705.432458791129d), (-1.016071546142839d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3527912529212212d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-4.172006674509893d));
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test73"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextChiSquare(0.7194659355658699d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.004904901635177446d);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test74"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     long var8 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var9.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3732791124268562d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-671931455001934447L));
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test75"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextSecureInt(22, 54);
//     int[] var12 = var2.nextPermutation(53, 24);
//     var2.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var2.nextGamma(0.8987000150098532d, (-0.6335224300239588d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test76"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(22);
//     int[] var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
//     double var4 = var3.nextGaussian();
//     byte[] var6 = new byte[] { (byte)10};
//     var3.nextBytes(var6);
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     int var10 = var3.nextInt(18);
//     int[] var11 = null;
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
//     double var13 = var12.nextGaussian();
//     int[] var16 = new int[] { 0, 1};
//     var12.setSeed(var16);
//     double var18 = var12.nextGaussian();
//     long var19 = var12.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
//     java.lang.Object var21 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var25 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var26 = var25.getMin();
//     org.apache.commons.math3.util.Pair var27 = new org.apache.commons.math3.util.Pair(var21, (java.lang.Object)var25);
//     org.apache.commons.math3.exception.util.Localizable var28 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var32 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var33 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var34 = new org.apache.commons.math3.exception.MathIllegalStateException(var28, var33);
//     boolean var35 = var27.equals((java.lang.Object)var33);
//     int[] var36 = null;
//     org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var36);
//     double var38 = var37.nextGaussian();
//     byte[] var40 = new byte[] { (byte)10};
//     var37.nextBytes(var40);
//     org.apache.commons.math3.random.RandomDataGenerator var42 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var37);
//     byte[] var44 = new byte[] { (byte)1};
//     var37.nextBytes(var44);
//     boolean var46 = var27.equals((java.lang.Object)var44);
//     var12.nextBytes(var44);
//     var3.nextBytes(var44);
//     var1.nextBytes(var44);
//     var1.setSeed(22);
//     var1.setSeed(64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0191739502553985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1890071049087785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-671931455001934447L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + 1.0d+ "'", var26.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-0.8541495578809964d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test77"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100L, (java.lang.Number)(-1L), (java.lang.Number)0.1431715674774945d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.1431715674774945d+ "'", var5.equals(0.1431715674774945d));

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test78"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)(short)1, (java.lang.Number)(-0.32577132027868605d));
//     java.lang.Number var5 = var4.getHi();
//     java.lang.Number var6 = var4.getHi();
//     java.lang.Throwable[] var7 = var4.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var11 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var9, (java.lang.Number)(-0.8940079763882589d));
//     java.lang.Throwable[] var12 = var11.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var8, (java.lang.Object[])var12);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test79"); }


    java.lang.Comparable[] var2 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var8 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextGaussian(106.0d, 20.087570183274988d);
//     double var20 = var0.nextT(0.9504921197652423d);
//     double var22 = var0.nextChiSquare(0.9999999988421355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6968823859608948d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7267701.170784727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 105.12656948481559d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.4852747377828022d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.5158162288665573d);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test81"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-679.7841048171373d));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var7 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var9 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test82"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     long var13 = var9.nextPoisson(5117965.756713317d);
//     var9.reSeed(1L);
//     var9.reSeedSecure((-187350727499901440L));
//     var9.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var20 = var9.nextHexString(1077317343);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.632912833761883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5113320L);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     long var13 = var0.nextPoisson(10.0d);
//     long var16 = var0.nextLong(7L, 24L);
//     long var19 = var0.nextLong(61L, 6992985943769857466L);
//     java.lang.String var21 = var0.nextSecureHexString(80);
//     var0.reSeed();
//     java.lang.String var24 = var0.nextSecureHexString(28);
//     double var27 = var0.nextCauchy(0.9635745263191828d, 11.96827795427667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2904847684483278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b18b7c132cf4a69749b497ed446b1c4f39ad0219fc8133efc62882155733e6705eea457904a7aab5a2c5294"+ "'", var8.equals("b18b7c132cf4a69749b497ed446b1c4f39ad0219fc8133efc62882155733e6705eea457904a7aab5a2c5294"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10.428224796533286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 11L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 23L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1848953567639100672L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "1c6c30e965532c9c61ccc261b9af204374d298c5e5f405688fd881097c33dc4e71a8f0e651c358bc"+ "'", var21.equals("1c6c30e965532c9c61ccc261b9af204374d298c5e5f405688fd881097c33dc4e71a8f0e651c358bc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "1031708b16b10b3d437a64809969"+ "'", var24.equals("1031708b16b10b3d437a64809969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 4.808512708127654d);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test84"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.5976979528047165d, 0.42470590447540324d, (-1.4160297022995845d), 9705.882351267377d, 0.02372282606752782d, 1.524696304927174d, 5924095.886286657d, (-0.32577132027868605d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1943644.066013602d));

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test85"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)(byte)100, 69);
    java.lang.Number var4 = var3.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)100+ "'", var4.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test86"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
    double[] var31 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var28, var31);
    double[] var36 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var28, var36);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var8, var28);
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var65);
    double[] var69 = org.apache.commons.math3.util.MathArrays.normalizeArray(var65, 9900.0d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var73 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var74 = var73.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var75 = var73.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = var73.getDirection();
    boolean var78 = org.apache.commons.math3.util.MathArrays.isMonotonic(var69, var76, false);
    boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var28, var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test87"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)(-0.3643230061371656d), (java.lang.Number)(-0.8940079763882589d));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.8940079763882589d)+ "'", var5.equals((-0.8940079763882589d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.8940079763882589d)+ "'", var6.equals((-0.8940079763882589d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-0.8940079763882589d)+ "'", var7.equals((-0.8940079763882589d)));

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test88"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.setSeed(14L);
//     var1.setSeed(6118812665134684913L);
//     int var11 = var1.nextInt();
//     boolean var12 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.15606842312263564d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1854482992));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     int var7 = var0.nextSecureInt(16, 34);
//     int var10 = var0.nextPascal(61, 0.5976979528047165d);
//     double var13 = var0.nextGamma(0.6188765767602198d, 0.021333908748968344d);
//     java.lang.String var15 = var0.nextSecureHexString(7);
//     org.apache.commons.math3.distribution.IntegerDistribution var16 = null;
//     int var17 = var0.nextInversionDeviate(var16);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test90"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5479430122306028d, (java.lang.Number)1.254866143501413d, (java.lang.Number)(-0.2686478988557602d));
    java.lang.Number var4 = var3.getHi();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.2686478988557602d)+ "'", var4.equals((-0.2686478988557602d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 0.548 out of [1.255, -0.269] range"+ "'", var5.equals("org.apache.commons.math3.exception.OutOfRangeException: 0.548 out of [1.255, -0.269] range"));

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test91"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    boolean var54 = var47.isSupportUpperBoundInclusive();
    double var56 = var47.inverseCumulativeProbability(0.21990630837896505d);
    boolean var57 = var47.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 9705.882351161024d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test92"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double[] var50 = var47.sample(318);
//     double[] var52 = var47.sample(69);
//     double var54 = var47.cumulativeProbability(0.11407385423536498d);
//     double var56 = var47.density(3.829127667332408d);
//     double var57 = var47.sample();
//     double var59 = var47.density(3.829127667332408d);
//     double var61 = var47.density(380.3232183455007d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var64 = var47.probability(10.987797904821823d, 0.7989403642917304d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 0.0d);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test93"); }


    double[] var3 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var4 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double[] var9 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var13 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var9, var13);
    double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var18);
    double[] var25 = null;
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var25, var33);
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var40);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var18, var40);
    double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
    double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var55, var64);
    double[] var68 = org.apache.commons.math3.util.MathArrays.normalizeArray(var64, 9900.0d);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var68);
    double[] var73 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var77 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var81 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var77, var81);
    double var83 = org.apache.commons.math3.util.MathArrays.distance1(var73, var82);
    double[] var85 = org.apache.commons.math3.util.MathArrays.normalizeArray(var82, 0.0d);
    double[] var86 = org.apache.commons.math3.util.MathArrays.copyOf(var82);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var68, var82);
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeDivide(var5, var68);
    double[] var90 = org.apache.commons.math3.util.MathArrays.copyOf(var68, 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     var0.reSeedSecure(27192867108684266L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var0.nextPermutation(25, 483);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test95"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     double var13 = var0.nextUniform(0.02372282606752782d, 1.327000036267693d);
//     double var15 = var0.nextT(12.353608498975962d);
//     int var18 = var0.nextZipf(84, 0.46646750212754284d);
//     double var20 = var0.nextT(0.4532530767125812d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("7b146d7aa9e547a8d5daf7566", "1ef03bff132b02dc765dca58cb0ac69c286df9ed82b3b67fa0520f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9.233947567881177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2102771187798171d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.6636842253426409d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.18313734417745509d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.9527202556514218d));
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test96"); }


    int[] var3 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var3);
    int var6 = var5.nextInt();
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    int var10 = var7.nextZipf(20, 0.0682504443495231d);
    double var13 = var7.nextBeta(0.07749354664565797d, 52.69070968968668d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2142147742);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4.459558026789758E-5d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test97"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.6255463268645447d, (java.lang.Object)(-36464.24236834751d));
    java.lang.Object var3 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0.6255463268645447d+ "'", var3.equals(0.6255463268645447d));

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test98"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     double var48 = var47.sample();
//     double var49 = var47.getNumericalMean();
//     double var50 = var47.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 9705.882352941177d);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test99"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     long var12 = var2.nextSecureLong(14L, 24L);
//     long var14 = var2.nextPoisson(0.6255463268645447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "c2c6bc60519413be75910aa6e3cdf"+ "'", var9.equals("c2c6bc60519413be75910aa6e3cdf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0L);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test100"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-189.46749166818958d), (java.lang.Number)(-0.6489035278636153d), (java.lang.Number)(-0.7877874469114099d));

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test101"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.setSeed(17);
    int var5 = var1.nextInt(53);
    var1.clear();
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    int[] var10 = null;
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
    int[] var15 = new int[] { 100, 10, (-1)};
    var11.setSeed(var15);
    int[] var17 = new int[] { };
    var11.setSeed(var17);
    org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
    boolean var20 = var11.nextBoolean();
    var11.setSeed((-3200518016629555151L));
    int[] var23 = null;
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
    int[] var28 = new int[] { 100, 10, (-1)};
    var24.setSeed(var28);
    int[] var30 = new int[] { };
    var24.setSeed(var30);
    org.apache.commons.math3.random.RandomDataGenerator var32 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var24);
    byte[] var35 = new byte[] { (byte)100, (byte)(-1)};
    var24.nextBytes(var35);
    var11.nextBytes(var35);
    var8.nextBytes(var35);
    var1.nextBytes(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test102"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    boolean var54 = var47.isSupportUpperBoundInclusive();
    var47.reseedRandomGenerator(9L);
    double[] var58 = var47.sample(71);
    double var59 = var47.getNumericalMean();
    double[] var61 = var47.sample(328);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     long var7 = var0.nextSecureLong(7L, 508515618537942016L);
//     var0.reSeedSecure();
//     double var10 = var0.nextExponential(0.0698963835083768d);
//     int var13 = var0.nextInt(17, 82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1238.284086534702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "50de28cf5566f5ee4f2654"+ "'", var4.equals("50de28cf5566f5ee4f2654"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 126448196784739280L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.01317429176347282d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 49);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test104"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.density(0.0d);
    double var55 = var47.density(0.5769815473378194d);
    boolean var56 = var47.isSupportLowerBoundInclusive();
    var47.reseedRandomGenerator(70L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test105"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(42);
    int var3 = var1.nextInt(94);
    int var5 = var1.nextInt(87);
    var1.setSeed(504);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     var0.reSeed();
//     java.lang.String var14 = var0.nextSecureHexString(9);
//     int var18 = var0.nextHypergeometric(2142147742, 87, 9);
//     java.lang.String var20 = var0.nextSecureHexString(8);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var24 = var0.nextLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8926761318753815d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "5a4f114f56d77f9bd2537c72213881b2cb2ec431cd8a32283ec44dc3db81bb8a6129e625acac5d5e3265ce4"+ "'", var8.equals("5a4f114f56d77f9bd2537c72213881b2cb2ec431cd8a32283ec44dc3db81bb8a6129e625acac5d5e3265ce4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 19.343097983982066d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "7c4f351f3"+ "'", var14.equals("7c4f351f3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "1e88c400"+ "'", var20.equals("1e88c400"));
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test107"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     double var18 = var1.nextUniform(0.10431629821572952d, 0.17463647001913052d, false);
//     int var21 = var1.nextBinomial(3, 1.372678300166809E-9d);
//     double var23 = var1.nextChiSquare(0.009938338305117611d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var25 = var1.nextSecureHexString((-964634710));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.093992590639553d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "dbe16105fa3806565b9857040470d2966e3d451c7737654"+ "'", var10.equals("dbe16105fa3806565b9857040470d2966e3d451c7737654"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "d4bf8dd94c630734fab3f602bf426ce"+ "'", var12.equals("d4bf8dd94c630734fab3f602bf426ce"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "4959fbf8ced6556ef1db7884e235c52aa4862580221be386ea514f94f4fd4"+ "'", var14.equals("4959fbf8ced6556ef1db7884e235c52aa4862580221be386ea514f94f4fd4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.17153465460623044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.0492317307945915E-9d);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test108"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var7.nextSample(var10, 22);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     var0.reSeed(369960311448764288L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation(81, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.774316958211746d));
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test110"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotANumberException var2 = new org.apache.commons.math3.exception.NotANumberException();
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test111"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     java.lang.String var8 = var2.nextHexString(95);
//     double var11 = var2.nextGaussian((-0.09070155974923377d), 0.4429300278176235d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextWeibull((-462.998849121615d), (-0.9733915814778804d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d28813702f62d3722e443e77d7e3f946fac330492e4d12b7cf111a046ff7e1d9bebe4cd8fe7a6e130714e9ee4eac516"+ "'", var8.equals("d28813702f62d3722e443e77d7e3f946fac330492e4d12b7cf111a046ff7e1d9bebe4cd8fe7a6e130714e9ee4eac516"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5136098587196275d);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test112"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.05559908654827428d), 0.2852074555286366d, 0.0d, 1.1022357856078504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-0.01585727400414975d));

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test113"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double[] var50 = var47.sample(318);
//     double var51 = var47.sample();
//     double var52 = var47.getNumericalVariance();
//     double[] var54 = var47.sample(43);
//     var47.reseedRandomGenerator((-2248713966779074371L));
//     double var57 = var47.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1774884.4601956457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 97.05882352941177d);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var5 = var1.nextExponential(9.49251188161346d);
//     double var7 = var1.nextT(5.722170011050812d);
//     java.lang.String var9 = var1.nextSecureHexString(54);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var1.nextSecureLong(1341518512737390592L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.08212739772778001d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 25.741502985929124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.9317800833348363d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "9c4e964ca02b62d8fcfc9060e2ce360acb4d3b7d8f203ae71fc332"+ "'", var9.equals("9c4e964ca02b62d8fcfc9060e2ce360acb4d3b7d8f203ae71fc332"));
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test115"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.1608312127045663E-9d, (java.lang.Number)1.7508552915653752d, false);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test116"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 10.0d};
//     double[] var6 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var10 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var11 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var10);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var10, var19);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     java.lang.Object[] var26 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var27 = new org.apache.commons.math3.exception.MathInternalError(var24, var26);
//     org.apache.commons.math3.util.Pair var28 = new org.apache.commons.math3.util.Pair((java.lang.Object)var23, (java.lang.Object)var24);
//     double var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var23);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 0.3127635608371082d);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 0.5769815473378194d);
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var34);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var36 = null;
//     boolean var39 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var36, true, false);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test117"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var10 = var1.nextFloat();
    double var11 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var14 = var12.nextPoisson(194.0d);
    java.lang.String var16 = var12.nextHexString(20);
    double var18 = var12.nextChiSquare(2.1778253410313186d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.045405984f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.3328432771849152d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 179L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "36f133a28234ac078f40"+ "'", var16.equals("36f133a28234ac078f40"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.46476742558500017d);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test118"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
//     int[] var3 = new int[] { };
//     int[] var4 = null;
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var4);
//     int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var4);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var10 = var8.nextT(0.1431715674774945d);
//     double var13 = var8.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int[] var16 = var8.nextPermutation(88, 34);
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.distance(var0, var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-11.700589182755532d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.138014435335568E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test119"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var25, var34);
//     double[] var37 = null;
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
//     double[] var42 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
//     double var52 = org.apache.commons.math3.util.MathArrays.distance1(var42, var51);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var34, var42);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var34);
//     double[] var56 = new double[] { 10.0d};
//     double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
//     double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var73);
//     double[] var77 = org.apache.commons.math3.util.MathArrays.normalizeArray(var73, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var78 = null;
//     java.lang.Object[] var80 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var81 = new org.apache.commons.math3.exception.MathInternalError(var78, var80);
//     org.apache.commons.math3.util.Pair var82 = new org.apache.commons.math3.util.Pair((java.lang.Object)var77, (java.lang.Object)var78);
//     double var83 = org.apache.commons.math3.util.MathArrays.distanceInf(var56, var77);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var77);
//     double var85 = var84.getNumericalVariance();
//     boolean var86 = var84.isSupportLowerBoundInclusive();
//     double var88 = var84.density((-0.9733915814778804d));
//     double var89 = var84.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.02474592943096532d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 87.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 180.87274125336444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == (-2.0d));
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test120"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1848953567639100672L, var1, 35, var3, true);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test121"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var11 = var8.nextZipf(55, 1.4527908398816171E-9d);
    var8.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var8.nextLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 9);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test122"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     long var10 = var6.nextPoisson(1.3431861837677899d);
//     var6.reSeedSecure(179L);
//     java.lang.String var14 = var6.nextSecureHexString(83);
//     int[] var17 = var6.nextPermutation(51, 24);
//     double var20 = var6.nextUniform((-1.5292628765521852d), 0.7764706560603918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.9050602433595925d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "2fc7333ed1f5439587dca3bb30b036b41aff64a86f7eee7e3d0348de2db52a99929e3ec5f8aed537047"+ "'", var14.equals("2fc7333ed1f5439587dca3bb30b036b41aff64a86f7eee7e3d0348de2db52a99929e3ec5f8aed537047"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1.006177379567696d));
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test123"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var14 = var0.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     var0.reSeedSecure();
//     int[] var18 = var0.nextPermutation(94, 25);
//     int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var21);
//     var22.reSeed();
//     int var26 = var22.nextZipf(18, 0.10832690038004085d);
//     double var28 = var22.nextT(11.36369913641775d);
//     int[] var31 = var22.nextPermutation(33, 31);
//     int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 0);
//     int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
//     int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
//     int var36 = org.apache.commons.math3.util.MathArrays.distance1(var18, var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-4035.840911091044d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.05794363598264543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6688201408368764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.005974231538737376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.2881490346477167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 819);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test124"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 'a'};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var3);
    double[] var9 = new double[] { 10.0d};
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var17, var26);
    double[] var30 = org.apache.commons.math3.util.MathArrays.normalizeArray(var26, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var31 = null;
    java.lang.Object[] var33 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var34 = new org.apache.commons.math3.exception.MathInternalError(var31, var33);
    org.apache.commons.math3.util.Pair var35 = new org.apache.commons.math3.util.Pair((java.lang.Object)var30, (java.lang.Object)var31);
    double var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var30);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var9, 0.3127635608371082d);
    double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var9, 0.5769815473378194d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var45 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Number var46 = var45.getPrevious();
    java.lang.Number var47 = var45.getArgument();
    java.lang.Number var48 = var45.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = var45.getDirection();
    boolean var51 = org.apache.commons.math3.util.MathArrays.isMonotonic(var9, var49, false);
    boolean var53 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var49, false);
    org.apache.commons.math3.exception.MathIllegalStateException var54 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var55 = var54.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + 0.0f+ "'", var46.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + (-1)+ "'", var47.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + 0.0f+ "'", var48.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test125"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var2, var4);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var1, var4);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextWeibull((-1.849480484909317d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 238.47857477987588d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "99fc7013d3649944fb3a53"+ "'", var4.equals("99fc7013d3649944fb3a53"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.4266494750023774E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test127"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     long var12 = var2.nextSecureLong(14L, 24L);
//     double var15 = var2.nextCauchy(0.0d, 6.785854381629338d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var2.nextBeta((-0.6759049083070825d), 9.451831387477975E12d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "606a6309ae25841dd2d1f62cc07a4"+ "'", var9.equals("606a6309ae25841dd2d1f62cc07a4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 19L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-7.247207337058009d));
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test128"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 570720782, (-1102768644));

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var5 = var1.nextExponential(9.49251188161346d);
//     double var8 = var1.nextGaussian(1.22705655817319d, 6.790436471693312E7d);
//     var1.reSeed();
//     var1.reSeed(7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.103415316578952E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 17.111182381271444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-4.619667644782006E7d));
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     double var11 = var0.nextT(0.013022537989140215d);
//     double var14 = var0.nextCauchy(0.31281161042515526d, 9975217.480416201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.46354007342016024d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f368fb2a89d416568a7e6524dc3b992b5933e1803a4449ce09d6d76d313898dc167fef2c7b8453ec05fe20f"+ "'", var8.equals("f368fb2a89d416568a7e6524dc3b992b5933e1803a4449ce09d6d76d313898dc167fef2c7b8453ec05fe20f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 8.95051244870992E32d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-8893406.891580475d));
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test131"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1102768644), (-1053312551));

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test132"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    boolean var5 = var2.equals((java.lang.Object)5546093.532539394d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test133"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    java.lang.Object var7 = var6.getValue();
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var9 = null;
    boolean var10 = var8.equals(var9);
    java.lang.Object var11 = var8.getKey();
    java.lang.Object var12 = var8.getValue();
    java.lang.Object var13 = var8.getValue();
    boolean var15 = var8.equals((java.lang.Object)"6add2df21cdc48bb7b86e81ceca2071a4278a706dde94367933c99c90f68f");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 24.811542425128824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test135"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    double var8 = var2.nextGaussian(1.3621815434775926d, 0.9692669377133449d);
    int var11 = var2.nextInt(0, 5);
    var2.reSeedSecure((-43986082236993568L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var2.nextHypergeometric(111852252, (-423136425), 38);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1054197636303182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test136"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 88);
    double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var23, var32);
    double[] var35 = null;
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    double[][] var37 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var37);
    double[] var42 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var43 = org.apache.commons.math3.util.MathArrays.safeNorm(var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var42);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var52 = var51.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = var51.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var55 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var53, true);
    boolean var57 = org.apache.commons.math3.util.MathArrays.isMonotonic(var42, var53, true);
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeAdd(var42, var61);
    double var68 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == (-887.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 99.04039579888602d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test137"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var6 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    long[][] var8 = new long[][] { var6};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var8);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "f8d5f4184b28c7cabc2e46bfdbec5b09f7e969f66268f9656ad68561ebd085138dc6512397a5e3ec9881b25");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.0746040866803575E8d));
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test139"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.setSeed(14L);
//     var1.setSeed(6118812665134684913L);
//     int var11 = var1.nextInt();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextInt((-118603794));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.46058604115775886d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1854482992));
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test140"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-2.596289776741364E7d), (java.lang.Number)0.003866239501939549d, false);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test141"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     double var16 = var0.nextExponential(0.6591014616866876d);
//     double var19 = var0.nextGamma(0.50527176291182d, 0.5951250420414592d);
//     long var22 = var0.nextSecureLong(0L, 7030608607747463866L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3417516845290889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2.195211190374462d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.30370917051856616d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0038767045758179406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.6835942210405395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.005835099412645639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3285904440241378304L);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test142"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)10.0d, (java.lang.Number)(short)1, (java.lang.Number)(-0.32577132027868605d));
    java.lang.Number var7 = var6.getHi();
    java.lang.Number var8 = var6.getHi();
    java.lang.Throwable[] var9 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-0.32577132027868605d)+ "'", var7.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-0.32577132027868605d)+ "'", var8.equals((-0.32577132027868605d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test143"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    int var8 = var2.nextPascal(16, 0.012115282842360003d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1398);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     long var13 = var0.nextPoisson(10.0d);
//     long var16 = var0.nextLong(7L, 24L);
//     long var19 = var0.nextLong(61L, 6992985943769857466L);
//     java.lang.String var21 = var0.nextSecureHexString(80);
//     double var24 = var0.nextUniform((-1.0436544432495118d), 1.824062541754132E-9d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c9044babbf819cc4a8deabf662be6eb83a46b06b1b02f55a5", "91f6405b3e99d7f96d85eeaf5ad2ffd32645e9149555d2a9f3f73d2d94af0a644bcfac0368b019aaa6ea40b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03845242563591045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "325cd4904b6a4e10872dee9e8e94d56c9249426882ec2cc8e42b90e46f3e1e995cbfb4648d5395c0afd1d2a"+ "'", var8.equals("325cd4904b6a4e10872dee9e8e94d56c9249426882ec2cc8e42b90e46f3e1e995cbfb4648d5395c0afd1d2a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 15.21362702853663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 19L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 237579084850146496L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "e520f66f2040277c628b48aed38f51976636123c71deac25e8668226fb73d5472da8cc723f5a9853"+ "'", var21.equals("e520f66f2040277c628b48aed38f51976636123c71deac25e8668226fb73d5472da8cc723f5a9853"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.9666220741991468d));
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test145"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(22, 18);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Number var4 = var2.getArgument();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(100);
    var6.clear();
    var6.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    var10.reSeedSecure(2563274223793255424L);
    org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var10);
    boolean var15 = var13.equals((java.lang.Object)7.013113343980493E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 22+ "'", var4.equals(22));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     var0.reSeedSecure(8L);
//     var0.reSeed(508515618537942016L);
//     int var13 = var0.nextSecureInt(0, 43);
//     java.lang.String var15 = var0.nextHexString(32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 127.111587628157d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "36ee56b4dfe70954893697"+ "'", var4.equals("36ee56b4dfe70954893697"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.731588689282006E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "53763b856029617c026bd88260517126"+ "'", var15.equals("53763b856029617c026bd88260517126"));
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test147"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var4, var13);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 88);
    double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var33);
    double[] var36 = null;
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var33, var36);
    double[][] var38 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var38);
    org.apache.commons.math3.exception.MathInternalError var40 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var38);
    org.apache.commons.math3.exception.NumberIsTooLargeException var44 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-679.7841048171373d), (java.lang.Number)95, false);
    var40.addSuppressed((java.lang.Throwable)var44);
    java.lang.Number var46 = var44.getMax();
    boolean var47 = var44.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + 95+ "'", var46.equals(95));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test148"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextT(1.818331372129114d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextT((-1.1037176242221964d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.1440400422066794d));

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test149"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     double var7 = var2.nextExponential(25.05052606779598d);
//     double var9 = var2.nextT(0.2384880170596717d);
//     var2.reSeed();
//     double var13 = var2.nextCauchy(0.6938061358177889d, 0.1431715674774945d);
//     double var15 = var2.nextChiSquare(0.5623308420714408d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.084194643041131d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 459.9918162621926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.7884256291839339d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.002455074189009947d);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test150"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.9581229188984522d, 6.599527980157741E-4d, 1126.0675830210619d, 0.0d, (-17.52647517823177d), 5568.461829121496d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-97595.50739671307d));

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test151"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     java.lang.String var8 = var2.nextSecureHexString(2);
//     double var11 = var2.nextGamma(0.08430081831437178d, 26.7909048614082d);
//     var2.reSeedSecure();
//     double var15 = var2.nextUniform(0.9087832633101555d, 2.401452688646927d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var2.nextBinomial(97, 12.211458734486403d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d8"+ "'", var8.equals("d8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.44231465887983695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.2754034582662945d);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test152"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    java.lang.Object var7 = var6.getValue();
    java.lang.Object var8 = var6.getKey();
    org.apache.commons.math3.exception.DimensionMismatchException var11 = new org.apache.commons.math3.exception.DimensionMismatchException(22, 18);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    java.lang.Number var13 = var11.getArgument();
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(100);
    var15.clear();
    var15.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var15);
    var19.reSeedSecure(2563274223793255424L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var19);
    boolean var23 = var6.equals((java.lang.Object)var19);
    java.lang.Object var24 = var6.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 22+ "'", var13.equals(22));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test153"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)61L);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test154"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     java.lang.String var13 = var10.nextHexString(86);
//     int var17 = var10.nextHypergeometric(80, 18, 43);
//     var10.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.8149332491209202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "cc52f2ab2f5aa2a9b9075454206c2e9e3ba298c52c166740eba314b98a055b1cdd7e852e2f49d8fcf20c78"+ "'", var13.equals("cc52f2ab2f5aa2a9b9075454206c2e9e3ba298c52c166740eba314b98a055b1cdd7e852e2f49d8fcf20c78"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test155"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var12 = var9.nextPermutation(66, 20);
    double var15 = var9.nextBeta(4.124408130986206d, 1.8727261569983433d);
    double var18 = var9.nextCauchy((-0.2686478988557602d), 0.3425019720115997d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var9.nextSecureInt(3, (-690853845));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5237619704844522d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2880963064757555d);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     double var18 = var1.nextUniform(0.10431629821572952d, 0.17463647001913052d, false);
//     int var21 = var1.nextPascal(18, 0.1431715674774945d);
//     long var23 = var1.nextPoisson(1.126463083415154E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5025257660538306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "ae50d67f7dea7967117a63931e538a3ba623575bed5520e"+ "'", var10.equals("ae50d67f7dea7967117a63931e538a3ba623575bed5520e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "a5e6b8e48b932556c4cb4fe42b98d70"+ "'", var12.equals("a5e6b8e48b932556c4cb4fe42b98d70"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "1cb68c5298d149e816289306ba816c1b95dcf78f01fa6037f6ca78b365e90"+ "'", var14.equals("1cb68c5298d149e816289306ba816c1b95dcf78f01fa6037f6ca78b365e90"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.12569891742363792d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 101);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0L);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test157"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     var12.reSeed();
//     int var16 = var12.nextZipf(18, 0.10832690038004085d);
//     double var18 = var12.nextT(11.36369913641775d);
//     int[] var21 = var12.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var9);
//     int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 77);
//     int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 48.55853813571144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "13615c40b09e02699feba7"+ "'", var4.equals("13615c40b09e02699feba7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0249728167208097E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.8753516873353685d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test159"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)9.042462336301517d, (java.lang.Number)(-2.307987183853192d), var3);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test160"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1.8557285939727521d), (java.lang.Number)(-1092428417482140062L), (java.lang.Number)0.02409261825292752d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test161"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var7 = var4.nextZipf(96, 1.1594185848885774E-9d);
//     double var9 = var4.nextChiSquare(0.11433830992311975d);
//     double var12 = var4.nextUniform(0.3928760176092778d, 0.9128503986588568d);
//     long var14 = var4.nextPoisson(0.13950886311666869d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.06625992257787683d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2415708812734101724L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0988197107853185E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.7869293469432799d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0L);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test162"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.setSeed(108L);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var12 = var1.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8428626452603972d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.4042022490052266d);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var0.nextSample(var7, 318);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     long var13 = var0.nextPoisson(10.0d);
//     double var16 = var0.nextGaussian(0.4337155679007866d, 0.021333908748968344d);
//     double var19 = var0.nextGaussian(0.0d, 0.214807428689491d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextGamma((-0.7885854311548531d), (-0.8148506618962821d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7060099337734673d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "cd849b842a93a2179560b96c7671bd992ffab5e8f54fe10ad1f2d2ed75ac17ba8d406e9cf5a95ab541f3c79"+ "'", var8.equals("cd849b842a93a2179560b96c7671bd992ffab5e8f54fe10ad1f2d2ed75ac17ba8d406e9cf5a95ab541f3c79"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.21753858659494135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.45189152789301046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0051953651579883d);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     long var8 = var0.nextPoisson(0.636769707396945d);
//     double var11 = var0.nextGaussian((-0.8258598346981539d), 454.7733245704089d);
//     var0.reSeed(2022582015419129856L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 14462.500615362918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "103605bcb5fbfa4e87e24b"+ "'", var4.equals("103605bcb5fbfa4e87e24b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 529.9961815694902d);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test166"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.setSeed(27192867108684266L);
//     double var12 = var1.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5901450212562029d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.23570486064056095d);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test167"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getNumericalMean();
//     double var53 = var47.probability(2.641195788033711d);
//     boolean var54 = var47.isSupportUpperBoundInclusive();
//     double var55 = var47.sample();
//     double var57 = var47.probability(6.813639406926573E-7d);
//     double var59 = var47.cumulativeProbability(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test168"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var10 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, (-0.35429237862306834d));
    double[] var12 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var13, false);
    double[] var16 = null;
    double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var16, var24);
    double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var31);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var12, var24);
    double[] var42 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var42, var51);
    double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 0.0d);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var24, var51);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    org.apache.commons.math3.util.MathArrays.checkPositive(var56);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 199.04522099261766d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test169"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var16);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test170"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 40, 90);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test171"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    double var11 = var2.nextT(23.562469870696063d);
    long var14 = var2.nextLong(460278515774591104L, 1919570930604823808L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var17 = var2.nextSecureLong(4097752537538055884L, (-644916536123436160L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.08515379833665031d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 784212244234295168L);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test172"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var3, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var5);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.25829166996012853d), var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test173"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getSupportUpperBound();
    double var53 = var47.density(0.6938061358177889d);
    double var54 = var47.sample();
    double var55 = var47.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var58 = var47.cumulativeProbability(0.7881276094947616d, 0.27246647420006576d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 9517.474048442906d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test174"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)103.56915419683993d, (-1), var3, true);
    java.lang.Number var6 = var5.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.String var10 = var9.toString();
    java.lang.Throwable[] var11 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var8, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 103.56915419683993d+ "'", var6.equals(103.56915419683993d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.apache.commons.math3.exception.MathIllegalStateException: illegal state"+ "'", var10.equals("org.apache.commons.math3.exception.MathIllegalStateException: illegal state"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test175"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
//     org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var14 = var11.nextInt(10, 100);
//     double var17 = var11.nextUniform((-1.0d), 1.0d);
//     var11.reSeedSecure();
//     org.apache.commons.math3.util.Pair var19 = new org.apache.commons.math3.util.Pair((java.lang.Object)var10, (java.lang.Object)var11);
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double var57 = org.apache.commons.math3.util.MathArrays.distance1(var47, var51);
//     double[] var58 = null;
//     double[] var62 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var66 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var62, var66);
//     boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var58, var66);
//     double var69 = org.apache.commons.math3.util.MathArrays.safeNorm(var66);
//     double[] var73 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var77 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var78 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var73, var77);
//     double[] var79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var66, var73);
//     boolean var80 = org.apache.commons.math3.util.MathArrays.equals(var51, var73);
//     double[] var81 = org.apache.commons.math3.util.MathArrays.copyOf(var51);
//     double[][] var82 = new double[][] { var51};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var28, var82);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var10, var82);
//     org.apache.commons.math3.exception.NotFiniteNumberException var85 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9170532f, (java.lang.Object[])var82);
//     org.apache.commons.math3.exception.MathArithmeticException var86 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.6742684472007663d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 102.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 102.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test176"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var4 = var2.nextT(0.1431715674774945d);
//     double var7 = var2.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var10 = var2.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var2.reSeedSecure();
//     var2.reSeedSecure(7741999113339246307L);
//     double var16 = var2.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     var2.reSeedSecure();
//     int[] var20 = var2.nextPermutation(94, 25);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 0);
//     var1.setSeed(var23);
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var23);
//     java.util.List var26 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var27 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var25, var26);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test177"); }


    double[] var1 = new double[] { 10.0d};
    double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
    double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var9, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    java.lang.Object[] var25 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var23, var25);
    org.apache.commons.math3.util.Pair var27 = new org.apache.commons.math3.util.Pair((java.lang.Object)var22, (java.lang.Object)var23);
    double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var31 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.3127635608371082d);
    double[] var33 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.5769815473378194d);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 79558.81471209228d);
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var40 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var49 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var50 = var49.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = var49.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var53 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var51, true);
    boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var40, var51, true);
    double[] var59 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var63 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var59, var63);
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeAdd(var40, var59);
    double[] var66 = null;
    double[] var70 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var74 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var70, var74);
    boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var66, var74);
    double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
    double[] var81 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var85 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var81, var85);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var74, var81);
    double var88 = org.apache.commons.math3.util.MathArrays.safeNorm(var81);
    boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var81);
    double var90 = org.apache.commons.math3.util.MathArrays.distanceInf(var35, var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 79558.81471209228d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 79548.81471209228d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test178"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.setSeed(0L);
    byte[] var7 = new byte[] { (byte)1, (byte)(-1), (byte)100};
    var1.nextBytes(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test179"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     double var16 = var0.nextExponential(0.6591014616866876d);
//     double var19 = var0.nextGamma(0.50527176291182d, 0.5951250420414592d);
//     int var22 = var0.nextSecureInt(9, 47);
//     double var25 = var0.nextCauchy(13.589650696693303d, 1.8448314989354738E-4d);
//     int var28 = var0.nextSecureInt(0, 37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var31 = var0.nextPermutation(81, 95);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.12112028859494206d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.764655704146315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5601861990039029d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 11.27635429574418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0970284596451716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.03100062256628423d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 13.59018856034275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 3);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test180"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed(100L);
    double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
    var2.reSeedSecure(0L);
    int var17 = var2.nextBinomial(2006952000, 0.9045563448629151d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var20 = var2.nextPermutation(91, 105632918);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-334.73040418701044d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1815399050);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test181"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var5 = var2.nextPermutation(318, 63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextT((-0.05212948525931097d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test182"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     long var12 = var2.nextSecureLong(14L, 24L);
//     var2.reSeed((-1L));
//     double var17 = var2.nextCauchy(0.24952062428591476d, 0.3942922993053048d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var2.nextGamma((-0.759773304439427d), 0.5095887895736975d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "9baf77c8459e0f66dbe6fb9e41e8e"+ "'", var9.equals("9baf77c8459e0f66dbe6fb9e41e8e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 19L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.17157860416301113d));
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test183"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var1, (java.lang.Number)103.56915419683993d, (-1), var4, true);
    java.lang.Number var7 = var6.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var6.getDirection();
    java.lang.Number var9 = var6.getPrevious();
    java.lang.Throwable[] var10 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 103.56915419683993d+ "'", var7.equals(103.56915419683993d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 103.56915419683993d+ "'", var9.equals(103.56915419683993d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

//  public void test184() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest6.test184"); }
//
//
//    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//    org.apache.commons.math3.exception.util.Localizable var21 = null;
//    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//    boolean var48 = var47.isSupportConnected();
//    double var50 = var47.density((-30.443553573156947d));
//    double var51 = var47.getNumericalMean();
//    double var52 = var47.getSupportUpperBound();
//    double var54 = var47.density((-19533.05988397774d));
//    double var56 = var47.probability(1.6200204638860117E-8d);
//    double var57 = var47.getNumericalMean();
//    boolean var58 = var47.isSupportUpperBoundInclusive();
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var60 = var47.sample(301405723);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var3);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var7);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var8);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var12);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var16);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var17);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var18);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var20);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var23);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var29);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var33);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var34);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var38);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var42);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var43);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var44);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var46);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var48 == true);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var50 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var51 == 9517.474048442906d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var52 == 9705.882352941177d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var54 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var56 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var57 == 9517.474048442906d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var58 == true);
//
//  }
//
  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     double var14 = var0.nextCauchy(0.0d, 0.6989809774046034d);
//     int[] var17 = var0.nextPermutation(42904144, 22);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 94);
//     org.apache.commons.math3.random.RandomDataImpl var21 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var23 = var21.nextT(0.1431715674774945d);
//     double var26 = var21.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var29 = var21.nextPermutation(83, 33);
//     int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var29);
//     int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var29);
//     org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var29);
//     org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(var29);
//     int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5633251963178445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f81de976c466d2b6aa47c7dec71f6b4ff8bccce4312f34627e3742cd21cbe2dddae59cd4d4631716f8128fc"+ "'", var8.equals("f81de976c466d2b6aa47c7dec71f6b4ff8bccce4312f34627e3742cd21cbe2dddae59cd4d4631716f8128fc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 16.139998137283122d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.08200840661151985d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-875348.2400928808d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 42692647);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test186"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    boolean var54 = var47.isSupportConnected();
    double var55 = var47.getSupportUpperBound();
    double var56 = var47.getSupportLowerBound();
    double var57 = var47.getNumericalMean();
    double var59 = var47.density(0.0d);
    boolean var60 = var47.isSupportConnected();
    double var61 = var47.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1774884.4601956457d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test187"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(20);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test188"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 'a'};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    java.lang.Comparable[] var11 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    boolean var14 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var11, var12, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var11, var15, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var11, var18, false);
    double[] var24 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var33 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var34 = var33.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = var33.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var35, true);
    boolean var39 = org.apache.commons.math3.util.MathArrays.isMonotonic(var24, var35, true);
    boolean var41 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var11, var35, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5769815473378194d, (java.lang.Number)11, 30, var35, false);
    boolean var45 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var35, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var49 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var50 = var49.getStrict();
    java.lang.String var51 = var49.toString();
    boolean var52 = var49.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = var49.getDirection();
    boolean var55 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var53, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var51.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test189"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    java.lang.Object var7 = var6.getValue();
    java.lang.Object var8 = var6.getKey();
    boolean var10 = var6.equals((java.lang.Object)(-4.092805944621339d));
    org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var6);
    org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)var11, (java.lang.Object)5849594.37426021d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test190"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator(3397311925594058240L);
    double var55 = var47.density(19.104120654673654d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextZipf(96, (-1.868352606993746d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 265.8826102215129d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9617786712981647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "c736780bd68c1e4b8862db0dd266106e6b462dcfd62bf6e314c54b7aba379f"+ "'", var12.equals("c736780bd68c1e4b8862db0dd266106e6b462dcfd62bf6e314c54b7aba379f"));
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test192"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var4 = var1.nextExponential(0.6888245262954816d);
//     var1.reSeedSecure((-1952321163872933406L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.007069799938350412d);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     double var16 = var0.nextBeta(0.6012895846489683d, 199.04522099261766d);
//     int var20 = var0.nextHypergeometric(1126, 87, 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextCauchy((-13.226267204932098d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.5599495430544743d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6024684.748259267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.00887892899038192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(4, 26);
//     java.lang.String var5 = var0.nextHexString(513);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "ba6b32ea9e085dac282fe11d6239f089b4d86c2af32e99f3c51e8c23bb0923630d3c919c2e669b71082d0c931a47df7754591081826f2a8d6f7cf174655df62fd48c70f7d58a0ac00a4ce808a15180e76231eb0f48a8c5d9639ffbbc92aa1478e06b6aee27658e6ef76a5fe30d6ddd113fb3efcab30498a119593cb9507ff62320fc572e65d8bde5aa439514141c9114c3febe15d528c2b41f5c7c8b0b57474331bcd6dd1be1f61767a2f0078183737a764e5afd797edd8f55f2220ce932eb020190e11734e41659fff7d5898d7bbf1d9748c11a3f58fd73634adfbbb4d82f535dfc8ce3dc41e77a2b731a667593de50c654e7dd84af3d7cae18d56539f12c342"+ "'", var5.equals("ba6b32ea9e085dac282fe11d6239f089b4d86c2af32e99f3c51e8c23bb0923630d3c919c2e669b71082d0c931a47df7754591081826f2a8d6f7cf174655df62fd48c70f7d58a0ac00a4ce808a15180e76231eb0f48a8c5d9639ffbbc92aa1478e06b6aee27658e6ef76a5fe30d6ddd113fb3efcab30498a119593cb9507ff62320fc572e65d8bde5aa439514141c9114c3febe15d528c2b41f5c7c8b0b57474331bcd6dd1be1f61767a2f0078183737a764e5afd797edd8f55f2220ce932eb020190e11734e41659fff7d5898d7bbf1d9748c11a3f58fd73634adfbbb4d82f535dfc8ce3dc41e77a2b731a667593de50c654e7dd84af3d7cae18d56539f12c342"));
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     long var18 = var0.nextLong(0L, 12L);
//     double var21 = var0.nextBeta(0.4429300278176235d, 23.255333405607846d);
//     double var24 = var0.nextWeibull(0.9999869680538664d, 0.41199132812854516d);
//     double var26 = var0.nextChiSquare(6.540316540242818d);
//     double var29 = var0.nextGaussian(0.9354117217009348d, 0.1074029478279522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0339858613224566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.48073865860094706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "0efac850c970013a57dca73fe3d559d477216d874a379e1936ec7286ffafdc"+ "'", var12.equals("0efac850c970013a57dca73fe3d559d477216d874a379e1936ec7286ffafdc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0040498379414251485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.14472059023442355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 3.6845632792320107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.9501690483634335d);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test196"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var5 = var4.getStrict();
//     boolean var6 = var4.getStrict();
//     boolean var7 = var4.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var4.getDirection();
//     int var9 = var4.getIndex();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var4.getDirection();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var11 = var4.getDirection();
//     boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var11, true);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test197"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var4 = var3.getMin();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0d+ "'", var4.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var14 = var0.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     int var17 = var0.nextZipf(78, 0.7454450602699914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 229.63736984454997d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.711407729121757E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.642089888186338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.068836712988524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 74);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test199"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     double var18 = var1.nextUniform(0.10431629821572952d, 0.17463647001913052d, false);
//     int var21 = var1.nextInt(9, 96);
//     double var25 = var1.nextUniform((-2342.368360175707d), (-0.10659341427742133d), true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var28 = var1.nextUniform(0.09451216995360798d, 0.03026743343560033d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.108193858925922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "9efe1ebaf68c6dfd1295ef6a83a3f2a056900386e0f990c"+ "'", var10.equals("9efe1ebaf68c6dfd1295ef6a83a3f2a056900386e0f990c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "f972f67d134dd76097933dcf5eb8952"+ "'", var12.equals("f972f67d134dd76097933dcf5eb8952"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "dbcc20a3f4d8da56525e38481572b02450ca2c5918b6b3facd960ceeebf19"+ "'", var14.equals("dbcc20a3f4d8da56525e38481572b02450ca2c5918b6b3facd960ceeebf19"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.12138312216821208d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-659.4339751710313d));
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test200"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    double[] var1 = null;
    double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
    double[] var14 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[][] var16 = new double[][] { var14};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var5);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
    double[] var20 = null;
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var20, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
    double[] var44 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var48 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var44, var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var39, var48);
    double[] var51 = null;
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var48, var51);
    double[] var56 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var56, var65);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var48, var56);
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var28, var48);
    double[] var70 = org.apache.commons.math3.util.MathArrays.normalizeArray(var48, (-61.09525665040872d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var71 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var19, var70);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test201"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     boolean var3 = var1.nextBoolean();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     int[] var11 = new int[] { 100, 10, (-1)};
//     var7.setSeed(var11);
//     int[] var13 = new int[] { };
//     var7.setSeed(var13);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var13);
//     int[] var19 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var19);
//     int var22 = org.apache.commons.math3.util.MathArrays.distance1(var13, var19);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
//     var1.setSeed(var19);
//     boolean var25 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8543153229149429d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     double var18 = var1.nextUniform(0.10431629821572952d, 0.17463647001913052d, false);
//     int var21 = var1.nextBinomial(3, 1.372678300166809E-9d);
//     double var23 = var1.nextChiSquare(0.009938338305117611d);
//     double var26 = var1.nextGaussian(0.9994866012634822d, 11162.246588731135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14.417023525664202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2dec6c1a90c9da760ac9aab304c0c0209b2d3bebd089d08"+ "'", var10.equals("2dec6c1a90c9da760ac9aab304c0c0209b2d3bebd089d08"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "3f692a37382ab23e9bf2a78489f7b6f"+ "'", var12.equals("3f692a37382ab23e9bf2a78489f7b6f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "e76717338152b6160921a10eae0b78c91cd07460115e901d6b9e7814fb235"+ "'", var14.equals("e76717338152b6160921a10eae0b78c91cd07460115e901d6b9e7814fb235"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.14907357889960185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.4250098343235727E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-2209.6146010449115d));
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test203"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.522562011502786E-9d, 1.1361943172125468d, 0.3328432771849152d, (-1.2984501854200612d), 0.3417516845290889d, 0.012500446548344674d, 1.8138862480316373d, 3.541393959544263d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 5.995777437498262d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test204"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var12 = var9.nextInt(5, 58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 7);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(25);
//     double var7 = var0.nextWeibull(4.645762949836714d, 0.08430081831437178d);
//     int var11 = var0.nextHypergeometric(71, 63, 9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal(0, (-0.3171329611873611d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-15.780232104053683d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7269400aa14a47ec3c5baf0cd"+ "'", var4.equals("7269400aa14a47ec3c5baf0cd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.07736907537232049d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var10 = var0.nextCauchy(7.500930705661022d, 0.4841123961597962d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextGaussian(9.400418087873408d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.4541333498363462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03087037788190176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7.1071714003898085d);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test207"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Number var4 = var3.getPrevious();
    java.lang.String var5 = var3.toString();
    boolean var6 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test208"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    var1.clear();
    int var5 = var1.nextInt();
    float var6 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1347491339));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.8255079f);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test209"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     int[] var9 = null;
//     int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
//     int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//     org.apache.commons.math3.random.RandomDataGenerator var15 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var18 = var15.nextInt(10, 100);
//     double var20 = var15.nextExponential(10.0d);
//     double var22 = var15.nextExponential(0.407741687198951d);
//     var15.reSeed();
//     int var27 = var15.nextHypergeometric(75, 0, 3);
//     int[] var30 = var15.nextPermutation(43, 10);
//     int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
//     org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var33);
//     var34.reSeed();
//     int var38 = var34.nextZipf(18, 0.10832690038004085d);
//     double var40 = var34.nextT(11.36369913641775d);
//     int[] var43 = var34.nextPermutation(33, 31);
//     int[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 0);
//     int[] var47 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 55);
//     double var48 = org.apache.commons.math3.util.MathArrays.distance(var31, var47);
//     double var49 = org.apache.commons.math3.util.MathArrays.distance(var7, var47);
//     org.apache.commons.math3.random.RandomDataImpl var50 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var52 = var50.nextT(0.1431715674774945d);
//     double var55 = var50.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var58 = var50.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var50.reSeedSecure();
//     var50.reSeedSecure(7741999113339246307L);
//     double var64 = var50.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     var50.reSeedSecure();
//     int[] var68 = var50.nextPermutation(94, 25);
//     int[] var69 = org.apache.commons.math3.util.MathArrays.copyOf(var68);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var70 = org.apache.commons.math3.util.MathArrays.distance(var47, var69);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 22.427680716436896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.16832275288681717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-1.4241236618094746d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 85.53361912137238d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == (-2.542771614372219d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 0.0019364331693935706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 0.3528969287614487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0.08246368128585632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     var0.reSeed(0L);
//     double var18 = var0.nextWeibull(6.785854381629338d, 4736077.9249220705d);
//     double var20 = var0.nextChiSquare(0.4188489407275768d);
//     var0.reSeed(0L);
//     long var25 = var0.nextSecureLong(12L, 100L);
//     int var28 = var0.nextSecureInt(0, 1889776577);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.47673798556300007d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6678948.753683769d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4955414.248644063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.11235981905790325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 30L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1074722571);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test211"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     long var13 = var0.nextPoisson(10.0d);
//     long var16 = var0.nextLong(7L, 24L);
//     long var19 = var0.nextLong(5L, 4097752537538055884L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextBeta(0.0d, (-349.08602480059557d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9128848111144321d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2568e7a11c2159b29f8fc4eaab7a68cf6b3be0f6dbebe934d4ab6693d5e7a33e7246c05f9de7a5785895ef6"+ "'", var8.equals("2568e7a11c2159b29f8fc4eaab7a68cf6b3be0f6dbebe934d4ab6693d5e7a33e7246c05f9de7a5785895ef6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9.405660056174861d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 20L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1016917385840206720L);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test212"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.6044871530760823d), (java.lang.Number)1.4387505701387593d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test213"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    var3.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0d+ "'", var4.equals(1.0d));

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test214"); }


    double[] var0 = null;
    double[] var1 = null;
    double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var1, var9);
    double var12 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var16 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 88);
    double var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var25);
    double[] var33 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var37 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var33, var37);
    double[] var42 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var43 = org.apache.commons.math3.util.MathArrays.safeNorm(var42);
    double[][] var44 = new double[][] { var42};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var33, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var50 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var50, var59);
    double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var59, 88);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var59);
    double[] var67 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var71 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var67, var71);
    double[] var76 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var76);
    double[][] var78 = new double[][] { var76};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var67, var78);
    double var80 = org.apache.commons.math3.util.MathArrays.safeNorm(var67);
    double var81 = org.apache.commons.math3.util.MathArrays.distance1(var63, var67);
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var25, var63);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var63);
    double[] var87 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var88 = org.apache.commons.math3.util.MathArrays.safeNorm(var87);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var87);
    double[] var91 = org.apache.commons.math3.util.MathArrays.normalizeArray(var89, 0.0d);
    double var92 = org.apache.commons.math3.util.MathArrays.distanceInf(var63, var91);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var0, var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 99.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test215"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-794.3022400505874d), (-3.6740148286150687d), (-596.7450887352298d), (-0.3815370706710368d), 0.14105383960970733d, 1.254866143501413d, 1.4276096462825826E-9d, (-0.7785348699116214d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3146.1355851280173d);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test216"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     double var13 = var7.nextUniform(1.0658587049379844d, 454.7733245704089d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var7.nextCauchy((-9414148.940115623d), (-0.1211796535429454d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.14090188952043245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 34.08534215706243d);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test217"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(0L);
//     int var12 = var7.nextBinomial(505, 0.5476442177036671d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var7.nextChiSquare((-0.5903111221322579d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.14172105576112562d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 260);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test218"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.4423815046747017d), (java.lang.Number)1334093301298512896L, (java.lang.Number)40);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test219"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeed(1L);
    var2.reSeed(1334093301298512896L);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     var0.reSeed();
//     int var13 = var0.nextZipf(91, 9.890633464336622d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextSecureInt(18, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1912.9203503078877d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "6a5c7bae0612c79dc003d8"+ "'", var4.equals("6a5c7bae0612c79dc003d8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.606500615488515E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test221"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.probability(2.641195788033711d);
    boolean var54 = var47.isSupportUpperBoundInclusive();
    double var55 = var47.getSupportLowerBound();
    boolean var56 = var47.isSupportLowerBoundInclusive();
    double var58 = var47.probability((-0.6783852588377042d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test222"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     int var13 = var0.nextBinomial(10, 0.2425808062257773d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8172211806147929d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4967984.171272678d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test223"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var2.getValue();
    java.lang.Object var6 = var2.getFirst();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var8 = var7.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test224"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     java.lang.String var8 = var2.nextSecureHexString(2);
//     double var11 = var2.nextGamma(0.08430081831437178d, 26.7909048614082d);
//     var2.reSeedSecure();
//     double var15 = var2.nextUniform(0.9087832633101555d, 2.401452688646927d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var2.nextHypergeometric(70, 10, 105632918);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d4"+ "'", var8.equals("d4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.44231465887983695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.2754034582662945d);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test225"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.27076499912961083d, (java.lang.Object)2.204842907154319d);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test226"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var7 = var4.nextZipf(96, 1.1594185848885774E-9d);
//     var4.reSeedSecure(14L);
//     int var13 = var4.nextHypergeometric(103, 1, 43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9309536278401231d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-4644066832242564528L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test227"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0, (java.lang.Number)(-0.14097693123713528d), 87);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    long[] var12 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var12);
    long[][] var14 = new long[][] { var12};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var14);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, (java.lang.Object[])var14);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var14);
    java.lang.Number var20 = var6.getPrevious();
    java.lang.Throwable[] var21 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-0.99489747431299d), (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + (-0.14097693123713528d)+ "'", var20.equals((-0.14097693123713528d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test228"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.0d), (java.lang.Number)0.20851425337288942d, 11);
    boolean var4 = var3.getStrict();
    boolean var5 = var3.getStrict();
    boolean var6 = var3.getStrict();
    int var7 = var3.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test229"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var4 = var2.nextT(1.818331372129114d);
//     java.lang.String var6 = var2.nextSecureHexString(25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var2.nextPermutation(818120085, 29);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.1440400422066794d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "8be510ab95a1233414bb49651"+ "'", var6.equals("8be510ab95a1233414bb49651"));
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-679.7841048171373d));
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    long[] var12 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var12);
    long[][] var14 = new long[][] { var12};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var14);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var8, (java.lang.Object[])var14);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var14);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.049321626654843825d, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-4.1647302236801416E11d), (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var5 = var1.nextExponential(9.49251188161346d);
//     org.apache.commons.math3.distribution.IntegerDistribution var6 = null;
//     int var7 = var1.nextInversionDeviate(var6);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var14 = var0.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     int[] var17 = var0.nextPermutation(1588471, 29);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 305.1409095331988d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.002760285739761245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.4492256567816337d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.04372436448352761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.6591014616866876d, (java.lang.Number)0.018830280094064424d, false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.018830280094064424d+ "'", var5.equals(0.018830280094064424d));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test234"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-2.0d), (java.lang.Number)(-0.46662863617956996d), true);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     java.lang.String var7 = var0.nextSecureHexString(76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "d53d3675526c6ee45f2f02c95248f7f4a74e0156bbc5d67ce0accd6a861be46db9e875f32fb94cdb91b4cc4"+ "'", var5.equals("d53d3675526c6ee45f2f02c95248f7f4a74e0156bbc5d67ce0accd6a861be46db9e875f32fb94cdb91b4cc4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "b8ba12f61f858821457c620449f174ead92bcc407f5c9e7d30c00a391f14988311bfc04cf671"+ "'", var7.equals("b8ba12f61f858821457c620449f174ead92bcc407f5c9e7d30c00a391f14988311bfc04cf671"));
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test236"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
//     double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double var35 = org.apache.commons.math3.util.MathArrays.distance1(var25, var29);
//     double[] var39 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
//     double var49 = org.apache.commons.math3.util.MathArrays.distance1(var39, var48);
//     double[] var51 = org.apache.commons.math3.util.MathArrays.normalizeArray(var48, 0.0d);
//     double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var48);
//     double var53 = org.apache.commons.math3.util.MathArrays.distance1(var25, var48);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 2784.9275671086507d);
//     double[] var57 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 0.11433830816137684d);
//     double var58 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var57);
//     double[] var60 = new double[] { 10.0d};
//     double[] var64 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var68 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var69 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var64, var68);
//     double[] var73 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var77 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var78 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var73, var77);
//     double[] var79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var68, var77);
//     double[] var81 = org.apache.commons.math3.util.MathArrays.normalizeArray(var77, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var82 = null;
//     java.lang.Object[] var84 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var85 = new org.apache.commons.math3.exception.MathInternalError(var82, var84);
//     org.apache.commons.math3.util.Pair var86 = new org.apache.commons.math3.util.Pair((java.lang.Object)var81, (java.lang.Object)var82);
//     double var87 = org.apache.commons.math3.util.MathArrays.distanceInf(var60, var81);
//     boolean var88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var60);
//     double[] var89 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var90 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var60, var89);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test237"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.298518314710266d, (java.lang.Number)0.18638408f, 7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test238"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     java.lang.Object var18 = var17.getValue();
//     java.lang.Object var19 = var17.getSecond();
//     java.lang.Object var20 = var17.getSecond();
//     java.lang.Object var21 = var17.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.8783690917566327d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test239"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.8242846637404583d), (java.lang.Number)24, false);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test240"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 42);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test241"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)38.525847830700606d, (java.lang.Number)0.28523564f, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.28523564f+ "'", var5.equals(0.28523564f));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test242"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.4523170714609886d), (java.lang.Number)4.3002793875004945d, (java.lang.Number)0.6809144527090116d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test243"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(99, 64);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 64);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test244"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var9 = null;
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
//     int[] var14 = new int[] { 100, 10, (-1)};
//     var10.setSeed(var14);
//     int[] var16 = new int[] { };
//     var10.setSeed(var16);
//     int[] var18 = null;
//     int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var18);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 66);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 0);
//     var8.setSeed(var23);
//     int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
//     var1.setSeed(var23);
//     org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(78);
//     java.lang.Object var29 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var33 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var34 = var33.getMin();
//     org.apache.commons.math3.util.Pair var35 = new org.apache.commons.math3.util.Pair(var29, (java.lang.Object)var33);
//     org.apache.commons.math3.exception.util.Localizable var36 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var40 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var41 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var42 = new org.apache.commons.math3.exception.MathIllegalStateException(var36, var41);
//     boolean var43 = var35.equals((java.lang.Object)var41);
//     int[] var44 = null;
//     org.apache.commons.math3.random.Well19937c var45 = new org.apache.commons.math3.random.Well19937c(var44);
//     double var46 = var45.nextGaussian();
//     byte[] var48 = new byte[] { (byte)10};
//     var45.nextBytes(var48);
//     org.apache.commons.math3.random.RandomDataGenerator var50 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var45);
//     byte[] var52 = new byte[] { (byte)1};
//     var45.nextBytes(var52);
//     boolean var54 = var35.equals((java.lang.Object)var52);
//     var28.nextBytes(var52);
//     int[] var56 = null;
//     org.apache.commons.math3.random.Well19937c var57 = new org.apache.commons.math3.random.Well19937c(var56);
//     int[] var61 = new int[] { 100, 10, (-1)};
//     var57.setSeed(var61);
//     int[] var63 = new int[] { };
//     var57.setSeed(var63);
//     org.apache.commons.math3.random.Well19937c var65 = new org.apache.commons.math3.random.Well19937c(var63);
//     int[] var69 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var70 = new org.apache.commons.math3.random.Well19937c(var69);
//     org.apache.commons.math3.random.Well19937c var71 = new org.apache.commons.math3.random.Well19937c(var69);
//     int var72 = org.apache.commons.math3.util.MathArrays.distance1(var63, var69);
//     int[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69);
//     var28.setSeed(var73);
//     double var75 = org.apache.commons.math3.util.MathArrays.distance(var23, var73);
//     org.apache.commons.math3.random.Well19937c var77 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var78 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var77);
//     var78.reSeedSecure(100L);
//     var78.reSeedSecure(1L);
//     int[] var85 = var78.nextPermutation(100, 18);
//     int[] var87 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 15);
//     int var88 = org.apache.commons.math3.util.MathArrays.distance1(var73, var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.10705364139104981d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + 1.0d+ "'", var34.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == (-0.24820288962004822d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 220);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test245"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     long var13 = var9.nextPoisson(0.9304525547601544d);
//     double[] var17 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
//     org.apache.commons.math3.util.Pair var28 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var17);
//     java.lang.Object var29 = var28.getValue();
//     boolean var31 = var28.equals((java.lang.Object)0.0024004543037950076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7314423803447273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test246"); }


    double[] var1 = new double[] { 10.0d};
    double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
    double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var9, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    java.lang.Object[] var25 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var23, var25);
    org.apache.commons.math3.util.Pair var27 = new org.apache.commons.math3.util.Pair((java.lang.Object)var22, (java.lang.Object)var23);
    double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var31 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.3127635608371082d);
    double[] var33 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.5769815473378194d);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 79558.81471209228d);
    double[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test247"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Object[] var12 = new java.lang.Object[] { true};
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var12);
    boolean var14 = var6.equals((java.lang.Object)var12);
    org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test248"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 15);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test249"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(7530142578955372636L);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1605494387));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test250"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    double var8 = var2.nextGaussian(1.3621815434775926d, 0.9692669377133449d);
    int[] var11 = var2.nextPermutation(819, 79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1054197636303182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test251"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(7530142578955372636L);
//     boolean var2 = var1.nextBoolean();
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(22);
//     int[] var5 = null;
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var5);
//     double var7 = var6.nextGaussian();
//     byte[] var9 = new byte[] { (byte)10};
//     var6.nextBytes(var9);
//     org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var6);
//     int var13 = var6.nextInt(18);
//     int[] var14 = null;
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
//     double var16 = var15.nextGaussian();
//     int[] var19 = new int[] { 0, 1};
//     var15.setSeed(var19);
//     double var21 = var15.nextGaussian();
//     long var22 = var15.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var15);
//     java.lang.Object var24 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var28 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var29 = var28.getMin();
//     org.apache.commons.math3.util.Pair var30 = new org.apache.commons.math3.util.Pair(var24, (java.lang.Object)var28);
//     org.apache.commons.math3.exception.util.Localizable var31 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var35 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var36 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var37 = new org.apache.commons.math3.exception.MathIllegalStateException(var31, var36);
//     boolean var38 = var30.equals((java.lang.Object)var36);
//     int[] var39 = null;
//     org.apache.commons.math3.random.Well19937c var40 = new org.apache.commons.math3.random.Well19937c(var39);
//     double var41 = var40.nextGaussian();
//     byte[] var43 = new byte[] { (byte)10};
//     var40.nextBytes(var43);
//     org.apache.commons.math3.random.RandomDataGenerator var45 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var40);
//     byte[] var47 = new byte[] { (byte)1};
//     var40.nextBytes(var47);
//     boolean var49 = var30.equals((java.lang.Object)var47);
//     var15.nextBytes(var47);
//     var6.nextBytes(var47);
//     var4.nextBytes(var47);
//     var1.nextBytes(var47);
//     int var55 = var1.nextInt(63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-2.1195469195970054d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.018846441683336785d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-671931455001934447L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + 1.0d+ "'", var29.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.06324048323582356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 33);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test252"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.8517994291561204d, 45.42182937163152d, 0.9758237560631358d, (-0.2635931869882604d), 2.6312450040134223d, (-0.34047520993710634d), 0.5987553781231536d, 0.9745686568813362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 38.12072236570342d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test253"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, var2, (java.lang.Number)6.251783231069299d, false);
    boolean var6 = var5.getBoundIsAllowed();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test254"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var9.nextInt(95, 75);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8302606272728371d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test255"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 8.967394155328378d};
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var2, (java.lang.Number)6.785854381629338d, 58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var5.getDirection();
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var6, true);
    double[] var12 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var16 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var20 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var12, var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double[] var26 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.4013839659209113d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var30 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var31 = var30.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = var30.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = var30.getDirection();
    boolean var36 = org.apache.commons.math3.util.MathArrays.checkOrder(var26, var33, true, false);
    boolean var38 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var33, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test256"); }
// 
// 
//     double[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { (short)1};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, false);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var13 = var12.getStrict();
//     java.lang.String var14 = var12.toString();
//     boolean var15 = var12.getStrict();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var20 = var19.getStrict();
//     var12.addSuppressed((java.lang.Throwable)var19);
//     java.lang.Number var22 = var19.getArgument();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var23 = var19.getDirection();
//     boolean var25 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var23, true);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var23, false);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test257"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var2.getSecond();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test258"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1590605);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test259"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     java.lang.String var13 = var10.nextHexString(86);
//     var10.reSeed(0L);
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var23, var32);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.normalizeArray(var32, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var37 = null;
//     java.lang.Object[] var39 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var40 = new org.apache.commons.math3.exception.MathInternalError(var37, var39);
//     org.apache.commons.math3.util.Pair var41 = new org.apache.commons.math3.util.Pair((java.lang.Object)var36, (java.lang.Object)var37);
//     double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
//     double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var58);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var58, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var63 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var36, var58);
//     boolean var64 = var63.isSupportConnected();
//     double[] var66 = var63.sample(318);
//     double var69 = var63.probability(4.577822368915567d, 24.00401720365219d);
//     double var70 = var10.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var63);
//     double var71 = var63.getSupportUpperBound();
//     double var72 = var63.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.26245980733128654d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "b85c99f930c191dc86af64af1c0af7fbd3cbf2f942b05fc108ea9abd4a1c940f85fd7032c8ef4dbba54515"+ "'", var13.equals("b85c99f930c191dc86af64af1c0af7fbd3cbf2f942b05fc108ea9abd4a1c940f85fd7032c8ef4dbba54515"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1774884.4601956457d);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test260"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.setSeed(108L);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.setSeed(0);
//     var1.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9391346920246163d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test261"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var6 = var4.nextPoisson(1.1761827992407105E-9d);
//     long var9 = var4.nextSecureLong(16L, 1239325836194842715L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 869128640211847040L);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     double var18 = var1.nextUniform(0.10431629821572952d, 0.17463647001913052d, false);
//     int var21 = var1.nextBinomial(3, 1.372678300166809E-9d);
//     double var24 = var1.nextUniform((-0.8524008904342466d), 14.417023525664202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.221977888965215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "d434c3a95a4874174355f3906a3ede5c8b3a498607b473e"+ "'", var10.equals("d434c3a95a4874174355f3906a3ede5c8b3a498607b473e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "8361eb9e31202082f85c8428d51c3b3"+ "'", var12.equals("8361eb9e31202082f85c8428d51c3b3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "cb45894957fd5de8f5d7ff1cb09b77595de6c92382f98b6c206474157d024"+ "'", var14.equals("cb45894957fd5de8f5d7ff1cb09b77595de6c92382f98b6c206474157d024"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.12862215927792692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.12413971149988412d));
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test263"); }


    double[] var1 = new double[] { 10.0d};
    double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
    double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var9, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    java.lang.Object[] var25 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var23, var25);
    org.apache.commons.math3.util.Pair var27 = new org.apache.commons.math3.util.Pair((java.lang.Object)var22, (java.lang.Object)var23);
    double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var22);
    double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
    double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var37, var41);
    double[] var51 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var55 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var59 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var59);
    double var61 = org.apache.commons.math3.util.MathArrays.distance1(var51, var60);
    double[] var63 = org.apache.commons.math3.util.MathArrays.normalizeArray(var60, 0.0d);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var60);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var37, var60);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var37);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var71 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.0d), (java.lang.Number)0.20851425337288942d, 11);
    boolean var72 = var71.getStrict();
    boolean var73 = var71.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var74 = var71.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var37, var74, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test264"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 'a'};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var2, false);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Comparable[] var7 = new java.lang.Comparable[] { 'a'};
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var7, var8, false);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var7);
    java.lang.Comparable[] var16 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var17, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var22 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var20, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    boolean var25 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var23, false);
    double[] var29 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var29);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var38 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var39 = var38.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = var38.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var40, true);
    boolean var44 = org.apache.commons.math3.util.MathArrays.isMonotonic(var29, var40, true);
    boolean var46 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var40, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var48 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5769815473378194d, (java.lang.Number)11, 30, var40, false);
    boolean var50 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var7, var40, false);
    boolean var52 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var40, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test265"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();
    java.lang.Throwable[] var1 = var0.getSuppressed();
    java.lang.Throwable[] var2 = var0.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test266"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
    double[] var31 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var28, var31);
    double[] var36 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var28, var36);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var8, var28);
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var65);
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var28, var56);
    double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
    double[] var81 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var82 = org.apache.commons.math3.util.MathArrays.safeNorm(var81);
    double[][] var83 = new double[][] { var81};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var72, var83);
    double var85 = org.apache.commons.math3.util.MathArrays.safeNorm(var72);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeAdd(var28, var72);
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var91 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var92 = var91.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var93 = var91.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var94 = var91.getDirection();
    boolean var97 = org.apache.commons.math3.util.MathArrays.checkOrder(var28, var94, false, false);
    double[] var99 = org.apache.commons.math3.util.MathArrays.normalizeArray(var28, 0.9019432617648498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test267"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.setSeed(0L);
//     byte[] var4 = null;
//     var1.nextBytes(var4);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test268"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var25, var34);
//     double[] var37 = null;
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
//     double[] var42 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
//     double var52 = org.apache.commons.math3.util.MathArrays.distance1(var42, var51);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var34, var42);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var34);
//     double[] var56 = new double[] { 10.0d};
//     double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
//     double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var73);
//     double[] var77 = org.apache.commons.math3.util.MathArrays.normalizeArray(var73, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var78 = null;
//     java.lang.Object[] var80 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var81 = new org.apache.commons.math3.exception.MathInternalError(var78, var80);
//     org.apache.commons.math3.util.Pair var82 = new org.apache.commons.math3.util.Pair((java.lang.Object)var77, (java.lang.Object)var78);
//     double var83 = org.apache.commons.math3.util.MathArrays.distanceInf(var56, var77);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var77);
//     double[] var86 = var84.sample(88);
//     double var87 = var84.getSupportUpperBound();
//     double var88 = var84.getSupportLowerBound();
//     double var89 = var84.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8763723768270637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 87.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == (-2.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == (-99.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == (-99.0d));
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test269"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    double var54 = var47.getSupportUpperBound();
    double var55 = var47.getNumericalVariance();
    double var56 = var47.getNumericalMean();
    double var57 = var47.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 9705.882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1774884.4601956457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 97.05882352941177d);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test270"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var9 = null;
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
//     int[] var14 = new int[] { 100, 10, (-1)};
//     var10.setSeed(var14);
//     int[] var16 = new int[] { };
//     var10.setSeed(var16);
//     int[] var18 = null;
//     int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var18);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 66);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 0);
//     var8.setSeed(var23);
//     int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
//     var1.setSeed(var23);
//     int[] var30 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(var30);
//     org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var30);
//     float var33 = var32.nextFloat();
//     java.lang.Object var34 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var38 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Number var39 = var38.getMin();
//     org.apache.commons.math3.util.Pair var40 = new org.apache.commons.math3.util.Pair(var34, (java.lang.Object)var38);
//     org.apache.commons.math3.exception.util.Localizable var41 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var45 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var46 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var47 = new org.apache.commons.math3.exception.MathIllegalStateException(var41, var46);
//     boolean var48 = var40.equals((java.lang.Object)var46);
//     int[] var49 = null;
//     org.apache.commons.math3.random.Well19937c var50 = new org.apache.commons.math3.random.Well19937c(var49);
//     double var51 = var50.nextGaussian();
//     byte[] var53 = new byte[] { (byte)10};
//     var50.nextBytes(var53);
//     org.apache.commons.math3.random.RandomDataGenerator var55 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var50);
//     byte[] var57 = new byte[] { (byte)1};
//     var50.nextBytes(var57);
//     boolean var59 = var40.equals((java.lang.Object)var57);
//     var32.nextBytes(var57);
//     var1.nextBytes(var57);
//     var1.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5344325124248446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.4987576f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + 1.0d+ "'", var39.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == (-2.1754816752711363d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextPoisson((-0.6925297642477137d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-4.946562253032609d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test272"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.setSeed(108L);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var14 = var10.nextUniform((-1.915642490695788d), 0.015781400485699374d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var10.nextSecureLong(188760334292408672L, (-5885824031410116532L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.3259148956673268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1.5411942829991334d));
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test273"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var6.nextUniform((-1.0525166427107446d), 0.05861285090965593d, false);
//     var6.reSeed(105448882508299760L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7865768943925796d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.6380914514352947d));
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test274"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-679.7841048171373d));
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    long[] var11 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    long[][] var13 = new long[][] { var11};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var13);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var13);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.049321626654843825d, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-4.1647302236801416E11d), (java.lang.Object[])var13);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test275"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var13 = var10.nextGamma(32.408412718428444d, 1.2786735854696036d);
//     var10.reSeed();
//     double var16 = var10.nextChiSquare(1.3482818995170671d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.22876453274597547d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 37.77324497465748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.6583939016891529d);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     int var9 = var0.nextBinomial(62, 0.10431629821572952d);
//     double var13 = var0.nextUniform((-5.891344771123487d), 0.0d, true);
//     var0.reSeedSecure(4076121792065851015L);
//     var0.reSeed();
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var0.nextSample(var17, 73);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test277"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var14 = var10.nextUniform(0.3777487957046537d, 79558.81471209228d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var10.nextUniform(0.0d, (-2.307987183853192d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5453751228513699d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 66508.710817166d);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test278"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     double var11 = var6.nextGaussian(0.13752805238137772d, 10.28736861355142d);
//     double var15 = var6.nextUniform((-161.3169897931843d), 4.919242794826979d, true);
//     double var18 = var6.nextGaussian(8.976959447253524d, 0.034278820082008166d);
//     double var22 = var6.nextUniform(0.10053253057864703d, 0.5401370577670481d, true);
//     double var24 = var6.nextT(0.11255642846027802d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.7369359018843327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.2556303181317578d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-33.91245518016272d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 9.016874563197895d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.396033848210548d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.48253090916831615d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test279"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.2269378137240654d, (java.lang.Number)0.6244813f, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.6244813f+ "'", var5.equals(0.6244813f));

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test280"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)5507950371326924800L, (java.lang.Number)1.4276096462825826E-9d, (java.lang.Number)12);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.4276096462825826E-9d+ "'", var5.equals(1.4276096462825826E-9d));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test281"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(59L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(23L);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test282"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     var7.reSeed();
//     var7.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1661111975730762d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test283"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     double var5 = var0.nextT(23.562469870696063d);
//     double var8 = var0.nextUniform((-0.6509646211185096d), 2.2655029077315754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-3.577096497119581d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5537008874718288d);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test284"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     var1.setSeed(0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5636153103878673d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.8241407500560395d));
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test285"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     double var11 = var2.nextT(81.560782738241d);
//     java.lang.String var13 = var2.nextHexString(27);
//     java.lang.String var15 = var2.nextSecureHexString(44);
//     var2.reSeed();
//     var2.reSeedSecure(2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "5da1e5a4c0d4aa62206ebcdae3155"+ "'", var9.equals("5da1e5a4c0d4aa62206ebcdae3155"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.7110563084721201d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "685639e4a20eacd2e00e09a64d7"+ "'", var13.equals("685639e4a20eacd2e00e09a64d7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "129e3d57ae35c852edfcfc80922a8aecab9c7ac0eb90"+ "'", var15.equals("129e3d57ae35c852edfcfc80922a8aecab9c7ac0eb90"));
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test286"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test287"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     long var7 = var0.nextSecureLong(7L, 508515618537942016L);
//     var0.reSeedSecure(3771079338555689984L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextZipf(96, (-0.36834119618796374d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7.7564981946500815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "285d91fadfceb5c97721e3"+ "'", var4.equals("285d91fadfceb5c97721e3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 306261602331212928L);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test288"); }


    int[] var3 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    int var5 = var4.nextInt();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
    int var9 = var6.nextBinomial(0, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2142147742);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test289"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure(1L);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(100);
//     var15.clear();
//     var15.setSeed(1L);
//     org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var15);
//     int var22 = var19.nextPascal(49, 0.10832690038004085d);
//     double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
//     double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var30, var39);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var39, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var44 = null;
//     java.lang.Object[] var46 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var47 = new org.apache.commons.math3.exception.MathInternalError(var44, var46);
//     org.apache.commons.math3.util.Pair var48 = new org.apache.commons.math3.util.Pair((java.lang.Object)var43, (java.lang.Object)var44);
//     double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
//     double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var65);
//     double[] var69 = org.apache.commons.math3.util.MathArrays.normalizeArray(var65, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var70 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var43, var65);
//     boolean var71 = var70.isSupportConnected();
//     double var73 = var70.density((-30.443553573156947d));
//     double var74 = var70.getSupportUpperBound();
//     double var76 = var70.cumulativeProbability(0.03603256163404128d);
//     double var77 = var19.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var70);
//     double var78 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var70);
//     double var79 = var70.getSupportLowerBound();
//     double var82 = var70.probability(1.6961371316133027d, 2.0652764284882417d);
//     double var83 = var70.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.18979838166249982d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 318);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 9705.88235142365d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 9705.882352941177d);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test290"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var2.getValue();
    java.lang.Object var6 = var2.getFirst();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var7);
    java.lang.Object var9 = var7.getFirst();
    java.lang.Object var10 = var7.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (short)100+ "'", var9.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 10.0d+ "'", var10.equals(10.0d));

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma((-1.006177379567696d), 1.2987310543860286d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 47);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeedSecure();
//     double var12 = var0.nextGamma(12.353608498975962d, 0.03603256163404128d);
//     int var15 = var0.nextPascal(71, 0.6081907677733664d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("a51da7cc511739eb6e05627c4cf078b811607b958d69d8898aeb488820aa30d046ac647f1be45eeece13e47", "d65d66");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5934068174588227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0d4d13522289cd58dee549b1f974b60851ac47f93271627ff982500115f362b6bab5d1ef84b7aef102bb3b5"+ "'", var8.equals("0d4d13522289cd58dee549b1f974b60851ac47f93271627ff982500115f362b6bab5d1ef84b7aef102bb3b5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.14053811887584935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 34);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test293"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.09882240266647696d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test294"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.2469924126740568d), var1, true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test295"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var1.nextLong(4993360439734039552L, 508515618537942016L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test296"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)1L, var7);
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var3, var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var2, var7);
//     org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var7);
//     org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     java.lang.Object[] var14 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var13, var14);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test297"); }


    long[] var3 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test298"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure();
//     java.lang.String var14 = var2.nextSecureHexString(12);
//     double var17 = var2.nextWeibull(2.125285173880562d, 4736077.9249220705d);
//     double var20 = var2.nextUniform(0.026649323194479716d, 1.1891493406396207d);
//     double var23 = var2.nextGaussian(0.6888245262954816d, 0.7435948986141283d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("b20642ee15b4d9e16ee2af7e6d5911ce4df992674a970ec2e9a1fbc785324b47213eb23782a649d3dad4e21", "f893a5cb8d110b5151ee47a86c5a4ff904b4aa04d9e799f6c7dec58a81fc66279");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.41426758794037144d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "e6d1e2676e7a"+ "'", var14.equals("e6d1e2676e7a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2854393.253614072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.9595578962232205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.0529864925708049d));
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test299"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var15);
    double[] var25 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.linearCombination(var21, var34);
    double[] var37 = null;
    double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var37, var45);
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var45, var52);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeAdd(var21, var45);
    double[] var63 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var67 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var63, var67);
    double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var67, var76);
    double[] var79 = null;
    boolean var80 = org.apache.commons.math3.util.MathArrays.equals(var76, var79);
    double var81 = org.apache.commons.math3.util.MathArrays.distance1(var45, var76);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var85 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var86 = var85.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = var85.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var88 = var85.getDirection();
    boolean var90 = org.apache.commons.math3.util.MathArrays.isMonotonic(var45, var88, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-9896.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test300"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)19.80545808541791d, (java.lang.Number)7.084194643041131d, true);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Comparable[] var9 = new java.lang.Comparable[] { (short)1};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
//     boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var9, var10, false);
//     org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var9);
//     double[] var17 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var21 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var17, var21);
//     double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var21, var30);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 21.869847397459292d);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var47 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
//     double[][] var49 = new double[][] { var47};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var38, var49);
//     double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
//     double[] var55 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var59 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var63 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var59, var63);
//     double var65 = org.apache.commons.math3.util.MathArrays.distance1(var55, var64);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 88);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var38, var64);
//     boolean var69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var68);
//     double[] var73 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.copyOf(var73);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var83 = var82.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var84 = var82.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var86 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var84, true);
//     boolean var88 = org.apache.commons.math3.util.MathArrays.isMonotonic(var73, var84, true);
//     boolean var91 = org.apache.commons.math3.util.MathArrays.checkOrder(var68, var84, false, false);
//     boolean var93 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var9, var84, false);
//     org.apache.commons.math3.exception.NotFiniteNumberException var94 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)70, (java.lang.Object[])var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var95 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var9);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test301"); }


    java.lang.Number var0 = null;
    double[] var6 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var14 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var10, var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var6, var15);
    java.lang.Comparable[] var19 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var22 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var19, var20, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var23 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.8258598346981539d), (java.lang.Object[])var19);
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var26, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var29, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    boolean var34 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var32, false);
    double[] var38 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var39 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var38);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var48 = var47.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = var47.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var49, true);
    boolean var53 = org.apache.commons.math3.util.MathArrays.isMonotonic(var38, var49, true);
    boolean var55 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var49, true);
    java.lang.Comparable[] var57 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = null;
    boolean var60 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var57, var58, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    boolean var63 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var57, var61, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = null;
    boolean var66 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var57, var64, false);
    double[] var70 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var71 = org.apache.commons.math3.util.MathArrays.safeNorm(var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.copyOf(var70);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var79 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var80 = var79.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var81 = var79.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var81, true);
    boolean var85 = org.apache.commons.math3.util.MathArrays.isMonotonic(var70, var81, true);
    boolean var87 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var57, var81, true);
    boolean var89 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var81, false);
    boolean var91 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var19, var81, false);
    boolean var93 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var81, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var95 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)0.70762956f, (-964634710), var81, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test302"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var1.nextT(0.1431715674774945d);
//     java.lang.String var5 = var1.nextHexString(22);
//     double var7 = var1.nextChiSquare(0.012774969105543068d);
//     int[] var10 = var1.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
//     var13.reSeed();
//     int var17 = var13.nextZipf(18, 0.10832690038004085d);
//     double var19 = var13.nextT(11.36369913641775d);
//     int[] var22 = var13.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
//     int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var22);
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var10);
//     int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 77);
//     int var28 = org.apache.commons.math3.util.MathArrays.distance1(var0, var27);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test303"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var25, var34);
//     double[] var37 = null;
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
//     double[] var42 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
//     double var52 = org.apache.commons.math3.util.MathArrays.distance1(var42, var51);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var34, var42);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var34);
//     double[] var56 = new double[] { 10.0d};
//     double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
//     double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var73);
//     double[] var77 = org.apache.commons.math3.util.MathArrays.normalizeArray(var73, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var78 = null;
//     java.lang.Object[] var80 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var81 = new org.apache.commons.math3.exception.MathInternalError(var78, var80);
//     org.apache.commons.math3.util.Pair var82 = new org.apache.commons.math3.util.Pair((java.lang.Object)var77, (java.lang.Object)var78);
//     double var83 = org.apache.commons.math3.util.MathArrays.distanceInf(var56, var77);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var77);
//     double[] var86 = var84.sample(88);
//     boolean var87 = var84.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9306719488143274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 87.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == true);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test304"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    long var9 = var2.nextPoisson(100.00999950005d);
    var2.reSeed((-509399413869688601L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 108L);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     var0.reSeedSecure(11L);
//     var0.reSeed(23L);
//     double var19 = var0.nextGamma(6.366378550567545d, 0.04517268717766476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 19.92147403941535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.4540243767200889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.3312303779986292d);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     long var7 = var0.nextSecureLong(7L, 508515618537942016L);
//     var0.reSeedSecure();
//     int var12 = var0.nextHypergeometric(26, 0, 3);
//     java.lang.String var14 = var0.nextSecureHexString(61);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5119789186481337d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5d1c5d203fdb6e55ac61ce"+ "'", var4.equals("5d1c5d203fdb6e55ac61ce"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 368020248050012672L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "8235bfcbe1ff7f741c28651670e45b773fc437c0326028029a32e4256c225"+ "'", var14.equals("8235bfcbe1ff7f741c28651670e45b773fc437c0326028029a32e4256c225"));
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test307"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     java.lang.String var8 = var2.nextHexString(95);
//     var2.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var2.nextGamma((-0.7633650944639981d), 0.8820876449002348d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b5f9bdc82ee51031a5c2b49c3519bfad981307336637149cb617eacc5c3337efc54b223b0cb93bd14df7aa9b1073de8"+ "'", var8.equals("b5f9bdc82ee51031a5c2b49c3519bfad981307336637149cb617eacc5c3337efc54b223b0cb93bd14df7aa9b1073de8"));
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     int var7 = var0.nextInt(0, 100);
//     int var11 = var0.nextHypergeometric(39, 15, 31);
//     int var14 = var0.nextInt(17, 505);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(0.5117876358710434d, (-4222763.102918504d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.474965716079939d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 198);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test309"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.setSeed(27192867108684266L);
//     boolean var12 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.5502287318140797d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test310"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var3.nextUniform(0.0427783828805389d, (-97595.50739671307d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test311"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var1, true);
//     java.lang.Number var4 = var3.getMin();
//     boolean var5 = var3.getBoundIsAllowed();
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double var8 = var7.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var11 = var9.nextT(0.1431715674774945d);
//     double var14 = var9.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var17 = var9.nextPermutation(83, 33);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     var7.setSeed(var18);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 0);
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var21);
//     java.lang.Object var23 = var22.getFirst();
//     org.apache.commons.math3.util.Pair var24 = new org.apache.commons.math3.util.Pair(var22);
//     java.lang.Object var25 = var22.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.2210462893366103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-82.112235930485d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.49198952013258956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     java.lang.String var12 = var1.nextSecureHexString(31);
//     java.lang.String var14 = var1.nextSecureHexString(61);
//     var1.reSeed();
//     double var17 = var1.nextExponential(0.029336411166028985d);
//     int var20 = var1.nextZipf(10, 1.1761827992407105E-9d);
//     double var23 = var1.nextUniform((-0.8711245800294634d), 0.5649871035897142d);
//     int var26 = var1.nextZipf(5, 0.002985747981427016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.526150536038859d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "bb9f6fb8a92a537f5defc8b31e9bb34a1827cb46a912884"+ "'", var10.equals("bb9f6fb8a92a537f5defc8b31e9bb34a1827cb46a912884"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2ff197b308baa91ed8e3aa72eb7b82f"+ "'", var12.equals("2ff197b308baa91ed8e3aa72eb7b82f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "b18b431794e9353543c8cc9587ed07cb24c6b01b060ec1129e5d5e6fedfe9"+ "'", var14.equals("b18b431794e9353543c8cc9587ed07cb24c6b01b060ec1129e5d5e6fedfe9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.002379053498704609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.5979588615698425d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test313"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var7);
//     int[] var13 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var13);
//     int var16 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var19 = var17.nextT(0.1431715674774945d);
//     java.lang.String var21 = var17.nextHexString(22);
//     double var23 = var17.nextChiSquare(0.012774969105543068d);
//     int[] var26 = var17.nextPermutation(43, 3);
//     int var27 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var26);
//     int[] var28 = null;
//     org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var28);
//     int[] var33 = new int[] { 100, 10, (-1)};
//     var29.setSeed(var33);
//     int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var33);
//     int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.9237109149945818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "db4bb274bbd9290ebfec29"+ "'", var21.equals("db4bb274bbd9290ebfec29"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 6.096461071036092E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test314"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    boolean var52 = var47.isSupportLowerBoundInclusive();
    var47.reseedRandomGenerator(100L);
    boolean var55 = var47.isSupportUpperBoundInclusive();
    double var56 = var47.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1774884.4601956457d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test315"); }


    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var13 = var12.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = var12.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var6, (java.lang.Number)0.8055186938534216d, 60, var14, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)2259531241767611904L, (java.lang.Number)1.3482818995170671d, 42, var14, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)3.6743395464043864d, (java.lang.Number)0.21429366601291247d, 0, var14, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var5 = var1.nextExponential(9.49251188161346d);
//     double var8 = var1.nextGaussian(1.22705655817319d, 6.790436471693312E7d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextExponential((-0.17843497100961647d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 19.293166101940695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2867332982009229E8d);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test317"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.3425019720115997d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test318"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1L, var4);
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var0, var4);
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     java.lang.Object[] var13 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var11, var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, var13);
//     org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var9, var13);
//     org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var8, var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var13);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test319"); }


    int[] var0 = new int[] { };
    int[] var1 = null;
    int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
    int[] var3 = new int[] { };
    int[] var4 = null;
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var4);
    int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var4);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var8 = null;
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int[] var13 = new int[] { 100, 10, (-1)};
    var9.setSeed(var13);
    int[] var15 = new int[] { };
    var9.setSeed(var15);
    int[] var17 = null;
    int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var17);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 66);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 0);
    double var23 = org.apache.commons.math3.util.MathArrays.distance(var0, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test320"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.6177707802291372d), var2, false);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test321"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9705.882351884546d, (java.lang.Number)(-0.9392255482827288d), false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.9392255482827288d)+ "'", var5.equals((-0.9392255482827288d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 9,705.882 is larger than, or equal to, the maximum (-0.939)"+ "'", var6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 9,705.882 is larger than, or equal to, the maximum (-0.939)"));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test322"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test323"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)5507950371326924800L, (java.lang.Number)1.4276096462825826E-9d, (java.lang.Number)12);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 12+ "'", var5.equals(12));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.4276096462825826E-9d+ "'", var6.equals(1.4276096462825826E-9d));

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test324"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     double var7 = var2.nextExponential(25.05052606779598d);
//     double var9 = var2.nextT(0.2384880170596717d);
//     var2.reSeed();
//     double var13 = var2.nextCauchy(0.6938061358177889d, 0.1431715674774945d);
//     var2.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.084194643041131d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 459.9918162621926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.6679476450906755d);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     int var12 = var0.nextSecureInt((-1), 7);
//     int var15 = var0.nextZipf(21, 7.829777967556679E7d);
//     long var18 = var0.nextSecureLong(100L, 5351699876684508160L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 131.53332288200093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c19badd55a7215af4b3e7c"+ "'", var4.equals("c19badd55a7215af4b3e7c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2268867213406337E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2935978053492992000L);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test326"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(36, 19);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test327"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var7 = var6.getSecond();
    java.lang.Object var8 = var6.getValue();
    boolean var9 = var3.equals((java.lang.Object)var6);
    java.lang.Object var10 = var6.getKey();
    java.lang.Object var11 = var6.getSecond();
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var13 = var6.getFirst();
    java.lang.Object var14 = var6.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0d+ "'", var7.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0d+ "'", var8.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)100+ "'", var10.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 10.0d+ "'", var11.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (short)100+ "'", var13.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 10.0d+ "'", var14.equals(10.0d));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test328"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    double var11 = var2.nextT(23.562469870696063d);
    long var14 = var2.nextLong(460278515774591104L, 1919570930604823808L);
    double var17 = var2.nextCauchy((-4.092805944621339d), 0.8642969913217398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.08515379833665031d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 784212244234295168L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-4.8187506347820985d));

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test329"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 21.869847397459292d);
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    double[] var34 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[][] var36 = new double[][] { var34};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var25, var36);
    org.apache.commons.math3.exception.NotFiniteNumberException var38 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var36);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var36);
    double[] var43 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var43);
    double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var43);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var52 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var53 = var52.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var54 = var52.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var56 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var54, true);
    boolean var58 = org.apache.commons.math3.util.MathArrays.isMonotonic(var43, var54, true);
    double[] var62 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var66 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var62, var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var62);
    double var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var43);
    double[] var73 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var75 = org.apache.commons.math3.util.MathArrays.copyOf(var73);
    double[] var77 = org.apache.commons.math3.util.MathArrays.normalizeArray(var75, 0.0d);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 22.44102686025421d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test330"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     boolean var3 = var1.nextBoolean();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     int[] var11 = new int[] { 100, 10, (-1)};
//     var7.setSeed(var11);
//     int[] var13 = new int[] { };
//     var7.setSeed(var13);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var13);
//     int[] var19 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var19);
//     int var22 = org.apache.commons.math3.util.MathArrays.distance1(var13, var19);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
//     var1.setSeed(var19);
//     long var25 = var1.nextLong();
//     double var26 = var1.nextGaussian();
//     var1.clear();
//     byte[] var28 = null;
//     var1.nextBytes(var28);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test331"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(35, 504);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test332"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.531817242990463d, (java.lang.Number)37.187702453096186d, false);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test333"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     int[] var1 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     double var3 = var2.nextGaussian();
//     int[] var6 = new int[] { 0, 1};
//     var2.setSeed(var6);
//     double var8 = var2.nextGaussian();
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     long var12 = var10.nextPoisson(0.6989809774046034d);
//     long var14 = var10.nextPoisson(0.9304525547601544d);
//     double[] var18 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance1(var18, var27);
//     org.apache.commons.math3.util.Pair var29 = new org.apache.commons.math3.util.Pair((java.lang.Object)var14, (java.lang.Object)var18);
//     org.apache.commons.math3.exception.util.Localizable var30 = null;
//     org.apache.commons.math3.exception.util.Localizable var31 = null;
//     double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
//     double[] var44 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
//     double[][] var46 = new double[][] { var44};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var46);
//     org.apache.commons.math3.exception.MathIllegalStateException var48 = new org.apache.commons.math3.exception.MathIllegalStateException(var31, (java.lang.Object[])var46);
//     org.apache.commons.math3.exception.MathIllegalStateException var49 = new org.apache.commons.math3.exception.MathIllegalStateException(var30, (java.lang.Object[])var46);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var46);
//     org.apache.commons.math3.exception.MathInternalError var51 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.21998425825434592d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 10.099504938362077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test334"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)570.8733363614718d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test335"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    var47.reseedRandomGenerator((-509399413869688601L));
    double var55 = var47.cumulativeProbability(0.0d);
    boolean var56 = var47.isSupportUpperBoundInclusive();
    double var57 = var47.getNumericalMean();
    double var58 = var47.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1774884.4601956457d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test336"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(260);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test337"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double[] var50 = var47.sample(318);
    double[] var52 = var47.sample(69);
    double var54 = var47.cumulativeProbability(0.11407385423536498d);
    boolean var55 = var47.isSupportUpperBoundInclusive();
    var47.reseedRandomGenerator(2585576727318569613L);
    boolean var58 = var47.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test338"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.7320508075688772d, (java.lang.Number)(-33988.90347597093d), false);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     java.lang.String var6 = var4.toString();
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test339"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    double[] var5 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var9 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var13 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var9, var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var5, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double[] var21 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var21, var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.normalizeArray(var30, 0.0d);
    double var34 = org.apache.commons.math3.util.MathArrays.distance(var17, var33);
    double[] var39 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var43 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var43);
    double[] var48 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    double[][] var50 = new double[][] { var48};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var39, var50);
    org.apache.commons.math3.exception.NotFiniteNumberException var52 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var50);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var33, var50);
    org.apache.commons.math3.exception.MathIllegalArgumentException var54 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var50);
    org.apache.commons.math3.exception.MathIllegalStateException var55 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test340"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    double[] var21 = null;
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    double[] var34 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[][] var36 = new double[][] { var34};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var25, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var25);
    double[] var39 = null;
    double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var39, var47);
    double var50 = org.apache.commons.math3.util.MathArrays.distance(var25, var47);
    double var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var47);
    double[] var53 = new double[] { 10.0d};
    double[] var57 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var61 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var57, var61);
    double[] var66 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var70 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var61, var70);
    double[] var74 = org.apache.commons.math3.util.MathArrays.normalizeArray(var70, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var75 = null;
    java.lang.Object[] var77 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var78 = new org.apache.commons.math3.exception.MathInternalError(var75, var77);
    org.apache.commons.math3.util.Pair var79 = new org.apache.commons.math3.util.Pair((java.lang.Object)var74, (java.lang.Object)var75);
    double var80 = org.apache.commons.math3.util.MathArrays.distanceInf(var53, var74);
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    double[] var83 = org.apache.commons.math3.util.MathArrays.normalizeArray(var53, 0.3127635608371082d);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var47, var83);
    double[] var86 = org.apache.commons.math3.util.MathArrays.copyOf(var83, 65);
    double[] var87 = null;
    double[] var91 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var95 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var96 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var91, var95);
    boolean var97 = org.apache.commons.math3.util.MathArrays.equals(var87, var95);
    double var98 = org.apache.commons.math3.util.MathArrays.safeNorm(var95);
    boolean var99 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var83, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == false);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test341"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.396033848210548d);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test342"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextUniform(0.012774969105543068d, 21.869847397459292d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var8 = var2.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 21.32187955682191d);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test343"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var13 = var0.nextExponential(0.9999999874067345d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 104469.3977802506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.34935126763658E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.85303679934511d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.05711703527015417d);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test344"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     double var10 = var6.nextT(0.03026743343560033d);
//     var6.reSeed(2334411078355409408L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.5197424338218057d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4318.904543168557d);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test345"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)73);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test346"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 2248);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test347"); }
// 
// 
//     int[] var3 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     int[] var11 = new int[] { 100, 10, (-1)};
//     var7.setSeed(var11);
//     int[] var13 = new int[] { };
//     var7.setSeed(var13);
//     org.apache.commons.math3.random.RandomDataGenerator var15 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var7);
//     byte[] var18 = new byte[] { (byte)100, (byte)(-1)};
//     var7.nextBytes(var18);
//     var5.nextBytes(var18);
//     org.apache.commons.math3.random.RandomDataImpl var21 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var23 = var21.nextT(0.1431715674774945d);
//     double var26 = var21.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int[] var29 = var21.nextPermutation(88, 34);
//     var5.setSeed(var29);
//     int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 8146583.740109393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.3648293287350062E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test348"); }
// 
// 
//     org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
//     java.lang.Object var3 = var2.getSecond();
//     java.lang.Object var4 = var2.getFirst();
//     double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
//     org.apache.commons.math3.random.RandomDataGenerator var14 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var17 = var14.nextInt(10, 100);
//     double var20 = var14.nextUniform((-1.0d), 1.0d);
//     var14.reSeedSecure();
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var14);
//     boolean var23 = var2.equals((java.lang.Object)var14);
//     java.lang.Object var24 = var2.getValue();
//     java.lang.Object var25 = var2.getKey();
//     java.lang.Object var26 = var2.getFirst();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.8985068471676252d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + 10.0d+ "'", var24.equals(10.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + (short)100+ "'", var25.equals((short)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (short)100+ "'", var26.equals((short)100));
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test349"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure(1L);
//     double var16 = var2.nextBeta(1.4392153051361142E-9d, 54746.28386276295d);
//     var2.reSeed(6L);
//     int var21 = var2.nextBinomial(43, 0.8285212713951737d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.1635189913681196d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 38);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     var0.reSeedSecure(0L);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var25);
//     double[] var29 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var30 = null;
//     java.lang.Object[] var32 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var33 = new org.apache.commons.math3.exception.MathInternalError(var30, var32);
//     org.apache.commons.math3.util.Pair var34 = new org.apache.commons.math3.util.Pair((java.lang.Object)var29, (java.lang.Object)var30);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var42, var51);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var29, var51);
//     boolean var57 = var56.isSupportConnected();
//     double var59 = var56.density((-30.443553573156947d));
//     double var60 = var56.getSupportLowerBound();
//     double[] var62 = var56.sample(7);
//     double var63 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var56);
//     double var64 = var56.sample();
//     double var65 = var56.getNumericalVariance();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var68 = var56.probability(0.9124181026314566d, (-0.7727733926356978d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.15843091133226905d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1ea99a2d1c99299859b10a"+ "'", var4.equals("1ea99a2d1c99299859b10a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 9705.88235159202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1774884.4601956457d);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test351"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var25 = var24.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var24.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = var24.getDirection();
    boolean var29 = org.apache.commons.math3.util.MathArrays.isMonotonic(var20, var27, false);
    double[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 260);
    double[] var36 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var36);
    double[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var45 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var46 = var45.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = var45.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var49 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var47, true);
    boolean var51 = org.apache.commons.math3.util.MathArrays.isMonotonic(var36, var47, true);
    double[] var55 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var59 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var59);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeAdd(var36, var55);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeAdd(var30, var36);
    double[] var66 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var70 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var70);
    double[] var75 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var75);
    double[][] var77 = new double[][] { var75};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var66, var77);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var30, var66);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test352"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.5679544318648708d), (java.lang.Number)1.2250023356852043E-9d, (java.lang.Number)0.0698963835083768d);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test353"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     java.lang.String var13 = var10.nextHexString(86);
//     var10.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var10.nextWeibull(0.7194659355658699d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7092407118541698d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "0a99c440bf3852326d227104bc676297bf99cd1a5dd01f943f4698cb2d1d5d8996b1b215d848bf4b3ee21f"+ "'", var13.equals("0a99c440bf3852326d227104bc676297bf99cd1a5dd01f943f4698cb2d1d5d8996b1b215d848bf4b3ee21f"));
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test354"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var11 = var9.nextPoisson(0.6989809774046034d);
//     double var14 = var9.nextCauchy(7860796.064051028d, 6.785854381629338d);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var9.nextSample(var15, 505);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     double var7 = var0.nextExponential(0.4301403036978695d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextSecureLong(7765006300557716338L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 143.00897023388822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.7596325008958253d);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test356"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    boolean var9 = var1.nextBoolean();
    boolean var10 = var1.nextBoolean();
    double var11 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5527318654953131d);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test357"); }
// 
// 
//     int[] var3 = new int[] { 0, 0, 0};
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
//     double var8 = var7.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var11 = var9.nextT(0.1431715674774945d);
//     double var14 = var9.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var17 = var9.nextPermutation(83, 33);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     var7.setSeed(var18);
//     var5.setSeed(var18);
//     int[] var21 = null;
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     double var23 = var22.nextGaussian();
//     byte[] var25 = new byte[] { (byte)10};
//     var22.nextBytes(var25);
//     org.apache.commons.math3.random.RandomDataGenerator var27 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var22);
//     var27.reSeedSecure();
//     var27.reSeedSecure();
//     long var31 = var27.nextPoisson(1.3431861837677899d);
//     var27.reSeedSecure(179L);
//     java.lang.String var35 = var27.nextSecureHexString(83);
//     int[] var38 = var27.nextPermutation(51, 24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var38);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.3518749979726503d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-9.031714798682386E9d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.06915074630727573d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.6428155138873302d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "3c07b77b3202e867d68bbb8768551a550458510edbc293837411ea26f3aee131230d5af15028510d368"+ "'", var35.equals("3c07b77b3202e867d68bbb8768551a550458510edbc293837411ea26f3aee131230d5af15028510d368"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.041602742051144226d, (java.lang.Number)1774884.4601956457d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test359"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2784.9275671086507d, (java.lang.Number)(-8.95529581416185d), (java.lang.Number)1.330906978493525E301d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test360"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.3902725132439794d, (java.lang.Number)0.4032303251089228d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test361"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.1594185848885774E-9d, 0.2650533450485204d, 0.0d, 2.2207488072808506d, 8.981043557653793d, 5.690439787085667d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 51.106087590329864d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test362"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var9 = null;
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var9, var17);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var17, var24);
    double[] var34 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var34, var43);
    double var45 = org.apache.commons.math3.util.MathArrays.linearCombination(var30, var43);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var43);
    double[] var50 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var54 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var50, var54);
    double[] var59 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var63 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var59, var63);
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var54, var63);
    double[] var67 = org.apache.commons.math3.util.MathArrays.normalizeArray(var63, 9900.0d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var71 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var72 = var71.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var73 = var71.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var74 = var71.getDirection();
    boolean var76 = org.apache.commons.math3.util.MathArrays.isMonotonic(var67, var74, false);
    boolean var79 = org.apache.commons.math3.util.MathArrays.checkOrder(var3, var74, false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-9896.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test363"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var10 = var1.nextFloat();
    double var11 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var12.nextBinomial(27, (-0.22876453274597547d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.045405984f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.3328432771849152d);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     var0.reSeedSecure(0L);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var25);
//     double[] var29 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var30 = null;
//     java.lang.Object[] var32 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var33 = new org.apache.commons.math3.exception.MathInternalError(var30, var32);
//     org.apache.commons.math3.util.Pair var34 = new org.apache.commons.math3.util.Pair((java.lang.Object)var29, (java.lang.Object)var30);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var42, var51);
//     double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var29, var51);
//     boolean var57 = var56.isSupportConnected();
//     double var59 = var56.density((-30.443553573156947d));
//     double var60 = var56.getSupportLowerBound();
//     double[] var62 = var56.sample(7);
//     double var63 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var56);
//     boolean var64 = var56.isSupportLowerBoundInclusive();
//     boolean var65 = var56.isSupportUpperBoundInclusive();
//     double var68 = var56.cumulativeProbability((-0.3604631137163894d), 0.0d);
//     double var70 = var56.density(0.612206986074538d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 114.70987435401474d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "74aaab52610cc3e9a35e04"+ "'", var4.equals("74aaab52610cc3e9a35e04"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 9705.88235159202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 0.0d);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test365"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getNumericalMean();
//     double var52 = var47.getSupportUpperBound();
//     double var54 = var47.density((-19533.05988397774d));
//     double var55 = var47.sample();
//     boolean var56 = var47.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == true);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test366"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var11 = var9.nextExponential(0.529583188695852d);
    double var14 = var9.nextF(6.790436471693312E7d, 6.186744492510037d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.7082137595646507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.210857953608884d);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test367"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     long var10 = var6.nextPoisson(1.3431861837677899d);
//     var6.reSeedSecure(179L);
//     java.lang.String var14 = var6.nextSecureHexString(83);
//     int[] var17 = var6.nextPermutation(51, 24);
//     double var20 = var6.nextCauchy((-0.8658881497318542d), 5.433048171930581d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0556888305030063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "9661aff416298aa5243b02c6b8f46320e4833ca927139367f51131b0a1e3d6472a1facd013e033bd7dc"+ "'", var14.equals("9661aff416298aa5243b02c6b8f46320e4833ca927139367f51131b0a1e3d6472a1facd013e033bd7dc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 35.9496082360773d);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test368"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     java.lang.String var9 = var2.nextSecureHexString(29);
//     double var12 = var2.nextCauchy(0.6224543031156315d, 2.1773846204730427d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("129e3d57ae35c852edfcfc80922a8aecab9c7ac0eb90", "b66afc2a6c5604a05cd5f4");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "2127cf8a4175af0e130fd62461ed4"+ "'", var9.equals("2127cf8a4175af0e130fd62461ed4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.702965151774087d));
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test369"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getSupportLowerBound();
    double[] var53 = var47.sample(7);
    boolean var54 = var47.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var57 = var47.cumulativeProbability(0.0339842858777826d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test370"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 21.869847397459292d);
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    double[] var34 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[][] var36 = new double[][] { var34};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var25, var36);
    org.apache.commons.math3.exception.NotFiniteNumberException var38 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var36);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var36);
    double[] var43 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var43);
    double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var43);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var52 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var53 = var52.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var54 = var52.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var56 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var54, true);
    boolean var58 = org.apache.commons.math3.util.MathArrays.isMonotonic(var43, var54, true);
    double[] var62 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var66 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var62, var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var62);
    double var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var43);
    double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    org.apache.commons.math3.util.MathArrays.checkPositive(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 22.44102686025421d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test371"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1.5471409101297562d), var2, (java.lang.Number)1.1022357856078504d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test372"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 18};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var2, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var5, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(100.0d);
//     long var4 = var0.nextPoisson(1.522562011502786E-9d);
//     int var7 = var0.nextSecureInt(64, 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 101.45524346082549d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 78);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test374"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.3108907469982957d, 74.28997240543302d, (-0.8024838501147071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-59.61650308082724d));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test375"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(2.185145629027406d, (-2.5793464066563074d), 6.251783231069299d, (-36464.35619377387d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-227972.88683149967d));

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test376"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var13 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var13);
    int var16 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.exception.NumberIsTooSmallException var20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var21 = var20.getMin();
    org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError();
    var20.addSuppressed((java.lang.Throwable)var22);
    org.apache.commons.math3.exception.util.ExceptionContext var24 = var22.getContext();
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)var24);
    java.lang.Object var26 = var25.getKey();
    java.lang.Object var27 = var25.getFirst();
    java.lang.Object var28 = var25.getSecond();
    java.lang.Object var29 = var25.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 1.0d+ "'", var21.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test377"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     int[] var9 = null;
//     int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
//     int[] var13 = null;
//     int var14 = org.apache.commons.math3.util.MathArrays.distance1(var12, var13);
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(7741999113339246307L);
//     double var14 = var0.nextUniform(3.672863970186956E-8d, 0.09455763871444445d);
//     java.lang.String var16 = var0.nextSecureHexString(93);
//     long var19 = var0.nextSecureLong(6L, 6758353113347147164L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.13519743793585368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0024905655682720086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.347850836297087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.00436615562941289d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "1d469cdade705780a0407a1234826d647a9df364b6786f577c9291d5c3e414d6f41dadec825ef93b54f5f9691321b"+ "'", var16.equals("1d469cdade705780a0407a1234826d647a9df364b6786f577c9291d5c3e414d6f41dadec825ef93b54f5f9691321b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4935253340052214784L);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test379"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var22 = null;
    double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var22, var30);
    double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var30);
    double[] var37 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var37, var46);
    double[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 88);
    double var50 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var46);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var57 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var58 = var57.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var59 = var57.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var61 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var59, true);
    boolean var63 = org.apache.commons.math3.util.MathArrays.isMonotonic(var30, var59, false);
    boolean var66 = org.apache.commons.math3.util.MathArrays.checkOrder(var16, var59, false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test380"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.clear();
//     var1.setSeed(1L);
//     org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var8 = var5.nextPascal(49, 0.10832690038004085d);
//     int var11 = var5.nextSecureInt(67, 81);
//     java.lang.String var13 = var5.nextSecureHexString(99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 318);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "d14383a582c1febadbf4019307160671d24a3230e9d8b4adaf4ce5befeb76cdecc04411b477a3363794e2c6506273b8c546"+ "'", var13.equals("d14383a582c1febadbf4019307160671d24a3230e9d8b4adaf4ce5befeb76cdecc04411b477a3363794e2c6506273b8c546"));
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test381"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     boolean var48 = var47.isSupportConnected();
//     double var50 = var47.density((-30.443553573156947d));
//     double var51 = var47.getNumericalMean();
//     double var53 = var47.probability(2.641195788033711d);
//     boolean var54 = var47.isSupportUpperBoundInclusive();
//     double var55 = var47.sample();
//     double var57 = var47.probability(6.813639406926573E-7d);
//     double[] var59 = var47.sample(15);
//     double var62 = var47.probability((-2.246183766799999d), 0.0d);
//     double var64 = var47.inverseCumulativeProbability(0.2128719238430852d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 9705.88235114497d);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test382"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     double[] var21 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var25 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var25);
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var25, var34);
//     double[] var37 = null;
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var34, var37);
//     double[] var42 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
//     double var52 = org.apache.commons.math3.util.MathArrays.distance1(var42, var51);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var34, var42);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var34);
//     double[] var56 = new double[] { 10.0d};
//     double[] var60 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var64 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var60, var64);
//     double[] var69 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var73 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var73);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var73);
//     double[] var77 = org.apache.commons.math3.util.MathArrays.normalizeArray(var73, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var78 = null;
//     java.lang.Object[] var80 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var81 = new org.apache.commons.math3.exception.MathInternalError(var78, var80);
//     org.apache.commons.math3.util.Pair var82 = new org.apache.commons.math3.util.Pair((java.lang.Object)var77, (java.lang.Object)var78);
//     double var83 = org.apache.commons.math3.util.MathArrays.distanceInf(var56, var77);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var77);
//     double var86 = var84.density(6.7814613825466825d);
//     boolean var87 = var84.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.3341424237142636d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 87.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == true);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test383"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var7 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var9 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)513, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test384"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)(byte)100, 69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    int var5 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 69);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test385"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     java.lang.String var8 = var2.nextSecureHexString(2);
//     double var12 = var2.nextUniform(0.529583188695852d, 1.0716282575829514d, false);
//     var2.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var2.nextBeta((-1.3601821887191676d), 7.084194643041131d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4c"+ "'", var8.equals("4c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9015685143006096d);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test386"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.setSeed(0L);
    var1.setSeed(513);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test387"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     var0.reSeed((-897178398285547140L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 21);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test388"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.016071546142839d), 45.42182937163152d, 0.0d, (-0.8752975953102416d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-46.15182839826985d));

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test389"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     long var8 = var2.nextSecureLong(0L, 14L);
//     var2.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var2.nextPascal(499, (-3.3781187158717527d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7L);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test390"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var19 = null;
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var19, var27);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var34);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var12, var34);
    double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
    double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var58);
    double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var58, 9900.0d);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var62);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var76 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var77 = var76.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var78 = var76.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var80 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var78, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)1, (java.lang.Number)1.4392153051361142E-9d, (-1612642752), var78, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var84 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)4.645762949836714d, (java.lang.Number)2134.7723463949237d, 42, var78, true);
    boolean var86 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var78, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var12);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test391"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    long var2 = var1.nextLong();
    double var3 = var1.nextDouble();
    boolean var4 = var1.nextBoolean();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var5.nextF(0.0d, 1.2933098862091679d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4418713979230659041L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.3934606808571868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test392"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
    double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
    double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
    double[] var41 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[][] var43 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var32, var43);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    double[] var49 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var49, var58);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var58, 88);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var32, var58);
    double[] var66 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var70 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var70);
    double[] var75 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var75);
    double[][] var77 = new double[][] { var75};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var66, var77);
    double var79 = org.apache.commons.math3.util.MathArrays.safeNorm(var66);
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var62, var66);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var24, var62);
    double var82 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
    double var83 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
    double[] var85 = org.apache.commons.math3.util.MathArrays.normalizeArray(var62, (-4.811174346084439d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 99.04039579888602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test393"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 98, 1077317343);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test394"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double[] var16 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var20 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
//     double[] var26 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
//     double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var35, 0.0d);
//     double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
//     double var40 = org.apache.commons.math3.util.MathArrays.distance1(var12, var35);
//     double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var50 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var51 = var50.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var52 = var50.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var54 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var52, true);
//     boolean var56 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var52, false);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var58 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1022.7042967872934d, (java.lang.Number)10.099504938362077d, 0, var52, false);
//     boolean var60 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var52, false);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test395"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var13 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var13);
    int var16 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.exception.NumberIsTooSmallException var20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var21 = var20.getMin();
    org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError();
    var20.addSuppressed((java.lang.Throwable)var22);
    org.apache.commons.math3.exception.util.ExceptionContext var24 = var22.getContext();
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)var24);
    java.lang.Object var26 = var25.getSecond();
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    org.apache.commons.math3.exception.OutOfRangeException var31 = new org.apache.commons.math3.exception.OutOfRangeException(var27, (java.lang.Number)100L, (java.lang.Number)(-1L), (java.lang.Number)0.1431715674774945d);
    org.apache.commons.math3.exception.MathArithmeticException var32 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var33 = var32.getContext();
    org.apache.commons.math3.util.Pair var34 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)var33);
    org.apache.commons.math3.util.Pair var35 = new org.apache.commons.math3.util.Pair(var34);
    java.lang.Object var36 = var35.getFirst();
    boolean var37 = var25.equals(var36);
    java.lang.Object var38 = var25.getSecond();
    org.apache.commons.math3.random.Well19937c var40 = new org.apache.commons.math3.random.Well19937c(2022582015419129856L);
    boolean var41 = var40.nextBoolean();
    int[] var42 = null;
    var40.setSeed(var42);
    boolean var44 = var25.equals((java.lang.Object)var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 1.0d+ "'", var21.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1L)+ "'", var36.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test396"); }
// 
// 
//     int[] var2 = new int[] { 1, 0};
//     int[] var3 = null;
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     double var5 = var4.nextGaussian();
//     int[] var8 = new int[] { 0, 1};
//     var4.setSeed(var8);
//     double var10 = org.apache.commons.math3.util.MathArrays.distance(var2, var8);
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var14 = null;
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
//     int[] var19 = new int[] { 100, 10, (-1)};
//     var15.setSeed(var19);
//     int[] var21 = new int[] { };
//     var15.setSeed(var21);
//     int[] var23 = null;
//     int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var23);
//     int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 66);
//     int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 0);
//     var13.setSeed(var28);
//     int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var28);
//     int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 21);
//     org.apache.commons.math3.random.RandomDataImpl var33 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var35 = var33.nextT(0.1431715674774945d);
//     java.lang.String var37 = var33.nextHexString(22);
//     double var39 = var33.nextChiSquare(0.012774969105543068d);
//     int[] var42 = var33.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var44);
//     var45.reSeed();
//     int var49 = var45.nextZipf(18, 0.10832690038004085d);
//     double var51 = var45.nextT(11.36369913641775d);
//     int[] var54 = var45.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var55 = new org.apache.commons.math3.random.Well19937c(var54);
//     int var56 = org.apache.commons.math3.util.MathArrays.distanceInf(var42, var54);
//     int var57 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var54);
//     int var58 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.16935575528312286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.4142135623730951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-0.10113195450183474d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "bdede8f1811b3a09478b0b"+ "'", var37.equals("bdede8f1811b3a09478b0b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 2.3001311815894205E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0.23629954838650835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 30);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test397"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var10 = var1.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.2555129028662975d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.07277703f);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test398"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)4.808512708127654d, var1, 1590605);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test399"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(49, 35);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test400"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getKey();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)100+ "'", var5.equals((short)100));

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test401"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     int var7 = var0.nextSecureInt(16, 34);
//     double var11 = var0.nextUniform(0.13029161104425163d, 0.9098943251447347d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.0437312725275829d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "cf29033d0bb91ee6fd8c28"+ "'", var4.equals("cf29033d0bb91ee6fd8c28"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.8219724535240613d);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test402"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var24);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var41 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var42 = var41.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = var41.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var45 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var43, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)1, (java.lang.Number)1.4392153051361142E-9d, (-1612642752), var43, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var49 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)4.645762949836714d, (java.lang.Number)2134.7723463949237d, 42, var43, true);
    boolean var51 = org.apache.commons.math3.util.MathArrays.isMonotonic(var8, var43, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var5 = var1.nextExponential(9.49251188161346d);
//     double var8 = var1.nextGaussian(1.22705655817319d, 6.790436471693312E7d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var1.nextPermutation(21, 192843090);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.03846317396475434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.266622858101471d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-4.008750361729468E7d));
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test404"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
//     org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
//     double var48 = var47.sample();
//     double var49 = var47.getNumericalMean();
//     double var50 = var47.getSupportLowerBound();
//     double var52 = var47.density(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 9705.882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 9517.474048442906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 97.05882352941177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0.0d);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test405"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     double var8 = var0.nextExponential(0.11681967467915401d);
//     double var11 = var0.nextUniform(0.6756233570174912d, 8.110362096038457d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(67, 1.7508552915653752d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-110.23392517007039d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1f149b4c2af088739a5f38"+ "'", var4.equals("1f149b4c2af088739a5f38"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.968636168611957E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.08937135886192797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.560109384885136d);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test406"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     var0.reSeed(10L);
//     double var9 = var0.nextChiSquare(9705.882352941177d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextZipf(0, 0.5064940690354035d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.476909930988558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9673.110537554716d);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test408"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(6189129.90146287d, (-75.62470873108684d), (-0.579922211411195d), 0.3112856219929603d, 0.0d, (-5.958014202698013d), (-0.6291135749008422d), 54746.28386276295d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-4.6808558790786463E8d));

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test409"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)13);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test410"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-679.7841048171373d));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var7 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var9 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var9);
    java.lang.Number var14 = var1.getMin();
    java.lang.Number var15 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 0+ "'", var14.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 0+ "'", var15.equals(0));

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test411"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     var0.reSeed((-56139359032789495L));
//     java.lang.String var12 = var0.nextHexString(86);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextBeta((-0.7785726358444499d), 0.3328432771849152d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 19.23307032802162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 29L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "1e4b704f36207af65b8989a5606c41911b053a8bf044b408de72621ed65b0dcc34ab829f8b4902be92bfa7"+ "'", var12.equals("1e4b704f36207af65b8989a5606c41911b053a8bf044b408de72621ed65b0dcc34ab829f8b4902be92bfa7"));
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test412"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    var1.clear();
    double var5 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.3674175180023106d));

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test413"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)6.251783231069299d, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    boolean var7 = var4.getBoundIsAllowed();
    java.lang.Number var8 = var4.getMax();
    boolean var9 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 6.251783231069299d+ "'", var6.equals(6.251783231069299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 6.251783231069299d+ "'", var8.equals(6.251783231069299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test414"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.32577132027868605d), (java.lang.Number)0L, 18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test415"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-0.18448641106378644d), var1);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test416"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double var2 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var1);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test417"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    var47.reseedRandomGenerator((-3200518016629555151L));
    double var53 = var47.sample();
    boolean var54 = var47.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 97.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test418"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure(1L);
//     var2.reSeed();
//     double var17 = var2.nextWeibull(105.12656948481559d, 0.08430081831437178d);
//     int[] var20 = var2.nextPermutation(63, 18);
//     double var22 = var2.nextChiSquare(0.00223635669013565d);
//     long var25 = var2.nextLong((-5298834133972813514L), (-458593501912865920L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.1798998859349807d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.08459352661121815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-5154742169353729024L));
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test419"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     int var18 = var0.nextZipf(36, 0.002575717853305201d);
//     int var21 = var0.nextSecureInt(15, 18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var0.nextBinomial(36, (-9896.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.3163870028901385d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3970442669942358d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "1014488b4b6d5b6e57da5c324e83e3d4e77ee238eeb3b2b5f4a2b9678dd2f1"+ "'", var12.equals("1014488b4b6d5b6e57da5c324e83e3d4e77ee238eeb3b2b5f4a2b9678dd2f1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 16);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test420"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     var7.reSeedSecure(39L);
//     double var14 = var7.nextCauchy((-0.062117049046509276d), 1.4926778407161656d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var7.nextHypergeometric(818120085, (-1612642752), 1588471);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.17737538762773492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-6.476585859809221d));
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test421"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double var50 = var47.density((-30.443553573156947d));
    double var51 = var47.getNumericalMean();
    double var53 = var47.cumulativeProbability((-0.6001566413360179d));
    boolean var54 = var47.isSupportLowerBoundInclusive();
    boolean var55 = var47.isSupportUpperBoundInclusive();
    double var58 = var47.cumulativeProbability((-3.738191689496304d), (-0.4852747377828022d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 9517.474048442906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test422"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)10L, 63, var3, false);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100.0d, (java.lang.Number)(byte)100, 10);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var13);
    int var17 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 63);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test423"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.0d), (java.lang.Number)0.20851425337288942d, 11);
    boolean var7 = var6.getStrict();
    boolean var8 = var6.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)54L, (java.lang.Number)0.19723959692993903d, 85936229, var9, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test424"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     boolean var3 = var1.nextBoolean();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var7 = var1.nextInt(4);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.012549921154311194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test425"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var23 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var21, var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var20, (java.lang.Object)var21);
    double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 9900.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var20, var42);
    boolean var48 = var47.isSupportConnected();
    double[] var50 = var47.sample(318);
    double[] var52 = var47.sample(69);
    double var54 = var47.cumulativeProbability(0.11407385423536498d);
    var47.reseedRandomGenerator(7765006300557716338L);
    double var59 = var47.probability((-1.6572693670715744d), 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var62 = var47.cumulativeProbability(1.423374292766079E-4d, (-256.0156659186293d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test426"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.2268867213406337E-9d, (java.lang.Number)(-5.146709692123926E-4d), (java.lang.Number)0.4261693954996687d);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test427"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 21.869847397459292d);
//     double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
//     double[] var33 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
//     double[][] var35 = new double[][] { var33};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
//     double[] var41 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var45 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var49 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var50 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var45, var49);
//     double var51 = org.apache.commons.math3.util.MathArrays.distance1(var41, var50);
//     double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 88);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var50);
//     boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var54);
//     double[] var56 = null;
//     double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var7, var56);
// 
//   }

}
