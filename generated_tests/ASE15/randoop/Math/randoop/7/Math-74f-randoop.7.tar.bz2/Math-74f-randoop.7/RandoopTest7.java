
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }
// 
// 
//     double[] var1 = new double[] { 100.0d};
//     org.apache.commons.math.linear.Array2DRowRealMatrix var2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var1);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var3 = null;
//     double var4 = var2.walkInOptimizedOrder(var3);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    org.apache.commons.math.FunctionEvaluationException var2 = new org.apache.commons.math.FunctionEvaluationException(0.0d);
    java.lang.Object[] var3 = var2.getArguments();
    java.lang.ArrayIndexOutOfBoundsException var4 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("matrix is singular", var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }
// 
// 
//     double[] var1 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var1, false);
//     java.io.ObjectInput var5 = null;
//     var4.readExternal(var5);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = var10.multiply(var21);
    org.apache.commons.math.linear.FieldMatrix var23 = var21.transpose();
    org.apache.commons.math.FieldElement[][] var24 = var21.getData();
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    org.apache.commons.math.Field var26 = var25.getField();
    org.apache.commons.math.fraction.BigFraction var31 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var32 = var31.reciprocal();
    org.apache.commons.math.fraction.BigFraction var35 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var36 = var35.reciprocal();
    org.apache.commons.math.fraction.BigFraction var37 = var31.subtract(var35);
    org.apache.commons.math.fraction.BigFraction var39 = new org.apache.commons.math.fraction.BigFraction(1.0d);
    org.apache.commons.math.fraction.BigFraction var41 = var39.pow(100L);
    org.apache.commons.math.fraction.BigFraction var42 = var37.divide(var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.multiplyEntry(2147483647, 16, (org.apache.commons.math.FieldElement)var42);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    org.apache.commons.math.fraction.BigFraction var4 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var5 = var4.reciprocal();
    org.apache.commons.math.fraction.BigFraction var8 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var9 = var8.reciprocal();
    org.apache.commons.math.fraction.BigFraction var12 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var13 = var12.reciprocal();
    org.apache.commons.math.fraction.BigFraction var14 = var8.subtract(var12);
    org.apache.commons.math.fraction.BigFraction var17 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var18 = var17.reciprocal();
    org.apache.commons.math.fraction.BigFraction var21 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var22 = var21.reciprocal();
    org.apache.commons.math.fraction.BigFraction var23 = var17.subtract(var21);
    org.apache.commons.math.fraction.BigFraction var24 = var8.subtract(var21);
    java.math.BigInteger var25 = var24.getDenominator();
    org.apache.commons.math.fraction.BigFraction var26 = var4.divide(var25);
    org.apache.commons.math.FieldElement[] var27 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var28 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var27);
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var27);
    org.apache.commons.math.ConvergenceException var30 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[])var27);
    org.apache.commons.math.linear.FieldMatrix var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var27);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var32 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var27);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var33 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var27);
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var38 = var37.reciprocal();
    org.apache.commons.math.fraction.BigFraction var41 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var42 = var41.reciprocal();
    org.apache.commons.math.fraction.BigFraction var43 = var37.subtract(var41);
    java.math.BigDecimal var44 = var43.bigDecimalValue();
    org.apache.commons.math.FieldElement[] var45 = new org.apache.commons.math.FieldElement[] { var43};
    org.apache.commons.math.linear.FieldVector var46 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var45);
    var33.setRow(0, var45);
    org.apache.commons.math.FieldElement[][] var48 = var33.getDataRef();
    org.apache.commons.math.FieldElement[][] var49 = var33.getDataRef();
    org.apache.commons.math.linear.FieldMatrix var50 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var49);
    org.apache.commons.math.FieldElement[][] var51 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var49);
    org.apache.commons.math.linear.InvalidMatrixException var52 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.linear.InvalidMatrixException: Dormand-Prince 8 (5, 3)", (java.lang.Object[])var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    java.lang.Throwable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var10 = new org.apache.commons.math.ConvergenceException(var6, "", var9);
    org.apache.commons.math.MaxEvaluationsExceededException var11 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", var9);
    double[] var14 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var15 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var14);
    double[][] var16 = new double[][] { var14};
    double[][] var17 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var16);
    org.apache.commons.math.MathRuntimeException var18 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var11, "hi!", (java.lang.Object[])var17);
    org.apache.commons.math.ode.IntegratorException var19 = new org.apache.commons.math.ode.IntegratorException("BlockRealMatrix{{10.0}}", (java.lang.Object[])var17);
    org.apache.commons.math.MathRuntimeException var20 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var17);
    org.apache.commons.math.linear.InvalidMatrixException var21 = new org.apache.commons.math.linear.InvalidMatrixException("BlockRealMatrix{{10.0}}", (java.lang.Object[])var17);
    org.apache.commons.math.linear.Array2DRowRealMatrix var23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var17, false);
    java.lang.ArrayIndexOutOfBoundsException var24 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", (java.lang.Object[])var17);
    org.apache.commons.math.linear.Array2DRowRealMatrix var26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var17, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }
// 
// 
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 10.0d, 100.0d, 100.0d);
//     var4.clearEventHandlers();
//     int var6 = var4.getOrder();
//     double var7 = var4.getMaxGrowth();
//     var4.setInitialStepSize(1.0d);
//     double var10 = var4.getSafety();
//     double var11 = var4.getSafety();
//     var4.clearStepHandlers();
//     double var13 = var4.getCurrentStepStart();
//     double var14 = var4.getMinReduction();
//     java.util.Collection var15 = var4.getEventHandlers();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
    java.lang.String var13 = var12.toString();
    org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
    boolean var15 = var14.isSingular();
    var14.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var20 = var5.subtract((org.apache.commons.math.linear.RealMatrix)var14);
    int var21 = var14.getColumnDimension();
    double[] var23 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var23);
    double[][] var25 = new double[][] { var23};
    double[][] var26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var25);
    org.apache.commons.math.linear.BlockRealMatrix var27 = new org.apache.commons.math.linear.BlockRealMatrix(var26);
    java.lang.String var28 = var27.toString();
    org.apache.commons.math.linear.BlockRealMatrix var29 = var14.subtract(var27);
    double[] var31 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var31);
    double[][] var33 = new double[][] { var31};
    double[][] var34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var33);
    org.apache.commons.math.linear.BlockRealMatrix var35 = new org.apache.commons.math.linear.BlockRealMatrix(var34);
    java.lang.String var36 = var35.toString();
    double[] var38 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var39 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var38);
    double[][] var40 = new double[][] { var38};
    double[][] var41 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var40);
    org.apache.commons.math.linear.BlockRealMatrix var42 = new org.apache.commons.math.linear.BlockRealMatrix(var41);
    java.lang.String var43 = var42.toString();
    org.apache.commons.math.linear.BlockRealMatrix var44 = var42.transpose();
    boolean var45 = var44.isSingular();
    var44.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var50 = var35.subtract((org.apache.commons.math.linear.RealMatrix)var44);
    double var51 = var44.getDeterminant();
    org.apache.commons.math.fraction.BigFraction var54 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var55 = var54.reciprocal();
    org.apache.commons.math.FieldElement[] var56 = new org.apache.commons.math.FieldElement[] { var54};
    org.apache.commons.math.linear.FieldMatrix var57 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var56);
    org.apache.commons.math.FieldElement[][] var58 = new org.apache.commons.math.FieldElement[][] { var56};
    org.apache.commons.math.FieldElement[][] var59 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var58);
    org.apache.commons.math.linear.BlockFieldMatrix var60 = new org.apache.commons.math.linear.BlockFieldMatrix(var58);
    java.lang.String var61 = var60.toString();
    org.apache.commons.math.linear.Array2DRowRealMatrix var62 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix((org.apache.commons.math.linear.FieldMatrix)var60);
    org.apache.commons.math.linear.FieldMatrix var64 = var60.getColumnMatrix(0);
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var44, (org.apache.commons.math.linear.AnyMatrix)var64);
    double var66 = var44.getNorm();
    org.apache.commons.math.linear.BlockRealMatrix var67 = var27.multiply(var44);
    int var68 = var44.getColumnDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var13.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var28.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var36.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var43.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "BlockFieldMatrix{{-1}}"+ "'", var61.equals("BlockFieldMatrix{{-1}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var6 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var7 = var6.reciprocal();
    org.apache.commons.math.fraction.BigFraction var10 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var11 = var10.reciprocal();
    org.apache.commons.math.fraction.BigFraction var12 = var6.subtract(var10);
    org.apache.commons.math.fraction.BigFraction var15 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var16 = var15.reciprocal();
    org.apache.commons.math.fraction.BigFraction var19 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var20 = var19.reciprocal();
    org.apache.commons.math.fraction.BigFraction var21 = var15.subtract(var19);
    org.apache.commons.math.fraction.BigFraction var22 = var6.subtract(var19);
    java.math.BigInteger var23 = var22.getDenominator();
    org.apache.commons.math.fraction.BigFraction var24 = var2.divide(var23);
    org.apache.commons.math.FieldElement[] var25 = new org.apache.commons.math.FieldElement[] { var24};
    org.apache.commons.math.linear.FieldMatrix var26 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var25);
    org.apache.commons.math.linear.FieldMatrix var27 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var25);
    org.apache.commons.math.linear.FieldVector var28 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var25);
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var25);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var30 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var25);
    org.apache.commons.math.fraction.BigFraction var36 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var37 = var36.reciprocal();
    org.apache.commons.math.FieldElement[] var38 = new org.apache.commons.math.FieldElement[] { var36};
    org.apache.commons.math.linear.FieldMatrix var39 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var38);
    org.apache.commons.math.FieldElement[][] var40 = new org.apache.commons.math.FieldElement[][] { var38};
    org.apache.commons.math.FieldElement[][] var41 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var40);
    java.lang.IllegalArgumentException var42 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var41);
    org.apache.commons.math.linear.InvalidMatrixException var43 = new org.apache.commons.math.linear.InvalidMatrixException("0", (java.lang.Object[])var41);
    org.apache.commons.math.linear.FieldMatrix var44 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var41);
    org.apache.commons.math.ConvergenceException var45 = new org.apache.commons.math.ConvergenceException("Maximal number of evaluations ({0}) exceeded", (java.lang.Object[])var41);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = new org.apache.commons.math.linear.BlockFieldMatrix(var41);
    org.apache.commons.math.linear.FieldMatrix var47 = var46.copy();
    org.apache.commons.math.linear.FieldMatrix var48 = var30.multiply(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var1 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var2 = var1.getNSteps();
    int var3 = var1.getNSteps();
    double[] var5 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var5);
    org.apache.commons.math.FunctionEvaluationException var7 = new org.apache.commons.math.FunctionEvaluationException(var5);
    double[] var10 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var10);
    double[][] var12 = new double[][] { var10};
    double[][] var13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var12);
    java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var12);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = var1.initializeHighOrderDerivatives(var5, var12);
    double[][] var16 = var15.getDataRef();
    double[] var18 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var19 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var18);
    double[][] var20 = new double[][] { var18};
    double[][] var21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var20);
    org.apache.commons.math.linear.BlockRealMatrix var22 = new org.apache.commons.math.linear.BlockRealMatrix(var21);
    java.lang.String var23 = var22.toString();
    double[] var25 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var26 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var25);
    double[][] var27 = new double[][] { var25};
    double[][] var28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var27);
    org.apache.commons.math.linear.BlockRealMatrix var29 = new org.apache.commons.math.linear.BlockRealMatrix(var28);
    java.lang.String var30 = var29.toString();
    org.apache.commons.math.linear.BlockRealMatrix var31 = var29.transpose();
    boolean var32 = var31.isSingular();
    var31.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var37 = var22.subtract((org.apache.commons.math.linear.RealMatrix)var31);
    double var38 = var31.getDeterminant();
    double var39 = var31.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var41 = var31.scalarMultiply((-1.0d));
    org.apache.commons.math.linear.RealMatrix var43 = var31.scalarMultiply(0.0d);
    double[] var45 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var46 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var45);
    double[][] var47 = new double[][] { var45};
    double[][] var48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var47);
    org.apache.commons.math.linear.BlockRealMatrix var49 = new org.apache.commons.math.linear.BlockRealMatrix(var48);
    java.lang.String var50 = var49.toString();
    org.apache.commons.math.linear.BlockRealMatrix var51 = var49.transpose();
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var54 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var55 = var54.getNSteps();
    double[] var57 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var58 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var57);
    org.apache.commons.math.FunctionEvaluationException var59 = new org.apache.commons.math.FunctionEvaluationException(var57);
    double[] var61 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var62 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var61);
    org.apache.commons.math.FunctionEvaluationException var63 = new org.apache.commons.math.FunctionEvaluationException(var61);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var65 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var66 = var65.getNSteps();
    int var67 = var65.getNSteps();
    double[] var69 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var70 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var69);
    org.apache.commons.math.FunctionEvaluationException var71 = new org.apache.commons.math.FunctionEvaluationException(var69);
    double[] var74 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var75 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var74);
    double[][] var76 = new double[][] { var74};
    double[][] var77 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var76);
    java.lang.IllegalArgumentException var78 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var76);
    org.apache.commons.math.linear.Array2DRowRealMatrix var79 = var65.initializeHighOrderDerivatives(var69, var76);
    var54.updateHighOrderDerivativesPhase2(var57, var61, var79);
    var49.setColumn(0, var61);
    org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix)var31, (org.apache.commons.math.linear.AnyMatrix)var49);
    org.apache.commons.math.linear.RealMatrix var83 = var15.subtract((org.apache.commons.math.linear.RealMatrix)var49);
    org.apache.commons.math.linear.BlockRealMatrix var84 = var49.copy();
    org.apache.commons.math.linear.RealMatrixChangingVisitor var85 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var90 = var49.walkInOptimizedOrder(var85, 10, (-1), (-2), 1);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var23.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var30.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var50.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var2};
    org.apache.commons.math.linear.FieldMatrix var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.FieldElement[][] var7 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var6);
    org.apache.commons.math.linear.BlockFieldMatrix var8 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    java.lang.String var9 = var8.toString();
    org.apache.commons.math.linear.Array2DRowRealMatrix var10 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix((org.apache.commons.math.linear.FieldMatrix)var8);
    org.apache.commons.math.linear.FieldMatrix var12 = var8.getColumnMatrix(0);
    java.lang.String var13 = var8.toString();
    int var14 = var8.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var20 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var21 = var20.reciprocal();
    org.apache.commons.math.fraction.BigFraction var24 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var25 = var24.reciprocal();
    org.apache.commons.math.fraction.BigFraction var28 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var29 = var28.reciprocal();
    org.apache.commons.math.fraction.BigFraction var30 = var24.subtract(var28);
    org.apache.commons.math.fraction.BigFraction var33 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var34 = var33.reciprocal();
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var38 = var37.reciprocal();
    org.apache.commons.math.fraction.BigFraction var39 = var33.subtract(var37);
    org.apache.commons.math.fraction.BigFraction var40 = var24.subtract(var37);
    java.math.BigInteger var41 = var40.getDenominator();
    org.apache.commons.math.fraction.BigFraction var42 = var20.divide(var41);
    org.apache.commons.math.FieldElement[] var43 = new org.apache.commons.math.FieldElement[] { var42};
    org.apache.commons.math.linear.FieldMatrix var44 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var43);
    org.apache.commons.math.linear.FieldMatrix var45 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var43);
    org.apache.commons.math.ode.IntegratorException var46 = new org.apache.commons.math.ode.IntegratorException("org.apache.commons.math.MathRuntimeException$6: hi!", (java.lang.Object[])var43);
    java.util.ConcurrentModificationException var47 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("matrix is singular", (java.lang.Object[])var43);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var48 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setColumn((-2), var43);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "BlockFieldMatrix{{-1}}"+ "'", var9.equals("BlockFieldMatrix{{-1}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "BlockFieldMatrix{{-1}}"+ "'", var13.equals("BlockFieldMatrix{{-1}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var1 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var8 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var9 = var8.getNSteps();
    double[] var11 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var12 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var11);
    org.apache.commons.math.FunctionEvaluationException var13 = new org.apache.commons.math.FunctionEvaluationException(var11);
    double[] var15 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var16 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var15);
    org.apache.commons.math.FunctionEvaluationException var17 = new org.apache.commons.math.FunctionEvaluationException(var15);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var19 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var20 = var19.getNSteps();
    int var21 = var19.getNSteps();
    double[] var23 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var23);
    org.apache.commons.math.FunctionEvaluationException var25 = new org.apache.commons.math.FunctionEvaluationException(var23);
    double[] var28 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var29 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    java.lang.IllegalArgumentException var32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var30);
    org.apache.commons.math.linear.Array2DRowRealMatrix var33 = var19.initializeHighOrderDerivatives(var23, var30);
    var8.updateHighOrderDerivativesPhase2(var11, var15, var33);
    org.apache.commons.math.linear.BigMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var11);
    java.lang.Throwable var36 = null;
    double[] var38 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var39 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var38);
    org.apache.commons.math.linear.RealVector var40 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var38);
    org.apache.commons.math.FunctionEvaluationException var41 = new org.apache.commons.math.FunctionEvaluationException(var36, var38);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var42 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.4142135623730951d, var11, var38);
    org.apache.commons.math.FunctionEvaluationException var43 = new org.apache.commons.math.FunctionEvaluationException(var38);
    double[] var45 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var46 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var45);
    double[][] var47 = new double[][] { var45};
    double[][] var48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var47);
    org.apache.commons.math.linear.Array2DRowRealMatrix var49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var48);
    var0.reinitialize((-2.0d), 1.0E-15d, var38, var49);
    org.apache.commons.math.linear.RealMatrix var51 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var38);
    java.math.BigDecimal var53 = null;
    java.math.BigDecimal[] var54 = new java.math.BigDecimal[] { var53};
    org.apache.commons.math.linear.BigMatrix var55 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var54);
    java.math.BigDecimal[][] var56 = new java.math.BigDecimal[][] { var54};
    org.apache.commons.math.linear.BigMatrix var58 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var56, false);
    org.apache.commons.math.FunctionEvaluationException var59 = new org.apache.commons.math.FunctionEvaluationException(var38, "", (java.lang.Object[])var56);
    org.apache.commons.math.linear.BigMatrix var60 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var56);
    org.apache.commons.math.linear.BigMatrix var62 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var56, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.FieldElement[][] var6 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var3, (-1), 8);
    org.apache.commons.math.fraction.BigFraction var7 = var3.getOne();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var8 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.resetRelativeAccuracy();
    var0.setFunctionValueAccuracy(100.0d);
    double var4 = var0.getRelativeAccuracy();
    int var5 = var0.getIterationCount();
    var0.setAbsoluteAccuracy(0.0d);
    int var8 = var0.getMaximalIterationCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.solve(1.0E-6d, (-200.0d));
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = var10.multiply(var21);
    org.apache.commons.math.linear.FieldMatrix var23 = var21.transpose();
    org.apache.commons.math.FieldElement[][] var24 = var21.getData();
    org.apache.commons.math.fraction.BigFraction var28 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var29 = var28.reciprocal();
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var28};
    org.apache.commons.math.linear.FieldMatrix var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var30);
    org.apache.commons.math.FieldElement[][] var32 = new org.apache.commons.math.FieldElement[][] { var30};
    org.apache.commons.math.FieldElement[][] var33 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var32);
    java.lang.IllegalArgumentException var34 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var33);
    org.apache.commons.math.linear.BlockFieldMatrix var35 = new org.apache.commons.math.linear.BlockFieldMatrix(var33);
    org.apache.commons.math.fraction.BigFraction var39 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var40 = var39.reciprocal();
    org.apache.commons.math.FieldElement[] var41 = new org.apache.commons.math.FieldElement[] { var39};
    org.apache.commons.math.linear.FieldMatrix var42 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var41);
    org.apache.commons.math.FieldElement[][] var43 = new org.apache.commons.math.FieldElement[][] { var41};
    org.apache.commons.math.FieldElement[][] var44 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var43);
    java.lang.IllegalArgumentException var45 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var44);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = new org.apache.commons.math.linear.BlockFieldMatrix(var44);
    org.apache.commons.math.linear.BlockFieldMatrix var47 = var35.multiply(var46);
    org.apache.commons.math.fraction.BigFraction var50 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    java.lang.String var51 = var50.toString();
    org.apache.commons.math.linear.FieldMatrix var52 = var47.scalarMultiply((org.apache.commons.math.FieldElement)var50);
    org.apache.commons.math.FieldElement var53 = var47.getTrace();
    org.apache.commons.math.linear.BlockFieldMatrix var54 = var21.subtract(var47);
    org.apache.commons.math.fraction.BigFraction var60 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var61 = var60.reciprocal();
    org.apache.commons.math.fraction.BigFraction var64 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var65 = var64.reciprocal();
    org.apache.commons.math.fraction.BigFraction var68 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var69 = var68.reciprocal();
    org.apache.commons.math.fraction.BigFraction var70 = var64.subtract(var68);
    org.apache.commons.math.fraction.BigFraction var73 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var74 = var73.reciprocal();
    org.apache.commons.math.fraction.BigFraction var77 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var78 = var77.reciprocal();
    org.apache.commons.math.fraction.BigFraction var79 = var73.subtract(var77);
    org.apache.commons.math.fraction.BigFraction var80 = var64.subtract(var77);
    java.math.BigInteger var81 = var80.getDenominator();
    org.apache.commons.math.fraction.BigFraction var82 = var60.divide(var81);
    org.apache.commons.math.FieldElement[] var83 = new org.apache.commons.math.FieldElement[] { var82};
    org.apache.commons.math.linear.FieldMatrix var84 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var83);
    org.apache.commons.math.linear.FieldMatrix var85 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var83);
    org.apache.commons.math.ode.IntegratorException var86 = new org.apache.commons.math.ode.IntegratorException("org.apache.commons.math.MathRuntimeException$6: hi!", (java.lang.Object[])var83);
    java.util.ConcurrentModificationException var87 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("matrix is singular", (java.lang.Object[])var83);
    org.apache.commons.math.linear.FieldMatrix var88 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var83);
    java.lang.IllegalStateException var89 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("BlockRealMatrix{{10.0}}", (java.lang.Object[])var83);
    org.apache.commons.math.FieldElement[] var90 = var21.preMultiply(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "0"+ "'", var51.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    double var1 = var0.getFunctionValueAccuracy();
    int var2 = var0.getIterationCount();
    double var3 = var0.getAbsoluteAccuracy();
    double var4 = var0.getRelativeAccuracy();
    var0.setFunctionValueAccuracy(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0E-14d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
    java.lang.String var13 = var12.toString();
    org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
    boolean var15 = var14.isSingular();
    var14.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var20 = var5.subtract((org.apache.commons.math.linear.RealMatrix)var14);
    org.apache.commons.math.linear.RealMatrix var22 = var5.scalarMultiply(10.0d);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var24 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var25 = var24.getNSteps();
    int var26 = var24.getNSteps();
    double[] var28 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var29 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var28);
    org.apache.commons.math.FunctionEvaluationException var30 = new org.apache.commons.math.FunctionEvaluationException(var28);
    double[] var33 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var34 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var33);
    double[][] var35 = new double[][] { var33};
    double[][] var36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var35);
    java.lang.IllegalArgumentException var37 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var35);
    org.apache.commons.math.linear.Array2DRowRealMatrix var38 = var24.initializeHighOrderDerivatives(var28, var35);
    org.apache.commons.math.linear.RealMatrix var39 = var38.copy();
    org.apache.commons.math.linear.RealMatrix var40 = var38.copy();
    java.lang.Throwable var44 = null;
    java.lang.Object[] var47 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var48 = new org.apache.commons.math.ConvergenceException(var44, "", var47);
    org.apache.commons.math.MaxEvaluationsExceededException var49 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var47);
    java.lang.IllegalStateException var50 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var47);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var55 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var56 = var55.getNSteps();
    double[] var58 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var59 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var58);
    org.apache.commons.math.FunctionEvaluationException var60 = new org.apache.commons.math.FunctionEvaluationException(var58);
    double[] var62 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var63 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var62);
    org.apache.commons.math.FunctionEvaluationException var64 = new org.apache.commons.math.FunctionEvaluationException(var62);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var66 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var67 = var66.getNSteps();
    int var68 = var66.getNSteps();
    double[] var70 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var71 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var70);
    org.apache.commons.math.FunctionEvaluationException var72 = new org.apache.commons.math.FunctionEvaluationException(var70);
    double[] var75 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var76 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var75);
    double[][] var77 = new double[][] { var75};
    double[][] var78 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var77);
    java.lang.IllegalArgumentException var79 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var77);
    org.apache.commons.math.linear.Array2DRowRealMatrix var80 = var66.initializeHighOrderDerivatives(var70, var77);
    var55.updateHighOrderDerivativesPhase2(var58, var62, var80);
    org.apache.commons.math.linear.BigMatrix var82 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var58);
    java.lang.Throwable var83 = null;
    double[] var85 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var86 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var85);
    org.apache.commons.math.linear.RealVector var87 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var85);
    org.apache.commons.math.FunctionEvaluationException var88 = new org.apache.commons.math.FunctionEvaluationException(var83, var85);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var89 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.4142135623730951d, var58, var85);
    org.apache.commons.math.FunctionEvaluationException var90 = new org.apache.commons.math.FunctionEvaluationException(var85);
    org.apache.commons.math.FunctionEvaluationException var91 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var50, var85);
    double[] var92 = var38.preMultiply(var85);
    org.apache.commons.math.linear.Array2DRowRealMatrix var93 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var85);
    double[][] var94 = var93.getDataRef();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setSubMatrix(var94, 0, 2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var13.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }
// 
// 
//     double[][] var2 = null;
//     org.apache.commons.math.linear.BlockRealMatrix var4 = new org.apache.commons.math.linear.BlockRealMatrix(1, 100, var2, true);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }


    org.apache.commons.math.Field var0 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var1 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var0);
    org.apache.commons.math.Field var2 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var3 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var2);
    org.apache.commons.math.FieldElement var4 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var5 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var4);
    var5.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var13 = var3.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var5);
    org.apache.commons.math.Field var14 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var15 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var14);
    org.apache.commons.math.FieldElement var16 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var17 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var16);
    var17.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var25 = var15.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var17);
    org.apache.commons.math.FieldElement var26 = var3.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var17);
    var17.start(0, 0, 0, 0, (-1), 1);
    org.apache.commons.math.fraction.BigFraction var38 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var39 = var38.reciprocal();
    org.apache.commons.math.fraction.BigFraction var41 = var39.add((-1L));
    double var42 = var41.doubleValue();
    var17.visit(1, (-2), (org.apache.commons.math.FieldElement)var41);
    org.apache.commons.math.FieldElement var44 = var17.end();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var49 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var17, 10, (-1), (-110), 16);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }


    java.lang.Throwable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var9 = new org.apache.commons.math.ConvergenceException(var5, "", var8);
    org.apache.commons.math.MaxEvaluationsExceededException var10 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", var8);
    double[] var13 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var14 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var13);
    double[][] var15 = new double[][] { var13};
    double[][] var16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var15);
    org.apache.commons.math.MathRuntimeException var17 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var10, "hi!", (java.lang.Object[])var16);
    org.apache.commons.math.ode.IntegratorException var18 = new org.apache.commons.math.ode.IntegratorException("BlockRealMatrix{{10.0}}", (java.lang.Object[])var16);
    org.apache.commons.math.MathRuntimeException var19 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var16);
    org.apache.commons.math.linear.RealMatrix var20 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var16);
    org.apache.commons.math.ode.IntegratorException var21 = new org.apache.commons.math.ode.IntegratorException("org.apache.commons.math.MathRuntimeException$6: hi!", (java.lang.Object[])var16);
    org.apache.commons.math.linear.RealMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var16);
    org.apache.commons.math.linear.Array2DRowRealMatrix var23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var25 = var23.getColumn(10);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     var0.clearEventsHandlers();
//     boolean var2 = var0.isEmpty();
//     boolean var3 = var0.stop();
//     double var4 = var0.getEventTime();
//     double[] var7 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var8 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var7);
//     double[][] var9 = new double[][] { var7};
//     double[][] var10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var9);
//     org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var10);
//     java.lang.String var12 = var11.toString();
//     double[] var14 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var15 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var14);
//     double[][] var16 = new double[][] { var14};
//     double[][] var17 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var16);
//     org.apache.commons.math.linear.BlockRealMatrix var18 = new org.apache.commons.math.linear.BlockRealMatrix(var17);
//     java.lang.String var19 = var18.toString();
//     org.apache.commons.math.linear.BlockRealMatrix var20 = var18.transpose();
//     boolean var21 = var20.isSingular();
//     var20.setEntry(0, 0, 10.0d);
//     org.apache.commons.math.linear.BlockRealMatrix var26 = var11.subtract((org.apache.commons.math.linear.RealMatrix)var20);
//     double var27 = var20.getDeterminant();
//     double var28 = var20.getFrobeniusNorm();
//     org.apache.commons.math.linear.RealMatrix var30 = var20.scalarMultiply((-1.0d));
//     double var31 = var20.getNorm();
//     double[] var33 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var34 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var33);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var36 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var33, false);
//     double[] var37 = var20.operate(var33);
//     org.apache.commons.math.linear.BigMatrix var38 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var33);
//     boolean var39 = var0.reset((-2.0d), var33);
//     org.apache.commons.math.linear.BigMatrix var40 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var12.equals("BlockRealMatrix{{10.0}}"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var19.equals("BlockRealMatrix{{10.0}}"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }
// 
// 
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(100.0d, Double.NaN, 0.0d, 100.0d);
//     double var5 = var4.getMaxStep();
//     int var6 = var4.getEvaluations();
//     int var7 = var4.getEvaluations();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }


    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var1 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var2 = var1.getNSteps();
    int var3 = var1.getNSteps();
    double[] var5 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var5);
    org.apache.commons.math.FunctionEvaluationException var7 = new org.apache.commons.math.FunctionEvaluationException(var5);
    double[] var10 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var10);
    double[][] var12 = new double[][] { var10};
    double[][] var13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var12);
    java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var12);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = var1.initializeHighOrderDerivatives(var5, var12);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var17 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var18 = var17.getNSteps();
    int var19 = var17.getNSteps();
    double[] var21 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var21);
    org.apache.commons.math.FunctionEvaluationException var23 = new org.apache.commons.math.FunctionEvaluationException(var21);
    double[] var26 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
    double[][] var28 = new double[][] { var26};
    double[][] var29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var28);
    java.lang.IllegalArgumentException var30 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var28);
    org.apache.commons.math.linear.Array2DRowRealMatrix var31 = var17.initializeHighOrderDerivatives(var21, var28);
    org.apache.commons.math.linear.Array2DRowRealMatrix var32 = var1.updateHighOrderDerivativesPhase1(var31);
    double[] var34 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var37 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var34, false);
    var37.setInterpolatedTime(0.0d);
    boolean var40 = var32.equals((java.lang.Object)var37);
    org.apache.commons.math.fraction.FractionConversionException var44 = new org.apache.commons.math.fraction.FractionConversionException(0.0d, 0L, 10L);
    java.lang.Object[] var47 = null;
    org.apache.commons.math.FunctionEvaluationException var48 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var44, 0.0d, "", var47);
    double[] var49 = var48.getArgument();
    org.apache.commons.math.linear.BigMatrix var50 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var49);
    double[][] var51 = new double[][] { var49};
    org.apache.commons.math.linear.Array2DRowRealMatrix var52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var51);
    org.apache.commons.math.linear.Array2DRowRealMatrix var53 = var32.subtract(var52);
    org.apache.commons.math.linear.RealMatrixChangingVisitor var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var59 = var52.walkInRowOrder(var54, (-110), 2147483647, (-1), (-2));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var2 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var3 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var2);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[] var6 = var5.getInterpolatedState();
//     org.apache.commons.math.FunctionEvaluationException var7 = new org.apache.commons.math.FunctionEvaluationException(var6);
//     var0.reinitialize(var6, false);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var10 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     double var11 = var10.getCurrentTime();
//     java.io.ObjectInput var12 = null;
//     var10.readExternal(var12);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = var10.multiply(var21);
    org.apache.commons.math.fraction.BigFraction var26 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var27 = var26.reciprocal();
    org.apache.commons.math.FieldElement[] var28 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var28);
    org.apache.commons.math.FieldElement[][] var30 = new org.apache.commons.math.FieldElement[][] { var28};
    org.apache.commons.math.FieldElement[][] var31 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var30);
    java.lang.IllegalArgumentException var32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockFieldMatrix var33 = new org.apache.commons.math.linear.BlockFieldMatrix(var31);
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var38 = var37.reciprocal();
    org.apache.commons.math.FieldElement[] var39 = new org.apache.commons.math.FieldElement[] { var37};
    org.apache.commons.math.linear.FieldMatrix var40 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var39);
    org.apache.commons.math.FieldElement[][] var41 = new org.apache.commons.math.FieldElement[][] { var39};
    org.apache.commons.math.FieldElement[][] var42 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var41);
    java.lang.IllegalArgumentException var43 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var42);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = new org.apache.commons.math.linear.BlockFieldMatrix(var42);
    org.apache.commons.math.linear.BlockFieldMatrix var45 = var33.multiply(var44);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = var22.multiply(var33);
    org.apache.commons.math.fraction.BigFraction var49 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var50 = var49.reciprocal();
    org.apache.commons.math.FieldElement[] var51 = new org.apache.commons.math.FieldElement[] { var49};
    org.apache.commons.math.linear.FieldMatrix var52 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var51);
    org.apache.commons.math.FieldElement[] var53 = var22.preMultiply(var51);
    org.apache.commons.math.fraction.BigFraction var56 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var57 = var56.reciprocal();
    org.apache.commons.math.fraction.BigFraction var60 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var61 = var60.reciprocal();
    org.apache.commons.math.fraction.BigFraction var64 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var65 = var64.reciprocal();
    org.apache.commons.math.fraction.BigFraction var66 = var60.subtract(var64);
    org.apache.commons.math.fraction.BigFraction var69 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var70 = var69.reciprocal();
    org.apache.commons.math.fraction.BigFraction var73 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var74 = var73.reciprocal();
    org.apache.commons.math.fraction.BigFraction var75 = var69.subtract(var73);
    org.apache.commons.math.fraction.BigFraction var76 = var60.subtract(var73);
    java.math.BigInteger var77 = var76.getDenominator();
    org.apache.commons.math.fraction.BigFraction var78 = var56.divide(var77);
    org.apache.commons.math.FieldElement[] var79 = new org.apache.commons.math.FieldElement[] { var78};
    org.apache.commons.math.linear.FieldMatrix var80 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var79);
    org.apache.commons.math.linear.FieldMatrix var81 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var79);
    org.apache.commons.math.linear.FieldVector var82 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var79);
    org.apache.commons.math.linear.FieldVector var83 = var22.preMultiply(var82);
    org.apache.commons.math.fraction.BigFraction var86 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(8, (-1));
    org.apache.commons.math.fraction.BigFraction var88 = var86.multiply((-2L));
    org.apache.commons.math.linear.FieldMatrix var89 = var22.scalarMultiply((org.apache.commons.math.FieldElement)var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var94 = var22.getSubMatrix(0, 100, (-1), (-2));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.fraction.BigFraction var7 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var8 = var7.reciprocal();
    org.apache.commons.math.fraction.BigFraction var11 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
    org.apache.commons.math.fraction.BigFraction var13 = var7.subtract(var11);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var17 = var16.reciprocal();
    org.apache.commons.math.fraction.BigFraction var20 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var21 = var20.reciprocal();
    org.apache.commons.math.fraction.BigFraction var22 = var16.subtract(var20);
    org.apache.commons.math.fraction.BigFraction var23 = var7.subtract(var20);
    java.math.BigInteger var24 = var23.getDenominator();
    org.apache.commons.math.fraction.BigFraction var25 = var3.divide(var24);
    org.apache.commons.math.FieldElement[] var26 = new org.apache.commons.math.FieldElement[] { var25};
    org.apache.commons.math.linear.FieldMatrix var27 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.linear.FieldMatrix var28 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.linear.FieldVector var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var26);
    org.apache.commons.math.linear.FieldMatrix var30 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var26);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var31 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var26);
    java.lang.NullPointerException var32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[])var26);
    org.apache.commons.math.MathException var33 = new org.apache.commons.math.MathException((java.lang.Throwable)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var8);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var12 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var8);
    org.apache.commons.math.Field var13 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var14 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var13);
    org.apache.commons.math.FieldElement var15 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var16 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var15);
    var16.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var24 = var14.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var16);
    org.apache.commons.math.FieldElement var25 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var26 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var25);
    org.apache.commons.math.FieldElement var27 = var14.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var26);
    var26.start((-1), 0, 0, 8, 0, 8);
    org.apache.commons.math.FieldElement var35 = var26.end();
    org.apache.commons.math.FieldElement var36 = var12.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var26);
    int var37 = var12.getRowDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    org.apache.commons.math.linear.Array2DRowRealMatrix var7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var4, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }


    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var4 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var5 = var4.getNSteps();
    double[] var7 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var8 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var7);
    org.apache.commons.math.FunctionEvaluationException var9 = new org.apache.commons.math.FunctionEvaluationException(var7);
    double[] var11 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var12 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var11);
    org.apache.commons.math.FunctionEvaluationException var13 = new org.apache.commons.math.FunctionEvaluationException(var11);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var15 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var16 = var15.getNSteps();
    int var17 = var15.getNSteps();
    double[] var19 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var20 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var19);
    org.apache.commons.math.FunctionEvaluationException var21 = new org.apache.commons.math.FunctionEvaluationException(var19);
    double[] var24 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var25 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var24);
    double[][] var26 = new double[][] { var24};
    double[][] var27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var26);
    java.lang.IllegalArgumentException var28 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var26);
    org.apache.commons.math.linear.Array2DRowRealMatrix var29 = var15.initializeHighOrderDerivatives(var19, var26);
    var4.updateHighOrderDerivativesPhase2(var7, var11, var29);
    org.apache.commons.math.linear.BigMatrix var31 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var7);
    java.lang.Throwable var32 = null;
    double[] var34 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    org.apache.commons.math.linear.RealVector var36 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var34);
    org.apache.commons.math.FunctionEvaluationException var37 = new org.apache.commons.math.FunctionEvaluationException(var32, var34);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var38 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.4142135623730951d, var7, var34);
    org.apache.commons.math.ode.events.EventHandler var39 = null;
    var38.addEventHandler(var39, 100.0d, (-2.0d), 100);
    int var44 = var38.getMaxEvaluations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 2147483647);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    org.apache.commons.math.linear.BlockRealMatrix var7 = var5.transpose();
    boolean var8 = var7.isSingular();
    var7.setEntry(0, 0, 10.0d);
    java.lang.Throwable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var20 = new org.apache.commons.math.ConvergenceException(var16, "", var19);
    org.apache.commons.math.MaxEvaluationsExceededException var21 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var19);
    java.lang.IllegalStateException var22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var19);
    org.apache.commons.math.ode.IntegratorException var23 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var22);
    boolean var24 = var7.equals((java.lang.Object)var23);
    double[] var26 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
    double[][] var28 = new double[][] { var26};
    double[][] var29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var28);
    org.apache.commons.math.linear.BlockRealMatrix var30 = new org.apache.commons.math.linear.BlockRealMatrix(var29);
    java.lang.String var31 = var30.toString();
    double[] var33 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var34 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var33);
    double[][] var35 = new double[][] { var33};
    double[][] var36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var35);
    org.apache.commons.math.linear.BlockRealMatrix var37 = new org.apache.commons.math.linear.BlockRealMatrix(var36);
    java.lang.String var38 = var37.toString();
    org.apache.commons.math.linear.BlockRealMatrix var39 = var37.transpose();
    boolean var40 = var39.isSingular();
    var39.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var45 = var30.subtract((org.apache.commons.math.linear.RealMatrix)var39);
    org.apache.commons.math.linear.RealMatrix var47 = var30.scalarMultiply(10.0d);
    double var48 = var30.getNorm();
    org.apache.commons.math.linear.BlockRealMatrix var49 = var7.add(var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealMatrix var51 = var49.getRowMatrix((-2));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var31.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var38.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(2147483647, 1);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }


    double[] var3 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var4 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var3);
    double[][] var5 = new double[][] { var3};
    double[][] var6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var5);
    java.lang.IllegalArgumentException var7 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var5);
    org.apache.commons.math.ode.IntegratorException var8 = new org.apache.commons.math.ode.IntegratorException("hi!", (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var1, false);
    var4.shift();
    var4.finalizeStep();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var5 = var3.add((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var3.reduce();
    org.apache.commons.math.fraction.BigFraction var9 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var10 = var9.getField();
    org.apache.commons.math.fraction.BigFraction var12 = var9.multiply(0);
    org.apache.commons.math.fraction.BigFraction var14 = var12.divide(100);
    org.apache.commons.math.fraction.BigFraction var15 = var3.subtract(var12);
    org.apache.commons.math.fraction.BigFraction var18 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var19 = var18.reciprocal();
    org.apache.commons.math.fraction.BigFraction var22 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var23 = var22.reciprocal();
    org.apache.commons.math.fraction.BigFraction var24 = var18.subtract(var22);
    java.lang.String var25 = var22.toString();
    org.apache.commons.math.fraction.BigFraction var27 = var22.divide((-1L));
    int var28 = var3.compareTo(var27);
    int var29 = var3.getDenominatorAsInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "-1"+ "'", var25.equals("-1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }


    org.apache.commons.math.Field var0 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var1 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var0);
    org.apache.commons.math.FieldElement var2 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var3 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var2);
    var3.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var11 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var3);
    org.apache.commons.math.Field var12 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var13 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var12);
    org.apache.commons.math.FieldElement var14 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var15 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var14);
    var15.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var23 = var13.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    org.apache.commons.math.FieldElement var24 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    boolean var25 = var1.isSquare();
    org.apache.commons.math.Field var26 = var1.getField();
    double[] var28 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var29 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    org.apache.commons.math.linear.BlockRealMatrix var32 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
    double[] var34 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    double[][] var36 = new double[][] { var34};
    double[][] var37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var36);
    org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var37);
    java.lang.String var39 = var38.toString();
    org.apache.commons.math.linear.BlockRealMatrix var40 = var38.transpose();
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var32, (org.apache.commons.math.linear.AnyMatrix)var38);
    double[] var43 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var43);
    double[][] var45 = new double[][] { var43};
    double[][] var46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var45);
    org.apache.commons.math.linear.BlockRealMatrix var47 = new org.apache.commons.math.linear.BlockRealMatrix(var46);
    java.lang.String var48 = var47.toString();
    org.apache.commons.math.linear.BlockRealMatrix var49 = var47.transpose();
    boolean var50 = var49.isSingular();
    var49.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var55 = var32.multiply((org.apache.commons.math.linear.RealMatrix)var49);
    boolean var56 = var1.equals((java.lang.Object)var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var55.setEntry(1, 2147483647, 100.0d);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var39.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var48.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var6 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var7 = var6.reciprocal();
    org.apache.commons.math.fraction.BigFraction var8 = var2.subtract(var6);
    org.apache.commons.math.fraction.BigFraction var11 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
    org.apache.commons.math.fraction.BigFraction var15 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var16 = var15.reciprocal();
    org.apache.commons.math.fraction.BigFraction var17 = var11.subtract(var15);
    org.apache.commons.math.fraction.BigFraction var18 = var2.subtract(var15);
    java.math.BigInteger var19 = var18.getDenominator();
    org.apache.commons.math.fraction.BigFraction var20 = var18.negate();
    org.apache.commons.math.fraction.BigFraction var21 = var20.negate();
    double var23 = var20.pow(0.0d);
    org.apache.commons.math.fraction.BigFraction var24 = var20.negate();
    org.apache.commons.math.fraction.BigFraction var27 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var28 = var27.reciprocal();
    org.apache.commons.math.fraction.BigFraction var31 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var32 = var31.reciprocal();
    org.apache.commons.math.fraction.BigFraction var33 = var27.subtract(var31);
    org.apache.commons.math.fraction.BigFraction var36 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var37 = var36.reciprocal();
    org.apache.commons.math.fraction.BigFraction var40 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var41 = var40.reciprocal();
    org.apache.commons.math.fraction.BigFraction var42 = var36.subtract(var40);
    org.apache.commons.math.fraction.BigFraction var43 = var27.subtract(var40);
    java.math.BigInteger var44 = var43.getDenominator();
    org.apache.commons.math.fraction.BigFraction var45 = var43.negate();
    org.apache.commons.math.fraction.BigFraction var46 = var45.negate();
    org.apache.commons.math.fraction.BigFraction var48 = var45.subtract(100L);
    int var49 = var24.compareTo(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }
// 
// 
//     double[] var1 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
//     double[][] var3 = new double[][] { var1};
//     double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
//     org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
//     java.lang.String var6 = var5.toString();
//     double[] var8 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
//     double[][] var10 = new double[][] { var8};
//     double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
//     org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
//     java.lang.String var13 = var12.toString();
//     org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
//     boolean var15 = var14.isSingular();
//     var14.setEntry(0, 0, 10.0d);
//     org.apache.commons.math.linear.BlockRealMatrix var20 = var5.subtract((org.apache.commons.math.linear.RealMatrix)var14);
//     double var21 = var14.getDeterminant();
//     double var22 = var14.getFrobeniusNorm();
//     org.apache.commons.math.linear.BlockRealMatrix var23 = var14.copy();
//     org.apache.commons.math.linear.RealVector var25 = null;
//     var14.setRowVector(8, var25);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var5 = var3.add((-1L));
    org.apache.commons.math.fraction.BigFraction var6 = var3.reduce();
    org.apache.commons.math.fraction.BigFraction var9 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var10 = var9.getField();
    org.apache.commons.math.fraction.BigFraction var12 = var9.multiply(0);
    org.apache.commons.math.fraction.BigFraction var14 = var12.divide(100);
    org.apache.commons.math.fraction.BigFraction var15 = var3.subtract(var12);
    org.apache.commons.math.fraction.BigFraction var18 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var19 = var18.reciprocal();
    org.apache.commons.math.fraction.BigFraction var22 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var23 = var22.reciprocal();
    org.apache.commons.math.fraction.BigFraction var24 = var18.subtract(var22);
    java.lang.String var25 = var22.toString();
    org.apache.commons.math.fraction.BigFraction var27 = var22.divide((-1L));
    int var28 = var3.compareTo(var27);
    org.apache.commons.math.fraction.BigFraction var29 = var27.reciprocal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "-1"+ "'", var25.equals("-1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    double[] var3 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var4 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var3);
    double[][] var5 = new double[][] { var3};
    double[][] var6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var5);
    java.lang.IllegalArgumentException var7 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var5);
    java.util.ConcurrentModificationException var8 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", (java.lang.Object[])var5);
    org.apache.commons.math.FunctionEvaluationException var10 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var8, 0.2d);
    org.apache.commons.math.ode.IntegratorException var11 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var8);
    org.apache.commons.math.MathRuntimeException var12 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }


    org.apache.commons.math.fraction.BigFraction var4 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var5 = var4.reciprocal();
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    org.apache.commons.math.FieldElement[][] var8 = new org.apache.commons.math.FieldElement[][] { var6};
    org.apache.commons.math.FieldElement[][] var9 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var8);
    java.lang.IllegalArgumentException var10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var9);
    org.apache.commons.math.linear.InvalidMatrixException var11 = new org.apache.commons.math.linear.InvalidMatrixException("0", (java.lang.Object[])var9);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var12 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var9);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var14 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var9, false);
    java.lang.String var15 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Array2DRowFieldMatrix{{-1}}"+ "'", var15.equals("Array2DRowFieldMatrix{{-1}}"));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }


    org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    var0.clearEventsHandlers();
    org.apache.commons.math.ode.events.EventHandler var2 = null;
    var0.addEventHandler(var2, (-900.0d), (-10000.0d), 1);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.FieldElement[][] var6 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var3, (-1), 8);
    org.apache.commons.math.linear.BlockFieldMatrix var9 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var3, 100, 1);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var22 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var21);
    var9.setRowMatrix(10, (org.apache.commons.math.linear.FieldMatrix)var21);
    org.apache.commons.math.linear.FieldMatrix var24 = var21.transpose();
    org.apache.commons.math.FieldElement[][] var25 = var21.getData();
    org.apache.commons.math.fraction.BigFraction var29 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var30 = var29.reciprocal();
    org.apache.commons.math.FieldElement[] var31 = new org.apache.commons.math.FieldElement[] { var29};
    org.apache.commons.math.linear.FieldMatrix var32 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var31);
    org.apache.commons.math.FieldElement[][] var33 = new org.apache.commons.math.FieldElement[][] { var31};
    org.apache.commons.math.FieldElement[][] var34 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var33);
    java.lang.IllegalArgumentException var35 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var34);
    org.apache.commons.math.linear.BlockFieldMatrix var36 = new org.apache.commons.math.linear.BlockFieldMatrix(var34);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var37 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var34);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var38 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var34);
    org.apache.commons.math.linear.BlockFieldMatrix var39 = new org.apache.commons.math.linear.BlockFieldMatrix(var34);
    org.apache.commons.math.fraction.BigFraction var42 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var43 = var42.reciprocal();
    org.apache.commons.math.fraction.BigFraction var46 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var47 = var46.reciprocal();
    org.apache.commons.math.fraction.BigFraction var50 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var51 = var50.reciprocal();
    org.apache.commons.math.fraction.BigFraction var52 = var46.subtract(var50);
    org.apache.commons.math.fraction.BigFraction var55 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var56 = var55.reciprocal();
    org.apache.commons.math.fraction.BigFraction var59 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var60 = var59.reciprocal();
    org.apache.commons.math.fraction.BigFraction var61 = var55.subtract(var59);
    org.apache.commons.math.fraction.BigFraction var62 = var46.subtract(var59);
    java.math.BigInteger var63 = var62.getDenominator();
    org.apache.commons.math.fraction.BigFraction var64 = var42.divide(var63);
    org.apache.commons.math.FieldElement[] var65 = new org.apache.commons.math.FieldElement[] { var64};
    org.apache.commons.math.linear.FieldMatrix var66 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var65);
    org.apache.commons.math.linear.FieldMatrix var67 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var65);
    org.apache.commons.math.FieldElement[] var68 = var39.operate(var65);
    org.apache.commons.math.linear.BlockFieldMatrix var69 = var21.multiply(var39);
    org.apache.commons.math.FieldElement[][] var70 = var69.getData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    org.apache.commons.math.fraction.BigFraction var4 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var5 = var4.reciprocal();
    org.apache.commons.math.fraction.BigFraction var8 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var9 = var8.reciprocal();
    org.apache.commons.math.fraction.BigFraction var12 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var13 = var12.reciprocal();
    org.apache.commons.math.fraction.BigFraction var14 = var8.subtract(var12);
    org.apache.commons.math.fraction.BigFraction var17 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var18 = var17.reciprocal();
    org.apache.commons.math.fraction.BigFraction var21 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var22 = var21.reciprocal();
    org.apache.commons.math.fraction.BigFraction var23 = var17.subtract(var21);
    org.apache.commons.math.fraction.BigFraction var24 = var8.subtract(var21);
    java.math.BigInteger var25 = var24.getDenominator();
    org.apache.commons.math.fraction.BigFraction var26 = var4.divide(var25);
    org.apache.commons.math.FieldElement[] var27 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var28 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var27);
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var27);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var30 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var27);
    org.apache.commons.math.FunctionEvaluationException var31 = new org.apache.commons.math.FunctionEvaluationException(1.0650410894399627d, "org.apache.commons.math.MathRuntimeException$6: hi!", (java.lang.Object[])var27);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var32 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var6 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var7 = var6.reciprocal();
    org.apache.commons.math.fraction.BigFraction var8 = var2.subtract(var6);
    org.apache.commons.math.fraction.BigFraction var11 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
    org.apache.commons.math.fraction.BigFraction var14 = var12.add((-1L));
    int var15 = var14.getDenominatorAsInt();
    long var16 = var14.getNumeratorAsLong();
    org.apache.commons.math.fraction.BigFraction var18 = var14.pow((-1L));
    org.apache.commons.math.fraction.BigFraction var21 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var22 = var21.reciprocal();
    org.apache.commons.math.fraction.BigFraction var25 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var26 = var25.reciprocal();
    org.apache.commons.math.fraction.BigFraction var27 = var21.subtract(var25);
    org.apache.commons.math.fraction.BigFraction var30 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var31 = var30.reciprocal();
    org.apache.commons.math.fraction.BigFraction var34 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var35 = var34.reciprocal();
    org.apache.commons.math.fraction.BigFraction var36 = var30.subtract(var34);
    org.apache.commons.math.fraction.BigFraction var37 = var21.subtract(var34);
    java.math.BigInteger var38 = var37.getDenominator();
    org.apache.commons.math.fraction.BigFraction var39 = var14.pow(var38);
    org.apache.commons.math.fraction.BigFraction var40 = var6.subtract(var38);
    org.apache.commons.math.fraction.BigFraction var42 = var40.pow((-2));
    int var43 = var42.intValue();
    org.apache.commons.math.fraction.BigFraction var45 = new org.apache.commons.math.fraction.BigFraction((-2L));
    org.apache.commons.math.fraction.BigFraction var46 = var45.reciprocal();
    org.apache.commons.math.fraction.BigFraction var48 = var46.pow(0);
    org.apache.commons.math.fraction.BigFraction var49 = var42.subtract(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.FieldElement[][] var6 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var3, (-1), 8);
    org.apache.commons.math.linear.BlockFieldMatrix var9 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var3, 100, 1);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var22 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var21);
    var9.setRowMatrix(10, (org.apache.commons.math.linear.FieldMatrix)var21);
    org.apache.commons.math.Field var24 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var25 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var24);
    org.apache.commons.math.FieldElement var26 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var27 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var26);
    var27.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var35 = var25.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var27);
    org.apache.commons.math.Field var36 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var37 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var36);
    org.apache.commons.math.FieldElement var38 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var39 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var38);
    var39.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var47 = var37.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var39);
    org.apache.commons.math.FieldElement var48 = var25.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var39);
    boolean var49 = var25.isSquare();
    org.apache.commons.math.Field var50 = var25.getField();
    org.apache.commons.math.FieldElement[][] var51 = var25.getDataRef();
    org.apache.commons.math.Field var52 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var53 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var52);
    org.apache.commons.math.FieldElement var54 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var55 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var54);
    var55.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var63 = var53.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var55);
    org.apache.commons.math.Field var64 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var65 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var64);
    org.apache.commons.math.FieldElement var66 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var67 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var66);
    var67.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var75 = var65.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var67);
    org.apache.commons.math.FieldElement var76 = var53.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var67);
    boolean var77 = var53.isSquare();
    org.apache.commons.math.FieldElement var78 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var79 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var78);
    org.apache.commons.math.FieldElement var80 = var53.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var79);
    org.apache.commons.math.FieldElement var81 = var25.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var79);
    org.apache.commons.math.FieldElement var82 = var9.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var79);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldVector var84 = var9.getRowVector((-110));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.fraction.BigFraction var7 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var8 = var7.reciprocal();
    org.apache.commons.math.fraction.BigFraction var11 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
    org.apache.commons.math.fraction.BigFraction var13 = var7.subtract(var11);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var17 = var16.reciprocal();
    org.apache.commons.math.fraction.BigFraction var20 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var21 = var20.reciprocal();
    org.apache.commons.math.fraction.BigFraction var22 = var16.subtract(var20);
    org.apache.commons.math.fraction.BigFraction var23 = var7.subtract(var20);
    java.math.BigInteger var24 = var23.getDenominator();
    org.apache.commons.math.fraction.BigFraction var25 = var3.divide(var24);
    org.apache.commons.math.FieldElement[] var26 = new org.apache.commons.math.FieldElement[] { var25};
    org.apache.commons.math.linear.FieldMatrix var27 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.linear.FieldMatrix var28 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.ConvergenceException var29 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[])var26);
    org.apache.commons.math.linear.FieldMatrix var30 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var31 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var26);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var32 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var26);
    org.apache.commons.math.fraction.BigFraction var36 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var37 = var36.reciprocal();
    org.apache.commons.math.fraction.BigFraction var40 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var41 = var40.reciprocal();
    org.apache.commons.math.fraction.BigFraction var42 = var36.subtract(var40);
    java.math.BigDecimal var43 = var42.bigDecimalValue();
    org.apache.commons.math.FieldElement[] var44 = new org.apache.commons.math.FieldElement[] { var42};
    org.apache.commons.math.linear.FieldVector var45 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var44);
    var32.setRow(0, var44);
    org.apache.commons.math.FieldElement[][] var47 = var32.getDataRef();
    org.apache.commons.math.FieldElement[][] var48 = var32.getDataRef();
    int var49 = var32.getColumnDimension();
    int var50 = var32.getColumnDimension();
    org.apache.commons.math.fraction.BigFraction var54 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var55 = var54.reciprocal();
    org.apache.commons.math.FieldElement[] var56 = new org.apache.commons.math.FieldElement[] { var54};
    org.apache.commons.math.linear.FieldMatrix var57 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var56);
    org.apache.commons.math.FieldElement[][] var58 = new org.apache.commons.math.FieldElement[][] { var56};
    org.apache.commons.math.FieldElement[][] var59 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var58);
    java.lang.IllegalArgumentException var60 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var59);
    org.apache.commons.math.linear.BlockFieldMatrix var61 = new org.apache.commons.math.linear.BlockFieldMatrix(var59);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var62 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var59);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var63 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var59);
    org.apache.commons.math.Field var64 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var65 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var64);
    org.apache.commons.math.FieldElement var66 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var67 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var66);
    var67.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var75 = var65.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var67);
    org.apache.commons.math.FieldElement var76 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var77 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var76);
    org.apache.commons.math.FieldElement var78 = var65.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var77);
    var77.start((-1), 0, 0, 8, 0, 8);
    org.apache.commons.math.FieldElement var86 = var77.end();
    org.apache.commons.math.FieldElement var87 = var63.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var77);
    org.apache.commons.math.fraction.BigFraction var91 = new org.apache.commons.math.fraction.BigFraction(1.4142135623730951d);
    org.apache.commons.math.fraction.BigFraction var93 = var91.subtract(0L);
    org.apache.commons.math.FieldElement var94 = var77.visit(8, 2147483647, (org.apache.commons.math.FieldElement)var91);
    org.apache.commons.math.FieldElement var95 = var32.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var95);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }


    double[] var4 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var5 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var4);
    org.apache.commons.math.linear.RealVector var6 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var4);
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var8, false);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var12 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.0d, 10.0d, var4, var8);
    org.apache.commons.math.fraction.BigFraction var17 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var18 = var17.reciprocal();
    org.apache.commons.math.fraction.BigFraction var21 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var22 = var21.reciprocal();
    org.apache.commons.math.fraction.BigFraction var25 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var26 = var25.reciprocal();
    org.apache.commons.math.fraction.BigFraction var27 = var21.subtract(var25);
    org.apache.commons.math.fraction.BigFraction var30 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var31 = var30.reciprocal();
    org.apache.commons.math.fraction.BigFraction var34 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var35 = var34.reciprocal();
    org.apache.commons.math.fraction.BigFraction var36 = var30.subtract(var34);
    org.apache.commons.math.fraction.BigFraction var37 = var21.subtract(var34);
    java.math.BigInteger var38 = var37.getDenominator();
    org.apache.commons.math.fraction.BigFraction var39 = var17.divide(var38);
    org.apache.commons.math.FieldElement[] var40 = new org.apache.commons.math.FieldElement[] { var39};
    org.apache.commons.math.linear.FieldMatrix var41 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var40);
    org.apache.commons.math.linear.FieldMatrix var42 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var40);
    org.apache.commons.math.ConvergenceException var43 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[])var40);
    org.apache.commons.math.linear.FieldMatrix var44 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var40);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var45 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var40);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var46 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var40);
    org.apache.commons.math.FunctionEvaluationException var47 = new org.apache.commons.math.FunctionEvaluationException(var8, "matrix is singular", (java.lang.Object[])var40);
    double[] var48 = var47.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }


    org.apache.commons.math.MathException var2 = new org.apache.commons.math.MathException();
    org.apache.commons.math.FunctionEvaluationException var4 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var2, (-2.0d));
    double[] var6 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var6);
    double[][] var8 = new double[][] { var6};
    double[][] var9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var8);
    org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    java.lang.String var11 = var10.toString();
    double[] var13 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var14 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var13);
    double[][] var15 = new double[][] { var13};
    double[][] var16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var15);
    org.apache.commons.math.linear.BlockRealMatrix var17 = new org.apache.commons.math.linear.BlockRealMatrix(var16);
    java.lang.String var18 = var17.toString();
    org.apache.commons.math.linear.BlockRealMatrix var19 = var17.transpose();
    boolean var20 = var19.isSingular();
    var19.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var25 = var10.subtract((org.apache.commons.math.linear.RealMatrix)var19);
    double[] var27 = var10.getColumn(0);
    java.lang.Throwable var33 = null;
    java.lang.Object[] var36 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var37 = new org.apache.commons.math.ConvergenceException(var33, "", var36);
    org.apache.commons.math.MaxEvaluationsExceededException var38 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", var36);
    double[] var41 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var42 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var41);
    double[][] var43 = new double[][] { var41};
    double[][] var44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var43);
    org.apache.commons.math.MathRuntimeException var45 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var38, "hi!", (java.lang.Object[])var44);
    org.apache.commons.math.ode.IntegratorException var46 = new org.apache.commons.math.ode.IntegratorException("BlockRealMatrix{{10.0}}", (java.lang.Object[])var44);
    org.apache.commons.math.MathRuntimeException var47 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var44);
    org.apache.commons.math.linear.RealMatrix var48 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var44);
    org.apache.commons.math.FunctionEvaluationException var49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var4, var27, "BlockFieldMatrix{{-1}}", (java.lang.Object[])var44);
    java.util.NoSuchElementException var50 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathRuntimeException$2: -1", (java.lang.Object[])var44);
    java.util.ConcurrentModificationException var51 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("hi!", (java.lang.Object[])var44);
    org.apache.commons.math.linear.BlockRealMatrix var52 = new org.apache.commons.math.linear.BlockRealMatrix(var44);
    int var53 = var52.getRowDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var11.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var18.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.fraction.BigFraction var7 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var8 = var7.reciprocal();
    org.apache.commons.math.fraction.BigFraction var11 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
    org.apache.commons.math.fraction.BigFraction var13 = var7.subtract(var11);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var17 = var16.reciprocal();
    org.apache.commons.math.fraction.BigFraction var20 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var21 = var20.reciprocal();
    org.apache.commons.math.fraction.BigFraction var22 = var16.subtract(var20);
    org.apache.commons.math.fraction.BigFraction var23 = var7.subtract(var20);
    java.math.BigInteger var24 = var23.getDenominator();
    org.apache.commons.math.fraction.BigFraction var25 = var3.divide(var24);
    org.apache.commons.math.FieldElement[] var26 = new org.apache.commons.math.FieldElement[] { var25};
    org.apache.commons.math.linear.FieldMatrix var27 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.linear.FieldMatrix var28 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.ConvergenceException var29 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[])var26);
    org.apache.commons.math.linear.FieldMatrix var30 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var31 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var26);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var32 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var26);
    double[] var34 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    double[][] var36 = new double[][] { var34};
    double[][] var37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var36);
    org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var37);
    double[] var40 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var41 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var40);
    double[][] var42 = new double[][] { var40};
    double[][] var43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var42);
    org.apache.commons.math.linear.BlockRealMatrix var44 = new org.apache.commons.math.linear.BlockRealMatrix(var43);
    java.lang.String var45 = var44.toString();
    org.apache.commons.math.linear.BlockRealMatrix var46 = var44.transpose();
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var38, (org.apache.commons.math.linear.AnyMatrix)var44);
    org.apache.commons.math.linear.RealMatrix var48 = var38.inverse();
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var32, (org.apache.commons.math.linear.AnyMatrix)var48);
    org.apache.commons.math.fraction.BigFraction var53 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var54 = var53.reciprocal();
    org.apache.commons.math.FieldElement[] var55 = new org.apache.commons.math.FieldElement[] { var53};
    org.apache.commons.math.linear.FieldMatrix var56 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var55);
    org.apache.commons.math.FieldElement[][] var57 = new org.apache.commons.math.FieldElement[][] { var55};
    org.apache.commons.math.FieldElement[][] var58 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var57);
    java.lang.IllegalArgumentException var59 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var58);
    org.apache.commons.math.linear.BlockFieldMatrix var60 = new org.apache.commons.math.linear.BlockFieldMatrix(var58);
    org.apache.commons.math.fraction.BigFraction var64 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var65 = var64.reciprocal();
    org.apache.commons.math.FieldElement[] var66 = new org.apache.commons.math.FieldElement[] { var64};
    org.apache.commons.math.linear.FieldMatrix var67 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var66);
    org.apache.commons.math.FieldElement[][] var68 = new org.apache.commons.math.FieldElement[][] { var66};
    org.apache.commons.math.FieldElement[][] var69 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var68);
    java.lang.IllegalArgumentException var70 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var69);
    org.apache.commons.math.linear.BlockFieldMatrix var71 = new org.apache.commons.math.linear.BlockFieldMatrix(var69);
    org.apache.commons.math.linear.BlockFieldMatrix var72 = var60.multiply(var71);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var73 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var71);
    boolean var74 = var32.equals((java.lang.Object)var73);
    org.apache.commons.math.FieldElement[] var76 = var32.getRow(0);
    org.apache.commons.math.linear.FieldVector var78 = var32.getColumnVector(0);
    org.apache.commons.math.FieldElement[][] var79 = var32.getDataRef();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var45.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = var10.multiply(var21);
    org.apache.commons.math.fraction.BigFraction var26 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var27 = var26.reciprocal();
    org.apache.commons.math.FieldElement[] var28 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var28);
    org.apache.commons.math.FieldElement[][] var30 = new org.apache.commons.math.FieldElement[][] { var28};
    org.apache.commons.math.FieldElement[][] var31 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var30);
    java.lang.IllegalArgumentException var32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockFieldMatrix var33 = new org.apache.commons.math.linear.BlockFieldMatrix(var31);
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var38 = var37.reciprocal();
    org.apache.commons.math.FieldElement[] var39 = new org.apache.commons.math.FieldElement[] { var37};
    org.apache.commons.math.linear.FieldMatrix var40 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var39);
    org.apache.commons.math.FieldElement[][] var41 = new org.apache.commons.math.FieldElement[][] { var39};
    org.apache.commons.math.FieldElement[][] var42 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var41);
    java.lang.IllegalArgumentException var43 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var42);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = new org.apache.commons.math.linear.BlockFieldMatrix(var42);
    org.apache.commons.math.linear.BlockFieldMatrix var45 = var33.multiply(var44);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = var22.multiply(var33);
    org.apache.commons.math.FieldElement var47 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var48 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var47);
    var48.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var56 = var46.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var48);
    org.apache.commons.math.fraction.BigFraction var61 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var62 = var61.reciprocal();
    org.apache.commons.math.fraction.BigFraction var65 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var66 = var65.reciprocal();
    org.apache.commons.math.fraction.BigFraction var67 = var61.subtract(var65);
    org.apache.commons.math.fraction.BigFraction var70 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var71 = var70.reciprocal();
    org.apache.commons.math.fraction.BigFraction var74 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var75 = var74.reciprocal();
    org.apache.commons.math.fraction.BigFraction var76 = var70.subtract(var74);
    org.apache.commons.math.fraction.BigFraction var77 = var61.subtract(var74);
    java.math.BigInteger var78 = var77.getDenominator();
    org.apache.commons.math.fraction.BigFraction var80 = var77.add(0L);
    var48.visit(0, 100, (org.apache.commons.math.FieldElement)var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var6 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var7 = var6.reciprocal();
    org.apache.commons.math.fraction.BigFraction var8 = var2.subtract(var6);
    org.apache.commons.math.fraction.BigFraction var11 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
    org.apache.commons.math.fraction.BigFraction var15 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var16 = var15.reciprocal();
    org.apache.commons.math.fraction.BigFraction var17 = var11.subtract(var15);
    org.apache.commons.math.fraction.BigFraction var18 = var2.subtract(var15);
    int var19 = var2.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var23 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var24 = var23.reciprocal();
    org.apache.commons.math.FieldElement[] var25 = new org.apache.commons.math.FieldElement[] { var23};
    org.apache.commons.math.linear.FieldMatrix var26 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var25);
    org.apache.commons.math.FieldElement[][] var27 = new org.apache.commons.math.FieldElement[][] { var25};
    org.apache.commons.math.FieldElement[][] var28 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var27);
    java.lang.IllegalArgumentException var29 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var28);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = new org.apache.commons.math.linear.BlockFieldMatrix(var28);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var31 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var30);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var32 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var33 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var32);
    boolean var34 = var30.equals((java.lang.Object)var32);
    boolean var35 = var2.equals((java.lang.Object)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    double[] var4 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var5 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var4);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
    double[] var8 = var7.getInterpolatedState();
    double[] var10 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var10);
    org.apache.commons.math.linear.RealVector var12 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var10);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var13 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(8, (-1.0d), (-2.0d), var8, var10);
    org.apache.commons.math.linear.RealMatrix var14 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(var8);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var16 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var8, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }


    java.lang.Object[] var4 = new java.lang.Object[] { (byte)0};
    org.apache.commons.math.ConvergenceException var5 = new org.apache.commons.math.ConvergenceException("hi!", var4);
    org.apache.commons.math.FunctionEvaluationException var6 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "hi!", var4);
    org.apache.commons.math.ode.IntegratorException var7 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var6);
    java.lang.Object[] var8 = var6.getArguments();
    double[] var9 = var6.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     var0.clearEventsHandlers();
//     double var2 = var0.getEventTime();
//     org.apache.commons.math.ode.events.EventHandler var3 = null;
//     var0.addEventHandler(var3, 1.0E-6d, 1.0E-15d, (-2));
//     boolean var8 = var0.isEmpty();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }
// 
// 
//     org.apache.commons.math.ode.events.EventHandler var0 = null;
//     org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 1.0d, (-900.0d), 0);
//     double var5 = var4.getMaxCheckInterval();
//     double var6 = var4.getEventTime();
//     double var7 = var4.getMaxCheckInterval();
//     org.apache.commons.math.ode.events.EventHandler var8 = var4.getEventHandler();
//     int var9 = var4.getMaxIterationCount();
//     double var10 = var4.getEventTime();
//     double var11 = var4.getConvergence();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 900.0d);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    boolean var6 = var5.isSquare();
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
    java.lang.String var13 = var12.toString();
    org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
    boolean var15 = var14.isSingular();
    var14.setEntry(0, 0, 10.0d);
    java.lang.Throwable var23 = null;
    java.lang.Object[] var26 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var27 = new org.apache.commons.math.ConvergenceException(var23, "", var26);
    org.apache.commons.math.MaxEvaluationsExceededException var28 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var26);
    java.lang.IllegalStateException var29 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var26);
    org.apache.commons.math.ode.IntegratorException var30 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var29);
    boolean var31 = var14.equals((java.lang.Object)var30);
    double[] var33 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var34 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var33);
    double[][] var35 = new double[][] { var33};
    double[][] var36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var35);
    org.apache.commons.math.linear.BlockRealMatrix var37 = new org.apache.commons.math.linear.BlockRealMatrix(var36);
    java.lang.String var38 = var37.toString();
    double[] var40 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var41 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var40);
    double[][] var42 = new double[][] { var40};
    double[][] var43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var42);
    org.apache.commons.math.linear.BlockRealMatrix var44 = new org.apache.commons.math.linear.BlockRealMatrix(var43);
    java.lang.String var45 = var44.toString();
    org.apache.commons.math.linear.BlockRealMatrix var46 = var44.transpose();
    boolean var47 = var46.isSingular();
    var46.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var52 = var37.subtract((org.apache.commons.math.linear.RealMatrix)var46);
    org.apache.commons.math.linear.RealMatrix var54 = var37.scalarMultiply(10.0d);
    double var55 = var37.getNorm();
    org.apache.commons.math.linear.BlockRealMatrix var56 = var14.add(var37);
    org.apache.commons.math.linear.BlockRealMatrix var57 = var5.multiply((org.apache.commons.math.linear.RealMatrix)var56);
    org.apache.commons.math.linear.BlockRealMatrix var58 = var57.copy();
    org.apache.commons.math.linear.RealMatrix var60 = var58.scalarMultiply(0.0d);
    double var61 = var58.getNorm();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var63 = var58.getRow(1);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var13.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var38.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var45.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 200.0d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
    java.lang.String var13 = var12.toString();
    org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
    boolean var15 = var14.isSingular();
    var14.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var20 = var5.subtract((org.apache.commons.math.linear.RealMatrix)var14);
    double[] var22 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var23 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var22);
    double[][] var24 = new double[][] { var22};
    double[][] var25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var24);
    org.apache.commons.math.linear.BlockRealMatrix var26 = new org.apache.commons.math.linear.BlockRealMatrix(var25);
    java.lang.String var27 = var26.toString();
    double[] var29 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var30 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var29);
    double[][] var31 = new double[][] { var29};
    double[][] var32 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var31);
    org.apache.commons.math.linear.BlockRealMatrix var33 = new org.apache.commons.math.linear.BlockRealMatrix(var32);
    java.lang.String var34 = var33.toString();
    org.apache.commons.math.linear.BlockRealMatrix var35 = var33.transpose();
    boolean var36 = var35.isSingular();
    var35.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var41 = var26.subtract((org.apache.commons.math.linear.RealMatrix)var35);
    org.apache.commons.math.linear.RealVector var43 = var41.getRowVector(0);
    boolean var44 = var41.isSquare();
    org.apache.commons.math.linear.BlockRealMatrix var45 = var14.add((org.apache.commons.math.linear.RealMatrix)var41);
    var41.luDecompose();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var13.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var27.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var34.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }


    java.lang.String[] var2 = new java.lang.String[] { "-1"};
    org.apache.commons.math.linear.BigMatrix var3 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var2);
    org.apache.commons.math.linear.BigMatrix var4 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var2);
    org.apache.commons.math.ode.events.EventException var5 = new org.apache.commons.math.ode.events.EventException("Array2DRowFieldMatrix{{-1}}", (java.lang.Object[])var2);
    org.apache.commons.math.linear.BigMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
    org.apache.commons.math.fraction.BigFraction var4 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var5 = var4.reciprocal();
    org.apache.commons.math.fraction.BigFraction var7 = var5.add((-1L));
    org.apache.commons.math.fraction.BigFractionField var8 = var7.getField();
    java.math.BigInteger var9 = var7.getNumerator();
    org.apache.commons.math.fraction.BigFraction var10 = var1.subtract(var9);
    org.apache.commons.math.fraction.BigFractionField var11 = var1.getField();
    org.apache.commons.math.fraction.BigFraction var12 = var11.getOne();
    org.apache.commons.math.fraction.BigFraction var13 = var11.getZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = var10.multiply(var21);
    org.apache.commons.math.fraction.BigFraction var26 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var27 = var26.reciprocal();
    org.apache.commons.math.FieldElement[] var28 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var28);
    org.apache.commons.math.FieldElement[][] var30 = new org.apache.commons.math.FieldElement[][] { var28};
    org.apache.commons.math.FieldElement[][] var31 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var30);
    java.lang.IllegalArgumentException var32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockFieldMatrix var33 = new org.apache.commons.math.linear.BlockFieldMatrix(var31);
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var38 = var37.reciprocal();
    org.apache.commons.math.FieldElement[] var39 = new org.apache.commons.math.FieldElement[] { var37};
    org.apache.commons.math.linear.FieldMatrix var40 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var39);
    org.apache.commons.math.FieldElement[][] var41 = new org.apache.commons.math.FieldElement[][] { var39};
    org.apache.commons.math.FieldElement[][] var42 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var41);
    java.lang.IllegalArgumentException var43 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var42);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = new org.apache.commons.math.linear.BlockFieldMatrix(var42);
    org.apache.commons.math.linear.BlockFieldMatrix var45 = var33.multiply(var44);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = var22.multiply(var33);
    org.apache.commons.math.fraction.BigFraction var49 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var50 = var49.reciprocal();
    org.apache.commons.math.FieldElement[] var51 = new org.apache.commons.math.FieldElement[] { var49};
    org.apache.commons.math.linear.FieldMatrix var52 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var51);
    org.apache.commons.math.FieldElement[][] var53 = new org.apache.commons.math.FieldElement[][] { var51};
    org.apache.commons.math.FieldElement[][] var54 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var53);
    org.apache.commons.math.linear.BlockFieldMatrix var55 = new org.apache.commons.math.linear.BlockFieldMatrix(var53);
    org.apache.commons.math.linear.FieldMatrix var56 = var22.subtract((org.apache.commons.math.linear.FieldMatrix)var55);
    org.apache.commons.math.FieldElement[][] var57 = var55.getData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(0L);
    double var2 = var1.doubleValue();
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract((-9L));
    double var6 = var1.pow(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var4 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var5 = var4.getNSteps();
    int var6 = var4.getNSteps();
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    org.apache.commons.math.FunctionEvaluationException var10 = new org.apache.commons.math.FunctionEvaluationException(var8);
    double[] var13 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var14 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var13);
    double[][] var15 = new double[][] { var13};
    double[][] var16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var15);
    java.lang.IllegalArgumentException var17 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var15);
    org.apache.commons.math.linear.Array2DRowRealMatrix var18 = var4.initializeHighOrderDerivatives(var8, var15);
    java.io.EOFException var19 = org.apache.commons.math.MathRuntimeException.createEOFException("BlockRealMatrix{{99.9}}", (java.lang.Object[])var15);
    org.apache.commons.math.ode.IntegratorException var20 = new org.apache.commons.math.ode.IntegratorException("BlockRealMatrix{{100.0}}", (java.lang.Object[])var15);
    org.apache.commons.math.ConvergenceException var21 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathRuntimeException$8: -2", (java.lang.Object[])var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }


    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((-1), 1);
    java.text.ParseException var5 = org.apache.commons.math.MathRuntimeException.createParseException(10, "org.apache.commons.math.MathRuntimeException$6: hi!", (java.lang.Object[])var4);
    org.apache.commons.math.linear.InvalidMatrixException var6 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var5);
    org.apache.commons.math.linear.InvalidMatrixException var7 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var6);
    java.lang.String var8 = var6.getPattern();
    java.lang.String var9 = var6.getPattern();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = var10.multiply(var21);
    org.apache.commons.math.fraction.BigFraction var26 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var27 = var26.reciprocal();
    org.apache.commons.math.FieldElement[] var28 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var28);
    org.apache.commons.math.FieldElement[][] var30 = new org.apache.commons.math.FieldElement[][] { var28};
    org.apache.commons.math.FieldElement[][] var31 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var30);
    java.lang.IllegalArgumentException var32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockFieldMatrix var33 = new org.apache.commons.math.linear.BlockFieldMatrix(var31);
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var38 = var37.reciprocal();
    org.apache.commons.math.FieldElement[] var39 = new org.apache.commons.math.FieldElement[] { var37};
    org.apache.commons.math.linear.FieldMatrix var40 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var39);
    org.apache.commons.math.FieldElement[][] var41 = new org.apache.commons.math.FieldElement[][] { var39};
    org.apache.commons.math.FieldElement[][] var42 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var41);
    java.lang.IllegalArgumentException var43 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var42);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = new org.apache.commons.math.linear.BlockFieldMatrix(var42);
    org.apache.commons.math.linear.BlockFieldMatrix var45 = var33.multiply(var44);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = var22.multiply(var33);
    org.apache.commons.math.fraction.BigFraction var49 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var50 = var49.reciprocal();
    org.apache.commons.math.FieldElement[] var51 = new org.apache.commons.math.FieldElement[] { var49};
    org.apache.commons.math.linear.FieldMatrix var52 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var51);
    org.apache.commons.math.FieldElement[] var53 = var22.preMultiply(var51);
    org.apache.commons.math.linear.FieldMatrix var54 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var53);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var55 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var53);
    org.apache.commons.math.linear.FieldMatrix var56 = var55.transpose();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix)var56, 0, 0, 1, 2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }


    java.lang.String[] var1 = new java.lang.String[] { "-1"};
    org.apache.commons.math.linear.BigMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var1);
    java.lang.String[][] var3 = new java.lang.String[][] { var1};
    org.apache.commons.math.linear.BigMatrix var4 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var3);
    org.apache.commons.math.linear.BigMatrix var5 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var3);
    org.apache.commons.math.linear.BigMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var3);
    org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }


    java.lang.Throwable var1 = null;
    org.apache.commons.math.linear.InvalidMatrixException var2 = new org.apache.commons.math.linear.InvalidMatrixException(var1);
    double[] var6 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var6);
    double[][] var8 = new double[][] { var6};
    double[][] var9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var8);
    org.apache.commons.math.linear.BlockRealMatrix var10 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    org.apache.commons.math.linear.BigMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var9);
    java.lang.IllegalArgumentException var12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var9);
    org.apache.commons.math.MathException var13 = new org.apache.commons.math.MathException(var1, "BlockRealMatrix{{10.0}}", (java.lang.Object[])var9);
    org.apache.commons.math.linear.MatrixIndexException var14 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var9);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9);
    org.apache.commons.math.linear.Array2DRowRealMatrix var17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9, true);
    org.apache.commons.math.linear.RealMatrix var19 = var17.scalarAdd(10.9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }


    org.apache.commons.math.MaxEvaluationsExceededException var1 = new org.apache.commons.math.MaxEvaluationsExceededException(10);
    java.io.IOException var2 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var1);
    org.apache.commons.math.fraction.BigFraction var6 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var7 = var6.reciprocal();
    org.apache.commons.math.FieldElement[] var8 = new org.apache.commons.math.FieldElement[] { var6};
    org.apache.commons.math.linear.FieldMatrix var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var8);
    org.apache.commons.math.FieldElement[][] var10 = new org.apache.commons.math.FieldElement[][] { var8};
    org.apache.commons.math.FieldElement[][] var11 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var10);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var12 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var11);
    org.apache.commons.math.MathException var13 = new org.apache.commons.math.MathException((java.lang.Throwable)var1, "0", (java.lang.Object[])var11);
    org.apache.commons.math.linear.BlockFieldMatrix var14 = new org.apache.commons.math.linear.BlockFieldMatrix(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var17 = var14.getEntry(100, 0);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    java.lang.Throwable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var10 = new org.apache.commons.math.ConvergenceException(var6, "", var9);
    org.apache.commons.math.MaxEvaluationsExceededException var11 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", var9);
    double[] var14 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var15 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var14);
    double[][] var16 = new double[][] { var14};
    double[][] var17 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var16);
    org.apache.commons.math.MathRuntimeException var18 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var11, "hi!", (java.lang.Object[])var17);
    org.apache.commons.math.ode.IntegratorException var19 = new org.apache.commons.math.ode.IntegratorException("BlockRealMatrix{{10.0}}", (java.lang.Object[])var17);
    org.apache.commons.math.MathRuntimeException var20 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var17);
    org.apache.commons.math.MathRuntimeException var21 = new org.apache.commons.math.MathRuntimeException("Dormand-Prince 8 (5, 3)", (java.lang.Object[])var17);
    org.apache.commons.math.ode.IntegratorException var22 = new org.apache.commons.math.ode.IntegratorException("org.apache.commons.math.MaxIterationsExceededException: -1", (java.lang.Object[])var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    org.apache.commons.math.ode.events.EventHandler var0 = null;
    org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 0.0d, (-800.0d), 10);
    double[] var7 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var8 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var7);
    double[][] var9 = new double[][] { var7};
    double[][] var10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var9);
    org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var10);
    java.lang.String var12 = var11.toString();
    double[] var14 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var15 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var14);
    double[][] var16 = new double[][] { var14};
    double[][] var17 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var16);
    org.apache.commons.math.linear.BlockRealMatrix var18 = new org.apache.commons.math.linear.BlockRealMatrix(var17);
    java.lang.String var19 = var18.toString();
    org.apache.commons.math.linear.BlockRealMatrix var20 = var18.transpose();
    boolean var21 = var20.isSingular();
    var20.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var26 = var11.subtract((org.apache.commons.math.linear.RealMatrix)var20);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var28 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var29 = var28.getNSteps();
    double[] var31 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var32 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var31);
    org.apache.commons.math.FunctionEvaluationException var33 = new org.apache.commons.math.FunctionEvaluationException(var31);
    double[] var35 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var36 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var35);
    org.apache.commons.math.FunctionEvaluationException var37 = new org.apache.commons.math.FunctionEvaluationException(var35);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var39 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var40 = var39.getNSteps();
    int var41 = var39.getNSteps();
    double[] var43 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var43);
    org.apache.commons.math.FunctionEvaluationException var45 = new org.apache.commons.math.FunctionEvaluationException(var43);
    double[] var48 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var49 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var48);
    double[][] var50 = new double[][] { var48};
    double[][] var51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var50);
    java.lang.IllegalArgumentException var52 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var50);
    org.apache.commons.math.linear.Array2DRowRealMatrix var53 = var39.initializeHighOrderDerivatives(var43, var50);
    var28.updateHighOrderDerivativesPhase2(var31, var35, var53);
    double[] var55 = var20.preMultiply(var31);
    boolean var56 = var4.reset((-2.0d), var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var12.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var19.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    double var1 = var0.getFunctionValueAccuracy();
    int var2 = var0.getIterationCount();
    int var3 = var0.getMaximalIterationCount();
    double var4 = var0.getFunctionValueAccuracy();
    var0.resetRelativeAccuracy();
    var0.setFunctionValueAccuracy(20.0d);
    var0.resetFunctionValueAccuracy();
    var0.setMaximalIterationCount(1);
    int var11 = var0.getIterationCount();
    var0.setFunctionValueAccuracy((-800.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }


    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var1 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var2 = var1.getNSteps();
    int var3 = var1.getNSteps();
    double[] var5 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var5);
    org.apache.commons.math.FunctionEvaluationException var7 = new org.apache.commons.math.FunctionEvaluationException(var5);
    double[] var10 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var10);
    double[][] var12 = new double[][] { var10};
    double[][] var13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var12);
    java.lang.IllegalArgumentException var14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var12);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = var1.initializeHighOrderDerivatives(var5, var12);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var17 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var18 = var17.getNSteps();
    int var19 = var17.getNSteps();
    double[] var21 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var21);
    org.apache.commons.math.FunctionEvaluationException var23 = new org.apache.commons.math.FunctionEvaluationException(var21);
    double[] var26 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
    double[][] var28 = new double[][] { var26};
    double[][] var29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var28);
    java.lang.IllegalArgumentException var30 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var28);
    org.apache.commons.math.linear.Array2DRowRealMatrix var31 = var17.initializeHighOrderDerivatives(var21, var28);
    org.apache.commons.math.linear.Array2DRowRealMatrix var32 = var1.updateHighOrderDerivativesPhase1(var31);
    double[] var34 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var37 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var34, false);
    var37.setInterpolatedTime(0.0d);
    boolean var40 = var32.equals((java.lang.Object)var37);
    org.apache.commons.math.fraction.FractionConversionException var44 = new org.apache.commons.math.fraction.FractionConversionException(0.0d, 0L, 10L);
    java.lang.Object[] var47 = null;
    org.apache.commons.math.FunctionEvaluationException var48 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var44, 0.0d, "", var47);
    double[] var49 = var48.getArgument();
    org.apache.commons.math.linear.BigMatrix var50 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var49);
    double[][] var51 = new double[][] { var49};
    org.apache.commons.math.linear.Array2DRowRealMatrix var52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var51);
    org.apache.commons.math.linear.Array2DRowRealMatrix var53 = var32.subtract(var52);
    double[][] var54 = var53.getDataRef();
    org.apache.commons.math.linear.RealMatrix var55 = var53.copy();
    double[] var57 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var58 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var57);
    double[][] var59 = new double[][] { var57};
    double[][] var60 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var59);
    org.apache.commons.math.linear.BlockRealMatrix var61 = new org.apache.commons.math.linear.BlockRealMatrix(var60);
    java.lang.String var62 = var61.toString();
    double[] var64 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var65 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var64);
    double[][] var66 = new double[][] { var64};
    double[][] var67 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var66);
    org.apache.commons.math.linear.BlockRealMatrix var68 = new org.apache.commons.math.linear.BlockRealMatrix(var67);
    java.lang.String var69 = var68.toString();
    org.apache.commons.math.linear.BlockRealMatrix var70 = var68.transpose();
    boolean var71 = var70.isSingular();
    var70.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var76 = var61.subtract((org.apache.commons.math.linear.RealMatrix)var70);
    double var77 = var70.getDeterminant();
    double var78 = var70.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var80 = var70.scalarMultiply((-1.0d));
    double var81 = var70.getNorm();
    double[] var83 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var84 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var83);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var86 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var83, false);
    double[] var87 = var70.operate(var83);
    org.apache.commons.math.linear.BigMatrix var88 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var83);
    double[] var89 = var53.operate(var83);
    double[][] var90 = var53.getDataRef();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var53.multiplyEntry(0, 8, 900.0d);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var62.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var69.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    org.apache.commons.math.linear.BlockRealMatrix var7 = var5.transpose();
    boolean var8 = var7.isSingular();
    var7.setEntry(0, 0, 10.0d);
    java.lang.Throwable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var20 = new org.apache.commons.math.ConvergenceException(var16, "", var19);
    org.apache.commons.math.MaxEvaluationsExceededException var21 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var19);
    java.lang.IllegalStateException var22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var19);
    org.apache.commons.math.ode.IntegratorException var23 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var22);
    boolean var24 = var7.equals((java.lang.Object)var23);
    double[] var26 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
    double[][] var28 = new double[][] { var26};
    double[][] var29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var28);
    org.apache.commons.math.linear.BlockRealMatrix var30 = new org.apache.commons.math.linear.BlockRealMatrix(var29);
    java.lang.String var31 = var30.toString();
    double[] var33 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var34 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var33);
    double[][] var35 = new double[][] { var33};
    double[][] var36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var35);
    org.apache.commons.math.linear.BlockRealMatrix var37 = new org.apache.commons.math.linear.BlockRealMatrix(var36);
    java.lang.String var38 = var37.toString();
    org.apache.commons.math.linear.BlockRealMatrix var39 = var37.transpose();
    boolean var40 = var39.isSingular();
    var39.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var45 = var30.subtract((org.apache.commons.math.linear.RealMatrix)var39);
    org.apache.commons.math.linear.RealMatrix var47 = var30.scalarMultiply(10.0d);
    double var48 = var30.getNorm();
    org.apache.commons.math.linear.BlockRealMatrix var49 = var7.add(var30);
    java.math.BigDecimal var50 = null;
    java.math.BigDecimal[] var51 = new java.math.BigDecimal[] { var50};
    org.apache.commons.math.linear.BigMatrix var52 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var51);
    java.math.BigDecimal[][] var53 = new java.math.BigDecimal[][] { var51};
    org.apache.commons.math.linear.BigMatrix var55 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var53, true);
    org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix)var7, (org.apache.commons.math.linear.AnyMatrix)var55);
    double var57 = var7.getFrobeniusNorm();
    java.lang.Object var58 = null;
    boolean var59 = var7.equals(var58);
    org.apache.commons.math.linear.BlockRealMatrix var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRowMatrix((-110), var61);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var31.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var38.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }
// 
// 
//     double[] var1 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
//     double[][] var3 = new double[][] { var1};
//     double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
//     org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
//     java.lang.String var6 = var5.toString();
//     org.apache.commons.math.linear.BlockRealMatrix var7 = var5.transpose();
//     org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var10 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
//     int var11 = var10.getNSteps();
//     int var12 = var10.getNSteps();
//     double[] var14 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var15 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var14);
//     org.apache.commons.math.FunctionEvaluationException var16 = new org.apache.commons.math.FunctionEvaluationException(var14);
//     double[] var19 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var20 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var19);
//     double[][] var21 = new double[][] { var19};
//     double[][] var22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var21);
//     java.lang.IllegalArgumentException var23 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var21);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var24 = var10.initializeHighOrderDerivatives(var14, var21);
//     org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var26 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
//     int var27 = var26.getNSteps();
//     int var28 = var26.getNSteps();
//     double[] var30 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var31 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var30);
//     org.apache.commons.math.FunctionEvaluationException var32 = new org.apache.commons.math.FunctionEvaluationException(var30);
//     double[] var35 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var36 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var35);
//     double[][] var37 = new double[][] { var35};
//     double[][] var38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var37);
//     java.lang.IllegalArgumentException var39 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var37);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var40 = var26.initializeHighOrderDerivatives(var30, var37);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var41 = var10.updateHighOrderDerivativesPhase1(var40);
//     double[] var43 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var43);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var46 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var43, false);
//     var46.setInterpolatedTime(0.0d);
//     boolean var49 = var41.equals((java.lang.Object)var46);
//     var7.setRowMatrix(0, (org.apache.commons.math.linear.RealMatrix)var41);
//     double[] var53 = new double[] { 100.0d};
//     org.apache.commons.math.linear.BigMatrix var54 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var53);
//     var41.setColumn(0, var53);
//     int var56 = var41.getColumnDimension();
//     double[][] var57 = var41.getData();
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var58 = null;
//     double var59 = var41.walkInColumnOrder(var58);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var2};
    org.apache.commons.math.linear.FieldMatrix var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.FieldElement[][] var7 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var6);
    org.apache.commons.math.linear.BlockFieldMatrix var8 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    java.lang.String var9 = var8.toString();
    org.apache.commons.math.linear.FieldMatrix var10 = var8.transpose();
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.fraction.BigFraction var25 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var26 = var25.reciprocal();
    org.apache.commons.math.FieldElement[] var27 = new org.apache.commons.math.FieldElement[] { var25};
    org.apache.commons.math.linear.FieldMatrix var28 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var27);
    org.apache.commons.math.FieldElement[][] var29 = new org.apache.commons.math.FieldElement[][] { var27};
    org.apache.commons.math.FieldElement[][] var30 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var29);
    java.lang.IllegalArgumentException var31 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var30);
    org.apache.commons.math.linear.BlockFieldMatrix var32 = new org.apache.commons.math.linear.BlockFieldMatrix(var30);
    org.apache.commons.math.linear.BlockFieldMatrix var33 = var21.multiply(var32);
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var38 = var37.reciprocal();
    org.apache.commons.math.FieldElement[] var39 = new org.apache.commons.math.FieldElement[] { var37};
    org.apache.commons.math.linear.FieldMatrix var40 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var39);
    org.apache.commons.math.FieldElement[][] var41 = new org.apache.commons.math.FieldElement[][] { var39};
    org.apache.commons.math.FieldElement[][] var42 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var41);
    java.lang.IllegalArgumentException var43 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var42);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = new org.apache.commons.math.linear.BlockFieldMatrix(var42);
    org.apache.commons.math.fraction.BigFraction var48 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var49 = var48.reciprocal();
    org.apache.commons.math.FieldElement[] var50 = new org.apache.commons.math.FieldElement[] { var48};
    org.apache.commons.math.linear.FieldMatrix var51 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var50);
    org.apache.commons.math.FieldElement[][] var52 = new org.apache.commons.math.FieldElement[][] { var50};
    org.apache.commons.math.FieldElement[][] var53 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var52);
    java.lang.IllegalArgumentException var54 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var53);
    org.apache.commons.math.linear.BlockFieldMatrix var55 = new org.apache.commons.math.linear.BlockFieldMatrix(var53);
    org.apache.commons.math.linear.BlockFieldMatrix var56 = var44.multiply(var55);
    org.apache.commons.math.linear.BlockFieldMatrix var57 = var33.multiply(var44);
    org.apache.commons.math.linear.FieldMatrix var58 = var8.preMultiply((org.apache.commons.math.linear.FieldMatrix)var57);
    org.apache.commons.math.linear.FieldMatrix var59 = var8.transpose();
    org.apache.commons.math.linear.FieldMatrix var60 = var8.transpose();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldVector var62 = var8.getColumnVector((-1));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "BlockFieldMatrix{{-1}}"+ "'", var9.equals("BlockFieldMatrix{{-1}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var3 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var5 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var5);
//     double[][] var7 = new double[][] { var5};
//     double[][] var8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var7);
//     org.apache.commons.math.linear.BlockRealMatrix var9 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
//     java.lang.String var10 = var9.toString();
//     org.apache.commons.math.linear.BlockRealMatrix var11 = var9.transpose();
//     double[] var13 = new double[] { 100.0d};
//     org.apache.commons.math.linear.BigMatrix var14 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var13);
//     double[] var15 = var11.preMultiply(var13);
//     var3.reinitialize(var15, false);
//     double[] var22 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var23 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var22);
//     org.apache.commons.math.linear.RealVector var24 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var22);
//     double[] var26 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var29 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var26, false);
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var30 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.0d, 10.0d, var22, var26);
//     var30.setMinReduction(1.0d);
//     org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var34 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
//     int var35 = var34.getNSteps();
//     int var36 = var34.getNSteps();
//     double[] var38 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var39 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var38);
//     org.apache.commons.math.FunctionEvaluationException var40 = new org.apache.commons.math.FunctionEvaluationException(var38);
//     double[] var43 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var43);
//     double[][] var45 = new double[][] { var43};
//     double[][] var46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var45);
//     java.lang.IllegalArgumentException var47 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var45);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var48 = var34.initializeHighOrderDerivatives(var38, var45);
//     org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var50 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
//     int var51 = var50.getNSteps();
//     int var52 = var50.getNSteps();
//     double[] var54 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var55 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var54);
//     org.apache.commons.math.FunctionEvaluationException var56 = new org.apache.commons.math.FunctionEvaluationException(var54);
//     double[] var59 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var60 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var59);
//     double[][] var61 = new double[][] { var59};
//     double[][] var62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var61);
//     java.lang.IllegalArgumentException var63 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var61);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var64 = var50.initializeHighOrderDerivatives(var54, var61);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var65 = var34.updateHighOrderDerivativesPhase1(var64);
//     double[] var67 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var68 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var67);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var70 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var67, false);
//     var70.setInterpolatedTime(0.0d);
//     boolean var73 = var65.equals((java.lang.Object)var70);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var74 = var30.updateHighOrderDerivativesPhase1(var65);
//     var0.reinitialize(100.0d, 0.0d, var15, var74);
//     double[] var77 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var78 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var77);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var80 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var77, false);
//     org.apache.commons.math.linear.RealMatrix var81 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var77);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var82 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var77);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var83 = var74.add(var82);
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var84 = null;
//     double var85 = var82.walkInColumnOrder(var84);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.resetRelativeAccuracy();
    var0.resetAbsoluteAccuracy();
    double var3 = var0.getFunctionValueAccuracy();
    var0.setAbsoluteAccuracy((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-15d);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }
// 
// 
//     org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var6 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var7 = var6.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var8 = var2.subtract(var6);
//     org.apache.commons.math.fraction.BigFraction var11 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var15 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var16 = var15.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var17 = var11.subtract(var15);
//     org.apache.commons.math.fraction.BigFraction var18 = var2.subtract(var15);
//     org.apache.commons.math.fraction.BigFraction var20 = var2.subtract(8);
//     java.math.BigDecimal var21 = var20.bigDecimalValue();
//     long var22 = var20.longValue();
//     org.apache.commons.math.fraction.BigFraction var23 = null;
//     org.apache.commons.math.fraction.BigFraction var24 = var20.subtract(var23);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    org.apache.commons.math.linear.BlockRealMatrix var7 = var5.transpose();
    boolean var8 = var7.isSingular();
    var7.setEntry(0, 0, 10.0d);
    java.lang.Throwable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var20 = new org.apache.commons.math.ConvergenceException(var16, "", var19);
    org.apache.commons.math.MaxEvaluationsExceededException var21 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var19);
    java.lang.IllegalStateException var22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var19);
    org.apache.commons.math.ode.IntegratorException var23 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var22);
    boolean var24 = var7.equals((java.lang.Object)var23);
    double[] var26 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
    double[][] var28 = new double[][] { var26};
    double[][] var29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var28);
    org.apache.commons.math.linear.BlockRealMatrix var30 = new org.apache.commons.math.linear.BlockRealMatrix(var29);
    java.lang.String var31 = var30.toString();
    double[] var33 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var34 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var33);
    double[][] var35 = new double[][] { var33};
    double[][] var36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var35);
    org.apache.commons.math.linear.BlockRealMatrix var37 = new org.apache.commons.math.linear.BlockRealMatrix(var36);
    java.lang.String var38 = var37.toString();
    org.apache.commons.math.linear.BlockRealMatrix var39 = var37.transpose();
    boolean var40 = var39.isSingular();
    var39.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var45 = var30.subtract((org.apache.commons.math.linear.RealMatrix)var39);
    org.apache.commons.math.linear.RealMatrix var47 = var30.scalarMultiply(10.0d);
    double var48 = var30.getNorm();
    org.apache.commons.math.linear.BlockRealMatrix var49 = var7.add(var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setEntry((-2), (-2), (-200.0d));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var31.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var38.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    double var1 = var0.getFunctionValueAccuracy();
    int var2 = var0.getIterationCount();
    int var3 = var0.getMaximalIterationCount();
    double var4 = var0.getFunctionValueAccuracy();
    var0.resetRelativeAccuracy();
    var0.setFunctionValueAccuracy(20.0d);
    var0.resetFunctionValueAccuracy();
    var0.resetMaximalIterationCount();
    var0.setRelativeAccuracy((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0E-15d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }


    org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    var0.clearEventsHandlers();
    boolean var2 = var0.stop();
    org.apache.commons.math.ode.events.EventHandler var3 = null;
    var0.addEventHandler(var3, Double.POSITIVE_INFINITY, 20.0d, 10);
    boolean var8 = var0.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.FieldElement[][] var6 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var3, (-1), 8);
    org.apache.commons.math.linear.BlockFieldMatrix var9 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var3, 100, 1);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var22 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var21);
    var9.setRowMatrix(10, (org.apache.commons.math.linear.FieldMatrix)var21);
    org.apache.commons.math.linear.FieldMatrix var24 = var21.transpose();
    org.apache.commons.math.FieldElement[][] var25 = var21.getData();
    org.apache.commons.math.FieldElement[][] var26 = var21.getData();
    int var27 = var21.getColumnDimension();
    org.apache.commons.math.fraction.BigFraction var30 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var31 = var30.reciprocal();
    org.apache.commons.math.fraction.BigFraction var34 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var35 = var34.reciprocal();
    org.apache.commons.math.fraction.BigFraction var36 = var30.subtract(var34);
    org.apache.commons.math.fraction.BigFraction var37 = var34.reduce();
    boolean var39 = var34.equals((java.lang.Object)100L);
    java.math.BigDecimal var40 = var34.bigDecimalValue();
    org.apache.commons.math.fraction.BigFraction var43 = new org.apache.commons.math.fraction.BigFraction(0, (-1));
    org.apache.commons.math.fraction.BigFraction var45 = new org.apache.commons.math.fraction.BigFraction((-1.0d));
    java.math.BigDecimal var46 = var45.bigDecimalValue();
    org.apache.commons.math.fraction.BigFraction var47 = var43.subtract(var45);
    java.math.BigInteger var48 = var47.getNumerator();
    org.apache.commons.math.fraction.BigFraction var49 = var34.divide(var48);
    long var50 = var34.getDenominatorAsLong();
    org.apache.commons.math.linear.FieldMatrix var51 = var21.scalarAdd((org.apache.commons.math.FieldElement)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
    java.lang.String var13 = var12.toString();
    org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
    boolean var15 = var14.isSingular();
    var14.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var20 = var5.subtract((org.apache.commons.math.linear.RealMatrix)var14);
    double var21 = var14.getDeterminant();
    double var22 = var14.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var24 = var14.scalarMultiply((-1.0d));
    double var25 = var14.getNorm();
    double[] var28 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var29 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    org.apache.commons.math.linear.BlockRealMatrix var32 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
    java.lang.String var33 = var32.toString();
    double[] var35 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var36 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var35);
    double[][] var37 = new double[][] { var35};
    double[][] var38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var37);
    org.apache.commons.math.linear.BlockRealMatrix var39 = new org.apache.commons.math.linear.BlockRealMatrix(var38);
    java.lang.String var40 = var39.toString();
    org.apache.commons.math.linear.BlockRealMatrix var41 = var39.transpose();
    boolean var42 = var41.isSingular();
    var41.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var47 = var32.subtract((org.apache.commons.math.linear.RealMatrix)var41);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var49 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var50 = var49.getNSteps();
    double[] var52 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var53 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var52);
    org.apache.commons.math.FunctionEvaluationException var54 = new org.apache.commons.math.FunctionEvaluationException(var52);
    double[] var56 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var57 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var56);
    org.apache.commons.math.FunctionEvaluationException var58 = new org.apache.commons.math.FunctionEvaluationException(var56);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var60 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var61 = var60.getNSteps();
    int var62 = var60.getNSteps();
    double[] var64 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var65 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var64);
    org.apache.commons.math.FunctionEvaluationException var66 = new org.apache.commons.math.FunctionEvaluationException(var64);
    double[] var69 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var70 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var69);
    double[][] var71 = new double[][] { var69};
    double[][] var72 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var71);
    java.lang.IllegalArgumentException var73 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var71);
    org.apache.commons.math.linear.Array2DRowRealMatrix var74 = var60.initializeHighOrderDerivatives(var64, var71);
    var49.updateHighOrderDerivativesPhase2(var52, var56, var74);
    double[] var76 = var41.preMultiply(var52);
    var14.setRow(0, var52);
    double var78 = var14.getFrobeniusNorm();
    double[] var80 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var81 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var80);
    double[][] var82 = new double[][] { var80};
    double[][] var83 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var82);
    org.apache.commons.math.linear.BlockRealMatrix var84 = new org.apache.commons.math.linear.BlockRealMatrix(var83);
    double[] var86 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var87 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var86);
    double[][] var88 = new double[][] { var86};
    double[][] var89 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var88);
    org.apache.commons.math.linear.BlockRealMatrix var90 = new org.apache.commons.math.linear.BlockRealMatrix(var89);
    java.lang.String var91 = var90.toString();
    org.apache.commons.math.linear.BlockRealMatrix var92 = var90.transpose();
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var84, (org.apache.commons.math.linear.AnyMatrix)var90);
    org.apache.commons.math.linear.BlockRealMatrix var94 = var14.add((org.apache.commons.math.linear.RealMatrix)var90);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.BlockRealMatrix var99 = var14.getSubMatrix(10, (-110), 10, 8);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var13.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var33.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var40.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var91 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var91.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }
// 
// 
//     org.apache.commons.math.ode.events.EventHandler var0 = null;
//     org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 1.0d, (-900.0d), 0);
//     double var5 = var4.getMaxCheckInterval();
//     double var6 = var4.getEventTime();
//     double var7 = var4.getEventTime();
//     boolean var8 = var4.stop();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }


    org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    java.util.Collection var1 = var0.getEventsHandlers();
    java.lang.Throwable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var10 = new org.apache.commons.math.ConvergenceException(var6, "", var9);
    org.apache.commons.math.MaxEvaluationsExceededException var11 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var9);
    java.lang.IllegalStateException var12 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var9);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var17 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var18 = var17.getNSteps();
    double[] var20 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var21 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var20);
    org.apache.commons.math.FunctionEvaluationException var22 = new org.apache.commons.math.FunctionEvaluationException(var20);
    double[] var24 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var25 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var24);
    org.apache.commons.math.FunctionEvaluationException var26 = new org.apache.commons.math.FunctionEvaluationException(var24);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var28 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var29 = var28.getNSteps();
    int var30 = var28.getNSteps();
    double[] var32 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var33 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var32);
    org.apache.commons.math.FunctionEvaluationException var34 = new org.apache.commons.math.FunctionEvaluationException(var32);
    double[] var37 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var38 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var37);
    double[][] var39 = new double[][] { var37};
    double[][] var40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var39);
    java.lang.IllegalArgumentException var41 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var39);
    org.apache.commons.math.linear.Array2DRowRealMatrix var42 = var28.initializeHighOrderDerivatives(var32, var39);
    var17.updateHighOrderDerivativesPhase2(var20, var24, var42);
    org.apache.commons.math.linear.BigMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var20);
    java.lang.Throwable var45 = null;
    double[] var47 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var48 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var47);
    org.apache.commons.math.linear.RealVector var49 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var47);
    org.apache.commons.math.FunctionEvaluationException var50 = new org.apache.commons.math.FunctionEvaluationException(var45, var47);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var51 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.4142135623730951d, var20, var47);
    org.apache.commons.math.FunctionEvaluationException var52 = new org.apache.commons.math.FunctionEvaluationException(var47);
    org.apache.commons.math.FunctionEvaluationException var53 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var12, var47);
    var0.stepAccepted(0.2d, var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var6 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var7 = var6.reciprocal();
    org.apache.commons.math.fraction.BigFraction var8 = var2.subtract(var6);
    java.math.BigDecimal var9 = var8.bigDecimalValue();
    org.apache.commons.math.fraction.BigFraction var11 = var8.subtract((-8L));
    org.apache.commons.math.fraction.BigFraction var13 = var11.add(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFraction var5 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var6 = var5.reciprocal();
    org.apache.commons.math.fraction.BigFraction var9 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var10 = var9.reciprocal();
    org.apache.commons.math.fraction.BigFraction var11 = var5.subtract(var9);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.fraction.BigFraction var18 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var19 = var18.reciprocal();
    org.apache.commons.math.fraction.BigFraction var20 = var14.subtract(var18);
    org.apache.commons.math.fraction.BigFraction var21 = var5.subtract(var18);
    org.apache.commons.math.fraction.BigFraction var23 = var5.subtract((-1));
    org.apache.commons.math.fraction.BigFraction var26 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var27 = var26.reciprocal();
    org.apache.commons.math.fraction.BigFraction var30 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var31 = var30.reciprocal();
    org.apache.commons.math.fraction.BigFraction var32 = var26.subtract(var30);
    org.apache.commons.math.fraction.BigFraction var35 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var36 = var35.reciprocal();
    org.apache.commons.math.fraction.BigFraction var39 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var40 = var39.reciprocal();
    org.apache.commons.math.fraction.BigFraction var41 = var35.subtract(var39);
    org.apache.commons.math.fraction.BigFraction var42 = var26.subtract(var39);
    java.math.BigInteger var43 = var42.getDenominator();
    org.apache.commons.math.fraction.BigFraction var44 = var5.pow(var43);
    org.apache.commons.math.fraction.BigFraction var45 = var2.subtract(var43);
    int var46 = var2.getNumeratorAsInt();
    org.apache.commons.math.fraction.BigFraction var48 = var2.add((-9L));
    java.math.BigDecimal var49 = var2.bigDecimalValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }


    double[] var4 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var5 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var4);
    org.apache.commons.math.linear.RealVector var6 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var4);
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var8, false);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var12 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.0d, 10.0d, var4, var8);
    double var13 = var12.getSafety();
    var12.clearEventHandlers();
    java.lang.String var15 = var12.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Adams-Moulton"+ "'", var15.equals("Adams-Moulton"));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.linear.FieldMatrix var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var3, 1);
    org.apache.commons.math.fraction.BigFraction var6 = var3.getZero();
    org.apache.commons.math.fraction.BigFraction var7 = var3.getOne();
    org.apache.commons.math.fraction.BigFraction var8 = var3.getZero();
    org.apache.commons.math.fraction.BigFraction var9 = var3.getZero();
    org.apache.commons.math.fraction.BigFraction var10 = var9.reduce();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.linear.FieldMatrix var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var3, 1);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var6 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    org.apache.commons.math.fraction.BigFraction var5 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var6 = var5.reciprocal();
    org.apache.commons.math.FieldElement[] var7 = new org.apache.commons.math.FieldElement[] { var5};
    org.apache.commons.math.linear.FieldMatrix var8 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var7);
    org.apache.commons.math.FieldElement[][] var9 = new org.apache.commons.math.FieldElement[][] { var7};
    org.apache.commons.math.FieldElement[][] var10 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var9);
    java.lang.IllegalArgumentException var11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var10);
    org.apache.commons.math.linear.BlockFieldMatrix var12 = new org.apache.commons.math.linear.BlockFieldMatrix(var10);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var17 = var16.reciprocal();
    org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var16};
    org.apache.commons.math.linear.FieldMatrix var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var18);
    org.apache.commons.math.FieldElement[][] var20 = new org.apache.commons.math.FieldElement[][] { var18};
    org.apache.commons.math.FieldElement[][] var21 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var20);
    java.lang.IllegalArgumentException var22 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var21);
    org.apache.commons.math.linear.BlockFieldMatrix var23 = new org.apache.commons.math.linear.BlockFieldMatrix(var21);
    org.apache.commons.math.linear.BlockFieldMatrix var24 = var12.multiply(var23);
    org.apache.commons.math.fraction.BigFraction var28 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var29 = var28.reciprocal();
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var28};
    org.apache.commons.math.linear.FieldMatrix var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var30);
    org.apache.commons.math.FieldElement[][] var32 = new org.apache.commons.math.FieldElement[][] { var30};
    org.apache.commons.math.FieldElement[][] var33 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var32);
    java.lang.IllegalArgumentException var34 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var33);
    org.apache.commons.math.linear.BlockFieldMatrix var35 = new org.apache.commons.math.linear.BlockFieldMatrix(var33);
    org.apache.commons.math.fraction.BigFraction var39 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var40 = var39.reciprocal();
    org.apache.commons.math.FieldElement[] var41 = new org.apache.commons.math.FieldElement[] { var39};
    org.apache.commons.math.linear.FieldMatrix var42 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var41);
    org.apache.commons.math.FieldElement[][] var43 = new org.apache.commons.math.FieldElement[][] { var41};
    org.apache.commons.math.FieldElement[][] var44 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var43);
    java.lang.IllegalArgumentException var45 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var44);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = new org.apache.commons.math.linear.BlockFieldMatrix(var44);
    org.apache.commons.math.linear.BlockFieldMatrix var47 = var35.multiply(var46);
    org.apache.commons.math.linear.BlockFieldMatrix var48 = var24.multiply(var35);
    org.apache.commons.math.fraction.BigFraction var51 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var52 = var51.reciprocal();
    org.apache.commons.math.FieldElement[] var53 = new org.apache.commons.math.FieldElement[] { var51};
    org.apache.commons.math.linear.FieldMatrix var54 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var53);
    org.apache.commons.math.FieldElement[] var55 = var24.preMultiply(var53);
    org.apache.commons.math.linear.FieldMatrix var56 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var55);
    org.apache.commons.math.MathException var57 = new org.apache.commons.math.MathException("Adams-Moulton", (java.lang.Object[])var55);
    java.util.NoSuchElementException var58 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", (java.lang.Object[])var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 10.0d, 100.0d, 100.0d);
    var4.clearEventHandlers();
    int var6 = var4.getOrder();
    var4.setMaxGrowth(1.0d);
    org.apache.commons.math.ode.sampling.StepHandler var9 = null;
    var4.addStepHandler(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }


    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var3 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    double[] var5 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var5);
    double[][] var7 = new double[][] { var5};
    double[][] var8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var7);
    org.apache.commons.math.linear.BlockRealMatrix var9 = new org.apache.commons.math.linear.BlockRealMatrix(var8);
    java.lang.String var10 = var9.toString();
    org.apache.commons.math.linear.BlockRealMatrix var11 = var9.transpose();
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math.linear.BigMatrix var14 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var13);
    double[] var15 = var11.preMultiply(var13);
    var3.reinitialize(var15, false);
    double[] var22 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var23 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var22);
    org.apache.commons.math.linear.RealVector var24 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var22);
    double[] var26 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var29 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var26, false);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var30 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.0d, 10.0d, var22, var26);
    var30.setMinReduction(1.0d);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var34 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var35 = var34.getNSteps();
    int var36 = var34.getNSteps();
    double[] var38 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var39 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var38);
    org.apache.commons.math.FunctionEvaluationException var40 = new org.apache.commons.math.FunctionEvaluationException(var38);
    double[] var43 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var43);
    double[][] var45 = new double[][] { var43};
    double[][] var46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var45);
    java.lang.IllegalArgumentException var47 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var45);
    org.apache.commons.math.linear.Array2DRowRealMatrix var48 = var34.initializeHighOrderDerivatives(var38, var45);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var50 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var51 = var50.getNSteps();
    int var52 = var50.getNSteps();
    double[] var54 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var55 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var54);
    org.apache.commons.math.FunctionEvaluationException var56 = new org.apache.commons.math.FunctionEvaluationException(var54);
    double[] var59 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var60 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var59);
    double[][] var61 = new double[][] { var59};
    double[][] var62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var61);
    java.lang.IllegalArgumentException var63 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var61);
    org.apache.commons.math.linear.Array2DRowRealMatrix var64 = var50.initializeHighOrderDerivatives(var54, var61);
    org.apache.commons.math.linear.Array2DRowRealMatrix var65 = var34.updateHighOrderDerivativesPhase1(var64);
    double[] var67 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var68 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var67);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var70 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var67, false);
    var70.setInterpolatedTime(0.0d);
    boolean var73 = var65.equals((java.lang.Object)var70);
    org.apache.commons.math.linear.Array2DRowRealMatrix var74 = var30.updateHighOrderDerivativesPhase1(var65);
    var0.reinitialize(100.0d, 0.0d, var15, var74);
    double[] var77 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var78 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var77);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var80 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var77, false);
    org.apache.commons.math.linear.RealMatrix var81 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var77);
    org.apache.commons.math.linear.Array2DRowRealMatrix var82 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var77);
    org.apache.commons.math.linear.Array2DRowRealMatrix var83 = var74.add(var82);
    double[] var86 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var87 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var86);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var89 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var86, false);
    org.apache.commons.math.linear.BigMatrix var90 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var86);
    org.apache.commons.math.linear.RealMatrix var91 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var74.setRowMatrix(100, var91);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var10.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }
// 
// 
//     double[] var1 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
//     double[][] var3 = new double[][] { var1};
//     double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
//     org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
//     java.lang.String var6 = var5.toString();
//     double[] var8 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
//     double[][] var10 = new double[][] { var8};
//     double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
//     org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
//     java.lang.String var13 = var12.toString();
//     org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
//     boolean var15 = var14.isSingular();
//     var14.setEntry(0, 0, 10.0d);
//     org.apache.commons.math.linear.BlockRealMatrix var20 = var5.subtract((org.apache.commons.math.linear.RealMatrix)var14);
//     double var21 = var14.getDeterminant();
//     double var22 = var14.getFrobeniusNorm();
//     double var23 = var14.getNorm();
//     org.apache.commons.math.linear.RealMatrix var25 = var14.scalarMultiply(100.0d);
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var26 = null;
//     double var27 = var14.walkInColumnOrder(var26);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var2 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var3 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var2);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
//     double[] var6 = var5.getInterpolatedState();
//     org.apache.commons.math.FunctionEvaluationException var7 = new org.apache.commons.math.FunctionEvaluationException(var6);
//     var0.reinitialize(var6, false);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var10 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var11 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var12 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var11);
//     var12.rescale((-100.0d));
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.2d, (-10000.0d), 1.0E-15d, 0.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }


    java.lang.Throwable var2 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var6 = new org.apache.commons.math.ConvergenceException(var2, "", var5);
    org.apache.commons.math.MaxEvaluationsExceededException var7 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var5);
    java.lang.RuntimeException var8 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable)var7);
    double[] var10 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var10);
    double[][] var12 = new double[][] { var10};
    double[][] var13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var12);
    org.apache.commons.math.linear.BlockRealMatrix var14 = new org.apache.commons.math.linear.BlockRealMatrix(var13);
    java.lang.String var15 = var14.toString();
    double[] var17 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var18 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var17);
    double[][] var19 = new double[][] { var17};
    double[][] var20 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var19);
    org.apache.commons.math.linear.BlockRealMatrix var21 = new org.apache.commons.math.linear.BlockRealMatrix(var20);
    java.lang.String var22 = var21.toString();
    org.apache.commons.math.linear.BlockRealMatrix var23 = var21.transpose();
    boolean var24 = var23.isSingular();
    var23.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var29 = var14.subtract((org.apache.commons.math.linear.RealMatrix)var23);
    org.apache.commons.math.linear.RealMatrix var31 = var14.scalarMultiply(10.0d);
    double[] var33 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var34 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var33);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var36 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var33, false);
    org.apache.commons.math.linear.BigMatrix var37 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var33);
    double[] var38 = var14.preMultiply(var33);
    org.apache.commons.math.FunctionEvaluationException var39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var8, var38);
    java.lang.String var40 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var15.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var22.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "org.apache.commons.math.MathRuntimeException$10: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var40.equals("org.apache.commons.math.MathRuntimeException$10: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 10.0d, 100.0d, 100.0d);
    var4.clearEventHandlers();
    int var6 = var4.getOrder();
    var4.setInitialStepSize((-1.0d));
    var4.setMaxGrowth(100.0d);
    org.apache.commons.math.ode.events.EventHandler var11 = null;
    var4.addEventHandler(var11, Double.NaN, 0.0d, 8);
    org.apache.commons.math.ode.sampling.StepHandler var16 = null;
    var4.addStepHandler(var16);
    java.util.Collection var18 = var4.getEventHandlers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }


    org.apache.commons.math.fraction.FractionConversionException var3 = new org.apache.commons.math.fraction.FractionConversionException(1.0d, 0L, (-1L));

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = var10.multiply(var21);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var23 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var21);
    org.apache.commons.math.fraction.BigFraction var27 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var28 = var27.reciprocal();
    org.apache.commons.math.fraction.BigFraction var31 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var32 = var31.reciprocal();
    org.apache.commons.math.fraction.BigFraction var35 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var36 = var35.reciprocal();
    org.apache.commons.math.fraction.BigFraction var37 = var31.subtract(var35);
    org.apache.commons.math.fraction.BigFraction var40 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var41 = var40.reciprocal();
    org.apache.commons.math.fraction.BigFraction var44 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var45 = var44.reciprocal();
    org.apache.commons.math.fraction.BigFraction var46 = var40.subtract(var44);
    org.apache.commons.math.fraction.BigFraction var47 = var31.subtract(var44);
    java.math.BigInteger var48 = var47.getDenominator();
    org.apache.commons.math.fraction.BigFraction var49 = var27.divide(var48);
    org.apache.commons.math.FieldElement[] var50 = new org.apache.commons.math.FieldElement[] { var49};
    org.apache.commons.math.linear.FieldMatrix var51 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var50);
    org.apache.commons.math.linear.FieldMatrix var52 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var50);
    org.apache.commons.math.linear.FieldVector var53 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var50);
    var21.setColumn(0, var50);
    org.apache.commons.math.linear.FieldVector var56 = var21.getColumnVector(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldVector var58 = var21.getColumnVector((-110));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 10.0d, 100.0d, 100.0d);
    var4.setMinReduction((-1.0d));
    org.apache.commons.math.ode.sampling.StepHandler var7 = null;
    var4.addStepHandler(var7);
    var4.setSafety((-2.0d));
    double var11 = var4.getMinStep();
    java.util.Collection var12 = var4.getStepHandlers();
    var4.setMaxGrowth((-900.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }


    org.apache.commons.math.Field var0 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var1 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var0);
    org.apache.commons.math.FieldElement var2 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var3 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var2);
    var3.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var11 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var3);
    org.apache.commons.math.Field var12 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var13 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var12);
    org.apache.commons.math.FieldElement var14 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var15 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var14);
    var15.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var23 = var13.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    org.apache.commons.math.FieldElement var24 = var1.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    boolean var25 = var1.isSquare();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    org.apache.commons.math.linear.BlockRealMatrix var7 = var5.transpose();
    boolean var8 = var7.isSingular();
    var7.setEntry(0, 0, 10.0d);
    java.lang.Throwable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var20 = new org.apache.commons.math.ConvergenceException(var16, "", var19);
    org.apache.commons.math.MaxEvaluationsExceededException var21 = new org.apache.commons.math.MaxEvaluationsExceededException(100, "", var19);
    java.lang.IllegalStateException var22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", var19);
    org.apache.commons.math.ode.IntegratorException var23 = new org.apache.commons.math.ode.IntegratorException((java.lang.Throwable)var22);
    boolean var24 = var7.equals((java.lang.Object)var23);
    double var25 = var7.getNorm();
    org.apache.commons.math.linear.RealVector var27 = var7.getColumnVector(0);
    double[] var29 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var30 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var29);
    double[][] var31 = new double[][] { var29};
    double[][] var32 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var31);
    org.apache.commons.math.linear.BlockRealMatrix var33 = new org.apache.commons.math.linear.BlockRealMatrix(var32);
    double[] var35 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var36 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var35);
    double[][] var37 = new double[][] { var35};
    double[][] var38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var37);
    org.apache.commons.math.linear.BlockRealMatrix var39 = new org.apache.commons.math.linear.BlockRealMatrix(var38);
    java.lang.String var40 = var39.toString();
    org.apache.commons.math.linear.BlockRealMatrix var41 = var39.transpose();
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var33, (org.apache.commons.math.linear.AnyMatrix)var39);
    double[] var44 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var45 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var44);
    double[][] var46 = new double[][] { var44};
    double[][] var47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var46);
    org.apache.commons.math.linear.BlockRealMatrix var48 = new org.apache.commons.math.linear.BlockRealMatrix(var47);
    java.lang.String var49 = var48.toString();
    org.apache.commons.math.linear.BlockRealMatrix var50 = var48.transpose();
    boolean var51 = var50.isSingular();
    var50.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var56 = var33.multiply((org.apache.commons.math.linear.RealMatrix)var50);
    org.apache.commons.math.linear.RealMatrix var58 = var33.scalarMultiply(0.2d);
    org.apache.commons.math.linear.BlockRealMatrix var59 = var7.subtract((org.apache.commons.math.linear.RealMatrix)var33);
    org.apache.commons.math.fraction.BigFraction var63 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var64 = var63.reciprocal();
    org.apache.commons.math.fraction.BigFraction var67 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var68 = var67.reciprocal();
    org.apache.commons.math.fraction.BigFraction var71 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var72 = var71.reciprocal();
    org.apache.commons.math.fraction.BigFraction var73 = var67.subtract(var71);
    org.apache.commons.math.fraction.BigFraction var76 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var77 = var76.reciprocal();
    org.apache.commons.math.fraction.BigFraction var80 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var81 = var80.reciprocal();
    org.apache.commons.math.fraction.BigFraction var82 = var76.subtract(var80);
    org.apache.commons.math.fraction.BigFraction var83 = var67.subtract(var80);
    java.math.BigInteger var84 = var83.getDenominator();
    org.apache.commons.math.fraction.BigFraction var85 = var63.divide(var84);
    org.apache.commons.math.FieldElement[] var86 = new org.apache.commons.math.FieldElement[] { var85};
    org.apache.commons.math.linear.FieldMatrix var87 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var86);
    org.apache.commons.math.linear.FieldMatrix var88 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var86);
    org.apache.commons.math.ConvergenceException var89 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[])var86);
    org.apache.commons.math.linear.FieldMatrix var90 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var86);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var91 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var86);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var92 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var86);
    org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix)var7, (org.apache.commons.math.linear.AnyMatrix)var92);
    org.apache.commons.math.Field var94 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var95 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var94);
    int var96 = var95.getRowDimension();
    java.lang.String var97 = var95.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var98 = var92.add((org.apache.commons.math.linear.FieldMatrix)var95);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var40.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var49.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var97 + "' != '" + "Array2DRowFieldMatrix{}"+ "'", var97.equals("Array2DRowFieldMatrix{}"));

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(100, 16);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test104"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var15 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var16 = var15.reciprocal();
    org.apache.commons.math.FieldElement[] var17 = new org.apache.commons.math.FieldElement[] { var15};
    org.apache.commons.math.linear.FieldMatrix var18 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var17);
    org.apache.commons.math.FieldElement[][] var19 = new org.apache.commons.math.FieldElement[][] { var17};
    org.apache.commons.math.FieldElement[][] var20 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var19);
    java.lang.IllegalArgumentException var21 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var20);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix(var20);
    org.apache.commons.math.fraction.BigFraction var26 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var27 = var26.reciprocal();
    org.apache.commons.math.FieldElement[] var28 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var28);
    org.apache.commons.math.FieldElement[][] var30 = new org.apache.commons.math.FieldElement[][] { var28};
    org.apache.commons.math.FieldElement[][] var31 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var30);
    java.lang.IllegalArgumentException var32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockFieldMatrix var33 = new org.apache.commons.math.linear.BlockFieldMatrix(var31);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = var22.multiply(var33);
    org.apache.commons.math.fraction.BigFraction var38 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var39 = var38.reciprocal();
    org.apache.commons.math.FieldElement[] var40 = new org.apache.commons.math.FieldElement[] { var38};
    org.apache.commons.math.linear.FieldMatrix var41 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var40);
    org.apache.commons.math.FieldElement[][] var42 = new org.apache.commons.math.FieldElement[][] { var40};
    org.apache.commons.math.FieldElement[][] var43 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var42);
    java.lang.IllegalArgumentException var44 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var43);
    org.apache.commons.math.linear.BlockFieldMatrix var45 = new org.apache.commons.math.linear.BlockFieldMatrix(var43);
    org.apache.commons.math.fraction.BigFraction var49 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var50 = var49.reciprocal();
    org.apache.commons.math.FieldElement[] var51 = new org.apache.commons.math.FieldElement[] { var49};
    org.apache.commons.math.linear.FieldMatrix var52 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var51);
    org.apache.commons.math.FieldElement[][] var53 = new org.apache.commons.math.FieldElement[][] { var51};
    org.apache.commons.math.FieldElement[][] var54 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var53);
    java.lang.IllegalArgumentException var55 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var54);
    org.apache.commons.math.linear.BlockFieldMatrix var56 = new org.apache.commons.math.linear.BlockFieldMatrix(var54);
    org.apache.commons.math.linear.BlockFieldMatrix var57 = var45.multiply(var56);
    org.apache.commons.math.linear.BlockFieldMatrix var58 = var34.multiply(var45);
    org.apache.commons.math.fraction.BigFraction var61 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var62 = var61.reciprocal();
    org.apache.commons.math.fraction.BigFraction var64 = var62.add((-1L));
    org.apache.commons.math.fraction.BigFractionField var65 = var64.getField();
    org.apache.commons.math.fraction.BigFraction var66 = var65.getOne();
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var67 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var66);
    org.apache.commons.math.FieldElement var68 = var45.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var67);
    org.apache.commons.math.FieldElement[][] var69 = var45.getData();
    var10.setRowMatrix(0, var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var75 = var10.getSubMatrix(1, 100, 100, (-1));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test105"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var14 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var15 = var14.reciprocal();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var14};
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var16);
    org.apache.commons.math.FieldElement[][] var18 = new org.apache.commons.math.FieldElement[][] { var16};
    org.apache.commons.math.FieldElement[][] var19 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var18);
    java.lang.IllegalArgumentException var20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var19);
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var19);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = var10.multiply(var21);
    org.apache.commons.math.fraction.BigFraction var26 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var27 = var26.reciprocal();
    org.apache.commons.math.FieldElement[] var28 = new org.apache.commons.math.FieldElement[] { var26};
    org.apache.commons.math.linear.FieldMatrix var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var28);
    org.apache.commons.math.FieldElement[][] var30 = new org.apache.commons.math.FieldElement[][] { var28};
    org.apache.commons.math.FieldElement[][] var31 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var30);
    java.lang.IllegalArgumentException var32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var31);
    org.apache.commons.math.linear.BlockFieldMatrix var33 = new org.apache.commons.math.linear.BlockFieldMatrix(var31);
    org.apache.commons.math.fraction.BigFraction var37 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var38 = var37.reciprocal();
    org.apache.commons.math.FieldElement[] var39 = new org.apache.commons.math.FieldElement[] { var37};
    org.apache.commons.math.linear.FieldMatrix var40 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var39);
    org.apache.commons.math.FieldElement[][] var41 = new org.apache.commons.math.FieldElement[][] { var39};
    org.apache.commons.math.FieldElement[][] var42 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var41);
    java.lang.IllegalArgumentException var43 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var42);
    org.apache.commons.math.linear.BlockFieldMatrix var44 = new org.apache.commons.math.linear.BlockFieldMatrix(var42);
    org.apache.commons.math.linear.BlockFieldMatrix var45 = var33.multiply(var44);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = var22.multiply(var33);
    org.apache.commons.math.fraction.BigFraction var49 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var50 = var49.reciprocal();
    org.apache.commons.math.fraction.BigFraction var53 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var54 = var53.reciprocal();
    org.apache.commons.math.fraction.BigFraction var57 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var58 = var57.reciprocal();
    org.apache.commons.math.fraction.BigFraction var59 = var53.subtract(var57);
    org.apache.commons.math.fraction.BigFraction var62 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var63 = var62.reciprocal();
    org.apache.commons.math.fraction.BigFraction var66 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var67 = var66.reciprocal();
    org.apache.commons.math.fraction.BigFraction var68 = var62.subtract(var66);
    org.apache.commons.math.fraction.BigFraction var69 = var53.subtract(var66);
    java.math.BigInteger var70 = var69.getDenominator();
    org.apache.commons.math.fraction.BigFraction var71 = var49.divide(var70);
    org.apache.commons.math.FieldElement[] var72 = new org.apache.commons.math.FieldElement[] { var71};
    org.apache.commons.math.linear.FieldMatrix var73 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var72);
    org.apache.commons.math.linear.FieldMatrix var74 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var72);
    org.apache.commons.math.linear.FieldVector var75 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var72);
    org.apache.commons.math.FieldElement[] var76 = var22.operate(var72);
    int var77 = var22.getColumnDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 1);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test106"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    org.apache.commons.math.FunctionEvaluationException var3 = new org.apache.commons.math.FunctionEvaluationException(var1);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math.linear.InvalidMatrixException var5 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var3);
    java.lang.Object[] var13 = new java.lang.Object[] { (byte)10};
    org.apache.commons.math.FunctionEvaluationException var14 = new org.apache.commons.math.FunctionEvaluationException(1.0d, "", var13);
    org.apache.commons.math.ode.IntegratorException var15 = new org.apache.commons.math.ode.IntegratorException("BlockRealMatrix{{10.0}}", var13);
    java.util.ConcurrentModificationException var16 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("hi!", var13);
    org.apache.commons.math.linear.InvalidMatrixException var17 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MathRuntimeException$2: -1", var13);
    java.lang.Object[] var18 = var17.getArguments();
    org.apache.commons.math.ConvergenceException var19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var5, "matrix is singular", var18);
    java.lang.String var20 = var5.getPattern();
    java.lang.Throwable var27 = null;
    java.lang.Object[] var30 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math.ConvergenceException var31 = new org.apache.commons.math.ConvergenceException(var27, "", var30);
    org.apache.commons.math.MaxEvaluationsExceededException var32 = new org.apache.commons.math.MaxEvaluationsExceededException(1, "", var30);
    double[] var35 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var36 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var35);
    double[][] var37 = new double[][] { var35};
    double[][] var38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var37);
    org.apache.commons.math.MathRuntimeException var39 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var32, "hi!", (java.lang.Object[])var38);
    double[][] var40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var38);
    org.apache.commons.math.MaxIterationsExceededException var41 = new org.apache.commons.math.MaxIterationsExceededException(1, "org.apache.commons.math.MathRuntimeException$2: -1", (java.lang.Object[])var40);
    org.apache.commons.math.FunctionEvaluationException var42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var5, (-100.0d), "Adams-Moulton", (java.lang.Object[])var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + ""+ "'", var20.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test107"); }


    java.lang.Throwable var0 = null;
    double[] var2 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var3 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var2);
    org.apache.commons.math.linear.RealVector var4 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var2);
    org.apache.commons.math.FunctionEvaluationException var5 = new org.apache.commons.math.FunctionEvaluationException(var0, var2);
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.ConvergenceException var12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var5, "Array2DRowFieldMatrix{}", (java.lang.Object[])var11);
    java.io.IOException var13 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test108"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var11 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var10);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var12 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var13 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var12);
    boolean var14 = var10.equals((java.lang.Object)var12);
    var12.storeTime(10.9d);
    double var17 = var12.getInterpolatedTime();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 10.9d);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test109"); }


    org.apache.commons.math.Field var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var3 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var0, (-110), (-2));
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test110"); }
// 
// 
//     org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
//     org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
//     org.apache.commons.math.FieldElement[][] var6 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var3, (-1), 8);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var7 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var3);
//     org.apache.commons.math.Field var8 = var7.getField();
//     int var9 = var7.getRowDimension();
//     int var10 = var7.getRowDimension();
//     org.apache.commons.math.MaxEvaluationsExceededException var12 = new org.apache.commons.math.MaxEvaluationsExceededException(10);
//     java.io.IOException var13 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var12);
//     org.apache.commons.math.fraction.BigFraction var17 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var18 = var17.reciprocal();
//     org.apache.commons.math.FieldElement[] var19 = new org.apache.commons.math.FieldElement[] { var17};
//     org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var19);
//     org.apache.commons.math.FieldElement[][] var21 = new org.apache.commons.math.FieldElement[][] { var19};
//     org.apache.commons.math.FieldElement[][] var22 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var21);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var23 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var22);
//     org.apache.commons.math.MathException var24 = new org.apache.commons.math.MathException((java.lang.Throwable)var12, "0", (java.lang.Object[])var22);
//     org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var22);
//     org.apache.commons.math.Field var26 = null;
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var27 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var26);
//     org.apache.commons.math.FieldElement var28 = null;
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var29 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var28);
//     var29.start(8, 100, 8, 1, 10, (-1));
//     org.apache.commons.math.FieldElement var37 = var27.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var29);
//     org.apache.commons.math.FieldElement var38 = null;
//     org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var39 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor(var38);
//     org.apache.commons.math.FieldElement var40 = var27.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var39);
//     var39.start((-1), 0, 0, 8, 0, 8);
//     var39.start(0, (-2), 8, 0, 100, 1);
//     org.apache.commons.math.FieldElement var55 = var25.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var39);
//     org.apache.commons.math.Field var56 = null;
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var57 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var56);
//     org.apache.commons.math.FieldElement var58 = null;
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var59 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var58);
//     var59.start(8, 100, 8, 1, 10, (-1));
//     org.apache.commons.math.FieldElement var67 = var57.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var59);
//     boolean var69 = var57.equals((java.lang.Object)"org.apache.commons.math.MathRuntimeException$6: hi!");
//     org.apache.commons.math.fraction.BigFraction var72 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var73 = var72.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var76 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var77 = var76.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var78 = var72.subtract(var76);
//     org.apache.commons.math.fraction.BigFraction var81 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var82 = var81.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var85 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var86 = var85.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var87 = var81.subtract(var85);
//     org.apache.commons.math.fraction.BigFraction var88 = var72.subtract(var85);
//     long var89 = var85.longValue();
//     double var91 = var85.pow(0.9d);
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var92 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var85);
//     org.apache.commons.math.FieldElement var93 = var57.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var92);
//     org.apache.commons.math.FieldElement var94 = var25.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var92);
//     boolean var95 = var7.equals((java.lang.Object)var25);
//     org.apache.commons.math.FieldElement[][] var96 = var25.getData();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test111"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    boolean var6 = var5.isSquare();
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
    java.lang.String var13 = var12.toString();
    org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var17 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var18 = var17.getNSteps();
    int var19 = var17.getNSteps();
    double[] var21 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var21);
    org.apache.commons.math.FunctionEvaluationException var23 = new org.apache.commons.math.FunctionEvaluationException(var21);
    double[] var26 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
    double[][] var28 = new double[][] { var26};
    double[][] var29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var28);
    java.lang.IllegalArgumentException var30 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var28);
    org.apache.commons.math.linear.Array2DRowRealMatrix var31 = var17.initializeHighOrderDerivatives(var21, var28);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var33 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var34 = var33.getNSteps();
    int var35 = var33.getNSteps();
    double[] var37 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var38 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var37);
    org.apache.commons.math.FunctionEvaluationException var39 = new org.apache.commons.math.FunctionEvaluationException(var37);
    double[] var42 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var43 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var42);
    double[][] var44 = new double[][] { var42};
    double[][] var45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var44);
    java.lang.IllegalArgumentException var46 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var44);
    org.apache.commons.math.linear.Array2DRowRealMatrix var47 = var33.initializeHighOrderDerivatives(var37, var44);
    org.apache.commons.math.linear.Array2DRowRealMatrix var48 = var17.updateHighOrderDerivativesPhase1(var47);
    double[] var50 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var51 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var50);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var53 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var50, false);
    var53.setInterpolatedTime(0.0d);
    boolean var56 = var48.equals((java.lang.Object)var53);
    var14.setRowMatrix(0, (org.apache.commons.math.linear.RealMatrix)var48);
    org.apache.commons.math.linear.BlockRealMatrix var58 = var5.add(var14);
    org.apache.commons.math.linear.RealMatrixPreservingVisitor var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var64 = var14.walkInOptimizedOrder(var59, 16, 1, 0, (-110));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var13.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test112"); }


    org.apache.commons.math.Field var0 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var1 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var0);
    org.apache.commons.math.FieldElement var2 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var3 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var2);
    var3.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var11 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var3);
    org.apache.commons.math.Field var12 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var13 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var12);
    org.apache.commons.math.FieldElement var14 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var15 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var14);
    var15.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var23 = var13.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    org.apache.commons.math.FieldElement var24 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
    boolean var25 = var1.isSquare();
    org.apache.commons.math.Field var26 = var1.getField();
    double[] var28 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var29 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var28);
    double[][] var30 = new double[][] { var28};
    double[][] var31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var30);
    org.apache.commons.math.linear.BlockRealMatrix var32 = new org.apache.commons.math.linear.BlockRealMatrix(var31);
    double[] var34 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    double[][] var36 = new double[][] { var34};
    double[][] var37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var36);
    org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var37);
    java.lang.String var39 = var38.toString();
    org.apache.commons.math.linear.BlockRealMatrix var40 = var38.transpose();
    org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix)var32, (org.apache.commons.math.linear.AnyMatrix)var38);
    double[] var43 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var43);
    double[][] var45 = new double[][] { var43};
    double[][] var46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var45);
    org.apache.commons.math.linear.BlockRealMatrix var47 = new org.apache.commons.math.linear.BlockRealMatrix(var46);
    java.lang.String var48 = var47.toString();
    org.apache.commons.math.linear.BlockRealMatrix var49 = var47.transpose();
    boolean var50 = var49.isSingular();
    var49.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var55 = var32.multiply((org.apache.commons.math.linear.RealMatrix)var49);
    boolean var56 = var1.equals((java.lang.Object)var55);
    org.apache.commons.math.linear.RealMatrix var58 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var55.setColumnMatrix((-110), var58);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var39.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var48.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test113"); }
// 
// 
//     org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var1 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
//     int var2 = var1.getNSteps();
//     int var3 = var1.getNSteps();
//     double[] var5 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var5);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var8 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var5, false);
//     double var9 = var8.getCurrentTime();
//     double[] var10 = var8.getInterpolatedDerivatives();
//     org.apache.commons.math.fraction.FractionConversionException var14 = new org.apache.commons.math.fraction.FractionConversionException(0.0d, 0L, 10L);
//     java.lang.Object[] var17 = null;
//     org.apache.commons.math.FunctionEvaluationException var18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var14, 0.0d, "", var17);
//     double[] var19 = var18.getArgument();
//     org.apache.commons.math.linear.BigMatrix var20 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var19);
//     double[] var25 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var26 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var25);
//     org.apache.commons.math.linear.RealVector var27 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var25);
//     double[] var29 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var30 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var29);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var32 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var29, false);
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var33 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.0d, 10.0d, var25, var29);
//     var33.setMinReduction(1.0d);
//     org.apache.commons.math.fraction.BigFraction var38 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var39 = var38.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var42 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var43 = var42.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var46 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var47 = var46.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var48 = var42.subtract(var46);
//     org.apache.commons.math.fraction.BigFraction var51 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var52 = var51.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var55 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
//     org.apache.commons.math.fraction.BigFraction var56 = var55.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var57 = var51.subtract(var55);
//     org.apache.commons.math.fraction.BigFraction var58 = var42.subtract(var55);
//     java.math.BigInteger var59 = var58.getDenominator();
//     org.apache.commons.math.fraction.BigFraction var60 = var38.divide(var59);
//     org.apache.commons.math.FieldElement[] var61 = new org.apache.commons.math.FieldElement[] { var60};
//     org.apache.commons.math.linear.FieldMatrix var62 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var61);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var63 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix(var62);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var64 = var33.updateHighOrderDerivativesPhase1(var63);
//     var1.updateHighOrderDerivativesPhase2(var10, var19, var63);
//     double[] var67 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var68 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var67);
//     double[][] var69 = new double[][] { var67};
//     double[][] var70 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var69);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var70);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var72 = var1.updateHighOrderDerivativesPhase1(var71);
//     org.apache.commons.math.linear.RealMatrix var73 = var71.transpose();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var71.addToEntry(2147483647, 8, 900.0d);
//       fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
//     } catch (org.apache.commons.math.linear.MatrixIndexException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test114"); }


    double[] var4 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var5 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var4);
    org.apache.commons.math.linear.RealVector var6 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var4);
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var8, false);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var12 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.0d, 10.0d, var4, var8);
    double var13 = var12.getSafety();
    var12.clearEventHandlers();
    double[] var19 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var20 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var19);
    org.apache.commons.math.linear.RealVector var21 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var19);
    double[] var23 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var23);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var26 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var23, false);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var27 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.0d, 10.0d, var19, var23);
    double var28 = var27.getSafety();
    var12.setStarterIntegrator((org.apache.commons.math.ode.FirstOrderIntegrator)var27);
    double var30 = var27.getMaxStep();
    var27.clearStepHandlers();
    var27.setMaxGrowth(900.0d);
    var27.setMinReduction(1.0E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 10.0d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test115"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.fraction.BigFraction var7 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var8 = var7.reciprocal();
    org.apache.commons.math.fraction.BigFraction var11 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
    org.apache.commons.math.fraction.BigFraction var13 = var7.subtract(var11);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var17 = var16.reciprocal();
    org.apache.commons.math.fraction.BigFraction var20 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var21 = var20.reciprocal();
    org.apache.commons.math.fraction.BigFraction var22 = var16.subtract(var20);
    org.apache.commons.math.fraction.BigFraction var23 = var7.subtract(var20);
    java.math.BigInteger var24 = var23.getDenominator();
    org.apache.commons.math.fraction.BigFraction var25 = var3.divide(var24);
    org.apache.commons.math.FieldElement[] var26 = new org.apache.commons.math.FieldElement[] { var25};
    org.apache.commons.math.linear.FieldMatrix var27 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.linear.FieldMatrix var28 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.ConvergenceException var29 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[])var26);
    org.apache.commons.math.linear.FieldMatrix var30 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var26);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var31 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var26);
    org.apache.commons.math.linear.FieldMatrix var32 = var31.copy();
    org.apache.commons.math.fraction.BigFraction var35 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var36 = var35.reciprocal();
    org.apache.commons.math.fraction.BigFraction var38 = var36.add((-1L));
    double var39 = var38.doubleValue();
    org.apache.commons.math.fraction.BigFraction var42 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var43 = var42.reciprocal();
    org.apache.commons.math.fraction.BigFraction var46 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var47 = var46.reciprocal();
    org.apache.commons.math.fraction.BigFraction var48 = var42.subtract(var46);
    java.math.BigInteger var49 = var48.getNumerator();
    org.apache.commons.math.fraction.BigFraction var50 = var38.multiply(var48);
    java.math.BigDecimal var51 = var50.bigDecimalValue();
    boolean var52 = var31.equals((java.lang.Object)var51);
    org.apache.commons.math.linear.FieldMatrix var53 = var31.transpose();
    org.apache.commons.math.linear.FieldMatrix var54 = var31.copy();
    int var55 = var31.getRowDimension();
    int var56 = var31.getRowDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test116"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var2 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var3 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var2);
//     double[][] var4 = new double[][] { var2};
//     double[][] var5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var4);
//     org.apache.commons.math.linear.BlockRealMatrix var6 = new org.apache.commons.math.linear.BlockRealMatrix(var5);
//     java.lang.String var7 = var6.toString();
//     org.apache.commons.math.linear.BlockRealMatrix var8 = var6.transpose();
//     double[] var10 = new double[] { 100.0d};
//     org.apache.commons.math.linear.BigMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var10);
//     double[] var12 = var8.preMultiply(var10);
//     var0.reinitialize(var12, false);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var15 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var16 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var15);
//     org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var23 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
//     int var24 = var23.getNSteps();
//     double[] var26 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var27 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var26);
//     org.apache.commons.math.FunctionEvaluationException var28 = new org.apache.commons.math.FunctionEvaluationException(var26);
//     double[] var30 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var31 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var30);
//     org.apache.commons.math.FunctionEvaluationException var32 = new org.apache.commons.math.FunctionEvaluationException(var30);
//     org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var34 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
//     int var35 = var34.getNSteps();
//     int var36 = var34.getNSteps();
//     double[] var38 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var39 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var38);
//     org.apache.commons.math.FunctionEvaluationException var40 = new org.apache.commons.math.FunctionEvaluationException(var38);
//     double[] var43 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var44 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var43);
//     double[][] var45 = new double[][] { var43};
//     double[][] var46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var45);
//     java.lang.IllegalArgumentException var47 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var45);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var48 = var34.initializeHighOrderDerivatives(var38, var45);
//     var23.updateHighOrderDerivativesPhase2(var26, var30, var48);
//     org.apache.commons.math.linear.BigMatrix var50 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var26);
//     java.lang.Throwable var51 = null;
//     double[] var53 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var54 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var53);
//     org.apache.commons.math.linear.RealVector var55 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var53);
//     org.apache.commons.math.FunctionEvaluationException var56 = new org.apache.commons.math.FunctionEvaluationException(var51, var53);
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var57 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.4142135623730951d, var26, var53);
//     org.apache.commons.math.FunctionEvaluationException var58 = new org.apache.commons.math.FunctionEvaluationException(var53);
//     double[] var60 = new double[] { 10.0d};
//     org.apache.commons.math.linear.RealMatrix var61 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var60);
//     double[][] var62 = new double[][] { var60};
//     double[][] var63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var62);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var63);
//     var15.reinitialize((-2.0d), 1.0E-15d, var53, var64);
//     var0.reinitialize(var53, false);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var68 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     boolean var69 = var0.isForward();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var70 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     double var71 = var70.getInterpolatedTime();
//     var70.rescale((-100.0d));
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test117"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction((-2));
    java.math.BigDecimal var2 = var1.bigDecimalValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test118"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
    java.lang.String var13 = var12.toString();
    org.apache.commons.math.linear.BlockRealMatrix var14 = var12.transpose();
    boolean var15 = var14.isSingular();
    var14.setEntry(0, 0, 10.0d);
    org.apache.commons.math.linear.BlockRealMatrix var20 = var5.subtract((org.apache.commons.math.linear.RealMatrix)var14);
    java.lang.String var21 = var14.toString();
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var27 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var28 = var27.getNSteps();
    double[] var30 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var31 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var30);
    org.apache.commons.math.FunctionEvaluationException var32 = new org.apache.commons.math.FunctionEvaluationException(var30);
    double[] var34 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    org.apache.commons.math.FunctionEvaluationException var36 = new org.apache.commons.math.FunctionEvaluationException(var34);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var38 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var39 = var38.getNSteps();
    int var40 = var38.getNSteps();
    double[] var42 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var43 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var42);
    org.apache.commons.math.FunctionEvaluationException var44 = new org.apache.commons.math.FunctionEvaluationException(var42);
    double[] var47 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var48 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var47);
    double[][] var49 = new double[][] { var47};
    double[][] var50 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var49);
    java.lang.IllegalArgumentException var51 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var49);
    org.apache.commons.math.linear.Array2DRowRealMatrix var52 = var38.initializeHighOrderDerivatives(var42, var49);
    var27.updateHighOrderDerivativesPhase2(var30, var34, var52);
    org.apache.commons.math.linear.BigMatrix var54 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var30);
    java.lang.Throwable var55 = null;
    double[] var57 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var58 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var57);
    org.apache.commons.math.linear.RealVector var59 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var57);
    org.apache.commons.math.FunctionEvaluationException var60 = new org.apache.commons.math.FunctionEvaluationException(var55, var57);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var61 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, 1.4142135623730951d, var30, var57);
    org.apache.commons.math.FunctionEvaluationException var62 = new org.apache.commons.math.FunctionEvaluationException(var57);
    var14.setRow(0, var57);
    org.apache.commons.math.fraction.BigFraction var67 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var68 = var67.reciprocal();
    org.apache.commons.math.FieldElement[] var69 = new org.apache.commons.math.FieldElement[] { var67};
    org.apache.commons.math.linear.FieldMatrix var70 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var69);
    java.io.EOFException var71 = org.apache.commons.math.MathRuntimeException.createEOFException("0", (java.lang.Object[])var69);
    boolean var72 = var14.equals((java.lang.Object)var69);
    org.apache.commons.math.linear.BlockRealMatrix var74 = var14.scalarAdd((-900.0d));
    org.apache.commons.math.linear.BlockRealMatrix var75 = var74.transpose();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.RealVector var77 = var75.getColumnVector((-110));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var13.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var21.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test119"); }


    org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    double[] var2 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var3 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var2);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var5 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var2, false);
    var5.setInterpolatedTime(0.0d);
    double var8 = var5.getInterpolatedTime();
    boolean var9 = var0.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var5);
    boolean var10 = var0.isEmpty();
    java.util.Collection var11 = var0.getEventsHandlers();
    org.apache.commons.math.fraction.BigFraction var15 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var16 = var15.reciprocal();
    org.apache.commons.math.FieldElement[] var17 = new org.apache.commons.math.FieldElement[] { var15};
    org.apache.commons.math.linear.FieldMatrix var18 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var17);
    org.apache.commons.math.FieldElement[][] var19 = new org.apache.commons.math.FieldElement[][] { var17};
    org.apache.commons.math.FieldElement[][] var20 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var19);
    java.lang.IllegalArgumentException var21 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var20);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix(var20);
    org.apache.commons.math.linear.FieldLUDecompositionImpl var23 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var22);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var24 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var25 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var24);
    boolean var26 = var22.equals((java.lang.Object)var24);
    var24.storeTime(10.9d);
    boolean var29 = var0.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test120"); }


    double[] var4 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var5 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var4);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var7 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var4, false);
    double[] var8 = var7.getInterpolatedState();
    double[] var10 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var10);
    org.apache.commons.math.linear.RealVector var12 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var10);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var13 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(8, (-1.0d), (-2.0d), var8, var10);
    org.apache.commons.math.FunctionEvaluationException var14 = new org.apache.commons.math.FunctionEvaluationException(var10);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var16 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var10, true);
    org.apache.commons.math.linear.RealMatrix var17 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test121"); }


    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    double[][] var10 = new double[][] { var8};
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var10);
    org.apache.commons.math.linear.BlockRealMatrix var12 = new org.apache.commons.math.linear.BlockRealMatrix(var11);
    java.lang.IllegalStateException var13 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("BlockRealMatrix{{10.0}}", (java.lang.Object[])var11);
    org.apache.commons.math.MaxEvaluationsExceededException var14 = new org.apache.commons.math.MaxEvaluationsExceededException((-1), "", (java.lang.Object[])var11);
    java.lang.Throwable[] var15 = var14.getSuppressed();
    org.apache.commons.math.ConvergenceException var16 = new org.apache.commons.math.ConvergenceException("Maximal number of evaluations ({0}) exceeded", (java.lang.Object[])var15);
    java.lang.ArrayIndexOutOfBoundsException var17 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", (java.lang.Object[])var15);
    java.text.ParseException var18 = org.apache.commons.math.MathRuntimeException.createParseException((-1), "org.apache.commons.math.linear.InvalidMatrixException: Dormand-Prince 8 (5, 3)", (java.lang.Object[])var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test122"); }


    org.apache.commons.math.fraction.BigFraction var4 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var5 = var4.reciprocal();
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    org.apache.commons.math.FieldElement[][] var8 = new org.apache.commons.math.FieldElement[][] { var6};
    org.apache.commons.math.FieldElement[][] var9 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var8);
    java.lang.IllegalArgumentException var10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var9);
    org.apache.commons.math.linear.InvalidMatrixException var11 = new org.apache.commons.math.linear.InvalidMatrixException("0", (java.lang.Object[])var9);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var12 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var9);
    org.apache.commons.math.FieldElement[][] var13 = var12.getData();
    org.apache.commons.math.fraction.BigFraction var17 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var18 = var17.reciprocal();
    org.apache.commons.math.FieldElement[] var19 = new org.apache.commons.math.FieldElement[] { var17};
    org.apache.commons.math.linear.FieldMatrix var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var19);
    org.apache.commons.math.FieldElement[][] var21 = new org.apache.commons.math.FieldElement[][] { var19};
    org.apache.commons.math.FieldElement[][] var22 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var21);
    java.lang.IllegalArgumentException var23 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var22);
    org.apache.commons.math.linear.BlockFieldMatrix var24 = new org.apache.commons.math.linear.BlockFieldMatrix(var22);
    org.apache.commons.math.fraction.BigFraction var28 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var29 = var28.reciprocal();
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var28};
    org.apache.commons.math.linear.FieldMatrix var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var30);
    org.apache.commons.math.FieldElement[][] var32 = new org.apache.commons.math.FieldElement[][] { var30};
    org.apache.commons.math.FieldElement[][] var33 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var32);
    java.lang.IllegalArgumentException var34 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var33);
    org.apache.commons.math.linear.BlockFieldMatrix var35 = new org.apache.commons.math.linear.BlockFieldMatrix(var33);
    org.apache.commons.math.linear.BlockFieldMatrix var36 = var24.multiply(var35);
    org.apache.commons.math.fraction.BigFraction var40 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var41 = var40.reciprocal();
    org.apache.commons.math.FieldElement[] var42 = new org.apache.commons.math.FieldElement[] { var40};
    org.apache.commons.math.linear.FieldMatrix var43 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var42);
    org.apache.commons.math.FieldElement[][] var44 = new org.apache.commons.math.FieldElement[][] { var42};
    org.apache.commons.math.FieldElement[][] var45 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var44);
    java.lang.IllegalArgumentException var46 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var45);
    org.apache.commons.math.linear.BlockFieldMatrix var47 = new org.apache.commons.math.linear.BlockFieldMatrix(var45);
    org.apache.commons.math.fraction.BigFraction var51 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var52 = var51.reciprocal();
    org.apache.commons.math.FieldElement[] var53 = new org.apache.commons.math.FieldElement[] { var51};
    org.apache.commons.math.linear.FieldMatrix var54 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var53);
    org.apache.commons.math.FieldElement[][] var55 = new org.apache.commons.math.FieldElement[][] { var53};
    org.apache.commons.math.FieldElement[][] var56 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var55);
    java.lang.IllegalArgumentException var57 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var56);
    org.apache.commons.math.linear.BlockFieldMatrix var58 = new org.apache.commons.math.linear.BlockFieldMatrix(var56);
    org.apache.commons.math.linear.BlockFieldMatrix var59 = var47.multiply(var58);
    org.apache.commons.math.linear.BlockFieldMatrix var60 = var36.multiply(var47);
    org.apache.commons.math.FieldElement var61 = null;
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var62 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var61);
    var62.start(8, 100, 8, 1, 10, (-1));
    org.apache.commons.math.FieldElement var70 = var60.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var62);
    org.apache.commons.math.linear.FieldMatrix var71 = var12.multiply((org.apache.commons.math.linear.FieldMatrix)var60);
    org.apache.commons.math.linear.FieldMatrix var72 = var60.transpose();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var74 = var60.getRowMatrix(2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test123"); }


    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var5 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(8, 10.0d, 1.0E-14d, 20.0d, 1.0d);
    double var6 = var5.getSafety();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test124"); }


    double[] var4 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var5 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var4);
    org.apache.commons.math.linear.RealVector var6 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var4);
    double[] var8 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var8);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var8, false);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var12 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.0d, 10.0d, var4, var8);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var14 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var15 = var14.getNSteps();
    int var16 = var14.getNSteps();
    double[] var18 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var19 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var18);
    org.apache.commons.math.FunctionEvaluationException var20 = new org.apache.commons.math.FunctionEvaluationException(var18);
    double[] var23 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var24 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var23);
    double[][] var25 = new double[][] { var23};
    double[][] var26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var25);
    java.lang.IllegalArgumentException var27 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var25);
    org.apache.commons.math.linear.Array2DRowRealMatrix var28 = var14.initializeHighOrderDerivatives(var18, var25);
    org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer var30 = org.apache.commons.math.ode.nonstiff.AdamsNordsieckTransformer.getInstance(1);
    int var31 = var30.getNSteps();
    int var32 = var30.getNSteps();
    double[] var34 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var34);
    org.apache.commons.math.FunctionEvaluationException var36 = new org.apache.commons.math.FunctionEvaluationException(var34);
    double[] var39 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var40 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var39);
    double[][] var41 = new double[][] { var39};
    double[][] var42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var41);
    java.lang.IllegalArgumentException var43 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var41);
    org.apache.commons.math.linear.Array2DRowRealMatrix var44 = var30.initializeHighOrderDerivatives(var34, var41);
    org.apache.commons.math.linear.Array2DRowRealMatrix var45 = var14.updateHighOrderDerivativesPhase1(var44);
    double[] var47 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var48 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var47);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var50 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var47, false);
    var50.setInterpolatedTime(0.0d);
    boolean var53 = var45.equals((java.lang.Object)var50);
    org.apache.commons.math.fraction.FractionConversionException var57 = new org.apache.commons.math.fraction.FractionConversionException(0.0d, 0L, 10L);
    java.lang.Object[] var60 = null;
    org.apache.commons.math.FunctionEvaluationException var61 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var57, 0.0d, "", var60);
    double[] var62 = var61.getArgument();
    org.apache.commons.math.linear.BigMatrix var63 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var62);
    double[][] var64 = new double[][] { var62};
    org.apache.commons.math.linear.Array2DRowRealMatrix var65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var64);
    org.apache.commons.math.linear.Array2DRowRealMatrix var66 = var45.subtract(var65);
    java.lang.Throwable var68 = null;
    org.apache.commons.math.linear.InvalidMatrixException var69 = new org.apache.commons.math.linear.InvalidMatrixException(var68);
    double[] var73 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var74 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var73);
    double[][] var75 = new double[][] { var73};
    double[][] var76 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var75);
    org.apache.commons.math.linear.BlockRealMatrix var77 = new org.apache.commons.math.linear.BlockRealMatrix(var76);
    org.apache.commons.math.linear.BigMatrix var78 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var76);
    java.lang.IllegalArgumentException var79 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var76);
    org.apache.commons.math.MathException var80 = new org.apache.commons.math.MathException(var68, "BlockRealMatrix{{10.0}}", (java.lang.Object[])var76);
    org.apache.commons.math.linear.MatrixIndexException var81 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.ConvergenceException: ", (java.lang.Object[])var76);
    org.apache.commons.math.linear.Array2DRowRealMatrix var82 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var76);
    org.apache.commons.math.linear.Array2DRowRealMatrix var83 = var45.subtract(var82);
    org.apache.commons.math.linear.Array2DRowRealMatrix var84 = var12.updateHighOrderDerivativesPhase1(var82);
    double[][] var85 = var82.getData();
    int var86 = var82.getRowDimension();
    org.apache.commons.math.linear.RealMatrix var87 = var82.transpose();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test125"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.fraction.BigFraction var4 = var3.getZero();
    org.apache.commons.math.FieldElement[][] var7 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>createBlocksLayout((org.apache.commons.math.Field)var3, 100, (-2));
    org.apache.commons.math.fraction.BigFraction var8 = var3.getOne();
    org.apache.commons.math.fraction.BigFraction var9 = var3.getZero();
    org.apache.commons.math.linear.FieldMatrix var12 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix((org.apache.commons.math.Field)var3, 10, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test126"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var5 = var3.add((-1L));
    org.apache.commons.math.fraction.BigFraction var8 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var9 = var8.reciprocal();
    org.apache.commons.math.fraction.BigFraction var11 = var9.add((-1L));
    int var12 = var11.getDenominatorAsInt();
    org.apache.commons.math.fraction.BigFraction var14 = var11.add(1);
    java.math.BigInteger var15 = var11.getDenominator();
    org.apache.commons.math.fraction.BigFraction var16 = var3.subtract(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test127"); }


    org.apache.commons.math.fraction.BigFraction var3 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var4 = var3.reciprocal();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldMatrix var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.FieldElement[][] var8 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var7);
    java.lang.IllegalArgumentException var9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var8);
    org.apache.commons.math.linear.BlockFieldMatrix var10 = new org.apache.commons.math.linear.BlockFieldMatrix(var8);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var8);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var12 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var8);
    org.apache.commons.math.fraction.BigFraction var16 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var17 = var16.reciprocal();
    org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var16};
    org.apache.commons.math.linear.FieldMatrix var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var18);
    org.apache.commons.math.FieldElement[][] var20 = new org.apache.commons.math.FieldElement[][] { var18};
    org.apache.commons.math.FieldElement[][] var21 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var20);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix(var20);
    java.lang.String var23 = var22.toString();
    org.apache.commons.math.linear.Array2DRowRealMatrix var24 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix((org.apache.commons.math.linear.FieldMatrix)var22);
    org.apache.commons.math.linear.FieldMatrix var26 = var22.getColumnMatrix(0);
    java.lang.String var27 = var22.toString();
    var12.setRowMatrix(0, (org.apache.commons.math.linear.FieldMatrix)var22);
    org.apache.commons.math.linear.FieldMatrix var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setColumnMatrix(10, var30);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "BlockFieldMatrix{{-1}}"+ "'", var23.equals("BlockFieldMatrix{{-1}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "BlockFieldMatrix{{-1}}"+ "'", var27.equals("BlockFieldMatrix{{-1}}"));

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test128"); }


    org.apache.commons.math.MaxEvaluationsExceededException var1 = new org.apache.commons.math.MaxEvaluationsExceededException(2147483647);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test129"); }


    org.apache.commons.math.fraction.BigFraction var4 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var5 = var4.reciprocal();
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    org.apache.commons.math.FieldElement[][] var8 = new org.apache.commons.math.FieldElement[][] { var6};
    org.apache.commons.math.FieldElement[][] var9 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var8);
    java.lang.IllegalArgumentException var10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var9);
    org.apache.commons.math.linear.BlockFieldMatrix var11 = new org.apache.commons.math.linear.BlockFieldMatrix(var9);
    org.apache.commons.math.fraction.BigFraction var15 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var16 = var15.reciprocal();
    org.apache.commons.math.FieldElement[] var17 = new org.apache.commons.math.FieldElement[] { var15};
    org.apache.commons.math.linear.FieldMatrix var18 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var17);
    org.apache.commons.math.FieldElement[][] var19 = new org.apache.commons.math.FieldElement[][] { var17};
    org.apache.commons.math.FieldElement[][] var20 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var19);
    java.lang.IllegalArgumentException var21 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var20);
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix(var20);
    org.apache.commons.math.linear.BlockFieldMatrix var23 = var11.multiply(var22);
    org.apache.commons.math.fraction.BigFraction var27 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var28 = var27.reciprocal();
    org.apache.commons.math.FieldElement[] var29 = new org.apache.commons.math.FieldElement[] { var27};
    org.apache.commons.math.linear.FieldMatrix var30 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var29);
    org.apache.commons.math.FieldElement[][] var31 = new org.apache.commons.math.FieldElement[][] { var29};
    org.apache.commons.math.FieldElement[][] var32 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var31);
    java.lang.IllegalArgumentException var33 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var32);
    org.apache.commons.math.linear.BlockFieldMatrix var34 = new org.apache.commons.math.linear.BlockFieldMatrix(var32);
    org.apache.commons.math.fraction.BigFraction var38 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var39 = var38.reciprocal();
    org.apache.commons.math.FieldElement[] var40 = new org.apache.commons.math.FieldElement[] { var38};
    org.apache.commons.math.linear.FieldMatrix var41 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var40);
    org.apache.commons.math.FieldElement[][] var42 = new org.apache.commons.math.FieldElement[][] { var40};
    org.apache.commons.math.FieldElement[][] var43 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var42);
    java.lang.IllegalArgumentException var44 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var43);
    org.apache.commons.math.linear.BlockFieldMatrix var45 = new org.apache.commons.math.linear.BlockFieldMatrix(var43);
    org.apache.commons.math.linear.BlockFieldMatrix var46 = var34.multiply(var45);
    org.apache.commons.math.linear.BlockFieldMatrix var47 = var23.multiply(var34);
    org.apache.commons.math.fraction.BigFraction var50 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var51 = var50.reciprocal();
    org.apache.commons.math.FieldElement[] var52 = new org.apache.commons.math.FieldElement[] { var50};
    org.apache.commons.math.linear.FieldMatrix var53 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var52);
    org.apache.commons.math.FieldElement[][] var54 = new org.apache.commons.math.FieldElement[][] { var52};
    org.apache.commons.math.FieldElement[][] var55 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var54);
    org.apache.commons.math.linear.BlockFieldMatrix var56 = new org.apache.commons.math.linear.BlockFieldMatrix(var54);
    org.apache.commons.math.linear.FieldMatrix var57 = var23.subtract((org.apache.commons.math.linear.FieldMatrix)var56);
    org.apache.commons.math.linear.FieldMatrix var58 = var56.transpose();
    org.apache.commons.math.fraction.BigFraction var64 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var65 = var64.reciprocal();
    org.apache.commons.math.fraction.BigFraction var68 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var69 = var68.reciprocal();
    org.apache.commons.math.fraction.BigFraction var72 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var73 = var72.reciprocal();
    org.apache.commons.math.fraction.BigFraction var74 = var68.subtract(var72);
    org.apache.commons.math.fraction.BigFraction var77 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var78 = var77.reciprocal();
    org.apache.commons.math.fraction.BigFraction var81 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var82 = var81.reciprocal();
    org.apache.commons.math.fraction.BigFraction var83 = var77.subtract(var81);
    org.apache.commons.math.fraction.BigFraction var84 = var68.subtract(var81);
    java.math.BigInteger var85 = var84.getDenominator();
    org.apache.commons.math.fraction.BigFraction var86 = var64.divide(var85);
    org.apache.commons.math.FieldElement[] var87 = new org.apache.commons.math.FieldElement[] { var86};
    org.apache.commons.math.linear.FieldMatrix var88 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var87);
    org.apache.commons.math.linear.FieldMatrix var89 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var87);
    org.apache.commons.math.ode.IntegratorException var90 = new org.apache.commons.math.ode.IntegratorException("org.apache.commons.math.MathRuntimeException$6: hi!", (java.lang.Object[])var87);
    java.util.ConcurrentModificationException var91 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("matrix is singular", (java.lang.Object[])var87);
    org.apache.commons.math.linear.FieldMatrix var92 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var87);
    java.lang.IllegalStateException var93 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("BlockRealMatrix{{10.0}}", (java.lang.Object[])var87);
    org.apache.commons.math.FieldElement[] var94 = var56.preMultiply(var87);
    org.apache.commons.math.linear.FieldVector var95 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var94);
    java.io.EOFException var96 = org.apache.commons.math.MathRuntimeException.createEOFException("Overflow trying to convert {0} to fraction ({1}/{2})", (java.lang.Object[])var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test130"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var5 = var3.add((-1L));
    double var6 = var5.doubleValue();
    org.apache.commons.math.fraction.BigFraction var9 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var10 = var9.reciprocal();
    org.apache.commons.math.fraction.BigFraction var13 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var14 = var13.reciprocal();
    org.apache.commons.math.fraction.BigFraction var15 = var9.subtract(var13);
    java.math.BigInteger var16 = var15.getNumerator();
    org.apache.commons.math.fraction.BigFraction var17 = var5.multiply(var15);
    short var18 = var15.shortValue();
    long var19 = var15.getNumeratorAsLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (short)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0L);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test131"); }
// 
// 
//     org.apache.commons.math.Field var0 = null;
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var1 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var0);
//     org.apache.commons.math.FieldElement var2 = null;
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var3 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var2);
//     var3.start(8, 100, 8, 1, 10, (-1));
//     org.apache.commons.math.FieldElement var11 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var3);
//     org.apache.commons.math.Field var12 = null;
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var13 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var12);
//     org.apache.commons.math.FieldElement var14 = null;
//     org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var15 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor(var14);
//     var15.start(8, 100, 8, 1, 10, (-1));
//     org.apache.commons.math.FieldElement var23 = var13.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
//     org.apache.commons.math.FieldElement var24 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var15);
//     int var25 = var1.getColumnDimension();
//     boolean var26 = var1.isSquare();
//     org.apache.commons.math.FieldElement[][] var27 = var1.getData();
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test132"); }


    double[] var1 = new double[] { 10.0d};
    org.apache.commons.math.linear.RealMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var1);
    double[][] var3 = new double[][] { var1};
    double[][] var4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var3);
    org.apache.commons.math.linear.BlockRealMatrix var5 = new org.apache.commons.math.linear.BlockRealMatrix(var4);
    java.lang.String var6 = var5.toString();
    org.apache.commons.math.linear.BlockRealMatrix var7 = var5.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var8 = var7.transpose();
    double var9 = var7.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var11 = var7.scalarMultiply(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "BlockRealMatrix{{10.0}}"+ "'", var6.equals("BlockRealMatrix{{10.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test133"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction((-1.0d));
    java.math.BigDecimal var2 = var1.bigDecimalValue();
    org.apache.commons.math.fraction.BigFraction var5 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var6 = var5.reciprocal();
    org.apache.commons.math.fraction.BigFraction var9 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var10 = var9.reciprocal();
    org.apache.commons.math.fraction.BigFraction var11 = var5.subtract(var9);
    java.lang.String var12 = var9.toString();
    double var14 = var9.pow(100.0d);
    org.apache.commons.math.fraction.BigFraction var16 = var9.divide((-2L));
    org.apache.commons.math.fraction.BigFraction var17 = var1.add(var9);
    org.apache.commons.math.fraction.BigFraction var18 = var1.reduce();
    java.lang.Throwable var23 = null;
    org.apache.commons.math.fraction.BigFraction var28 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var29 = var28.reciprocal();
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var28};
    org.apache.commons.math.linear.FieldMatrix var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var30);
    org.apache.commons.math.FieldElement[][] var32 = new org.apache.commons.math.FieldElement[][] { var30};
    org.apache.commons.math.FieldElement[][] var33 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var32);
    org.apache.commons.math.FieldElement[][] var34 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var33);
    org.apache.commons.math.FunctionEvaluationException var35 = new org.apache.commons.math.FunctionEvaluationException(var23, (-2.0d), "BlockRealMatrix{{100.0}}", (java.lang.Object[])var34);
    org.apache.commons.math.FunctionEvaluationException var36 = new org.apache.commons.math.FunctionEvaluationException((-2.0d), "", (java.lang.Object[])var34);
    org.apache.commons.math.linear.FieldMatrix var37 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldMatrix(var34);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var38 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var34);
    org.apache.commons.math.linear.BlockFieldMatrix var40 = new org.apache.commons.math.linear.BlockFieldMatrix(1, 1, var34, false);
    boolean var41 = var18.equals((java.lang.Object)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "-1"+ "'", var12.equals("-1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test134"); }


    org.apache.commons.math.fraction.BigFraction var4 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var5 = var4.reciprocal();
    org.apache.commons.math.FieldElement[] var6 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldMatrix var7 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldDiagonalMatrix(var6);
    org.apache.commons.math.FieldElement[][] var8 = new org.apache.commons.math.FieldElement[][] { var6};
    org.apache.commons.math.FieldElement[][] var9 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var8);
    java.lang.IllegalArgumentException var10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("0", (java.lang.Object[])var9);
    org.apache.commons.math.linear.BlockFieldMatrix var11 = new org.apache.commons.math.linear.BlockFieldMatrix(var9);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var12 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var9);
    org.apache.commons.math.linear.InvalidMatrixException var13 = new org.apache.commons.math.linear.InvalidMatrixException("Adams-Moulton", (java.lang.Object[])var9);
    org.apache.commons.math.ConvergenceException var14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var13);
    java.lang.String var15 = var13.getPattern();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Adams-Moulton"+ "'", var15.equals("Adams-Moulton"));

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test135"); }


    org.apache.commons.math.fraction.BigFraction var2 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.fraction.BigFraction var5 = var2.add((-2L));
    org.apache.commons.math.fraction.BigFraction var8 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var9 = var8.reciprocal();
    org.apache.commons.math.fraction.BigFraction var12 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var13 = var12.reciprocal();
    org.apache.commons.math.fraction.BigFraction var14 = var8.subtract(var12);
    org.apache.commons.math.fraction.BigFraction var17 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var18 = var17.reciprocal();
    org.apache.commons.math.fraction.BigFraction var21 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var22 = var21.reciprocal();
    org.apache.commons.math.fraction.BigFraction var23 = var17.subtract(var21);
    org.apache.commons.math.fraction.BigFraction var24 = var8.subtract(var21);
    org.apache.commons.math.fraction.BigFraction var26 = var8.subtract((-1));
    org.apache.commons.math.fraction.BigFraction var29 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(0, 8);
    org.apache.commons.math.fraction.BigFraction var32 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var33 = var32.reciprocal();
    org.apache.commons.math.fraction.BigFraction var36 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var37 = var36.reciprocal();
    org.apache.commons.math.fraction.BigFraction var38 = var32.subtract(var36);
    org.apache.commons.math.fraction.BigFraction var41 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var42 = var41.reciprocal();
    org.apache.commons.math.fraction.BigFraction var45 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var46 = var45.reciprocal();
    org.apache.commons.math.fraction.BigFraction var47 = var41.subtract(var45);
    org.apache.commons.math.fraction.BigFraction var48 = var32.subtract(var45);
    org.apache.commons.math.fraction.BigFraction var50 = var32.subtract((-1));
    org.apache.commons.math.fraction.BigFraction var53 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var54 = var53.reciprocal();
    org.apache.commons.math.fraction.BigFraction var57 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var58 = var57.reciprocal();
    org.apache.commons.math.fraction.BigFraction var59 = var53.subtract(var57);
    org.apache.commons.math.fraction.BigFraction var62 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var63 = var62.reciprocal();
    org.apache.commons.math.fraction.BigFraction var66 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(1, (-1));
    org.apache.commons.math.fraction.BigFraction var67 = var66.reciprocal();
    org.apache.commons.math.fraction.BigFraction var68 = var62.subtract(var66);
    org.apache.commons.math.fraction.BigFraction var69 = var53.subtract(var66);
    java.math.BigInteger var70 = var69.getDenominator();
    org.apache.commons.math.fraction.BigFraction var71 = var32.pow(var70);
    org.apache.commons.math.fraction.BigFraction var72 = var29.subtract(var70);
    org.apache.commons.math.fraction.BigFraction var73 = var8.divide(var70);
    org.apache.commons.math.fraction.BigFraction var74 = var5.pow(var70);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var75 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

}
