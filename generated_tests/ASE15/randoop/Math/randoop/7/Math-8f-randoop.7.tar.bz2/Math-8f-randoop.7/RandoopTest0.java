
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     org.apache.commons.math3.util.Pair var0 = null;
//     org.apache.commons.math3.util.Pair var1 = new org.apache.commons.math3.util.Pair(var0);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double[] var2 = new double[] { 10.0d, (-1.0d)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     double[] var1 = new double[] { 0.0d};
//     double[] var2 = null;
//     double var3 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var2);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(100.0d, (-1.0d), 0.0d, 10.0d, 1.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    double[] var1 = new double[] { };
    double[] var4 = new double[] { 1.0d, (-1.0d)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var5 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var1, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var1.nextSample(var3, (-1));
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var38 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var7, var26);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var4, var17);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var33, var46);
    double[][] var59 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var59);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var59);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1, 0);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var1.nextGaussian(140.0071426749364d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.743842034720653d);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    int var4 = var1.nextZipf(100, 141.42489172702236d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.nextExponential((-0.44930379803545945d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c73a7b06e8", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "209e6ad961"+ "'", var3.equals("209e6ad961"));
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var4 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, true, true);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     java.util.List var2 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var3 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 10.0d, 1.0d, 1.145389752706889d, (-0.44930379803545945d), 0.5219515461396678d, 10.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.910874940635856d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextSecureInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.470685060497404d));
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var35);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var7, var35);
    double[] var50 = new double[] { 10.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var51 = org.apache.commons.math3.util.MathArrays.distance1(var7, var50);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var35);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var7, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1028812019);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     java.util.List var3 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var4 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var3);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextGamma((-0.44930379803545945d), 10.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 228.50112648638387d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.624017735739021d);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var1.nextSample(var5, 10);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextHypergeometric(10, 1028812019, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 14L);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var1.nextPoisson((-0.44930379803545945d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 73L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.19439893154424884d);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
//     double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
//     double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
//     double[] var49 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var53 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var54 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
//     double var55 = org.apache.commons.math3.util.MathArrays.distance1(var44, var53);
//     double var56 = org.apache.commons.math3.util.MathArrays.linearCombination(var31, var44);
//     double var57 = org.apache.commons.math3.util.MathArrays.distance(var16, var44);
//     boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var7, var44);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var59, var60, false);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)50L, (java.lang.Number)10.0f, false);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 50L+ "'", var5.equals(50L));

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
//     double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
//     double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
//     double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
//     double var46 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
//     double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var35);
//     double var48 = org.apache.commons.math3.util.MathArrays.distance(var7, var35);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var35, var49, true);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var16);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(141.42489172702236d, 0.9338216241499386d, 0.03510480520930032d, 0.0d, (-0.44930379803545945d), 1.145389752706889d, 0.019290119022056726d, 0.9487345360513418d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 131.5692953237559d);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     org.apache.commons.math3.distribution.IntegerDistribution var2 = null;
//     int var3 = var1.nextInversionDeviate(var2);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     org.apache.commons.math3.distribution.RealDistribution var9 = null;
//     double var10 = var1.nextInversionDeviate(var9);
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1), 1028812019);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     int var6 = var1.nextInt(100);
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var7);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double var29 = org.apache.commons.math3.util.MathArrays.linearCombination(var4, var17);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var37, var46);
    double[] var52 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var56 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var52, var56);
    double[] var61 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var65 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double var67 = org.apache.commons.math3.util.MathArrays.distance1(var56, var65);
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var37, var56);
    double var69 = org.apache.commons.math3.util.MathArrays.linearCombination(var17, var37);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var0, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed();
    int var6 = var1.nextHypergeometric(1028812019, 100, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var9 = var1.nextPermutation(514406009, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c73a7b06e8", "c73a7b06e8");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.1679255687559253d);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0f);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var4 = new int[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = org.apache.commons.math3.util.MathArrays.distance1(var3, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var1.nextSample(var5, 41);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.039691703214181015d, (java.lang.Number)7.794554629059993E114d, (java.lang.Number)100L);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var1.nextSample(var9, 100);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double[] var49 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var53 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var54 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var44, var53);
    double var56 = org.apache.commons.math3.util.MathArrays.linearCombination(var31, var44);
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var16, var44);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var7, var44);
    double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.distance1(var67, var76);
    double[] var82 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var86 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var87 = org.apache.commons.math3.util.MathArrays.distance(var82, var86);
    double[] var91 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var95 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var96 = org.apache.commons.math3.util.MathArrays.distance(var91, var95);
    double var97 = org.apache.commons.math3.util.MathArrays.distance1(var86, var95);
    double var98 = org.apache.commons.math3.util.MathArrays.distance1(var67, var86);
    boolean var99 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == true);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var3, var16);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var32, var45);
    double[][] var58 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var9 = var8.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var10);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     double var7 = var1.nextCauchy(0.1945318675277668d, 1426.887198243755d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextInt(1, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-533.8616652500849d));
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(10);
//     var1.reSeedSecure(41L);
//     org.apache.commons.math3.distribution.IntegerDistribution var6 = null;
//     int var7 = var1.nextInversionDeviate(var6);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.util.List var0 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var1 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(100.0d, (-0.14863104184816925d), 0.10588996378510665d, 0.800421916980158d, 141.15466586111373d, 0.03282615243296957d, 836930.5077725694d, 0.5219515461396678d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 436827.027760391d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var5.nextExponential((-0.267596010140786d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(141.15466586111373d, 0.1945318675277668d, 0.03759646091721926d, 0.03759646091721926d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 27.460494254093863d);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 29.545499890082418d);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     var1.reSeed(66L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextPascal((-1), 0.05272999253983823d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 59L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.02894123525873579d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.662412741081364E11d);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var1.nextSecureLong(41L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.7252271618569677d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 150.49165033818613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.003339955165345366d));
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextHypergeometric(907608747, 41, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5022033002728669d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.8904115653130695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var3 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var1, true);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.nextUniform(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextBinomial((-1), 2.244546466239121d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100L);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     long var7 = var1.nextLong(22L, 88L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 78L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 82L);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     var1.reSeed(66L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)", "c9f482a2f7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03365724660783731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4022762.1646630517d));
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var9.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.74955746306695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2344875775226378d);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextBinomial((-1), 0.5328962565365816d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.18517031770591294d);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     int var11 = var1.nextSecureInt(1, 1028812019);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextGaussian(0.0d, (-1.9004211692006052d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 978173278);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var3.nextBeta(433.8473116074771d, 1.70318249281768d);
    double var9 = var3.nextBeta(836930.5077725694d, 131.5692953237559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9991548839151001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.9998367706742745d);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextSecureInt(1689900776, 1689900776);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.8902104233252215d);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     int var13 = var1.nextZipf(10, 126.65787460843954d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextPascal(108894710, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 62L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03649631533819616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 201.4380703226126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(10);
//     var1.reSeedSecure(41L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var1.nextPermutation(1028812019, 514406009);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "71ed999196"+ "'", var3.equals("71ed999196"));
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextSecureInt(907608747, 907608747);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.941186111647374d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.790655950086642d);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkPositive(var0);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     long[][] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     int var13 = var1.nextZipf(10, 126.65787460843954d);
//     double var15 = var1.nextExponential(200.81717002836405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 32L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03568598920353319d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 200.58085083797894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 235.48999079421458d);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.1945318675277668d, (java.lang.Number)0.5328962565365816d, false);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextHypergeometric(3, 1, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var9 = var8.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
//     java.lang.Throwable[] var11 = var3.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     double[] var17 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var21 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var22 = org.apache.commons.math3.util.MathArrays.distance(var17, var21);
//     double[] var26 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var30 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var31 = org.apache.commons.math3.util.MathArrays.distance(var26, var30);
//     double[] var35 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var39 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var40 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
//     double var41 = org.apache.commons.math3.util.MathArrays.distance1(var30, var39);
//     double var42 = org.apache.commons.math3.util.MathArrays.distance1(var17, var30);
//     double[] var46 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var50 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var51 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
//     double[] var55 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var59 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var60 = org.apache.commons.math3.util.MathArrays.distance(var55, var59);
//     double[] var64 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var68 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var69 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
//     double var70 = org.apache.commons.math3.util.MathArrays.distance1(var59, var68);
//     double var71 = org.apache.commons.math3.util.MathArrays.distance1(var46, var59);
//     double[][] var72 = new double[][] { var46};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var72);
//     org.apache.commons.math3.exception.MathInternalError var74 = new org.apache.commons.math3.exception.MathInternalError(var13, (java.lang.Object[])var72);
//     org.apache.commons.math3.exception.MathIllegalStateException var75 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var12, (java.lang.Object[])var72);
//     org.apache.commons.math3.exception.util.Localizable var76 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var81 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var82 = var81.getSuppressed();
//     org.apache.commons.math3.util.Pair var84 = new org.apache.commons.math3.util.Pair((java.lang.Object)var82, (java.lang.Object)201.0d);
//     org.apache.commons.math3.exception.NotFiniteNumberException var85 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)10.0f, (java.lang.Object[])var82);
//     org.apache.commons.math3.exception.MathIllegalStateException var86 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var75, var76, (java.lang.Object[])var82);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var1.nextSecureLong(78L, 22L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 315.32816350221935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8772896824523526d));
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextSecureLong(64L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     double var7 = var1.nextCauchy(0.1945318675277668d, 1426.887198243755d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextBeta(0.0d, 0.03510480520930032d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-4850.153041814678d));
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)141.15466586111373d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(short)100);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(10);
//     var1.reSeedSecure(41L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextHypergeometric(0, 7, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d163cd885e"+ "'", var3.equals("d163cd885e"));
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    double var2 = var1.nextDouble();
    float var3 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2395389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.39346063f);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextZipf(100, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 23L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.029298094298447798d);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     byte[] var1 = null;
//     var0.nextBytes(var1);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var5.nextPoisson((-0.14863104184816925d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(5);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var4, var17);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var33, var46);
    double[][] var59 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var59);
    org.apache.commons.math3.exception.MathInternalError var61 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var59);
    org.apache.commons.math3.exception.util.ExceptionContext var62 = var61.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var63 = var61.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextInt(10, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100L, var2);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 514406009);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 41, 41);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.9798395551529173d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var3.nextBeta(1.9020015664445744d, (-0.2015768976317097d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var16);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 201.0d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = null;
    boolean var11 = var9.equals(var10);
    java.lang.Object var12 = var9.getSecond();
    java.lang.Object var13 = var9.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 201.0d+ "'", var12.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 201.0d+ "'", var13.equals(201.0d));

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextT(0.007523027327565226d);
//     org.apache.commons.math3.distribution.IntegerDistribution var6 = null;
//     int var7 = var1.nextInversionDeviate(var6);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
//     double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
//     double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var7, var12);
//     double[] var39 = null;
//     double var40 = org.apache.commons.math3.util.MathArrays.distance(var12, var39);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.10588996378510665d, 0.5219515461396678d, 0.05272999253983823d, 4.497671471910009d, 0.8082030461156922d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2924316134787679d);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, (-1));
//       fail("Expected exception of type java.lang.NegativeArraySizeException");
//     } catch (java.lang.NegativeArraySizeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
//     double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
//     double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var4, var17);
//     double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
//     double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
//     double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
//     double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
//     double var58 = org.apache.commons.math3.util.MathArrays.distance1(var33, var46);
//     double[][] var59 = new double[][] { var33};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var59);
//     org.apache.commons.math3.exception.MathInternalError var61 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var59);
//     java.lang.Throwable var62 = null;
//     var61.addSuppressed(var62);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var26);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var8 = var1.nextBeta(200.81717002836405d, 0.1991753248498107d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextBinomial(7, 3.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.1456648494016732d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9997579963550712d);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextUniform(0.0998915660109107d, 1.089117284020693E-9d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.3401587916378264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.19855056655238829d);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextUniform(0.9899703701402124d, 201.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var1.nextLong(45L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 42.44032620270458d);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 100, 0);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 59L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.20201262519206045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7861058764731469d);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 8);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed();
    int var6 = var1.nextHypergeometric(1028812019, 100, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var1.nextUniform(1.05492292904169d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var1.nextSample(var10, 7);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 5, 5);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.4649256620524505d), (java.lang.Number)62L, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var7, var12);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double[] var60 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var64 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var55, var64);
    double[] var70 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var74 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var70, var74);
    double[] var79 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var83 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var84 = org.apache.commons.math3.util.MathArrays.distance(var79, var83);
    double[] var88 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var92 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var93 = org.apache.commons.math3.util.MathArrays.distance(var88, var92);
    double var94 = org.apache.commons.math3.util.MathArrays.distance1(var83, var92);
    double var95 = org.apache.commons.math3.util.MathArrays.linearCombination(var70, var83);
    double var96 = org.apache.commons.math3.util.MathArrays.distance(var55, var83);
    boolean var97 = org.apache.commons.math3.util.MathArrays.equals(var46, var83);
    double[] var98 = org.apache.commons.math3.util.MathArrays.ebeAdd(var12, var83);
    double var99 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 141.42489172702236d);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     org.apache.commons.math3.distribution.RealDistribution var6 = null;
//     double var7 = var1.nextInversionDeviate(var6);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextSecureInt(41, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 53L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03567637524916996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 180.68047226607004d);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextUniform(0.9899703701402124d, 201.0d);
//     double var14 = var1.nextGaussian(54.22225463326228d, 0.035179478860137996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 192.11099022113703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 54.16432207452556d);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var6.nextBeta(1.089117284020693E-9d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextUniform(0.9899703701402124d, 201.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 181.37035183879357d);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.2015768976317097d));
    boolean var2 = var1.getBoundIsAllowed();
    boolean var3 = var1.getBoundIsAllowed();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
//     double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     double[] var14 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var18 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var19 = org.apache.commons.math3.util.MathArrays.distance(var14, var18);
//     double[] var23 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var27 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var18, var27);
//     double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
//     double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
//     double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
//     double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
//     double var58 = org.apache.commons.math3.util.MathArrays.linearCombination(var33, var46);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance(var18, var46);
//     double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
//     double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
//     double[] var81 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var85 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var86 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
//     double var87 = org.apache.commons.math3.util.MathArrays.distance1(var76, var85);
//     double var88 = org.apache.commons.math3.util.MathArrays.linearCombination(var63, var76);
//     double var89 = org.apache.commons.math3.util.MathArrays.distance1(var46, var76);
//     double var90 = org.apache.commons.math3.util.MathArrays.distance(var4, var46);
//     double var91 = org.apache.commons.math3.util.MathArrays.distance(var0, var4);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    double[] var1 = new double[] { 0.0d};
    double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)8.11989620793123d, (java.lang.Number)0L, false);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextWeibull(198.0d, 436827.027760391d);
//     double var16 = var1.nextWeibull(10.0d, 433.8473116074771d);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var1.nextSample(var17, 108894710);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     java.util.List var5 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var6 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var5);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var10);
    java.lang.Throwable[] var12 = var4.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    double[] var18 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var22 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var23 = org.apache.commons.math3.util.MathArrays.distance(var18, var22);
    double[] var27 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var31 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance(var27, var31);
    double[] var36 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var40 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var41 = org.apache.commons.math3.util.MathArrays.distance(var36, var40);
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var31, var40);
    double var43 = org.apache.commons.math3.util.MathArrays.distance1(var18, var31);
    double[] var47 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var51 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var52 = org.apache.commons.math3.util.MathArrays.distance(var47, var51);
    double[] var56 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var60 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var61 = org.apache.commons.math3.util.MathArrays.distance(var56, var60);
    double[] var65 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var69 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var65, var69);
    double var71 = org.apache.commons.math3.util.MathArrays.distance1(var60, var69);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var47, var60);
    double[][] var73 = new double[][] { var47};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var73);
    org.apache.commons.math3.exception.MathInternalError var75 = new org.apache.commons.math3.exception.MathInternalError(var14, (java.lang.Object[])var73);
    org.apache.commons.math3.exception.MathIllegalStateException var76 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var13, (java.lang.Object[])var73);
    org.apache.commons.math3.exception.NullArgumentException var77 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     double var9 = var1.nextBeta(200.58085083797894d, 0.9991548839151001d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var1.nextPermutation(2, 907608747);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9817631055856462d);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var1.nextPermutation(2, 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2L);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextGamma((-0.44930379803545945d), 0.8196234207249693d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.296797892358879d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9869855650357826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.812737135621557d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    double var3 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9066258578518134d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)10, (java.lang.Number)1.9020015664445744d, (-1));
    java.lang.Number var4 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.9020015664445744d+ "'", var4.equals(1.9020015664445744d));

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl(var1);
//     int var5 = var2.nextSecureInt((-1), 0);
//     int[] var8 = var2.nextPermutation(10, 8);
//     int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var8);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.2015768976317097d));
    java.lang.Throwable[] var2 = var1.getSuppressed();
    boolean var3 = var1.getBoundIsAllowed();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var2.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-30245107));
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var3 = var1.nextInt(1028812019);
//     var1.setSeed(1);
//     long var6 = var1.nextLong();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var9 = var8.nextInt();
//     byte[] var12 = new byte[] { (byte)100, (byte)10};
//     var8.nextBytes(var12);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var16 = var15.nextInt();
//     byte[] var19 = new byte[] { (byte)100, (byte)10};
//     var15.nextBytes(var19);
//     var8.nextBytes(var19);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var19, (java.lang.Object)0.007523027327565226d);
//     var1.nextBytes(var19);
//     float var25 = var1.nextFloat();
//     java.util.List var26 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var27 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var26);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.2015768976317097d));
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    org.apache.commons.math3.exception.NotPositiveException var20 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03510480520930032d);
    org.apache.commons.math3.util.Pair var21 = new org.apache.commons.math3.util.Pair((java.lang.Object)var18, (java.lang.Object)var20);
    boolean var22 = var20.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2857L, (java.lang.Number)0.9438523786817169d, true);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)(-1), (java.lang.Number)2852L, false);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.2015768976317097d));
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.029977394192225556d, (java.lang.Number)1.5324442802669078d, 2);
    java.lang.Number var4 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.5324442802669078d+ "'", var4.equals(1.5324442802669078d));

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(2.677146259383745d, 0.03282615243296957d, 0.31804493603716955d, 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0420152193073937d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)200.81717002836405d);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c9f482a2f7", "c9f482a2f7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.7578278969820165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.7136744696542372d);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var9);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var20 = var19.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var15, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathArithmeticException var22 = new org.apache.commons.math3.exception.MathArithmeticException();
    var14.addSuppressed((java.lang.Throwable)var22);
    boolean var24 = var9.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextUniform(0.9899703701402124d, 201.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric(1689900776, 3, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 162.08541873020516d);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var9 = var1.nextUniform(0.0d, 54.22225463326228d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 28.607227405226453d);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextGamma(0.4900218365169397d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextInt(907608747, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.4769118524131823d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 146.58409897245423d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.20047551791469d);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     double var9 = var1.nextGamma(0.5587862084152698d, 201.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextCauchy((-12.587651277008359d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 971.3544238154528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.737834207670875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 158.34400627978323d);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     int var11 = var1.nextPascal(10, 0.5587862084152698d);
//     double var13 = var1.nextChiSquare(0.9991548839151001d);
//     double var16 = var1.nextF(1.089117284020693E-9d, 0.9893766669763007d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var1.nextSecureLong(94L, 41L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5098316587635403d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.414066034867126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.8104865781988014d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)140.0071426749364d, false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var16 = var15.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var16);
    java.lang.Number var21 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 140.0071426749364d+ "'", var21.equals(140.0071426749364d));

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    float[] var3 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    float[] var9 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var10 = new float[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var10);
    float[] var15 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var16 = new float[] { };
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextZipf((-839619997), (-0.2015768976317097d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 63L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.14384825337276372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9090294369519732d);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var5.nextSecureLong(3100774812746927104L, 19L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     int var11 = var1.nextPascal(10, 0.5587862084152698d);
//     double var13 = var1.nextChiSquare(0.9991548839151001d);
//     double var16 = var1.nextF(1.089117284020693E-9d, 0.9893766669763007d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextHypergeometric(2, 41, 1689900776);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.28099439525892833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.027018185973913564d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.528091272374971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    float[] var0 = null;
    float[] var4 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var5 = new float[] { };
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
    float[] var10 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var11 = new float[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var11);
    float[] var17 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var18 = new float[] { };
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var17);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextF(0.0d, 0.03711666723053142d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3111737171576375808L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.07783171743066819d);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     double var10 = var1.nextF(0.326843498449728d, 94.0834911443809d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.015725077090641856d);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    var1.reSeedSecure();
    long var7 = var1.nextLong(0L, 82L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var1.nextInt(1689900776, 108894710);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 6L);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(208.96704151750916d, 3.7618551512431844d, 0.9798395551529173d, 0.9472890462734886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 787.0319328503921d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.244546466239121d);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
//     double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
//     double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
//     double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
//     double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
//     double[] var59 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var63 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var64 = org.apache.commons.math3.util.MathArrays.distance(var59, var63);
//     double var65 = org.apache.commons.math3.util.MathArrays.distance1(var54, var63);
//     double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var41, var54);
//     double var67 = org.apache.commons.math3.util.MathArrays.distance(var26, var54);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var54);
//     double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.linearCombination(var54, var72);
//     double[] var79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var72);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var80 = null;
//     boolean var82 = org.apache.commons.math3.util.MathArrays.isMonotonic(var72, var80, false);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)141.42489172702236d, (java.lang.Number)(byte)10, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)10+ "'", var5.equals((byte)10));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)200.42902505131346d, (java.lang.Number)437520.3234163918d, (java.lang.Number)10.0d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 437520.3234163918d+ "'", var5.equals(437520.3234163918d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0d+ "'", var6.equals(10.0d));

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var5.nextPermutation(1, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-30245107));

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextBinomial(3, 1.70318249281768d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9172129951145356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.401640138187912d);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.2015768976317097d));
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1689900776, 0);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 1028812019, 41);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     boolean var6 = var4.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var4.getDirection();
//     boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var7, false);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(208.96704151750916d, 0.9998367706742745d, 19.187896974239802d, 0.07526242366211702d, 0.0998915660109107d, 0.03510480520930032d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 210.38056627345054d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 855451518);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    var1.reSeedSecure();
    long var7 = var1.nextLong(0L, 82L);
    double var10 = var1.nextCauchy(0.03609112308169037d, 0.016855007404038964d);
    long var13 = var1.nextLong(77L, 78L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var1.nextInt(108894710, 3);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.02647681120026045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 78L);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var9);
    var12.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextCauchy(2.0805938937575448E8d, 0.0319217721093273d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextBinomial((-839619997), 201.22095288793136d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.080593894369851E8d);
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextSecureInt(108894710, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.1958109719598635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1477694138043795d);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     double var12 = var1.nextBeta(100.0d, 0.03510480520930032d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextPascal((-1623951277), 0.1945318675277668d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.80779248003811d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 135.0117670802011d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.054975094865160806d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9963294467800438d);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
//     double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     double[] var14 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var18 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var19 = org.apache.commons.math3.util.MathArrays.distance(var14, var18);
//     double[] var23 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var27 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var18, var27);
//     double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
//     double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
//     double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
//     double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
//     double var58 = org.apache.commons.math3.util.MathArrays.linearCombination(var33, var46);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance(var18, var46);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var46);
//     double[] var64 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var68 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var69 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
//     double var70 = org.apache.commons.math3.util.MathArrays.linearCombination(var46, var64);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var71 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var64);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.linearCombination(var45, var63);
    double[] var73 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var77 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var73, var77);
    double[] var82 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var86 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var87 = org.apache.commons.math3.util.MathArrays.distance(var82, var86);
    double[] var91 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var95 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var96 = org.apache.commons.math3.util.MathArrays.distance(var91, var95);
    double var97 = org.apache.commons.math3.util.MathArrays.distance1(var86, var95);
    double var98 = org.apache.commons.math3.util.MathArrays.distance1(var73, var86);
    double var99 = org.apache.commons.math3.util.MathArrays.distance1(var45, var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 198.0d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 1.0420152193073937d, 238.39792420612676d, (-0.00621860083647843d), 3.7618551512431844d, 148.80913770781288d, (-0.9696851998830972d), 0.6420589260774159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 557.6933246692392d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    double var2 = var1.nextDouble();
    int[] var3 = null;
    var1.setSeed(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1991753248498107d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.7881833486097136d), 0.07514916563775412d, 0.0d, 0.0d, 434777.8672564595d, 0.3419393764355132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 148667.53843714943d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var9.getFirst();
    java.lang.Object var11 = null;
    boolean var12 = var9.equals(var11);
    java.lang.Object var13 = var9.getFirst();
    java.lang.Object var14 = var9.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 201.0d+ "'", var14.equals(201.0d));

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     int[] var10 = new int[] { 0, 10};
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     org.apache.commons.math3.random.RandomGenerator var13 = null;
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl(var13);
//     int var17 = var14.nextSecureInt((-1), 0);
//     int[] var20 = var14.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
//     int var22 = org.apache.commons.math3.util.MathArrays.distance1(var12, var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = org.apache.commons.math3.util.MathArrays.distance(var7, var12);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 5);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    byte[] var5 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var5);
    float var7 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.39346063f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1.05492292904169d, (java.lang.Number)8.11989620793123d);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-30245107), (-839619997));
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.2015768976317097d));
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)3.0d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    double var2 = var1.nextDouble();
    byte[] var6 = new byte[] { (byte)100, (byte)100, (byte)10};
    var1.nextBytes(var6);
    long var8 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2999151554469617837L);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    int var4 = var1.nextZipf(100, 141.42489172702236d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var1.nextWeibull((-0.44930379803545945d), 0.03472411615674555d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     double var6 = var1.nextExponential(0.9487345360513418d);
//     double var9 = var1.nextCauchy(1.5324442802669078d, 2840.6711051053326d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var1.nextPermutation(1378651682, 692191003);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9691780155343909d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8784999135350547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6564.468436974652d);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2090448509803676160L, (java.lang.Number)136.1891660715202d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var16);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var3, var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 140.0071426749364d);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     int var13 = var1.nextHypergeometric(10, 0, 1);
//     double var16 = var1.nextBeta(136.1891660715202d, 27.460494254093863d);
//     double var20 = var1.nextUniform(0.0d, 140.0071426749364d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var1.nextBinomial(1, 9.061399540474673d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 95L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.034752152462006546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.6827154935549165E12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.8101306693474998d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 11.422145963729053d);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var9.getFirst();
    java.lang.Object var11 = null;
    boolean var12 = var9.equals(var11);
    java.lang.Object var13 = var9.getValue();
    java.lang.Object var14 = var9.getFirst();
    java.lang.Object var15 = var9.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 201.0d+ "'", var13.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1028812019);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var17 = var1.nextGamma(235.48999079421458d, 0.03307865221419767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 636254083245766656L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.8642959633895003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.920319137950138d);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c9f482a2f7", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double[] var59 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var63 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var64 = org.apache.commons.math3.util.MathArrays.distance(var59, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var54, var63);
    double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var41, var54);
    double var67 = org.apache.commons.math3.util.MathArrays.distance(var26, var54);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var54);
    double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.linearCombination(var54, var72);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var72);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var84 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var88 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var89 = var88.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var90 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var83, var84, (java.lang.Object[])var89);
    java.lang.Throwable[] var91 = var83.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var92 = var83.getDirection();
    org.apache.commons.math3.util.Pair var93 = new org.apache.commons.math3.util.Pair((java.lang.Object)var72, (java.lang.Object)var92);
    java.lang.Object var94 = var93.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var35);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var7, var35);
    double[] var52 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var56 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var52, var56);
    double[] var61 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var65 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double[] var70 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var74 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var70, var74);
    double var76 = org.apache.commons.math3.util.MathArrays.distance1(var65, var74);
    double var77 = org.apache.commons.math3.util.MathArrays.linearCombination(var52, var65);
    double var78 = org.apache.commons.math3.util.MathArrays.distance1(var35, var65);
    double var79 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 1.7320508075688772d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
    double[] var61 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var65 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double[] var70 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var74 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var70, var74);
    double var76 = org.apache.commons.math3.util.MathArrays.distance1(var65, var74);
    double var77 = org.apache.commons.math3.util.MathArrays.distance1(var46, var65);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var81 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var82 = var81.getSuppressed();
    boolean var83 = var81.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var84 = var81.getDirection();
    boolean var86 = org.apache.commons.math3.util.MathArrays.isMonotonic(var46, var84, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var87 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var26, var46);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var9);
    java.lang.Object var11 = var9.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 201.0d+ "'", var11.equals(201.0d));

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var2 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var1);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(8, 100);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGamma(1.3150901193635438d, 201.22095288793136d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("668fa4ae4cde072ab0d2c169fe3ffa8814484af7d", "0dea");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 208.16858377280636d);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    double[] var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var19, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var6, var19);
    double[] var35 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var39 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var40 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
    double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
    double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var48, var57);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var35, var48);
    double[][] var61 = new double[][] { var35};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var61);
    org.apache.commons.math3.exception.MathInternalError var63 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var61);
    org.apache.commons.math3.exception.MathIllegalStateException var64 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var61);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var61);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.7881833486097136d), (java.lang.Number)1.0d, 100);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var1.nextSample(var12, 108894710);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 0);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1028812019);
//     java.util.List var2 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var3 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.145389752706889d, 1.28390985328776d, 0.034840239579776264d, (-0.4246216658271394d), 2.0056804291592623d, 0.055342234061093135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.56678210454931d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(907608747, 8);
    java.lang.Number var3 = var2.getArgument();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    long[] var5 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var7);
    var2.addSuppressed((java.lang.Throwable)var9);
    int var11 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 907608747+ "'", var3.equals(907608747));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextGaussian(0.910874940635856d, (-0.14863104184816925d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.050827720212386567d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 147.1219559787711d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.1680138097255789d));
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var5.nextT(2.0805938937575448E8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var5.nextBeta((-3368.8741687352244d), 0.04590135295676213d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.4649256620524505d));

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextUniform(0.9899703701402124d, 201.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextF(0.0d, 434777.8672564595d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 160.82277225468255d);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     java.lang.String var9 = var1.nextHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c73a7b06e8", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "6845"+ "'", var9.equals("6845"));
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextGamma(0.0d, 0.0998915660109107d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var9.getFirst();
    java.lang.Object var11 = null;
    boolean var12 = var9.equals(var11);
    java.lang.Object var13 = var9.getValue();
    java.lang.Object var14 = null;
    boolean var15 = var9.equals(var14);
    java.lang.Object var16 = var9.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 201.0d+ "'", var13.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 201.0d+ "'", var16.equals(201.0d));

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
    double[] var81 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var85 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var86 = org.apache.commons.math3.util.MathArrays.distance(var81, var85);
    double[] var90 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var94 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var95 = org.apache.commons.math3.util.MathArrays.distance(var90, var94);
    double var96 = org.apache.commons.math3.util.MathArrays.distance1(var85, var94);
    double var97 = org.apache.commons.math3.util.MathArrays.linearCombination(var72, var85);
    boolean var98 = org.apache.commons.math3.util.MathArrays.equals(var67, var72);
    double var99 = org.apache.commons.math3.util.MathArrays.distance1(var3, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 198.0d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var5.nextChiSquare((-0.2015768976317097d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     java.lang.String var9 = var1.nextHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextF(1.845734920494461d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "b6c1"+ "'", var9.equals("b6c1"));
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)174L, (java.lang.Number)192.11099022113703d, (java.lang.Number)3L);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 19.187896974239802d);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 33.234412449780464d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)201.0d);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)0.9681755253392977d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var9);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03510480520930032d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double[] var60 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var64 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double[] var69 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var73 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var74 = org.apache.commons.math3.util.MathArrays.distance(var69, var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var64, var73);
    double var76 = org.apache.commons.math3.util.MathArrays.linearCombination(var51, var64);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var46, var51);
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var26, var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 140.0071426749364d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var8 = var1.nextBeta(200.81717002836405d, 0.1991753248498107d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(0, 330.54018860523774d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.3337375930423779d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9997579963550712d);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)636254083245766656L, (java.lang.Number)(-1.0f), 8);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     double var10 = var1.nextExponential(2.5331613618987565d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextUniform(0.03344771607428209d, 0.002123327067530301d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.5731133159837087d);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var3.nextBeta(433.8473116074771d, 1.70318249281768d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var3.nextHypergeometric(3, 0, 1689900776);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9991548839151001d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var7, var12);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double[] var60 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var64 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var55, var64);
    double[] var70 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var74 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var70, var74);
    double[] var79 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var83 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var84 = org.apache.commons.math3.util.MathArrays.distance(var79, var83);
    double[] var88 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var92 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var93 = org.apache.commons.math3.util.MathArrays.distance(var88, var92);
    double var94 = org.apache.commons.math3.util.MathArrays.distance1(var83, var92);
    double var95 = org.apache.commons.math3.util.MathArrays.linearCombination(var70, var83);
    double var96 = org.apache.commons.math3.util.MathArrays.distance(var55, var83);
    boolean var97 = org.apache.commons.math3.util.MathArrays.equals(var46, var83);
    double[] var98 = org.apache.commons.math3.util.MathArrays.copyOf(var46);
    double var99 = org.apache.commons.math3.util.MathArrays.distance(var7, var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.0d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    double[] var14 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var18 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var19 = org.apache.commons.math3.util.MathArrays.distance(var14, var18);
    double[] var23 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var27 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var18, var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
    double var58 = org.apache.commons.math3.util.MathArrays.linearCombination(var33, var46);
    double var59 = org.apache.commons.math3.util.MathArrays.distance(var18, var46);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var46);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var0, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 855451518);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var7 = var1.nextExponential(433.8473116074771d);
//     long var10 = var1.nextLong(32L, 2865512416584424448L);
//     org.apache.commons.math3.distribution.RealDistribution var11 = null;
//     double var12 = var1.nextInversionDeviate(var11);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.11598742873037599d, 0.20201262519206045d, 490.66783567706426d, 201.0d, 0.0d, 54.22225463326228d, 1.0420152193073937d, 0.0866828383904682d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 98624.34872685173d);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     int var13 = var1.nextHypergeometric(10, 0, 1);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var1.nextSample(var14, 8);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("b1aa", "668fa4ae4cde072ab0d2c169fe3ffa8814484af7d");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 97L);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     int var9 = var1.nextBinomial(1, 1.0d);
//     double var12 = var1.nextF(4.140285621523964E-13d, 141.42489172702236d);
//     double var15 = var1.nextGaussian(0.2787313252014696d, 0.9066258578518134d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextBinomial(792999694, 235.48999079421458d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12.23397280973199d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.05812843019332278d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.7775325406032462E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.003695521391844092d));
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    var1.reSeedSecure();
    long var7 = var1.nextLong(0L, 82L);
    double var10 = var1.nextCauchy(0.03609112308169037d, 0.016855007404038964d);
    long var13 = var1.nextLong(77L, 78L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var1.nextWeibull(0.326843498449728d, (-0.44930379803545945d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.02647681120026045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 78L);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var3.nextBeta(433.8473116074771d, 1.70318249281768d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.nextGaussian(0.038011585546474595d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9991548839151001d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = null;
    boolean var11 = var9.equals(var10);
    java.lang.Object var12 = var9.getSecond();
    java.lang.Object var13 = var9.getFirst();
    java.lang.Object var14 = var9.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 201.0d+ "'", var12.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var5.nextT(2.0805938937575448E8d);
    double var9 = var5.nextExponential(1.845734920494461d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.4649256620524505d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.1627758383401945d);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     double var16 = var1.nextBeta(0.348176533212522d, 1.28390985328776d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextPascal(108894710, 9.061399540474673d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.28452619131272944d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 144.2671932485839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.4563848758398351d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.049313813666611875d);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextExponential((-0.44930379803545945d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.273551373066451d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7220528993025445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.1113266915273769d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 72.4311721562498d);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextGamma(0.0d, 94.0834911443809d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9449428176400354d);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var3, var63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var9 = var6.nextWeibull(1.089117284020693E-9d, 0.08522522639280383d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    long[][] var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkRectangular(var0);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var2.nextInt();
    byte[] var6 = new byte[] { (byte)100, (byte)10};
    var2.nextBytes(var6);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var10 = var9.nextInt();
    byte[] var13 = new byte[] { (byte)100, (byte)10};
    var9.nextBytes(var13);
    var2.nextBytes(var13);
    int var16 = var2.nextInt();
    org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)145.90522233641423d, (java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1378651682);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9066258578518134d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)10, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var1.nextSecureLong(65L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 14L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.16982507886711976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.4314628757633607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2861L);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    long[] var1 = new long[] { 100L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     double var12 = var1.nextBeta(100.0d, 0.03510480520930032d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextF(0.0d, 2.0805938937575448E8d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0716256622352152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 152.5328389327352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.49902663554632576d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9997204979928197d);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException(var0, var1);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     double var7 = var1.nextCauchy(0.1945318675277668d, 1426.887198243755d);
//     java.lang.String var9 = var1.nextHexString(3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextF((-0.267596010140786d), 1.087776523405259d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3422.9329965170955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "c33"+ "'", var9.equals("c33"));
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 141.15466586111373d);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    int var4 = var1.nextZipf(100, 141.42489172702236d);
    var1.reSeed(10L);
    double var9 = var1.nextGamma(0.03449238325907719d, 0.05272999253983823d);
    double var11 = var1.nextExponential(3.7618551512431844d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var1.nextGaussian(200.40417679089168d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.140285621523964E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.677146259383745d);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(907608747, 8);
//     java.lang.Number var3 = var2.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     long[] var5 = new long[] { };
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
//     long[][] var7 = new long[][] { var5};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var7);
//     var2.addSuppressed((java.lang.Throwable)var9);
//     java.lang.String var11 = var9.toString();
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     var1.reSeed(65L);
//     long var21 = var1.nextSecureLong(0L, 10L);
//     java.util.Collection var22 = null;
//     java.lang.Object[] var24 = var1.nextSample(var22, 855451518);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var6 = var1.nextFloat();
    boolean var7 = var1.nextBoolean();
    boolean var8 = var1.nextBoolean();
    int[] var9 = null;
    var1.setSeed(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.32099235f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextBinomial(7, (-0.09700389822790001d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)286.8963404480585d, var1, (java.lang.Number)(byte)0);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     var1.reSeed();
//     int var6 = var1.nextBinomial(2, 0.2638609393874067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    float[] var3 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    float[] var9 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var10 = new float[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var10);
    float[] var16 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var17 = new float[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var17);
    float[] var22 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var23 = new float[] { };
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var23);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var4, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     int var9 = var1.nextBinomial(1, 1.0d);
//     double var12 = var1.nextCauchy(8.11989620793123d, 0.326843498449728d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.678398245825071d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.3523601350829413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 25.96343796727935d);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextBeta(0.0d, 19.187896974239802d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.009871012095814537d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3323443825169346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.11323398365139009d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 39.525949853760814d);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    java.lang.Object var9 = var6.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 201.0d+ "'", var9.equals(201.0d));

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     int var11 = var1.nextPascal(10, 0.5587862084152698d);
//     var1.reSeed(88L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5988490853254274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.33383201759406217d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 13);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     double var12 = var1.nextBeta(100.0d, 0.03510480520930032d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var1.nextPermutation((-1623951277), 2);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.8042451453608336d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 122.86929114203545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.22254360370977538d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.999998735167725d);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(0);
    boolean var6 = var1.nextBoolean();
    int var8 = var1.nextInt(1378651682);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 30240769);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    boolean var4 = var3.getStrict();
    boolean var5 = var3.getStrict();
    int var6 = var3.getIndex();
    java.lang.Number var7 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1+ "'", var7.equals(1));

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     int var6 = var1.nextInt(100);
//     int[] var9 = new int[] { 0, 10};
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
//     var1.setSeed(var9);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var9);
//     int[] var15 = new int[] { 0, 10};
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var9, var16);
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var20 = var19.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var21 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var19);
//     long var22 = var19.nextLong();
//     int var24 = var19.nextInt(100);
//     int[] var27 = new int[] { 0, 10};
//     int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
//     var19.setSeed(var27);
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var27);
//     int[] var33 = new int[] { 0, 10};
//     int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var33);
//     double var35 = org.apache.commons.math3.util.MathArrays.distance(var27, var34);
//     int var36 = org.apache.commons.math3.util.MathArrays.distance1(var16, var34);
//     org.apache.commons.math3.random.RandomGenerator var37 = null;
//     org.apache.commons.math3.random.RandomDataImpl var38 = new org.apache.commons.math3.random.RandomDataImpl(var37);
//     int var41 = var38.nextSecureInt((-1), 0);
//     int[] var44 = var38.nextPermutation(10, 8);
//     double var45 = org.apache.commons.math3.util.MathArrays.distance(var16, var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1722448868039600408L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1722448868039600408L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 11.40175425099138d);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)50L, (java.lang.Number)10.0f, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMin();
    boolean var7 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0f+ "'", var6.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 30240769, (-839619997));

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 3);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.029977394192225556d, (java.lang.Number)1.5324442802669078d, 2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotANumberException var7 = new org.apache.commons.math3.exception.NotANumberException();
    double[] var11 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var15 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var16 = org.apache.commons.math3.util.MathArrays.distance(var11, var15);
    double[] var20 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var24 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance(var20, var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
    org.apache.commons.math3.exception.NotPositiveException var28 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03510480520930032d);
    org.apache.commons.math3.util.Pair var29 = new org.apache.commons.math3.util.Pair((java.lang.Object)var26, (java.lang.Object)var28);
    var7.addSuppressed((java.lang.Throwable)var28);
    java.lang.Throwable[] var31 = var7.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var32 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)70L, (java.lang.Object[])var31);
    org.apache.commons.math3.exception.MathIllegalStateException var33 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var31);
    org.apache.commons.math3.exception.util.ExceptionContext var34 = var33.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     double var7 = var1.nextCauchy(0.1945318675277668d, 1426.887198243755d);
//     long var9 = var1.nextPoisson(0.3974920595329054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("2dc46250e1", "0dea");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 461.2013450370375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)174L, (java.lang.Number)3.1627758383401945d, false);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextF(0.0d, 0.07645625043058513d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 57L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2881432519505097d);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     long var6 = var1.nextPoisson(434777.8672564595d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextSecureInt(10, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9594116625978906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 434910L);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 692191003, 1629366900);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double[] var59 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var63 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var64 = org.apache.commons.math3.util.MathArrays.distance(var59, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var54, var63);
    double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var41, var54);
    double var67 = org.apache.commons.math3.util.MathArrays.distance(var26, var54);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var54);
    double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.linearCombination(var54, var72);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var72);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var84 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var88 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var89 = var88.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var90 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var83, var84, (java.lang.Object[])var89);
    java.lang.Throwable[] var91 = var83.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var92 = var83.getDirection();
    org.apache.commons.math3.util.Pair var93 = new org.apache.commons.math3.util.Pair((java.lang.Object)var72, (java.lang.Object)var92);
    long[] var95 = new long[] { 100L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var95);
    boolean var97 = var93.equals((java.lang.Object)var95);
    java.lang.Object var98 = var93.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)19L, (java.lang.Number)437520.3234163918d, (java.lang.Number)126.65787460843954d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 126.65787460843954d+ "'", var5.equals(126.65787460843954d));

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     double var7 = var1.nextCauchy(0.1945318675277668d, 1426.887198243755d);
//     double var9 = var1.nextExponential(1.0420152193073937d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var1.nextSample(var10, (-839619997));
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var1.nextPermutation(353197573, 1629366900);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 22L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.028168251848732322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 202.0446115145071d);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     double var6 = var1.nextExponential(0.9487345360513418d);
//     double var9 = var1.nextCauchy(1.5324442802669078d, 2840.6711051053326d);
//     var1.reSeedSecure(85L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform(145.90522233641423d, 0.10262088780234416d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9336342506447053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.12200654943473781d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1108.6420731763526d));
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
    java.lang.Throwable[] var11 = var3.getSuppressed();
    java.lang.Number var12 = var3.getPrevious();
    java.lang.Number var13 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1+ "'", var12.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 1+ "'", var13.equals(1));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var3.nextExponential(4.497671471910009d);
    long var8 = var3.nextLong(2857L, 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5172264847508324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4353643293855910912L);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(0);
    boolean var6 = var1.nextBoolean();
    double var7 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.01408195728001127d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
    boolean var11 = var3.getStrict();
    java.lang.Number var12 = var3.getPrevious();
    boolean var13 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1+ "'", var12.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextPascal(1, (-1.22320332460919347E18d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9651718229559758d);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var3.nextExponential(4.497671471910009d);
//     int var8 = var3.nextSecureInt(41, 1629366900);
//     int var11 = var3.nextBinomial(102762836, 0.035179478860137996d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var3.nextT((-0.9494791599918844d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5172264847508324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 590462702);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3615507);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var5.reSeed(19L);
    long var10 = var5.nextLong((-1722448868039600408L), 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1538904934532245248L));

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     var1.reSeed(65L);
//     int var21 = var1.nextBinomial(0, 0.0d);
//     var1.reSeed(64L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 482806506685451456L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.13577924877535585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 99.63836752982392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     int var9 = var1.nextBinomial(1, 1.0d);
//     double var12 = var1.nextF(4.140285621523964E-13d, 141.42489172702236d);
//     double var15 = var1.nextGaussian(0.2787313252014696d, 0.9066258578518134d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.4200682258215138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.5348852695805206d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.838149552287309d);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 1689900776, 7);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("2dc46250e1", "668fa4ae4cde072ab0d2c169fe3ffa8814484af7d");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.86012137575047d));
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.List var3 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var4 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var3);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.03318395473810047d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0.1945318675277668d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var2, true);
    java.lang.Comparable[] var9 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var17 = var16.getSuppressed();
    boolean var18 = var16.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = var16.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var21 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var19, false);
    boolean var23 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var9, var19, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)1, 100, var19, true);
    boolean var27 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var19, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var34 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var35 = var34.getSuppressed();
    boolean var36 = var34.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = var34.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var39 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var37, false);
    boolean var41 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var37, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var6 = var1.nextCauchy(0.75650268282136d, 27.460494254093863d);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var1.nextSample(var7, 0);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     org.apache.commons.math3.distribution.RealDistribution var8 = null;
//     double var9 = var1.nextInversionDeviate(var8);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    long var7 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2776907188931195853L);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
    java.lang.Throwable[] var11 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    double[] var17 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var21 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var22 = org.apache.commons.math3.util.MathArrays.distance(var17, var21);
    double[] var26 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var30 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var26, var30);
    double[] var35 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var39 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var40 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var30, var39);
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var17, var30);
    double[] var46 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var50 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var55 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var59 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var60 = org.apache.commons.math3.util.MathArrays.distance(var55, var59);
    double[] var64 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var68 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var59, var68);
    double var71 = org.apache.commons.math3.util.MathArrays.distance1(var46, var59);
    double[][] var72 = new double[][] { var46};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var72);
    org.apache.commons.math3.exception.MathInternalError var74 = new org.apache.commons.math3.exception.MathInternalError(var13, (java.lang.Object[])var72);
    org.apache.commons.math3.exception.MathIllegalStateException var75 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var12, (java.lang.Object[])var72);
    org.apache.commons.math3.exception.util.ExceptionContext var76 = var75.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.14670562355396907d, var2);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)5, var1, 18);
    boolean var4 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextT(0.007523027327565226d);
//     long var8 = var1.nextLong((-1722448868039600408L), 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.06255758538297275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.7115664949807755E19d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-286027913838884512L));
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.19391506262080332d, 0.32533776112236124d, 0.9066258578518134d, 1.4200682258215138d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.3505584657644873d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.04665318503516837d, 1.0d, 1.560491824001295d, 0.0d, 2.677146259383745d, (-0.2015768976317097d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.49299765243774335d));

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     double[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 1.4184088203104963d};
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var12 = var11.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var12);
//     java.lang.Throwable[] var14 = var6.getSuppressed();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = var6.getDirection();
//     boolean var17 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var15, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var15, false);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    byte[] var5 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var5);
    int var7 = var1.nextInt();
    long var8 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1689900776);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 5921263887411940960L);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     var1.reSeed(26L);
//     var1.reSeed(4901779005301544960L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.7573762511221594d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 147.98997692862494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.3090120983402358d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 731540631, 692191003);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var1.nextPermutation(731540631, (-30245107));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 56L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.12942246356376128d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.2743757491146709d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2940L);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGamma(1.3150901193635438d, 201.22095288793136d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextGamma(5.589878776069069d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 211.7919253643911d);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 7);
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl(var11);
//     int var15 = var12.nextSecureInt((-1), 0);
//     int[] var18 = var12.nextPermutation(10, 8);
//     int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
//     int var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1689900776);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 8);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 8);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     int[] var2 = new int[] { 0, 10};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var4 = null;
//     double var5 = org.apache.commons.math3.util.MathArrays.distance(var3, var4);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double[] var49 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var53 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var54 = org.apache.commons.math3.util.MathArrays.distance(var49, var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var44, var53);
    double var56 = org.apache.commons.math3.util.MathArrays.linearCombination(var31, var44);
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var16, var44);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var7, var44);
    double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var59);
    double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1.7320508075688772d);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     var1.reSeed(66L);
//     double var13 = var1.nextExponential(0.13577924877535585d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextHypergeometric((-30245107), 102762836, 1629366900);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 49L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.031856135671420746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.619733517328313E32d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.006639851549226661d);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4, (-1505764920));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextCauchy(433.8473116074771d, 134.5471615274561d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextBinomial(35839364, 1.6182658289453562d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 346.9222360622919d);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var4 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.90662575f);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    int var6 = var1.nextInt((-1623951277), 10);
    double var9 = var1.nextCauchy(0.4912594112390942d, 0.03449238325907719d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1505764920));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.47158451450145683d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var9.getFirst();
    java.lang.Object var11 = var9.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextCauchy(436827.027760391d, (-0.09614109642992076d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    byte[] var5 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    var1.nextBytes(var12);
    double var15 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.32099235282147576d);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     int var6 = var1.nextInt(100);
//     int[] var9 = new int[] { 0, 10};
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
//     var1.setSeed(var9);
//     float var12 = var1.nextFloat();
//     java.util.List var13 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var14 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var13);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
//     double var2 = var1.nextDouble();
//     var1.clear();
//     int[] var6 = new int[] { 0, 10};
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
//     var1.setSeed(var6);
//     org.apache.commons.math3.random.RandomGenerator var9 = null;
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl(var9);
//     int var13 = var10.nextSecureInt((-1), 0);
//     int[] var16 = var10.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.distance(var6, var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1991753248498107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 11.40175425099138d);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(482806506685451456L, 5921263887411940960L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4189086320134634496L);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-951.5924675673654d), (java.lang.Number)200.40417679089168d, (java.lang.Number)0.9595173058637325d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     int var6 = var1.nextSecureInt(0, 1028812019);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextPascal(692191003, 2.677146259383745d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.9413205639959674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 693870472);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     double var16 = var1.nextUniform(0.4921662174347376d, 44.086886661056695d);
//     var1.reSeedSecure(78L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.2377345594940574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.0749778349521515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.8038079410567367d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 32.392901956609904d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 15.994887085769745d);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    int var4 = var3.getIndex();
    int var5 = var3.getIndex();
    boolean var6 = var3.getStrict();
    java.lang.Number var7 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.005325640742598586d, 126.65787460843954d, 0.02551602800088468d, 131.5692953237559d, 0.0d, 0.5328962565365816d, 200.21530124351486d, (-2988.111794020837d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-598261.6713290205d));

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     double var14 = var1.nextGaussian(0.0714245743247656d, 1.6182658289453562d);
//     double var17 = var1.nextBeta(0.0319217721093273d, 1.56678210454931d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 80L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2504872732210354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9364359062185877d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2838L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.035157804453694194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1L, (java.lang.Number)100L, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1028812019);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.List var3 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var4 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var3);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     double var9 = var1.nextBeta(200.58085083797894d, 0.9991548839151001d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextHypergeometric(12, (-1), (-1623951277));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9998153804720231d);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.9066258578518134d, (java.lang.Number)(-0.12367721872691984d), true);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    float[] var3 = null;
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    float[] var8 = new float[] { 10.0f, 100.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.055342234061093135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.1631524852552153E-9d);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var5.reSeed(19L);
    double var9 = var5.nextExponential(0.1388307343509505d);
    var5.reSeed(77L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.29331957279297216d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0f, (java.lang.Number)(byte)1, true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextInt(1378651682, 692191003);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5654257609969638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.08159635356876824d);
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextCauchy(0.0d, (-0.49299765243774335d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4225463148553522176L);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.17728586563368837d), false);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.4649256620524505d), 0.49712344046407414d, (-2675.9452845590495d), 2.0805938937575448E8d, 1013.3787058370359d, 0.40934924792401617d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-5.567555414936907E11d));

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     var1.reSeed(65L);
//     int var21 = var1.nextBinomial(0, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var23 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4580125855188477952L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9651729010914889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 56.7799552581816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1L, (java.lang.Number)100L, true);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12L);
    int var3 = var1.nextInt(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 58);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     double var13 = var1.nextExponential(8.11989620793123d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextUniform(0.9345220433900091d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 52L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.26520160730673636d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8907497782342692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2849L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19.872130170760986d);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)141.42489172702236d, (java.lang.Number)(byte)10, false);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    boolean var7 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var25);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     int var17 = var1.nextHypergeometric(1689900776, 3, 1378651682);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var1.nextUniform(3.688547965439525d, 0.20201262519206045d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.8375697465428715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 146.7589418283547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.26661736920257717d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.2015768976317097d));
//     java.lang.Throwable[] var6 = var5.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)3.0d, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl(var10);
//     double var13 = var11.nextChiSquare(1.145389752706889d);
//     double var15 = var11.nextChiSquare(1.145389752706889d);
//     double var17 = var11.nextExponential(433.8473116074771d);
//     long var20 = var11.nextLong(32L, 2865512416584424448L);
//     java.lang.String var22 = var11.nextHexString(4);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, (java.lang.Object)4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.082833371580868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0012407997852097038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1503.7081845688251d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2243061314491676928L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "8fee"+ "'", var22.equals("8fee"));
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var61 = org.apache.commons.math3.util.MathArrays.normalizeArray(var45, 1.5324442802669078d);
    java.lang.Comparable[] var66 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var73 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var74 = var73.getSuppressed();
    boolean var75 = var73.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = var73.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var78 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var76, false);
    boolean var80 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var66, var76, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)94.0834911443809d, (java.lang.Number)(-91.85508929238087d), (-1505764920), var76, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var45, var76, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextGamma(0.800421916980158d, (-0.18429215584238368d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4322403068793092096L);
// 
//   }

//  public void test373() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
//
//
//    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 261614908);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var3);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var7);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == 140.0071426749364d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var9 == 141.42489172702236d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var10);
//
//  }
//
  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    int[] var3 = new int[] { 100, 10, 100};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, (-1169327278));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var8 = var1.nextBeta(200.81717002836405d, 0.1991753248498107d);
//     var1.reSeedSecure();
//     int var12 = var1.nextBinomial(0, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextInt(100, 5);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.8586710420624986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9997579963550712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     var1.reSeed(65L);
//     int var21 = var1.nextBinomial(0, 0.0d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextWeibull(0.0d, (-3368.8741687352244d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2290767296966776320L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9517005379490819d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 109.03304948601826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)436827.027760391d);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextGamma(0.9487345360513418d, 2.0805938937575448E8d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextBinomial(731540631, 1426.887198243755d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 35L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03631955845522259d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 201.5542501997613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.894328790239564E8d);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    org.apache.commons.math3.exception.NotPositiveException var20 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03510480520930032d);
    org.apache.commons.math3.util.Pair var21 = new org.apache.commons.math3.util.Pair((java.lang.Object)var18, (java.lang.Object)var20);
    java.lang.Object var22 = var21.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    boolean var5 = var3.getStrict();
    int var6 = var3.getIndex();
    int var7 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.40877557f, var1, false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 0.409 is larger than, or equal to, the maximum (null)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 0.409 is larger than, or equal to, the maximum (null)"));

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    float var12 = var1.nextFloat();
    var1.setSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.40877557f);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var8 = var1.nextBeta(200.81717002836405d, 0.1991753248498107d);
//     var1.reSeedSecure();
//     int var12 = var1.nextBinomial(0, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextBeta(0.0d, 200.42902505131346d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.810989255667956d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9997579963550712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     double var7 = var1.nextUniform(0.0d, 1.3150901193635438d);
//     double var11 = var1.nextUniform(6.033636185499283d, 40.284703565000456d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextSecureInt(1378651682, 659309102);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.136421133211401d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 39.43236001995805d);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//     int[] var13 = new int[] { 0, 10};
//     int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
//     int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var16);
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
//     double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
//     double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var43 = var42.getSuppressed();
//     boolean var44 = var42.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var45 = var42.getDirection();
//     boolean var47 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var45, false);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 0.0d);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
//     boolean var52 = org.apache.commons.math3.util.MathArrays.isMonotonic(var49, var50, false);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var8 = var1.nextBeta(200.81717002836405d, 0.1991753248498107d);
//     var1.reSeedSecure();
//     int var12 = var1.nextBinomial(0, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextHypergeometric(1, 1629366900, 353197573);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.004294167421331349d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9997579963550712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)10, (java.lang.Number)1.9020015664445744d, (-1));
    java.lang.Number var4 = var3.getArgument();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextLong(174L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 697149944254972032L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.5320196696779061d);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, 7);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 7);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     double var6 = var1.nextExponential(0.9487345360513418d);
//     double var9 = var1.nextCauchy(1.5324442802669078d, 2840.6711051053326d);
//     var1.reSeedSecure(85L);
//     double var13 = var1.nextChiSquare(0.05272999253983823d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("c9f482a2f7", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9515946802092295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.35958848280275146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3770.7122227727623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1064217762715997E-9d);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, (-0.9696851998830972d));
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(1028812019);
    var1.setSeed(1);
    long var6 = var1.nextLong();
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var16 = var15.nextInt();
    byte[] var19 = new byte[] { (byte)100, (byte)10};
    var15.nextBytes(var19);
    var8.nextBytes(var19);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var19, (java.lang.Object)0.007523027327565226d);
    var1.nextBytes(var19);
    org.apache.commons.math3.random.RandomDataImpl var25 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var27 = var25.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5141685311728891869L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 731540631, (-30245107));

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double[] var59 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var63 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var64 = org.apache.commons.math3.util.MathArrays.distance(var59, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var54, var63);
    double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var41, var54);
    double var67 = org.apache.commons.math3.util.MathArrays.distance(var26, var54);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var54);
    double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.linearCombination(var54, var72);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var72);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var84 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var88 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var89 = var88.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var90 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var83, var84, (java.lang.Object[])var89);
    java.lang.Throwable[] var91 = var83.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var92 = var83.getDirection();
    org.apache.commons.math3.util.Pair var93 = new org.apache.commons.math3.util.Pair((java.lang.Object)var72, (java.lang.Object)var92);
    org.apache.commons.math3.util.Pair var94 = new org.apache.commons.math3.util.Pair(var93);
    java.lang.Object var95 = var93.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var9);
    java.lang.Object var11 = var10.getKey();
    java.lang.Object var12 = var10.getValue();
    java.lang.Object var13 = var10.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 201.0d+ "'", var12.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(907608747, 8);
//     java.lang.Number var3 = var2.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     long[] var5 = new long[] { };
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
//     long[][] var7 = new long[][] { var5};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var7);
//     var2.addSuppressed((java.lang.Throwable)var9);
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator(var11);
//     double var15 = var12.nextBeta(201.0d, 10.0d);
//     double var17 = var12.nextExponential(0.9487345360513418d);
//     org.apache.commons.math3.util.Pair var18 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, (java.lang.Object)var12);
//     java.lang.Object var19 = var18.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + 907608747+ "'", var3.equals(907608747));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9298969240097741d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.34895104799294213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(1028812019);
    var1.setSeed(1);
    boolean var6 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     java.lang.String var9 = var1.nextHexString(4);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0332654843922763E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "d6c2"+ "'", var9.equals("d6c2"));
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1623951277));
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)50L, (java.lang.Number)10.0f, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Object[] var6 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var6);
// 
//   }

//  public void test402() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
//
//
//    org.apache.commons.math3.random.RandomGenerator var0 = null;
//    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//    var1.reSeed(1L);
//    var1.reSeedSecure();
//    double var7 = var1.nextWeibull(0.03711666723053142d, 0.1945318675277668d);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var10 = var1.nextPermutation(880245310, 108894710);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var7 == 1.1696012973793972E-31d);
//
//  }
//
  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var11 = var1.nextUniform(0.5587862084152698d, 1.5324442802669078d, false);
//     int var14 = var1.nextBinomial(1028812019, 0.034840239579776264d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextSecureLong(7540580061456263210L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 47L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03477018905612087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.3079345436828953d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 35842567);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(855451518, 855451518);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.4246216658271394d));

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)235.48999079421458d, (java.lang.Number)12, 692191003);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(102762836, 10);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    double[] var25 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var29 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var30 = org.apache.commons.math3.util.MathArrays.distance(var25, var29);
    double[] var34 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var38 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var29, var38);
    double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
    double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double[] var62 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var66 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var67 = org.apache.commons.math3.util.MathArrays.distance(var62, var66);
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var57, var66);
    double var69 = org.apache.commons.math3.util.MathArrays.linearCombination(var44, var57);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var29, var57);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var57);
    double[] var75 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var79 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var80 = org.apache.commons.math3.util.MathArrays.distance(var75, var79);
    double var81 = org.apache.commons.math3.util.MathArrays.linearCombination(var57, var75);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var75);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var86 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var87 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var91 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var92 = var91.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var93 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var86, var87, (java.lang.Object[])var92);
    java.lang.Throwable[] var94 = var86.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var95 = var86.getDirection();
    org.apache.commons.math3.util.Pair var96 = new org.apache.commons.math3.util.Pair((java.lang.Object)var75, (java.lang.Object)var95);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var98 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.032179375351228966d, (java.lang.Number)434971L, 692191003, var95, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     double var10 = var1.nextExponential(2.5331613618987565d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.nextSecureInt(1378651682, 12);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.8516419576632375d);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextWeibull(198.0d, 436827.027760391d);
//     long var15 = var1.nextPoisson(0.9998367706742745d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 42L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.029960342148347842d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 198.72961047835153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 435369.21713312366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0L);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var13);
    java.lang.Throwable[] var19 = var18.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    boolean var8 = var6.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)45L, (java.lang.Number)50L, 0, var9, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextUniform(0.029977394192225556d, 126.65787460843954d);
//     double var14 = var1.nextUniform(0.03282615243296957d, 0.034840239579776264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 27.108625880646407d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.03334200658556004d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(41);
    double var4 = var3.nextDouble();
    var3.clear();
    int[] var8 = new int[] { 0, 10};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    var3.setSeed(var8);
    var1.setSeed(var8);
    int var12 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1755678109);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     double var9 = var1.nextBeta(200.58085083797894d, 0.9991548839151001d);
//     long var12 = var1.nextSecureLong(1L, 50L);
//     long var15 = var1.nextLong(26L, 2888L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9930081030798933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1993L);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    org.apache.commons.math3.exception.util.Localizable var30 = null;
    org.apache.commons.math3.exception.util.Localizable var31 = null;
    double[] var35 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var39 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var40 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
    double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
    double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var48, var57);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var35, var48);
    double[] var64 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var68 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double[] var73 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var77 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var73, var77);
    double[] var82 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var86 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var87 = org.apache.commons.math3.util.MathArrays.distance(var82, var86);
    double var88 = org.apache.commons.math3.util.MathArrays.distance1(var77, var86);
    double var89 = org.apache.commons.math3.util.MathArrays.distance1(var64, var77);
    double[][] var90 = new double[][] { var64};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var90);
    org.apache.commons.math3.exception.MathInternalError var92 = new org.apache.commons.math3.exception.MathInternalError(var31, (java.lang.Object[])var90);
    org.apache.commons.math3.exception.MathIllegalStateException var93 = new org.apache.commons.math3.exception.MathIllegalStateException(var30, (java.lang.Object[])var90);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var29, var90);
    double[] var95 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     java.lang.String var9 = var1.nextHexString(4);
//     org.apache.commons.math3.distribution.RealDistribution var10 = null;
//     double var11 = var1.nextInversionDeviate(var10);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.019290119022056726d, var1, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.08522522639280383d, (java.lang.Number)6, false);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     int[] var2 = new int[] { 0, 10};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     int var9 = var6.nextSecureInt((-1), 0);
//     int[] var12 = var6.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     int var14 = org.apache.commons.math3.util.MathArrays.distance1(var4, var12);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var4);
//     java.util.List var16 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var17 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var15, var16);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)10);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.029977394192225556d, (java.lang.Number)1.5324442802669078d, 2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    double[] var10 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var14 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance(var10, var14);
    double[] var19 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var23 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var19, var23);
    double[] var28 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var32 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var28, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var23, var32);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var10, var23);
    double[] var39 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var43 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var39, var43);
    double[] var48 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var52 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var53 = org.apache.commons.math3.util.MathArrays.distance(var48, var52);
    double[] var57 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var61 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var62 = org.apache.commons.math3.util.MathArrays.distance(var57, var61);
    double var63 = org.apache.commons.math3.util.MathArrays.distance1(var52, var61);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var39, var52);
    double[][] var65 = new double[][] { var39};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var10, var65);
    org.apache.commons.math3.exception.MathInternalError var67 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var65);
    org.apache.commons.math3.exception.MathIllegalStateException var68 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, (java.lang.Object[])var65);
    org.apache.commons.math3.exception.MathIllegalStateException var69 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     double var6 = var1.nextExponential(0.9487345360513418d);
//     double var9 = var1.nextCauchy(1.5324442802669078d, 2840.6711051053326d);
//     double var12 = var1.nextUniform(0.016855007404038964d, 2.1042444166006993d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("8fee", "c9f482a2f7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9573083678479926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.228224196946821d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-502.27016231410715d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6163839863372476d);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     int var6 = var1.nextSecureInt(0, 1028812019);
//     var1.reSeed();
//     var1.reSeedSecure(83L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextPascal(58, 1.845734920494461d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.1121136785000664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 899552184);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var16);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 201.0d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(1028812019, 0.0998915660109107d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var2.nextPermutation(8, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 102762836);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     int var11 = var1.nextPascal(10, 0.5587862084152698d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextF(39.41398356875526d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.08728475313516475d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.022989717728565645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var12);
    java.lang.Object[] var14 = new java.lang.Object[] { var12};
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var14);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var14);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var45);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     int var6 = var1.nextInt(100);
//     int[] var9 = new int[] { 0, 10};
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
//     var1.setSeed(var9);
//     long var12 = var1.nextLong();
//     float var13 = var1.nextFloat();
//     java.util.List var14 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var15 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var14);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(1028812019, 0.0998915660109107d);
    double var7 = var2.nextT(0.034840239579776264d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooLargeException: 0.409 is larger than, or equal to, the maximum (null)", "668fa4ae4cde072ab0d2c169fe3ffa8814484af7d");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 102762836);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-91.85508929238087d));

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var8 = var1.nextGaussian(1.0420152193073937d, 1.29910331984832d);
//     int var11 = var1.nextPascal(880245310, 0.1637736129994477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.3661956046707928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2147483647);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextCauchy(4.497671471910009d, (-0.1014977691526634d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    double var4 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2395389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.3934606808571868d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.linearCombination(var45, var63);
    double[] var71 = org.apache.commons.math3.util.MathArrays.normalizeArray(var63, 0.033628253521389304d);
    java.lang.Comparable[] var73 = new java.lang.Comparable[] { 1.4184088203104963d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var77 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var78 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var83 = var82.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var84 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var77, var78, (java.lang.Object[])var83);
    java.lang.Throwable[] var85 = var77.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var86 = var77.getDirection();
    boolean var88 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var73, var86, false);
    boolean var91 = org.apache.commons.math3.util.MathArrays.checkOrder(var63, var86, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var93 = org.apache.commons.math3.util.MathArrays.copyOf(var63, 880245310);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == true);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     double var16 = var1.nextUniform(0.4921662174347376d, 44.086886661056695d);
//     double var18 = var1.nextChiSquare(0.49948825038985073d);
//     var1.reSeed(2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.38853612665832227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.3900651718683252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.4959754782162493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 37.23683624742112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 23.33918726571379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.1901438820506576E-5d);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)0.8018791158561639d, false);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)140.0071426749364d, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 140.0071426749364d+ "'", var4.equals(140.0071426749364d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 140.0071426749364d+ "'", var5.equals(140.0071426749364d));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1629366900);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     double var19 = var1.nextBeta(0.0319217721093273d, 0.326843498449728d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 384826235193078848L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.8682923085545167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 91.54089948517347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0361870758145477E-9d);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.8018791158561639d, (java.lang.Number)0.0319217721093273d, false);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)", "org.apache.commons.math3.exception.NumberIsTooLargeException: 0.409 is larger than, or equal to, the maximum (null)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    java.lang.Object var9 = var6.getSecond();
    java.lang.Object var10 = null;
    boolean var11 = var6.equals(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 201.0d+ "'", var9.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     double var7 = var1.nextUniform(0.0d, 1.3150901193635438d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextBinomial(41, 1.3023515952574023d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.5497094267741327d);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    float[] var3 = null;
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    float[] var8 = new float[] { 10.0f, 100.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var8);
    float[] var13 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var14 = new float[] { };
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var13, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var13);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var13);
    float[] var21 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var22 = new float[] { };
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var22);
    float[] var27 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var28 = new float[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var28);
    float[] var34 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var35 = new float[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var34);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var13, var22);
    float[] var42 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var43 = new float[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    float[] var48 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var49 = new float[] { };
    boolean var50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var48, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var49);
    float[] var55 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var56 = new float[] { };
    boolean var57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var55, var56);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var55);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var22, var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     double var8 = var1.nextCauchy(1.1974284276030979E-9d, 0.3934606808571868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7324720623521701d);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     int var13 = var1.nextHypergeometric(10, 0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("d416d8efd", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 96L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03408076072950711d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2790381386176973E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.9998367706742745d, 3.0d, 0.18912229022911436d, 2.0149753804024266E-96d, 148.80913770781288d, 0.002123327067530301d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.3154807820136662d);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var3.nextExponential(4.497671471910009d);
//     int var8 = var3.nextSecureInt(41, 1629366900);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var3.nextUniform(2840.6711051053326d, (-0.1014977691526634d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5172264847508324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 117599361);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.0361870758145477E-9d);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     double var11 = var1.nextGamma(0.002123327067530301d, 28.607227405226453d);
//     var1.reSeed(68L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.1888614299200695E-10d);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    var1.reSeedSecure();
    long var7 = var1.nextLong(0L, 82L);
    double var10 = var1.nextCauchy(0.03609112308169037d, 0.016855007404038964d);
    double var13 = var1.nextF(98.0d, 0.07645625043058513d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.02647681120026045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.1488774559618734E13d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)88L);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var7 = var5.nextT(2.0805938937575448E8d);
//     int var10 = var5.nextPascal(4, 0.9595173058637325d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var5.nextSample(var11, 731540631);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     long var18 = var1.nextPoisson(0.034840239579776264d);
//     long var20 = var1.nextPoisson(2840.6711051053326d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextUniform(0.17713117444469184d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1568354313484320512L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9451194969967462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 85.09020446135239d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2795L);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(261614908);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)140.0071426749364d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     double var14 = var1.nextGaussian(0.0714245743247656d, 1.6182658289453562d);
//     java.lang.String var16 = var1.nextHexString(10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 85L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.05831133798747233d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7453268923971134d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2838L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.690022483616897d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "e418dfaced"+ "'", var16.equals("e418dfaced"));
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)7, var2);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     double var12 = var1.nextF(0.029977394192225556d, 94.0834911443809d);
//     double var15 = var1.nextUniform((-3368.8741687352244d), 2.1487447713062093d);
//     var1.reSeedSecure();
//     double var19 = var1.nextCauchy(0.47158451450145683d, 7.794554629059993E114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 84L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03390131270999756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.4733070898117541d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4.820633026514478E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-703.4409695007171d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.343743543740839E115d));
// 
//   }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
//     double[] var12 = null;
//     double var13 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var12);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-30245107), (-30245107));
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var11, var12, true);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextGamma(0.9487345360513418d, 2.0805938937575448E8d);
//     double var15 = var1.nextExponential(0.9798395551529173d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextWeibull(0.0d, 37.23683624742112d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 47L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03236953288926733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 203.55459618723276d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3108487784462403E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5960714993409078d);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextInt(1378651682, 261614908);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(49L);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(1028812019);
    var1.setSeed(1);
    double var6 = var1.nextDouble();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var1.nextInt((-1169327278));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2787313252014696d);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var8 = var1.nextGaussian(1.0420152193073937d, 1.29910331984832d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextSecureLong(75L, 46L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.2421685477708548d));
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-1), 108894710);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextGamma(134.5471615274561d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.1504845819780021d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 138.78358923650308d);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.1991753248498107d, (java.lang.Number)4560884032503238656L, 2);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var3.nextExponential(4.497671471910009d);
//     int var8 = var3.nextSecureInt(41, 1629366900);
//     double var11 = var3.nextGaussian(160.94037419925016d, 1.2375875452562675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5172264847508324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 464544813);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 159.7414268489564d);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var12 = var11.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var16);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     double var16 = var1.nextUniform(0.4921662174347376d, 44.086886661056695d);
//     double var19 = var1.nextBeta(11.40175425099138d, 3165323.7539757295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.1983014396786959d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.47933932102560817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.14536762410688497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 38.303756908619334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 30.612117263149702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4.201220679773407E-6d);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var3, var16);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var32, var45);
    double[][] var58 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var58);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, 6.1687580398955015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextGamma(0.9487345360513418d, 2.0805938937575448E8d);
//     double var15 = var1.nextExponential(0.9798395551529173d);
//     double var18 = var1.nextGaussian(0.9345220433900091d, 94.0834911443809d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 23L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03995235002498734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 200.69158924888194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.4884423259479985E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9954119943753462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-175.21299780055995d));
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var43 = var42.getSuppressed();
    boolean var44 = var42.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = var42.getDirection();
    boolean var47 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var45, false);
    double[] var49 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 0.0d);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    int var6 = var1.nextInt((-1623951277), 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var1.nextBinomial(8, 1.5665637811284938d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1505764920));

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var8, var45);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var0, var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var7 = var1.nextExponential(433.8473116074771d);
//     long var10 = var1.nextLong(32L, 2865512416584424448L);
//     java.lang.String var12 = var1.nextHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextHexString((-30245107));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.11208467456263405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.00953650364200008d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 573.153554495818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 133097404561690464L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "6628"+ "'", var12.equals("6628"));
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-5.567555414936907E11d), (java.lang.Number)636254083245766656L, (java.lang.Number)84L);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0998915660109107d, 6.871297324978886E-8d, 2.244546466239121d, 131.74990902618083d, (-8733.082045636873d), 1.845734920494461d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-15823.235702436275d));

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
//     double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
//     double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
//     double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
//     double var39 = org.apache.commons.math3.util.MathArrays.distance1(var28, var37);
//     double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var28);
//     double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
//     double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance1(var48, var57);
//     double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
//     double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var67, var76);
//     double var79 = org.apache.commons.math3.util.MathArrays.distance1(var48, var67);
//     double var80 = org.apache.commons.math3.util.MathArrays.linearCombination(var28, var48);
//     boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var28);
//     double[] var82 = null;
//     double var83 = org.apache.commons.math3.util.MathArrays.distance(var28, var82);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)489564.14665999054d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    var1.reSeedSecure();
    long var7 = var1.nextLong(0L, 82L);
    double var10 = var1.nextCauchy(0.03609112308169037d, 0.016855007404038964d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var1.nextHypergeometric(5, 0, 1532920128);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.02647681120026045d);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     long var6 = var1.nextPoisson(434777.8672564595d);
//     double var9 = var1.nextUniform((-91.85508929238087d), 7.794554629059993E114d);
//     double var12 = var1.nextF(489564.14665999054d, 1.3023515952574023d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9612819245494626d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 434804L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.2137720553529126E114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.2901016280383602d);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var8 = var1.nextBeta(200.81717002836405d, 0.1991753248498107d);
//     var1.reSeedSecure();
//     int var12 = var1.nextBinomial(0, 0.0d);
//     long var14 = var1.nextPoisson(14.370652339149443d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.1722013776235398d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9997579963550712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 12L);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    byte[] var5 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var5);
    var1.setSeed(59L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.343743543740839E115d), (-1.7881833486097136d), (-0.18429215584238368d), 201.59648470932015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.402859829719177E115d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var6 = var5.nextInt();
    byte[] var9 = new byte[] { (byte)100, (byte)10};
    var5.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var13 = var12.nextInt();
    byte[] var16 = new byte[] { (byte)100, (byte)10};
    var12.nextBytes(var16);
    var5.nextBytes(var16);
    org.apache.commons.math3.util.Pair var20 = new org.apache.commons.math3.util.Pair((java.lang.Object)var16, (java.lang.Object)0.007523027327565226d);
    var1.nextBytes(var16);
    float var22 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.39346063f);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     var1.reSeed(65L);
//     int var21 = var1.nextBinomial(0, 0.0d);
//     var1.reSeed();
//     double var24 = var1.nextT(0.7324720623521701d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1639382982828472320L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.7330515909091372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 31.41004007357357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.24769886863969978d);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(94L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var1.nextBinomial((-2104328881), 170.7857280627396d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var3.nextBeta(433.8473116074771d, 1.70318249281768d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.nextGamma((-2.8986490987226393E119d), 2.244546466239121d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9991548839151001d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var25);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 7);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.7320508075688772d);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     double var15 = var1.nextExponential(0.9606147597499597d);
//     double var18 = var1.nextGamma(144.89626164556063d, 0.34895104799294213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.7850724763500969d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 144.5852511045922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.002899844470991556d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5277521571782883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 51.78299387716586d);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     var1.reSeed(26L);
//     org.apache.commons.math3.random.RandomGenerator var16 = null;
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl(var16);
//     double var19 = var17.nextChiSquare(1.145389752706889d);
//     double var21 = var17.nextChiSquare(1.145389752706889d);
//     double var24 = var17.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var27 = var17.nextZipf(2, 0.8082030461156922d);
//     double var29 = var17.nextChiSquare(45.24674473641221d);
//     org.apache.commons.math3.util.Pair var30 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var17);
//     long var33 = var1.nextSecureLong(0L, 2857L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1058395307532054d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 140.06330634687643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.15599179933981247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.9189969644545162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.14895193982676458d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.321336712852131d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 63.60509330300895d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1715L);
// 
//   }

}
