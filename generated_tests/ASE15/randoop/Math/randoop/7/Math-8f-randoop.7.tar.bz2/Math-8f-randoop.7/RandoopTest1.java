
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var3, var16);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double[] var61 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var65 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double[] var70 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var74 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var70, var74);
    double var76 = org.apache.commons.math3.util.MathArrays.distance1(var65, var74);
    double[] var80 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var84 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var85 = org.apache.commons.math3.util.MathArrays.distance(var80, var84);
    double[] var89 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var93 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var94 = org.apache.commons.math3.util.MathArrays.distance(var89, var93);
    double var95 = org.apache.commons.math3.util.MathArrays.distance1(var84, var93);
    double var96 = org.apache.commons.math3.util.MathArrays.distance1(var65, var84);
    double var97 = org.apache.commons.math3.util.MathArrays.linearCombination(var45, var65);
    double[] var98 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextF(0.9401972627048174d, (-1.343743543740839E115d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.660107911410881d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.640055076258829d));
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     var1.reSeed();
//     var1.reSeedSecure(19L);
//     double var17 = var1.nextF(0.2901016280383602d, 3.2699480464074356E114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.8315644433805597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5160015492949894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.3309794741553644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.10201244888124232d);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var12);
    java.lang.Object[] var14 = new java.lang.Object[] { var12};
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)3, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.10201244888124232d);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     double var13 = var1.nextExponential(8.11989620793123d);
//     long var16 = var1.nextLong((-1L), 77L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextUniform(148667.53843714943d, 235.48999079421458d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 43L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7069991763206456d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.70654833201008d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2753L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 17.62660437474383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 36L);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     int var9 = var1.nextBinomial(1, 1.0d);
//     double var12 = var1.nextGaussian(0.02551602800088468d, 0.1945318675277668d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2344.359608292941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7168703690201694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.3085671731829579d));
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    java.lang.Object var9 = var6.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var16.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(26.249529082046173d, 1.9189969644545162d, 200.81717002836405d, 0.07645625043058513d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 65.72649446925715d);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var7 = var1.nextExponential(433.8473116074771d);
//     long var10 = var1.nextLong(32L, 2865512416584424448L);
//     java.lang.String var12 = var1.nextHexString(4);
//     var1.reSeed(5141685311728891869L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.22676278012252432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.17966370825140088d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1051.7774912737136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1000377182327320064L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "9592"+ "'", var12.equals("9592"));
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var28, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var28);
    double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
    double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var48, var57);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.distance1(var67, var76);
    double var79 = org.apache.commons.math3.util.MathArrays.distance1(var48, var67);
    double var80 = org.apache.commons.math3.util.MathArrays.linearCombination(var28, var48);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var11);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    float[] var3 = null;
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    float[] var8 = new float[] { 10.0f, 100.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var8);
    float[] var13 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var14 = new float[] { };
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var13, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var13);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var13);
    float[] var21 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var22 = new float[] { };
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var22);
    float[] var27 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var28 = new float[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var28);
    float[] var34 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var35 = new float[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var34);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var13, var22);
    float[] var39 = null;
    float[] var40 = new float[] { };
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var39, var40);
    float[] var44 = new float[] { 10.0f, 100.0f};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var39, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var13, var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var12.nextSecureLong(2L, (-508716120208475904L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)10, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 100, 41);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 41);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextSecureLong(1549759351893267712L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.23292931635961484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.7995636574694838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.20598448457409751d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     double var9 = var1.nextBeta(200.58085083797894d, 0.9991548839151001d);
//     long var12 = var1.nextSecureLong(1L, 50L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextGamma((-1.5982505015077922E15d), 0.31804493603716955d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9980950287378498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5L);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    double[] var1 = new double[] { 0.0d};
    double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var28, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var28);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var10, var15);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var15);
    double[] var46 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var50 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var55 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var59 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var60 = org.apache.commons.math3.util.MathArrays.distance(var55, var59);
    double[] var64 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var68 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double[] var73 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var77 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var73, var77);
    double var79 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
    double var80 = org.apache.commons.math3.util.MathArrays.linearCombination(var55, var68);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var50, var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var15, var55);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     java.lang.String var11 = var1.nextHexString(76825519);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 11L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.037761262229646486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.6476808502706696E35d);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 0);
    int[] var8 = new int[] { 0, 10};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var2, var9);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var14 = var13.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var15 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var13);
    long var16 = var13.nextLong();
    int var18 = var13.nextInt(100);
    int[] var21 = new int[] { 0, 10};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    var13.setSeed(var21);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var27 = var26.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var28 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var26);
    long var29 = var26.nextLong();
    int var31 = var26.nextInt(100);
    int[] var34 = new int[] { 0, 10};
    int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var34);
    var26.setSeed(var34);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var34);
    int[] var40 = new int[] { 0, 10};
    int[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    double var42 = org.apache.commons.math3.util.MathArrays.distance(var34, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var21, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     double var13 = var1.nextExponential(8.11989620793123d);
//     double var16 = var1.nextBeta(0.75650268282136d, 0.039691703214181015d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var1.nextLong(482806506685451456L, 482806506685451456L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 94L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.09108769555930858d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6236983881412635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2804L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.659578565250095d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.992657407767861d);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(1028812019);
    var1.setSeed(1);
    long var6 = var1.nextLong();
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var16 = var15.nextInt();
    byte[] var19 = new byte[] { (byte)100, (byte)10};
    var15.nextBytes(var19);
    var8.nextBytes(var19);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var19, (java.lang.Object)0.007523027327565226d);
    var1.nextBytes(var19);
    org.apache.commons.math3.random.RandomDataImpl var25 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var26 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5141685311728891869L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.7528026535264862d);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextWeibull(198.0d, 436827.027760391d);
//     long var15 = var1.nextPoisson(0.9998367706742745d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var1.nextLong(4819128677742066688L, 65L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 31L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03967377226028068d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 201.68486338384744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 435798.2765852495d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2L);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(855888619);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     var1.reSeed(66L);
//     double var13 = var1.nextExponential(0.13577924877535585d);
//     int var16 = var1.nextPascal(9, 0.17928310857166874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 39L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.02946791864504028d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3.074221638839909E8d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.006639851549226661d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 42);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, 0);
    java.lang.Number var3 = var2.getArgument();
    java.lang.Number var4 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1+ "'", var3.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1+ "'", var4.equals(1));

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
//     double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
//     double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
//     double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
//     double var39 = org.apache.commons.math3.util.MathArrays.distance1(var28, var37);
//     double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var28);
//     double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
//     double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance1(var48, var57);
//     double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
//     double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var67, var76);
//     double var79 = org.apache.commons.math3.util.MathArrays.distance1(var48, var67);
//     double var80 = org.apache.commons.math3.util.MathArrays.linearCombination(var28, var48);
//     boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var28);
//     double[] var82 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var11, var82);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.9685374826344926d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextUniform(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.046805438209400155d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 146.96794974456122d);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(9, 1629366900);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(1028812019, 0.0998915660109107d);
    double var8 = var2.nextF(0.035157804453694194d, 222.52139753165895d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 102762836);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.5310042397263528E-9d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { (-0.1722013776235398d)};
    double[] var5 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var9 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var10 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var5);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var19, var28);
    double[] var34 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var38 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double[] var43 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var47 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var43, var47);
    double[] var52 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var56 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var52, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var47, var56);
    double var59 = org.apache.commons.math3.util.MathArrays.linearCombination(var34, var47);
    double var60 = org.apache.commons.math3.util.MathArrays.distance(var19, var47);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeDivide(var5, var47);
    double[] var65 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var69 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var65, var69);
    double var71 = org.apache.commons.math3.util.MathArrays.linearCombination(var47, var65);
    double[] var73 = org.apache.commons.math3.util.MathArrays.normalizeArray(var65, 0.033628253521389304d);
    java.lang.Comparable[] var75 = new java.lang.Comparable[] { 1.4184088203104963d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var79 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var80 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var84 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var85 = var84.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var86 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var79, var80, (java.lang.Object[])var85);
    java.lang.Throwable[] var87 = var79.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var88 = var79.getDirection();
    boolean var90 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var75, var88, false);
    boolean var93 = org.apache.commons.math3.util.MathArrays.checkOrder(var65, var88, false, true);
    boolean var95 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var88, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == true);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    double[] var1 = new double[] { 0.0d};
    double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 1.087776523405259d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1378651682);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)201.0d);
    boolean var9 = var7.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var7);
    java.lang.Object var11 = null;
    boolean var12 = var10.equals(var11);
    java.lang.Object var13 = var10.getSecond();
    java.lang.Object var14 = var10.getFirst();
    org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair((java.lang.Object)27.460494254093863d, (java.lang.Object)var10);
    java.lang.Object var16 = var15.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 201.0d+ "'", var13.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     var1.reSeedSecure(2888L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0910649462982517E-9d);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//     int[] var13 = new int[] { 0, 10};
//     int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
//     org.apache.commons.math3.random.RandomGenerator var16 = null;
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl(var16);
//     int var20 = var17.nextSecureInt((-1), 0);
//     int[] var23 = var17.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
//     int var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var23);
//     int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 30240769);
//     int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 907608747);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 6);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var16);
    double var29 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var31 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, (-0.9080664008124023d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextUniform(0.5587862084152698d, 201.22095288793136d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextZipf(0, 0.016855007404038964d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7.2718526219961594d);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.2015768976317097d));
    boolean var2 = var1.getBoundIsAllowed();
    boolean var3 = var1.getBoundIsAllowed();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    double var2 = var1.nextDouble();
    byte[] var6 = new byte[] { (byte)100, (byte)100, (byte)10};
    var1.nextBytes(var6);
    int[] var10 = new int[] { 0, 10};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    var1.setSeed(var11);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(1629366900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.linearCombination(var45, var63);
    double[] var71 = org.apache.commons.math3.util.MathArrays.normalizeArray(var63, 0.033628253521389304d);
    java.lang.Comparable[] var73 = new java.lang.Comparable[] { 1.4184088203104963d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var77 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var78 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var83 = var82.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var84 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var77, var78, (java.lang.Object[])var83);
    java.lang.Throwable[] var85 = var77.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var86 = var77.getDirection();
    boolean var88 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var73, var86, false);
    boolean var91 = org.apache.commons.math3.util.MathArrays.checkOrder(var63, var86, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var63);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == true);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var16);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var3, var36);
    double[] var52 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var56 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var52, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var36, var52);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var59, (-1169327278));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(41);
    double var4 = var3.nextDouble();
    var3.clear();
    int[] var8 = new int[] { 0, 10};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    var3.setSeed(var8);
    var1.setSeed(var8);
    var1.setSeed(0L);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var9 = var1.nextLong(22L, 32L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 27L);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    byte[] var5 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    var1.nextBytes(var12);
    var1.setSeed(659309102);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var20 = var18.nextInt(1028812019);
    var18.setSeed(1);
    long var23 = var18.nextLong();
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var26 = var25.nextInt();
    byte[] var29 = new byte[] { (byte)100, (byte)10};
    var25.nextBytes(var29);
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var33 = var32.nextInt();
    byte[] var36 = new byte[] { (byte)100, (byte)10};
    var32.nextBytes(var36);
    var25.nextBytes(var36);
    org.apache.commons.math3.util.Pair var40 = new org.apache.commons.math3.util.Pair((java.lang.Object)var36, (java.lang.Object)0.007523027327565226d);
    var18.nextBytes(var36);
    var1.nextBytes(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5141685311728891869L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     int var6 = var1.nextSecureInt(0, 1028812019);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextCauchy(94.0834911443809d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.22609204875606295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 286647445);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     var1.reSeedSecure();
//     long var10 = var1.nextLong((-1538904934532245248L), 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.3337379438244791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 152.00431209997905d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-248896021020807360L));
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     double var12 = var1.nextF(0.029977394192225556d, 94.0834911443809d);
//     double var15 = var1.nextUniform((-3368.8741687352244d), 2.1487447713062093d);
//     var1.reSeedSecure();
//     double var18 = var1.nextChiSquare(238.39792420612676d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextUniform(0.4900218365169397d, 0.033628253521389304d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 88L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.02902149977769446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9.262793553062426E21d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-222.0309135377281d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 264.528402717841d);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     int var6 = var1.nextSecureInt(0, 1028812019);
//     var1.reSeed();
//     var1.reSeedSecure(83L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextT((-2782.713527117665d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.4915317112797131d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 862453794);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)200.42902505131346d, (java.lang.Number)437520.3234163918d, (java.lang.Number)10.0d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    byte[] var5 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    var1.nextBytes(var12);
    org.apache.commons.math3.util.Pair var16 = new org.apache.commons.math3.util.Pair((java.lang.Object)var12, (java.lang.Object)0.007523027327565226d);
    java.lang.Object var17 = var16.getSecond();
    org.apache.commons.math3.util.Pair var18 = new org.apache.commons.math3.util.Pair(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 0.007523027327565226d+ "'", var17.equals(0.007523027327565226d));

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int[] var5 = new int[] { 0, 10};
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
//     int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
//     var1.setSeed(var6);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl(var10);
//     int var14 = var11.nextSecureInt((-1), 0);
//     int[] var17 = var11.nextPermutation(10, 8);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 0);
//     int[] var23 = new int[] { 0, 10};
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
//     int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
//     org.apache.commons.math3.random.RandomGenerator var26 = null;
//     org.apache.commons.math3.random.RandomDataImpl var27 = new org.apache.commons.math3.random.RandomDataImpl(var26);
//     int var30 = var27.nextSecureInt((-1), 0);
//     int[] var33 = var27.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var33);
//     int var35 = org.apache.commons.math3.util.MathArrays.distance1(var25, var33);
//     int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 30240769);
//     int var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var33);
//     int var39 = org.apache.commons.math3.util.MathArrays.distance1(var6, var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 17);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     long var8 = var1.nextLong(50L, 88L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextGamma(3.217280193035311E-5d, (-0.18429215584238368d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.6426945171232131d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 65L);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     var1.reSeed();
//     int var15 = var1.nextInt(1, 1689900776);
//     double var18 = var1.nextBeta(0.7528026535264862d, 0.41003356388866874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.115246734875563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7277501822409892d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.11501799940612883d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1397411844);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.8046233673116935d);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var3 = var1.nextInt(1028812019);
//     var1.setSeed(1);
//     long var6 = var1.nextLong();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var9 = var8.nextInt();
//     byte[] var12 = new byte[] { (byte)100, (byte)10};
//     var8.nextBytes(var12);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var16 = var15.nextInt();
//     byte[] var19 = new byte[] { (byte)100, (byte)10};
//     var15.nextBytes(var19);
//     var8.nextBytes(var19);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var19, (java.lang.Object)0.007523027327565226d);
//     var1.nextBytes(var19);
//     float var25 = var1.nextFloat();
//     var1.setSeed(8);
//     java.util.List var28 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var29 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var28);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var3 = var1.nextInt(1028812019);
//     var1.setSeed(1);
//     double var6 = var1.nextDouble();
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var7);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1051.7774912737136d);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextGamma(0.9487345360513418d, 2.0805938937575448E8d);
//     double var15 = var1.nextExponential(0.9798395551529173d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextPascal(0, 0.36090396144204023d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 35L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.02948834421008696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 200.52640598946894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.9496816315285736E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7974126653901435d);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     double var7 = var1.nextCauchy(0.1945318675277668d, 1426.887198243755d);
//     double var9 = var1.nextExponential(1.0420152193073937d);
//     double var11 = var1.nextExponential(0.9991548839151001d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1735.0073134974334d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6901272393728562d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.3355457447479484d);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     double var13 = var1.nextExponential(8.11989620793123d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextBeta(0.4921662174347376d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 88L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0826190007539475d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3010397301132848d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2828L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1721029902434894d);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1623951277), 659309102);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     double var6 = var1.nextT(1.0d);
//     java.lang.String var8 = var1.nextHexString(10);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var19 = var18.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var13, var14, (java.lang.Object[])var19);
//     java.lang.Throwable[] var21 = var13.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-2988.111794020837d), (java.lang.Object[])var21);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 74.36953870845406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.727454634066242d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "79ddff2083"+ "'", var8.equals("79ddff2083"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     long var6 = var1.nextPoisson(434777.8672564595d);
//     int var9 = var1.nextPascal(564429813, 0.9641660113674045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9727702314764002d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 435808L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 20976499);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(102762836, 10);
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 102,762,836 != 10"+ "'", var3.equals("org.apache.commons.math3.exception.DimensionMismatchException: 102,762,836 != 10"));

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var7 = var1.nextT(2.0805938937575448E8d);
//     int var10 = var1.nextSecureInt(35839364, 907608747);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.8952814046994416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.581236713571425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.1811099348517762d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 47962530);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var1.nextHexString((-30245107));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.019927811520768918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.2883290451030823d);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var5.nextT(2.0805938937575448E8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var5.nextPascal(2147483647, 6.356995742044212E8d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.4649256620524505d));

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl(var1);
//     int var5 = var2.nextSecureInt((-1), 0);
//     int[] var8 = var2.nextPermutation(10, 8);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
//     double var12 = org.apache.commons.math3.util.MathArrays.distance(var0, var8);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)10, (java.lang.Number)1.9020015664445744d, (-1));
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var61 = org.apache.commons.math3.util.MathArrays.normalizeArray(var45, 1.5324442802669078d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var61);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotANumberException var2 = new org.apache.commons.math3.exception.NotANumberException();
    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var10, var19);
    org.apache.commons.math3.exception.NotPositiveException var23 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03510480520930032d);
    org.apache.commons.math3.util.Pair var24 = new org.apache.commons.math3.util.Pair((java.lang.Object)var21, (java.lang.Object)var23);
    var2.addSuppressed((java.lang.Throwable)var23);
    java.lang.Throwable[] var26 = var2.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var27 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)145.75115125183055d, (java.lang.Object[])var26);
    org.apache.commons.math3.exception.MathIllegalArgumentException var28 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var13 = var1.nextT(1.4184088203104963d);
//     double var16 = var1.nextF(0.9338216241499386d, 0.75650268282136d);
//     double var18 = var1.nextExponential(1.6436245968414982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3162103359770720256L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.3279960104196653d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.08243460838862714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0667899396187497d);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.31804493603716955d, 3.7618551512431844d, 19.187896974239802d, 0.6901272393728562d, 0.033512180789649695d, 0.0d, 0.8473347092987995d, 0.8046233673116935d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 15.120314656197205d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)94.0834911443809d, (java.lang.Number)7, (java.lang.Number)200.81717002836405d);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 200.81717002836405d+ "'", var4.equals(200.81717002836405d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 7+ "'", var5.equals(7));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 7+ "'", var6.equals(7));

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextUniform(0.5587862084152698d, 201.22095288793136d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextBinomial((-1), 0.025819867448242714d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 142.20941573693915d);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     int var5 = var2.nextSecureInt(692191003, 907608747);
//     double var8 = var2.nextF(148667.53843714943d, 98624.34872685173d);
//     double var10 = var2.nextChiSquare(0.9807757175132036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1219167678));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 875046671);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9973549356716908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5530701871271959d);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var7 = var1.nextT(4.2137720553529126E114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.855899087547689d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-5.1258395853151056E-11d));
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1104140038992463488L);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     double var19 = var1.nextGaussian(1.082833371580868d, 153.55465926701496d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextUniform(152.13868512060463d, 0.0866828383904682d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3172616567095074816L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.8599617357944123d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 22.018071455037198d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 106.8843531742253d);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var7 = var1.nextExponential(433.8473116074771d);
//     long var10 = var1.nextLong(32L, 2865512416584424448L);
//     java.lang.String var12 = var1.nextHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("8fee", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.24541792800284584d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.2541178195850807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 518.2971007530003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2090231158183689216L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "ddbb"+ "'", var12.equals("ddbb"));
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     long var9 = var1.nextPoisson(0.7861058764731469d);
//     long var11 = var1.nextPoisson(4.317592544396895d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.5280328277083841E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(1028812019, 0.0998915660109107d);
    double var7 = var2.nextT(0.034840239579776264d);
    double var10 = var2.nextF(0.11598742873037599d, 147.98997692862494d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextInt(692191003, 30240769);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 102762836);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-91.85508929238087d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.1237743699467411E-9d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     var1.reSeed(65L);
//     int var21 = var1.nextBinomial(0, 0.0d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var1.nextHypergeometric(42, 30240769, 1629366900);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 208391468509282432L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.2784874070935728d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 52.77272781425887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     double var7 = var1.nextUniform(0.0d, 1.3150901193635438d);
//     double var10 = var1.nextF(4.140285621523964E-13d, 2.1042444166006993d);
//     java.lang.String var12 = var1.nextHexString(6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.37904438697113213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.8096525213976357E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "62625a"+ "'", var12.equals("62625a"));
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    java.lang.Number var0 = null;
    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double var12 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var16 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var20 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var16, var20);
    double[] var25 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var29 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var30 = org.apache.commons.math3.util.MathArrays.distance(var25, var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var20, var29);
    double[] var35 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var39 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var40 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
    double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
    double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var48, var57);
    double var60 = org.apache.commons.math3.util.MathArrays.linearCombination(var35, var48);
    double var61 = org.apache.commons.math3.util.MathArrays.distance(var20, var48);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var48);
    java.lang.Comparable[] var64 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var71 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var72 = var71.getSuppressed();
    boolean var73 = var71.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var74 = var71.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var76 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var74, false);
    boolean var78 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var64, var74, true);
    boolean var81 = org.apache.commons.math3.util.MathArrays.checkOrder(var62, var74, false, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)222.52139753165895d, 108894710, var74, false);
    java.lang.String var84 = var83.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var84 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 108,894,709 and 108,894,710 are not increasing (222.521 > null)"+ "'", var84.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 108,894,709 and 108,894,710 are not increasing (222.521 > null)"));

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(184.2894949557855d);
//     double var6 = var1.nextGaussian(1.6250521118938452E8d, 0.03510480520930032d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 165L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.6250521119041842E8d);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    long var12 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var13 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var15 = var1.nextInt(464544813);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 224787129);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)50L, (java.lang.Number)10.0f, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMin();
    java.lang.Number var7 = var4.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0f+ "'", var6.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0f+ "'", var7.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     long var9 = var1.nextPoisson(0.7861058764731469d);
//     var1.reSeed();
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("62625a", "9592");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var5.nextT(2.0805938937575448E8d);
    int var10 = var5.nextPascal(4, 0.9595173058637325d);
    double var13 = var5.nextGamma(0.08522522639280383d, 4.4884423259479985E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.4649256620524505d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 102408.01017573195d);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     int var6 = var1.nextSecureInt(0, 1028812019);
//     var1.reSeed();
//     double var10 = var1.nextGaussian(0.2787313252014696d, 134.5471615274561d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.589391508872641d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 861133202);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 60.17437051555126d);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var8 = var1.nextBeta(200.81717002836405d, 0.1991753248498107d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextGaussian(0.7061543173239464d, (-0.11501799940612883d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9064521417017025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9997579963550712d);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     int var11 = var1.nextPascal(10, 0.5587862084152698d);
//     double var13 = var1.nextChiSquare(0.9991548839151001d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextZipf((-1623951277), (-5.567555414936907E11d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.2609301722359172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.10113486756379196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.3783538723594555d);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 9, 1483429225);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.3934606808571868d, (java.lang.Number)25.96343796727935d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
//     double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     double[] var14 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var18 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var19 = org.apache.commons.math3.util.MathArrays.distance(var14, var18);
//     double[] var23 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var27 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var18, var27);
//     double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
//     double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
//     double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
//     double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
//     double var58 = org.apache.commons.math3.util.MathArrays.linearCombination(var33, var46);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance(var18, var46);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var46);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var46, 1.5324442802669078d);
//     double var63 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var46);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(6108845, 1397411844);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.70318249281768d, (java.lang.Number)4.317592544396895d, false);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 855888619);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     int var5 = var2.nextSecureInt(692191003, 907608747);
//     double var8 = var2.nextF(148667.53843714943d, 98624.34872685173d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var2.nextHypergeometric(1272500942, 1532920128, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-382406730));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 844855852);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0075825503514566d);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1028812019, 514406009);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.082833371580868d, (java.lang.Number)58, (java.lang.Number)0.2924316134787679d);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     double var10 = var1.nextExponential(2.5331613618987565d);
//     double var13 = var1.nextBeta(3.910310725123449d, 1.7619943088504275d);
//     java.lang.String var15 = var1.nextSecureHexString(2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.5707319577791172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.9341742757185967d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "49"+ "'", var15.equals("49"));
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     double var4 = var1.nextT(2.0805938945797375E8d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextBeta(0.8682923085545167d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.7127504913616968d);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.025819867448242714d);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.025819867448242714d+ "'", var2.equals(0.025819867448242714d));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1640.20711766643d));

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var5.nextT(2.0805938937575448E8d);
    double var9 = var5.nextChiSquare(0.9954119943753462d);
    double var13 = var5.nextUniform(0.1983014396786959d, 0.25063865984365247d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.4649256620524505d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.043086182780309096d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.22851895421115465d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.1983014396786959d, 4.0200632148206875E7d, 6.033636185499283d, 0.0d, (-1.26973445799314d), 0.0d, 0.08522522639280383d, 0.7573762511221594d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7971843.295530652d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }
// 
// 
//     org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
//     java.lang.Throwable var1 = null;
//     var0.addSuppressed(var1);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)880245310, (java.lang.Number)0.04590135295676213d, (java.lang.Number)0.05044619811896476d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)141.15466586111373d, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var13);
    java.lang.Object[] var15 = new java.lang.Object[] { var13};
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var15);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)731540631, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     var1.reSeed(26L);
//     org.apache.commons.math3.random.RandomGenerator var16 = null;
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl(var16);
//     double var19 = var17.nextChiSquare(1.145389752706889d);
//     double var21 = var17.nextChiSquare(1.145389752706889d);
//     double var24 = var17.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var27 = var17.nextZipf(2, 0.8082030461156922d);
//     double var29 = var17.nextChiSquare(45.24674473641221d);
//     org.apache.commons.math3.util.Pair var30 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var17);
//     java.lang.Object var31 = var30.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.16474985602052872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 133.71552833463434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6008196088319883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.4022323417212943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.07931118182576716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.4847456497749198d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 51.110525772770934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var5.nextT(2.0805938937575448E8d);
    double var9 = var5.nextChiSquare(0.9954119943753462d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var5.nextHypergeometric(3615507, 514406009, 1272500942);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.4649256620524505d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.043086182780309096d);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     java.util.List var2 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var3 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var3 = var1.nextInt(1028812019);
//     var1.setSeed(1);
//     long var6 = var1.nextLong();
//     boolean var7 = var1.nextBoolean();
//     int var9 = var1.nextInt(1755678109);
//     java.util.List var10 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var11 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-569181736), 12);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     double var15 = var1.nextExponential(0.9606147597499597d);
//     var1.reSeed(1104140038992463488L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.3333458103619088d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 138.36901804373372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.18184194819746674d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.138003401968329d);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var4, var17);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var33, var46);
    double[][] var59 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var59);
    org.apache.commons.math3.exception.MathIllegalStateException var61 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var59);
    org.apache.commons.math3.exception.util.ExceptionContext var62 = var61.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var63 = var61.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var64 = var61.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var8 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance(var4, var8);
//     double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
//     double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
//     double var29 = org.apache.commons.math3.util.MathArrays.linearCombination(var4, var17);
//     java.lang.Comparable[] var34 = new java.lang.Comparable[] { 0.03282615243296957d};
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var41 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var42 = var41.getSuppressed();
//     boolean var43 = var41.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var44 = var41.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var44, false);
//     boolean var48 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var34, var44, true);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var50 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)1, 100, var44, true);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var17, var44, false);
//     double var53 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var17);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var4 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)10, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0L, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var9.getFirst();
    java.lang.Object var11 = null;
    boolean var12 = var9.equals(var11);
    java.lang.Object var13 = var9.getValue();
    java.lang.Object var14 = var9.getKey();
    java.lang.Object var15 = var9.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 201.0d+ "'", var13.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 201.0d+ "'", var15.equals(201.0d));

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-2.8986490987226393E119d));

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)14.156746852520266d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = null;
    boolean var11 = var9.equals(var10);
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     int var5 = var2.nextSecureInt(692191003, 907608747);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var2.nextInt(907608747, 659309102);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1248788712));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 761223903);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    float[] var5 = new float[] { 10.0f, 100.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var5);
    float[] var10 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var11 = new float[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var14 = null;
    float[] var15 = new float[] { };
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var15);
    float[] var17 = null;
    float[] var18 = new float[] { };
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var18);
    float[] var22 = new float[] { 10.0f, 100.0f};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var22);
    float[] var27 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var28 = new float[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var22, var27);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var27);
    float[] var35 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var36 = new float[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var36);
    float[] var41 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var42 = new float[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var42);
    float[] var48 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var49 = new float[] { };
    boolean var50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var48, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var48);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var27, var36);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var7 = var6.getSuppressed();
//     org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)201.0d);
//     org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.9681755253392977d, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
//     java.lang.String var12 = var11.toString();
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var5.nextInt(907608747, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    float[] var5 = new float[] { 10.0f, 100.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var5);
    float[] var10 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var11 = new float[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var14 = null;
    float[] var15 = new float[] { };
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var15);
    float[] var19 = new float[] { 10.0f, 100.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var10, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var35);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var7, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var7);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1169327278), 1378651682);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var10 = var9.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException();
//     var4.addSuppressed((java.lang.Throwable)var12);
//     boolean var14 = var4.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = var4.getDirection();
//     boolean var17 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var15, true);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var3.nextExponential(4.497671471910009d);
//     int var8 = var3.nextSecureInt(41, 1629366900);
//     int var11 = var3.nextBinomial(102762836, 0.035179478860137996d);
//     double var14 = var3.nextWeibull(7.794554629059993E114d, 1.4685833464640283d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var3.nextUniform(2.3523601350829413d, (-1.7881833486097136d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5172264847508324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 834566500);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3615507);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.4685833464640283d);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(27.460494254093863d, 0.9999999980673456d, 0.033628253521389304d, 0.32099235282147576d, 0.9472890462734886d, 32.392901956609904d, 0.5530701871271959d, 0.13577924877535585d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 58.23182526827712d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var1.nextInt(108894710, 47962530);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var3 = var1.nextInt(1028812019);
//     var1.setSeed(1);
//     long var6 = var1.nextLong();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var9 = var8.nextInt();
//     byte[] var12 = new byte[] { (byte)100, (byte)10};
//     var8.nextBytes(var12);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var16 = var15.nextInt();
//     byte[] var19 = new byte[] { (byte)100, (byte)10};
//     var15.nextBytes(var19);
//     var8.nextBytes(var19);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var19, (java.lang.Object)0.007523027327565226d);
//     var1.nextBytes(var19);
//     org.apache.commons.math3.random.RandomDataImpl var25 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.Collection var26 = null;
//     java.lang.Object[] var28 = var25.nextSample(var26, 0);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1028812019);
    int var2 = var1.nextInt();
    int[] var5 = new int[] { 0, 10};
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var11 = var10.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var10);
    long var13 = var10.nextLong();
    int var15 = var10.nextInt(100);
    int[] var18 = new int[] { 0, 10};
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    var10.setSeed(var18);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var18);
    int[] var24 = new int[] { 0, 10};
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var18, var25);
    org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var29 = var28.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var30 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var28);
    long var31 = var28.nextLong();
    int var33 = var28.nextInt(100);
    int[] var36 = new int[] { 0, 10};
    int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    var28.setSeed(var36);
    org.apache.commons.math3.random.Well19937c var39 = new org.apache.commons.math3.random.Well19937c(var36);
    int[] var42 = new int[] { 0, 10};
    int[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var36, var43);
    int var45 = org.apache.commons.math3.util.MathArrays.distance1(var25, var43);
    int var46 = org.apache.commons.math3.util.MathArrays.distance1(var6, var43);
    var1.setSeed(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1169327278));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)10, (java.lang.Number)1.9020015664445744d, (-1));
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var45);
    double[] var64 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var68 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double var70 = org.apache.commons.math3.util.MathArrays.linearCombination(var60, var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 201.0d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var11);
    java.lang.Throwable[] var13 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-2988.111794020837d), (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)42L, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3L);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
//     double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
//     double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
//     double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
//     double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
//     double[] var59 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var63 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var64 = org.apache.commons.math3.util.MathArrays.distance(var59, var63);
//     double var65 = org.apache.commons.math3.util.MathArrays.distance1(var54, var63);
//     double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var41, var54);
//     double var67 = org.apache.commons.math3.util.MathArrays.distance(var26, var54);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var54);
//     double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.linearCombination(var54, var72);
//     double[] var79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var72);
//     double[] var80 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var81 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var72, var80);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     int var13 = var1.nextHypergeometric(10, 0, 1);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03421277657519566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3.8261378360024128d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     double var16 = var1.nextUniform(0.4921662174347376d, 44.086886661056695d);
//     java.lang.String var18 = var1.nextHexString(102762836);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.4809950318569278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.1851256320131205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.037491676371315924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 42.41560288326284d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.635959825624703d);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     int var13 = var1.nextHypergeometric(10, 0, 1);
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var1.nextInversionDeviate(var14);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextT(0.007523027327565226d);
//     double var8 = var1.nextGamma(1.7320508075688772d, 1.3150901193635438d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextSecureInt(855451518, 9);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.66639196522181E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.392465381858901E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.3707041817732746d);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     double var12 = var1.nextF(0.029977394192225556d, 94.0834911443809d);
//     double var15 = var1.nextWeibull(1.8551847961043366d, 52.553790082113515d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextF(1.0738576919282752d, (-1.8038079410567367d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 77L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.027307371097683643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 43.641018365175185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 45.69442446367659d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 84.47456546225594d);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     var1.reSeed(49L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.03065673795407664d, (java.lang.Number)297.16026257545883d, false);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }
// 
// 
//     long[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     int var7 = var1.nextSecureInt(8, 1629366900);
//     var1.reSeed();
//     double var10 = var1.nextExponential(1.6250521118938452E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1548212337);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.800491802932956E8d);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(5884590, 0);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextZipf(3, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 47L);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException();
    var3.addSuppressed((java.lang.Throwable)var11);
    boolean var13 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = var3.getDirection();
    java.lang.Number var15 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 1+ "'", var15.equals(1));

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var6 = new int[] { 0, 10};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var12 = var11.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var13 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var11);
    long var14 = var11.nextLong();
    int var16 = var11.nextInt(100);
    int[] var19 = new int[] { 0, 10};
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    var11.setSeed(var19);
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var19);
    int[] var25 = new int[] { 0, 10};
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var19, var26);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var30 = var29.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var29);
    long var32 = var29.nextLong();
    int var34 = var29.nextInt(100);
    int[] var37 = new int[] { 0, 10};
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var37);
    var29.setSeed(var37);
    org.apache.commons.math3.random.Well19937c var40 = new org.apache.commons.math3.random.Well19937c(var37);
    int[] var43 = new int[] { 0, 10};
    int[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var37, var44);
    int var46 = org.apache.commons.math3.util.MathArrays.distance1(var26, var44);
    int var47 = org.apache.commons.math3.util.MathArrays.distance1(var7, var44);
    int var48 = org.apache.commons.math3.util.MathArrays.distance1(var3, var7);
    int[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12L);
    long var2 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3910679037987293465L);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.linearCombination(var45, var63);
    double[] var71 = org.apache.commons.math3.util.MathArrays.normalizeArray(var63, 0.033628253521389304d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var63);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextBeta(0.07554057532249034d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2424882323036180480L);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var7, var12);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double[] var60 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var64 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double[] var69 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var73 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var74 = org.apache.commons.math3.util.MathArrays.distance(var69, var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var64, var73);
    double var76 = org.apache.commons.math3.util.MathArrays.linearCombination(var51, var64);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var46, var51);
    java.lang.Comparable[] var79 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var86 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var87 = var86.getSuppressed();
    boolean var88 = var86.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var89 = var86.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var91 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var89, false);
    boolean var93 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var79, var89, true);
    org.apache.commons.math3.util.MathArrays.checkOrder(var51, var89, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var96 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var7, var51);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     double var12 = var1.nextF(0.029977394192225556d, 94.0834911443809d);
//     double var15 = var1.nextWeibull(1.8551847961043366d, 52.553790082113515d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextUniform(20001.0d, 1.3023515952574023d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 29L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.030463814403663154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3.3166555451299084E10d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 67.23943615071526d);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    double var2 = var1.nextDouble();
    byte[] var6 = new byte[] { (byte)100, (byte)100, (byte)10};
    var1.nextBytes(var6);
    int[] var10 = new int[] { 0, 10};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    var1.setSeed(var11);
    var1.clear();
    float var15 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.40877557f);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)", "a5f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double[] var60 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var64 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double[] var69 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var73 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var74 = org.apache.commons.math3.util.MathArrays.distance(var69, var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var64, var73);
    double var76 = org.apache.commons.math3.util.MathArrays.linearCombination(var51, var64);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var64);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var64);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var78);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.5331613618987565d);
    java.lang.Number var2 = var1.getMin();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextGamma((-0.44930379803545945d), 3.1801722383530926d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var25);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextWeibull(198.0d, 436827.027760391d);
//     double var16 = var1.nextWeibull(10.0d, 433.8473116074771d);
//     double var18 = var1.nextExponential(1051.7774912737136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 22L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03559404823003065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 201.55003047003103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 431644.7425356528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 412.00155461780525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1955.295974127463d);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var9 = var8.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var8);
//     long var11 = var8.nextLong();
//     int var13 = var8.nextInt(100);
//     int[] var16 = new int[] { 0, 10};
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     var8.setSeed(var16);
//     var1.setSeed(var16);
//     java.util.List var20 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var21 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var20);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)152.00431209997905d, (java.lang.Number)(-2.3279960104196653d), (java.lang.Number)0.9998367706742745d);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     var1.reSeed();
//     int var15 = var1.nextInt(1, 1689900776);
//     double var18 = var1.nextWeibull(131.5692953237559d, 230.34559940976334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.10606929710166893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.11507128021039674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.01579165073381486d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 346212920);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 227.86914789483404d);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }
// 
// 
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var4 = var3.getSuppressed();
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
//     boolean var8 = var6.equals((java.lang.Object)66L);
//     org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
//     java.lang.Object var10 = var9.getFirst();
//     java.lang.Object var11 = null;
//     boolean var12 = var9.equals(var11);
//     java.lang.Object var13 = var9.getValue();
//     java.lang.Object var14 = var9.getKey();
//     java.lang.Object var15 = var9.getValue();
//     org.apache.commons.math3.random.RandomGenerator var16 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var17 = new org.apache.commons.math3.random.RandomDataGenerator(var16);
//     double var19 = var17.nextT(10.0d);
//     double var22 = var17.nextGaussian(141.42489172702236d, 10.0d);
//     double var25 = var17.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var17.reSeed();
//     int var29 = var17.nextSecureInt(0, 1);
//     boolean var30 = var9.equals((java.lang.Object)var17);
//     double var33 = var17.nextGamma(0.7493076322328543d, 0.06249932356314449d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + 201.0d+ "'", var13.equals(201.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + 201.0d+ "'", var15.equals(201.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.23929896056451525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 157.37349803641558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.2330157167900908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.04298085203960322d);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var9.getFirst();
    org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     int var13 = var1.nextHypergeometric(10, 0, 1);
//     double var16 = var1.nextBeta(136.1891660715202d, 27.460494254093863d);
//     double var20 = var1.nextUniform(0.0d, 140.0071426749364d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextGamma(0.0d, 0.029960342148347842d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 50L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.032401777057425134d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 8.556914693264666E12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.8225167849552303d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 62.32718716306086d);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 19.187896974239802d);
    java.lang.Comparable[] var42 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var49 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var50 = var49.getSuppressed();
    boolean var51 = var49.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = var49.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var54 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var52, false);
    boolean var56 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var42, var52, true);
    boolean var59 = org.apache.commons.math3.util.MathArrays.checkOrder(var7, var52, true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(58);
//     byte[] var2 = null;
//     var1.nextBytes(var2);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.0d, (java.lang.Number)140.0071426749364d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.034840239579776264d, (java.lang.Number)907608747, (java.lang.Number)0.8056667389154711d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.4921662174347376d, (java.lang.Number)3100774812746927104L);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3100774812746927104L+ "'", var4.equals(3100774812746927104L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.4921662174347376d+ "'", var5.equals(0.4921662174347376d));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var5.reSeed(19L);
    double var9 = var5.nextExponential(0.1388307343509505d);
    double var12 = var5.nextBeta(0.9066258578518134d, 7.920319137950138d);
    var5.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var16 = var5.nextLong(165L, 78L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.29331957279297216d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.07554057532249034d);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1372527618);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    boolean var8 = var6.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var9, false);
    java.lang.String var12 = var11.toString();
    java.lang.Number var13 = var11.getArgument();
    java.lang.String var14 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)"+ "'", var12.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0.0f+ "'", var13.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)"+ "'", var14.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)"));

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     var1.reSeed();
//     var1.reSeedSecure(2852L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextBinomial(9, (-1.26973445799314d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4L);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    double var2 = var1.nextDouble();
    var1.clear();
    int[] var6 = new int[] { 0, 10};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    var1.setSeed(var6);
    double var9 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.2554932247505838d));

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     int var6 = var1.nextInt(100);
//     int[] var9 = new int[] { 0, 10};
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
//     var1.setSeed(var9);
//     float var12 = var1.nextFloat();
//     var1.setSeed(5L);
//     double var15 = var1.nextDouble();
//     boolean var16 = var1.nextBoolean();
//     java.util.List var17 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var18 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var17);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var5.reSeed(19L);
    double var9 = var5.nextExponential(0.1388307343509505d);
    double var11 = var5.nextChiSquare(0.5219515461396678d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.29331957279297216d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.106001259295742d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    double[] var1 = new double[] { 0.0d};
    double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var28, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var28);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var10, var15);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var15);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     double[] var5 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var9 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var10 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
//     double[] var14 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var18 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var19 = org.apache.commons.math3.util.MathArrays.distance(var14, var18);
//     double[] var23 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var27 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var28 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var18, var27);
//     double var30 = org.apache.commons.math3.util.MathArrays.distance1(var5, var18);
//     double[] var34 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var38 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var39 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
//     double[] var43 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var47 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var48 = org.apache.commons.math3.util.MathArrays.distance(var43, var47);
//     double[] var52 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var56 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var57 = org.apache.commons.math3.util.MathArrays.distance(var52, var56);
//     double var58 = org.apache.commons.math3.util.MathArrays.distance1(var47, var56);
//     double var59 = org.apache.commons.math3.util.MathArrays.distance1(var34, var47);
//     double[][] var60 = new double[][] { var34};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var60);
//     org.apache.commons.math3.exception.MathInternalError var62 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var60);
//     org.apache.commons.math3.exception.MathIllegalStateException var63 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var60);
//     java.lang.String var64 = var63.toString();
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)198.0d, var1, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.String var5 = var3.toString();
    java.lang.Number var6 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 198 is smaller than, or equal to, the minimum (null)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 198 is smaller than, or equal to, the minimum (null)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGamma(1.3150901193635438d, 201.22095288793136d);
//     int var6 = var0.nextBinomial(18, 0.9641660113674045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 22.753557439912626d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextGamma(0.9487345360513418d, 2.0805938937575448E8d);
//     double var15 = var1.nextExponential(0.9798395551529173d);
//     long var18 = var1.nextLong(88L, 4560884032503238656L);
//     double var21 = var1.nextCauchy((-0.17728586563368837d), 0.9954119943753462d);
//     org.apache.commons.math3.distribution.IntegerDistribution var22 = null;
//     int var23 = var1.nextInversionDeviate(var22);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextUniform(0.9899703701402124d, 201.0d);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var1.nextSample(var12, (-1623951277));
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var7, var12);
    java.lang.Comparable[] var40 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var48 = var47.getSuppressed();
    boolean var49 = var47.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = var47.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var52 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var50, false);
    boolean var54 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var40, var50, true);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12, var50, false);
    double[] var60 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var64 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var60);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 20001.0d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(94L);
    double var5 = var1.nextChiSquare(10.585691407196235d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var1.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 11.778860840139426d);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextUniform(0.11419085583612978d, 91.54089948517347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 31.657212704685328d);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var9);
    java.lang.Object var11 = var9.getKey();
    boolean var13 = var9.equals((java.lang.Object)201.74910293311632d);
    java.lang.Object var14 = var9.getValue();
    java.lang.Object var15 = var9.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 201.0d+ "'", var14.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     var1.reSeed(65L);
//     var1.reSeed();
//     int var22 = var1.nextInt(3615507, 108894710);
//     double var25 = var1.nextUniform((-1.1847861266648632d), 0.03334200658556004d);
//     double var27 = var1.nextT(0.07554057532249034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1405553685081135872L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9587176150939694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 44.62816311510747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 88779611);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.2868147269647349d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 8499419.832283411d);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextCauchy(433.8473116074771d, 134.5471615274561d);
//     int var14 = var1.nextPascal(2, 0.03711666723053142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 443.30278948673833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 62);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     double var16 = var1.nextUniform(0.4921662174347376d, 44.086886661056695d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextSecureInt(3615507, 17);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.48081332095146606d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3015057882041887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.547260060531964d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 51.81538113192574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 38.07011007478543d);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     var1.reSeedSecure();
//     double var11 = var1.nextExponential(147.98997692862494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.38398822491146434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.12339089928983347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 58.81044694920038d);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     java.lang.String var13 = var1.nextHexString(41);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextT((-1.26973445799314d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 56L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.031222789380244285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.2163554316347631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2771L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "ec715ddf83532b2e8b1c28191491cf5b16737d540"+ "'", var13.equals("ec715ddf83532b2e8b1c28191491cf5b16737d540"));
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    boolean var4 = var3.getStrict();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-30245107));

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1028812019);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian((-1.0d), 0.24769886863969978d);
    double var7 = var2.nextT(0.9798395551529173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.0542341737090821d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0185653366314518d));

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     double var11 = var1.nextChiSquare(0.037491676371315924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 53L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03417932712311849d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6218279334086521d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     double var2 = var1.nextDouble();
//     int[] var5 = new int[] { 0, 10};
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl(var8);
//     int var12 = var9.nextSecureInt((-1), 0);
//     int[] var15 = var9.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     int var17 = org.apache.commons.math3.util.MathArrays.distance1(var7, var15);
//     var1.setSeed(var7);
//     double var19 = var1.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2395389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.2554932247505838d));
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)100.0d, (java.lang.Number)433.8473116074771d, false);
    java.lang.Number var4 = var3.getMin();
    java.lang.Number var5 = var3.getMin();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    long[] var7 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var9 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var6, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.util.ExceptionContext var16 = var15.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 433.8473116074771d+ "'", var4.equals(433.8473116074771d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 433.8473116074771d+ "'", var5.equals(433.8473116074771d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var16);
    double[] var30 = new double[] { 0.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    double[] var35 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var39 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var40 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
    double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
    double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double[] var62 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var66 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var67 = org.apache.commons.math3.util.MathArrays.distance(var62, var66);
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var57, var66);
    double var69 = org.apache.commons.math3.util.MathArrays.linearCombination(var44, var57);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var39, var44);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var44);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.nextUniform(1.0062200885092036d, 0.0d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextWeibull(198.0d, 436827.027760391d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 40L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03225134344103874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 201.76426866267457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 429086.4930386198d);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0.1945318675277668d};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
//     java.lang.Comparable[] var10 = new java.lang.Comparable[] { 0.03282615243296957d};
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var18 = var17.getSuppressed();
//     boolean var19 = var17.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var20 = var17.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var20, false);
//     boolean var24 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var20, true);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var26 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)1, 100, var20, true);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var20, false);
//     boolean var30 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var20, false);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)10, (java.lang.Number)1.9020015664445744d, (-1));
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.9020015664445744d+ "'", var5.equals(1.9020015664445744d));

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     var1.reSeed(2833L);
//     org.apache.commons.math3.distribution.RealDistribution var11 = null;
//     double var12 = var1.nextInversionDeviate(var11);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextSecureInt(1629366900, 5884590);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.8108203052839953d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.2219781134433433d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0019358995600889d);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
//     double[] var12 = null;
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeAdd(var11, var12);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1483429225);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var2 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var1.nextSecureLong(80L, 72L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.21340481929931635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 134.92689796642532d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2457557636987926d);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     double var6 = var1.nextExponential(0.9487345360513418d);
//     double var9 = var1.nextCauchy(1.5324442802669078d, 2840.6711051053326d);
//     double var12 = var1.nextUniform(0.016855007404038964d, 2.1042444166006993d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextSecureLong(2888L, 2852L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9598127107480111d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9234104580679593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-6374.112615573382d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.9118261134104795d);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextBinomial(792999694, 0.9225044967928602d);
//     long var6 = var0.nextLong(2856L, 3753204218245556224L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 731536256);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3311493493092948480L);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     double var15 = var1.nextExponential(0.9606147597499597d);
//     var1.reSeedSecure();
//     long var19 = var1.nextLong((-248896021020807360L), 2835L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.2967391334549745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 139.459481210174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.036322382370710136d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.21831168161296394d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-67433603712874944L));
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     org.apache.commons.math3.distribution.RealDistribution var2 = null;
//     double var3 = var1.nextInversionDeviate(var2);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 0);
    int[] var8 = new int[] { 0, 10};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int[] var14 = new int[] { 0, 10};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var8, var15);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var21 = new int[] { 0, 10};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    int[] var25 = new int[] { 0, 10};
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 0);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var22, var25);
    double var30 = org.apache.commons.math3.util.MathArrays.distance(var18, var22);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var5, var18);
    int[] var34 = new int[] { 0, 10};
    int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var34);
    int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var34, 0);
    int[] var40 = new int[] { 0, 10};
    int[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    int[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 0);
    int[] var46 = new int[] { 0, 10};
    int[] var47 = org.apache.commons.math3.util.MathArrays.copyOf(var46);
    int[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var47);
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var40, var47);
    int[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    int[] var53 = new int[] { 0, 10};
    int[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var53);
    int[] var57 = new int[] { 0, 10};
    int[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var57);
    int[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var57, 0);
    double var61 = org.apache.commons.math3.util.MathArrays.distance(var54, var57);
    double var62 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var63 = org.apache.commons.math3.util.MathArrays.distance(var37, var50);
    int var64 = org.apache.commons.math3.util.MathArrays.distance1(var18, var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }
// 
// 
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
//     java.lang.Throwable[] var4 = var3.getSuppressed();
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
//     boolean var8 = var6.equals((java.lang.Object)66L);
//     org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
//     java.lang.Object var10 = var9.getFirst();
//     java.lang.Object var11 = null;
//     boolean var12 = var9.equals(var11);
//     java.lang.Object var13 = var9.getValue();
//     java.lang.Object var14 = var9.getKey();
//     java.lang.Object var15 = var9.getValue();
//     org.apache.commons.math3.random.RandomGenerator var16 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var17 = new org.apache.commons.math3.random.RandomDataGenerator(var16);
//     double var19 = var17.nextT(10.0d);
//     double var22 = var17.nextGaussian(141.42489172702236d, 10.0d);
//     double var25 = var17.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var17.reSeed();
//     int var29 = var17.nextSecureInt(0, 1);
//     boolean var30 = var9.equals((java.lang.Object)var17);
//     double var33 = var17.nextWeibull(433378.0229678348d, 542.5543744963898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + 201.0d+ "'", var13.equals(201.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + 201.0d+ "'", var15.equals(201.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.03198621995856463d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 145.57969560397746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.29066910382843814d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 542.5538704454092d);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.9685374826344926d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-91.85508929238087d));

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     double var12 = var1.nextF(0.029977394192225556d, 94.0834911443809d);
//     var1.reSeedSecure(64L);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var1.nextInversionDeviate(var15);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var3 = var0.nextPermutation(5, 7095798);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)4353643293855910912L, (java.lang.Number)(byte)1, true);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.1991753248498107d, (java.lang.Number)200.81717002836405d, false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var16);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
    double[] var61 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var65 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double[] var70 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var74 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var70, var74);
    double[] var79 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var83 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var84 = org.apache.commons.math3.util.MathArrays.distance(var79, var83);
    double var85 = org.apache.commons.math3.util.MathArrays.distance1(var74, var83);
    double var86 = org.apache.commons.math3.util.MathArrays.linearCombination(var61, var74);
    double var87 = org.apache.commons.math3.util.MathArrays.distance(var46, var74);
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeDivide(var32, var74);
    double[] var89 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var32);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextBinomial(1028812019, 0.0998915660109107d);
//     org.apache.commons.math3.distribution.RealDistribution var6 = null;
//     double var7 = var2.nextInversionDeviate(var6);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     long var4 = var1.nextSecureLong((-1538904934532245248L), 2104967897813151744L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 980950594405262592L);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)184.2894949557855d, var1);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1722448868039600408L), (java.lang.Number)907608747, true);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    boolean var4 = var3.getStrict();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     double var16 = var1.nextUniform(0.4921662174347376d, 44.086886661056695d);
//     double var18 = var1.nextChiSquare(0.49948825038985073d);
//     var1.reSeedSecure();
//     int var22 = var1.nextSecureInt(15, 564429813);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0375770183472361d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.697184518118543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8053469881451545d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 41.162175416443056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6.533300879205559d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.19276596467970034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 49461254);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 88779611);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var7 = var1.nextExponential(433.8473116074771d);
//     long var10 = var1.nextLong(32L, 2865512416584424448L);
//     java.lang.String var12 = var1.nextHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextCauchy(23.33918726571379d, (-0.3090120983402358d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.2832560690764136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.18052660172555543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 636.530433040734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 445787430707911872L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "cd50"+ "'", var12.equals("cd50"));
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-12.587651277008359d), (java.lang.Number)542.5543744963898d, false);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9954119943753462d, (java.lang.Object[])var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
//     double var2 = var1.nextDouble();
//     byte[] var6 = new byte[] { (byte)100, (byte)100, (byte)10};
//     var1.nextBytes(var6);
//     int[] var10 = new int[] { 0, 10};
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     var1.setSeed(var11);
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.List var15 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var16 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var15);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var10);
    java.lang.Throwable[] var12 = var4.getSuppressed();
    org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)1.5665637811284938d, (java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextBinomial(792999694, 0.9225044967928602d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextUniform(1.05492292904169d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 731555568);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     java.lang.String var9 = var1.nextHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var1.nextLong(3100774812746927104L, 2090448509803676160L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.2655191627945101E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "4c6f"+ "'", var9.equals("4c6f"));
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     double var11 = var1.nextGamma(0.002123327067530301d, 28.607227405226453d);
//     int var14 = var1.nextZipf(10, 0.348176533212522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.48530634323038E-108d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(1028812019);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9066258578518134d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    var1.reSeedSecure();
    long var7 = var1.nextLong(0L, 82L);
    double var10 = var1.nextCauchy(0.03609112308169037d, 0.016855007404038964d);
    long var13 = var1.nextLong(77L, 78L);
    var1.reSeed(45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.02647681120026045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 78L);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0f, (java.lang.Number)(byte)1, true);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    java.lang.Number var7 = var4.getMax();
    long[] var9 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var9);
    long[][] var11 = new long[][] { var9};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)80L, (java.lang.Object[])var11);
    var4.addSuppressed((java.lang.Throwable)var15);
    java.lang.Number var17 = var15.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)1+ "'", var5.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)1+ "'", var7.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 80L+ "'", var17.equals(80L));

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     double var7 = var1.nextUniform(0.0d, 1.3150901193635438d);
//     double var10 = var1.nextF(4.140285621523964E-13d, 2.1042444166006993d);
//     long var13 = var1.nextSecureLong(165L, 482806506685451456L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.5878564876389494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 348772329959288896L);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     double var7 = var1.nextCauchy(0.1945318675277668d, 1426.887198243755d);
//     double var10 = var1.nextWeibull(836930.5077725694d, 1.3421363959502273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-556.3176339808972d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3421345892228325d);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var3 = var1.nextInt(1028812019);
//     var1.setSeed(1);
//     long var6 = var1.nextLong();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var9 = var8.nextInt();
//     byte[] var12 = new byte[] { (byte)100, (byte)10};
//     var8.nextBytes(var12);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var16 = var15.nextInt();
//     byte[] var19 = new byte[] { (byte)100, (byte)10};
//     var15.nextBytes(var19);
//     var8.nextBytes(var19);
//     org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var19, (java.lang.Object)0.007523027327565226d);
//     var1.nextBytes(var19);
//     int var26 = var1.nextInt(1378651682);
//     java.util.List var27 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var28 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var27);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, (java.lang.Object)201.0d);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)0.9681755253392977d, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(5141685311728891869L);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var4 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)10, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double[] var59 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var63 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var64 = org.apache.commons.math3.util.MathArrays.distance(var59, var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var54, var63);
    double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var41, var54);
    double var67 = org.apache.commons.math3.util.MathArrays.distance(var26, var54);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var54);
    double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.linearCombination(var54, var72);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var72);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var84 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var88 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var89 = var88.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var90 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var83, var84, (java.lang.Object[])var89);
    java.lang.Throwable[] var91 = var83.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var92 = var83.getDirection();
    org.apache.commons.math3.util.Pair var93 = new org.apache.commons.math3.util.Pair((java.lang.Object)var72, (java.lang.Object)var92);
    org.apache.commons.math3.util.Pair var94 = new org.apache.commons.math3.util.Pair(var93);
    java.lang.Object var95 = var93.getValue();
    java.lang.Object var96 = var93.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    double var2 = var1.nextDouble();
    byte[] var6 = new byte[] { (byte)100, (byte)100, (byte)10};
    var1.nextBytes(var6);
    var1.clear();
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var11 = var10.nextInt();
    byte[] var14 = new byte[] { (byte)100, (byte)10};
    var10.nextBytes(var14);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var18 = var17.nextInt();
    byte[] var21 = new byte[] { (byte)100, (byte)10};
    var17.nextBytes(var21);
    var10.nextBytes(var21);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)var21, (java.lang.Object)0.007523027327565226d);
    var1.nextBytes(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     int var11 = var1.nextPascal(10, 0.5587862084152698d);
//     double var13 = var1.nextChiSquare(0.9991548839151001d);
//     double var16 = var1.nextF(1.089117284020693E-9d, 0.9893766669763007d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextUniform(0.0d, (-3.8261378360024128d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.601089967624231d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.04594633145885349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.04743822940320161d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.0d, (-2675.9452845590495d), 1.1237743699467411E-9d, 0.01408195728001127d, 0.029960342148347842d, 84.90310037617164d, 1.4184088203104963d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 120.42772533836877d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(short)(-1), var2, (java.lang.Number)(-0.44930379803545945d));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)50L);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 50L+ "'", var2.equals(50L));

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(1L);
    var1.reSeedSecure();
    long var7 = var1.nextLong(0L, 82L);
    double var9 = var1.nextExponential(1.29910331984832d);
    double var12 = var1.nextGaussian(1.56678210454931d, 14.156746852520266d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var1.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.3421363959502273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 26.249529082046173d);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextCauchy(433.8473116074771d, 134.5471615274561d);
//     double var14 = var1.nextGaussian(0.14536762410688497d, 0.9550923085142555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 360.1144105821264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.8585212057776297d);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    boolean var8 = var6.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var9, false);
    java.lang.String var12 = var11.toString();
    java.lang.String var13 = var11.toString();
    boolean var14 = var11.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)"+ "'", var12.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)"+ "'", var13.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     double var16 = var1.nextWeibull(0.03334200658556004d, 200.40417679089168d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.5435297800309093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 147.5135066084356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.03417843528176085d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.7567856558587644E14d);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.8177111776375223d));

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-30245107), 0);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(62L);
    org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeAdd(var17, var45);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var63 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var64 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var68 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var69 = var68.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var70 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var63, var64, (java.lang.Object[])var69);
    java.lang.Throwable[] var71 = var63.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var72 = var63.getDirection();
    org.apache.commons.math3.util.MathArrays.checkOrder(var59, var72, false);
    double[] var78 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var82 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var83 = org.apache.commons.math3.util.MathArrays.distance(var78, var82);
    double var84 = org.apache.commons.math3.util.MathArrays.safeNorm(var78);
    double var85 = org.apache.commons.math3.util.MathArrays.distanceInf(var59, var78);
    double var86 = org.apache.commons.math3.util.MathArrays.distance(var3, var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 98.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 138.5965367532681d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1755678109);
    var1.setSeed(85L);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    org.apache.commons.math3.exception.NotPositiveException var20 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03510480520930032d);
    org.apache.commons.math3.util.Pair var21 = new org.apache.commons.math3.util.Pair((java.lang.Object)var18, (java.lang.Object)var20);
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    java.lang.Number var23 = null;
    org.apache.commons.math3.exception.OutOfRangeException var26 = new org.apache.commons.math3.exception.OutOfRangeException(var22, var23, (java.lang.Number)1.5324442802669078d, (java.lang.Number)(-839619997));
    java.lang.Number var27 = var26.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var28 = var26.getContext();
    boolean var29 = var21.equals((java.lang.Object)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-839619997)+ "'", var27.equals((-839619997)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var3 = var0.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1781557503);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.43465288367659505d);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    int[] var8 = new int[] { 0, 10};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int[] var14 = new int[] { 0, 10};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var8, var15);
    var5.setSeed(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextT(0.007523027327565226d);
//     double var8 = var1.nextGamma(1.7320508075688772d, 1.3150901193635438d);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var1.nextInversionDeviate(var9);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1548212337, 102762836);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     double var9 = var1.nextBeta(200.58085083797894d, 0.9991548839151001d);
//     long var12 = var1.nextSecureLong(1L, 50L);
//     var1.reSeed(46L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextSecureInt(1781557503, 907608747);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9971617183742483d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 13L);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance1(var3, var16);
//     double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
//     double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
//     double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
//     double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
//     double var57 = org.apache.commons.math3.util.MathArrays.distance1(var32, var45);
//     double[][] var58 = new double[][] { var32};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var58);
//     double[] var60 = null;
//     double[] var61 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var60);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }
// 
// 
//     int[] var2 = new int[] { 0, 10};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl(var5);
//     int var9 = var6.nextSecureInt((-1), 0);
//     int[] var12 = var6.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     int var14 = org.apache.commons.math3.util.MathArrays.distance1(var4, var12);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var4);
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     int[] var19 = new int[] { 0, 10};
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     int var26 = var23.nextSecureInt((-1), 0);
//     int[] var29 = var23.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var29);
//     int var31 = org.apache.commons.math3.util.MathArrays.distance1(var21, var29);
//     org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var21);
//     int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
//     int[] var36 = new int[] { 0, 10};
//     int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
//     int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var37);
//     int[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var37);
//     int var40 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
//     double var41 = org.apache.commons.math3.util.MathArrays.distance(var4, var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.0d);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     java.lang.String var16 = var1.nextSecureHexString(3615507);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2601022738855165440L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.2297105571020356d);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 0.0d};
//     double[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     double[] var7 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var11 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var12 = org.apache.commons.math3.util.MathArrays.distance(var7, var11);
//     double[] var16 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var20 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var21 = org.apache.commons.math3.util.MathArrays.distance(var16, var20);
//     double[] var25 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var29 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var30 = org.apache.commons.math3.util.MathArrays.distance(var25, var29);
//     double[] var34 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var38 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var39 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
//     double var40 = org.apache.commons.math3.util.MathArrays.distance1(var29, var38);
//     double var41 = org.apache.commons.math3.util.MathArrays.linearCombination(var16, var29);
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var11, var16);
//     boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var16);
//     double[] var47 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var51 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var52 = org.apache.commons.math3.util.MathArrays.distance(var47, var51);
//     double[] var56 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var60 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var61 = org.apache.commons.math3.util.MathArrays.distance(var56, var60);
//     double[] var65 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var69 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var70 = org.apache.commons.math3.util.MathArrays.distance(var65, var69);
//     double[] var74 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var78 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var79 = org.apache.commons.math3.util.MathArrays.distance(var74, var78);
//     double var80 = org.apache.commons.math3.util.MathArrays.distance1(var69, var78);
//     double var81 = org.apache.commons.math3.util.MathArrays.linearCombination(var56, var69);
//     boolean var82 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var69);
//     double[] var84 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 7);
//     double var85 = org.apache.commons.math3.util.MathArrays.distance1(var16, var84);
//     double[] var86 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var84);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(41.873787915740365d, (-0.036322382370710136d), 0.9341742757185967d, 0.8419126536054229d, 1.05492292904169d, 0.03554647067918854d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6969638056193912d));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)19L, (java.lang.Number)437520.3234163918d, (java.lang.Number)126.65787460843954d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = null;
    boolean var11 = var9.equals(var10);
    java.lang.Object var12 = var9.getSecond();
    org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair(var9);
    java.lang.Object var14 = var13.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 201.0d+ "'", var12.equals(201.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 201.0d+ "'", var14.equals(201.0d));

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     var1.reSeed(2833L);
//     int var14 = var1.nextHypergeometric(370427906, 1, 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.45376493132254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0076490825460329434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.5331613618987565d);
    java.lang.Number var2 = var1.getMin();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var16 = var15.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(1028812019);
    var1.setSeed(1);
    long var6 = var1.nextLong();
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var16 = var15.nextInt();
    byte[] var19 = new byte[] { (byte)100, (byte)10};
    var15.nextBytes(var19);
    var8.nextBytes(var19);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var19, (java.lang.Object)0.007523027327565226d);
    var1.nextBytes(var19);
    float var25 = var1.nextFloat();
    var1.setSeed(8);
    org.apache.commons.math3.random.RandomDataGenerator var28 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5141685311728891869L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.87197447f);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     var1.reSeedSecure();
//     double var7 = var1.nextChiSquare(1.0738576919282752d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.009547772086820606d);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (-598261.6713290205d), 0.0d, 238.39792420612676d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    java.lang.Comparable[] var15 = new java.lang.Comparable[] { 1.4184088203104963d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var25 = var24.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var19, var20, (java.lang.Object[])var25);
    java.lang.Throwable[] var27 = var19.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = var19.getDirection();
    boolean var30 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var15, var28, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var32 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)77L, (java.lang.Number)0.016855007404038964d, 7, var28, true);
    boolean var34 = org.apache.commons.math3.util.MathArrays.isMonotonic(var10, var28, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextCauchy(2.0805938937575448E8d, 0.0319217721093273d);
//     double var8 = var1.nextUniform((-0.14863104184816925d), 0.016855007404038964d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextPascal(861133202, 200.42902505131346d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.0805938931530252E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.013173467084757902d);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)4.0200632148206875E7d, (java.lang.Number)4.0200632148206875E7d, (-839619997));
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    double[] var14 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var18 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var19 = org.apache.commons.math3.util.MathArrays.distance(var14, var18);
    double[] var23 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var27 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    double var48 = org.apache.commons.math3.util.MathArrays.linearCombination(var23, var36);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var36);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 7);
    double var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 99.0d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 0.1945318675277668d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)77.18360686611912d, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
    boolean var11 = var3.getStrict();
    int var12 = var3.getIndex();
    boolean var13 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGamma(0.033512180789649695d, 99.63836752982392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.799091676838239d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.895702912834664E-39d);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var9.getFirst();
    java.lang.Object var11 = null;
    boolean var12 = var9.equals(var11);
    java.lang.Object var13 = var9.getFirst();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 5, 8);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    byte[] var5 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    var1.nextBytes(var12);
    int var15 = var1.nextInt();
    boolean var16 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1378651682);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var3, var16);
    double[] var30 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, (-1.799091676838239d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    double var2 = var1.nextDouble();
    var1.setSeed(11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2395389662180223d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)4.0200632148206875E7d, (java.lang.Number)10, (java.lang.Number)0.009547772086820606d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var35);
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeAdd(var7, var35);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 2147483647);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.7320508075688772d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    java.lang.Object var7 = var6.getFirst();
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03510480520930032d);
    boolean var2 = var1.getBoundIsAllowed();
    boolean var3 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     double var8 = var1.nextBeta(200.81717002836405d, 0.1991753248498107d);
//     var1.reSeedSecure();
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.1707757168394712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9997579963550712d);
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     long var18 = var1.nextPoisson(0.034840239579776264d);
//     double var21 = var1.nextF(0.02551602800088468d, 0.9503863631052277d);
//     double var24 = var1.nextWeibull(0.1388307343509505d, 0.9973549356716908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1332593878191004672L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.7464064709627993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 19.758846570389245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1336.9032695997428d);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    double var2 = var1.nextDouble();
    byte[] var6 = new byte[] { (byte)100, (byte)100, (byte)10};
    var1.nextBytes(var6);
    int[] var10 = new int[] { 0, 10};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    var1.setSeed(var11);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var15 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     double var13 = var1.nextExponential(8.11989620793123d);
//     int var16 = var1.nextZipf(7, 170.7857280627396d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)", "e418dfaced");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 85L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.14093285286703863d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9009430259674818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2849L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.675154571071861d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     double var9 = var1.nextBeta(200.58085083797894d, 0.9991548839151001d);
//     long var12 = var1.nextSecureLong(1L, 50L);
//     var1.reSeed(46L);
//     int var17 = var1.nextSecureInt(731540631, 907608747);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var1.nextSample(var18, 855451518);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 7, 1629366900);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1629366900);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var10, var19);
    double[] var25 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var29 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var30 = org.apache.commons.math3.util.MathArrays.distance(var25, var29);
    double[] var34 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var38 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double[] var43 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var47 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var43, var47);
    double var49 = org.apache.commons.math3.util.MathArrays.distance1(var38, var47);
    double var50 = org.apache.commons.math3.util.MathArrays.linearCombination(var25, var38);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeAdd(var10, var38);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var56 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var57 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var61 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var62 = var61.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var63 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var56, var57, (java.lang.Object[])var62);
    java.lang.Throwable[] var64 = var56.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var65 = var56.getDirection();
    org.apache.commons.math3.util.MathArrays.checkOrder(var52, var65, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var69 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.9341742757185967d, (java.lang.Number)0.910874940635856d, 464544813, var65, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     int var13 = var1.nextHypergeometric(10, 0, 1);
//     double var15 = var1.nextExponential(0.03711666723053142d);
//     double var18 = var1.nextCauchy(0.06424450367037651d, 1.4200682258215138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.02903165867884471d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3.544000813588728E13d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.00580589354629837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.2472572950834879d));
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    int var4 = var1.nextZipf(100, 141.42489172702236d);
    var1.reSeed(10L);
    double var9 = var1.nextGamma(0.03449238325907719d, 0.05272999253983823d);
    double var11 = var1.nextExponential(3.7618551512431844d);
    var1.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.140285621523964E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.677146259383745d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var16);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var3, var36);
    double[] var52 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var56 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var52, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var36, var52);
    double var60 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 141.42489172702236d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)855888619, var1);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     int var11 = var1.nextPascal(10, 0.5587862084152698d);
//     var1.reSeed(88L);
//     double var16 = var1.nextBeta(148.80913770781288d, 200.40417679089168d);
//     org.apache.commons.math3.distribution.RealDistribution var17 = null;
//     double var18 = var1.nextInversionDeviate(var17);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3150901193635438d, (java.lang.Object[])var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     long var6 = var1.nextPoisson(434777.8672564595d);
//     double var9 = var1.nextUniform((-91.85508929238087d), 7.794554629059993E114d);
//     int var12 = var1.nextSecureInt(3615507, 7095798);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextInt(659309102, (-1505764920));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9684808285813745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 435108L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.010424618768811E114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4386216);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.linearCombination(var22, var35);
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeAdd(var7, var35);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var54 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var58 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var59 = org.apache.commons.math3.util.MathArrays.distance(var54, var58);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.distance1(var58, var67);
    double[] var73 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var77 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var73, var77);
    double[] var82 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var86 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var87 = org.apache.commons.math3.util.MathArrays.distance(var82, var86);
    double var88 = org.apache.commons.math3.util.MathArrays.distance1(var77, var86);
    double var89 = org.apache.commons.math3.util.MathArrays.distance1(var58, var77);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var93 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var94 = var93.getSuppressed();
    boolean var95 = var93.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var96 = var93.getDirection();
    boolean var98 = org.apache.commons.math3.util.MathArrays.isMonotonic(var58, var96, false);
    double var99 = org.apache.commons.math3.util.MathArrays.distance1(var35, var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.0d);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     long var18 = var1.nextPoisson(0.034840239579776264d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var20 = var1.nextHexString((-569181736));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2937747455447008256L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9802133068421518d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 11.320526156847837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0L);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2243061314491676928L, (java.lang.Number)0.03088160939819984d, true);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var9 = var1.nextT(0.03510480520930032d);
//     int var13 = var1.nextHypergeometric(10, 0, 1);
//     double var16 = var1.nextBeta(136.1891660715202d, 27.460494254093863d);
//     double var20 = var1.nextUniform(0.0d, 140.0071426749364d, false);
//     java.lang.String var22 = var1.nextHexString(3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 28L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03616239119645785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.9213392535756073E10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.7490160517335605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 37.86669689528646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "e68"+ "'", var22.equals("e68"));
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     var1.reSeed(10L);
//     int var8 = var1.nextZipf(3, 0.7330515909091372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-3.0971793594011334d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var3.nextExponential(4.497671471910009d);
    double var7 = var3.nextChiSquare(0.0012407997852097038d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5172264847508324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.025520070096945E-9d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var4 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)10, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     var1.reSeed(65L);
//     int var21 = var1.nextBinomial(0, 0.0d);
//     var1.reSeed();
//     double var24 = var1.nextT(0.7527633941277073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1460562862479365120L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.7992406560713536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 146.37483031957555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 4.778416266385268d);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     float var2 = var1.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.65503585f);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    float[] var5 = new float[] { 10.0f, 100.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var5);
    float[] var10 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var11 = new float[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var17 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var18 = new float[] { };
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var18);
    float[] var23 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var24 = new float[] { };
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var24);
    float[] var30 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var31 = new float[] { };
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var31);
    float[] var36 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var37 = new float[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var37);
    float[] var43 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var44 = new float[] { };
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var43);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var24, var43);
    float[] var51 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var52 = new float[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    float[] var57 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var58 = new float[] { };
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var57, var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var58);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var24, var52);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
    java.lang.Throwable[] var11 = var3.getSuppressed();
    java.lang.Number var12 = var3.getPrevious();
    int var13 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1+ "'", var12.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    boolean var5 = var3.getStrict();
    int var6 = var3.getIndex();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    boolean var8 = var3.getStrict();
    int var9 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    double[] var5 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var9 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var10 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    double[] var14 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var18 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var19 = org.apache.commons.math3.util.MathArrays.distance(var14, var18);
    double[] var23 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var27 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var18, var27);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var5, var18);
    double[] var34 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var38 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var39 = org.apache.commons.math3.util.MathArrays.distance(var34, var38);
    double[] var43 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var47 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var43, var47);
    double[] var52 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var56 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var52, var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var47, var56);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var34, var47);
    double[][] var60 = new double[][] { var34};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var60);
    org.apache.commons.math3.exception.MathIllegalStateException var62 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var60);
    org.apache.commons.math3.exception.MathIllegalStateException var63 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var60);
    org.apache.commons.math3.exception.util.Localizable var64 = null;
    org.apache.commons.math3.exception.util.Localizable var65 = null;
    long[] var67 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var67);
    long[][] var69 = new long[][] { var67};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var69);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var69);
    org.apache.commons.math3.exception.NotFiniteNumberException var72 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)10, (java.lang.Object[])var69);
    org.apache.commons.math3.exception.MathIllegalArgumentException var73 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var65, (java.lang.Object[])var69);
    org.apache.commons.math3.exception.MathIllegalArgumentException var74 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var64, (java.lang.Object[])var69);
    var63.addSuppressed((java.lang.Throwable)var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 907608747, 10);
//     java.lang.Number var4 = var3.getArgument();
//     java.lang.String var5 = var3.toString();
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     double var6 = var1.nextExponential(0.9487345360513418d);
//     double var9 = var1.nextCauchy(1.5324442802669078d, 2840.6711051053326d);
//     double var12 = var1.nextUniform(1.4685833464640283d, 114.79816937303474d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9474965421280476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.3511774415263216d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2946.6190795349453d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 40.60545143341782d);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)200.21530124351486d, (java.lang.Number)0.04504381602697635d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12L);
    double var2 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.21199833658750666d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
    double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.linearCombination(var45, var63);
    double[] var71 = org.apache.commons.math3.util.MathArrays.normalizeArray(var63, 0.033628253521389304d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var63);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1028812019);
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var5 = var4.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    long var7 = var4.nextLong();
    int var9 = var4.nextInt(100);
    int[] var12 = new int[] { 0, 10};
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    var4.setSeed(var12);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var12);
    int[] var18 = new int[] { 0, 10};
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var12, var19);
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var23 = var22.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var24 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var22);
    long var25 = var22.nextLong();
    int var27 = var22.nextInt(100);
    int[] var30 = new int[] { 0, 10};
    int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    var22.setSeed(var30);
    org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(var30);
    int[] var36 = new int[] { 0, 10};
    int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var30, var37);
    int var39 = org.apache.commons.math3.util.MathArrays.distance1(var19, var37);
    var1.setSeed(var37);
    org.apache.commons.math3.random.RandomDataImpl var41 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1169327278));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var5 = var1.nextHypergeometric(1689900776, 7, 907608747);
//     double var7 = var1.nextChiSquare(0.016855007404038964d);
//     java.lang.String var9 = var1.nextHexString(4);
//     double var12 = var1.nextBeta(1.5500613397364666d, 0.039691703214181015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "4162"+ "'", var9.equals("4162"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9920500430076258d);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var11 = var10.nextInt();
//     byte[] var14 = new byte[] { (byte)100, (byte)10};
//     var10.nextBytes(var14);
//     var8.nextBytes(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(23L);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextHypergeometric(0, 3615507, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.6350722319479901d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 144.46491901899034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2.5738570397299325d));
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 1.1869522060257927E7d);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 0);
    int[] var8 = new int[] { 0, 10};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var2, var9);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var14 = var13.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var15 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var13);
    long var16 = var13.nextLong();
    int var18 = var13.nextInt(100);
    int[] var21 = new int[] { 0, 10};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    var13.setSeed(var21);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(4560884032503238656L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double[] var40 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var44 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var22, var35);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double[] var60 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var64 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double[] var69 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var73 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var74 = org.apache.commons.math3.util.MathArrays.distance(var69, var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var64, var73);
    double var76 = org.apache.commons.math3.util.MathArrays.distance1(var51, var64);
    double[][] var77 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var22, var77);
    double[] var79 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var79);
    double var81 = org.apache.commons.math3.util.MathArrays.safeNorm(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 141.42489172702236d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(434971L);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     double var15 = var1.nextExponential(0.9606147597499597d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var1.nextPermutation(0, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.5694250412682488d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 158.8351123193977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.08696011701502897d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8226812688413692d);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var7 = var1.nextExponential(433.8473116074771d);
//     long var10 = var1.nextLong(32L, 2865512416584424448L);
//     double var13 = var1.nextUniform(0.0d, 0.9681755253392977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.175271736851309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.1616991797016807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 716.6921192136991d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1487516304763058176L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.6604310182267742d);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 907608747, 10);
    java.lang.Number var4 = var3.getArgument();
    int var5 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 907608747+ "'", var4.equals(907608747));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1629366900, 731536256);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1735.0073134974334d), (java.lang.Number)5L, (java.lang.Number)0.9341742757185967d);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     int var5 = var2.nextSecureInt(692191003, 907608747);
//     double var8 = var2.nextF(148667.53843714943d, 98624.34872685173d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 514,406,008 and 514,406,009 are not increasing (-1 > 0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1125547203);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 796833592);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.998439495142986d);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)200.68041025388703d, (java.lang.Number)286.8963404480585d, false);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0.1945318675277668d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var2, true);
    java.lang.Comparable[] var6 = new java.lang.Comparable[] { 0.1945318675277668d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var7, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    boolean var15 = var13.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = var13.getDirection();
    boolean var18 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var16, false);
    boolean var20 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var16, true);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
    double var58 = org.apache.commons.math3.util.MathArrays.linearCombination(var33, var46);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var28, var33);
    java.lang.Comparable[] var61 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var68 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var69 = var68.getSuppressed();
    boolean var70 = var68.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = var68.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var73 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var71, false);
    boolean var75 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var61, var71, true);
    org.apache.commons.math3.util.MathArrays.checkOrder(var33, var71, false);
    boolean var79 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var71, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(1028812019);
    var1.setSeed(1);
    long var6 = var1.nextLong();
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var16 = var15.nextInt();
    byte[] var19 = new byte[] { (byte)100, (byte)10};
    var15.nextBytes(var19);
    var8.nextBytes(var19);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)var19, (java.lang.Object)0.007523027327565226d);
    var1.nextBytes(var19);
    int var26 = var1.nextInt(1378651682);
    boolean var27 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var30 = var29.nextInt();
    byte[] var33 = new byte[] { (byte)100, (byte)10};
    var29.nextBytes(var33);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var37 = var36.nextInt();
    byte[] var40 = new byte[] { (byte)100, (byte)10};
    var36.nextBytes(var40);
    var29.nextBytes(var40);
    org.apache.commons.math3.util.Pair var44 = new org.apache.commons.math3.util.Pair((java.lang.Object)var40, (java.lang.Object)0.007523027327565226d);
    var1.nextBytes(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5141685311728891869L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1372527618);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)224787129);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     double var11 = var1.nextUniform(0.029977394192225556d, 126.65787460843954d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 122.49419893264519d);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    org.apache.commons.math3.exception.NotPositiveException var20 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03510480520930032d);
    org.apache.commons.math3.util.Pair var21 = new org.apache.commons.math3.util.Pair((java.lang.Object)var18, (java.lang.Object)var20);
    java.lang.Number var22 = var20.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + 0+ "'", var22.equals(0));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var28, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var28);
    double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
    double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var48, var57);
    double[] var63 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var67 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var63, var67);
    double[] var72 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var76 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var72, var76);
    double var78 = org.apache.commons.math3.util.MathArrays.distance1(var67, var76);
    double var79 = org.apache.commons.math3.util.MathArrays.distance1(var48, var67);
    double var80 = org.apache.commons.math3.util.MathArrays.linearCombination(var28, var48);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var28);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    float[] var3 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    float[] var9 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var10 = new float[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var10);
    float[] var16 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var17 = new float[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var17);
    float[] var22 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var23 = new float[] { };
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var23);
    float[] var29 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var30 = new float[] { };
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var29);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var10, var29);
    float[] var37 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var38 = new float[] { };
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var38);
    float[] var41 = null;
    float[] var42 = new float[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    float[] var46 = new float[] { 10.0f, 100.0f};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var46);
    float[] var51 = new float[] { 0.0f, 100.0f, (-1.0f)};
    float[] var52 = new float[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var46, var51);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var10, var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     int var11 = var1.nextPascal(10, 0.5587862084152698d);
//     double var13 = var1.nextChiSquare(0.9991548839151001d);
//     double var16 = var1.nextF(1.089117284020693E-9d, 0.9893766669763007d);
//     long var18 = var1.nextPoisson(1.138003401968329d);
//     int var21 = var1.nextBinomial(1378651682, 0.21199833658750666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.7338432919167632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.08248062861843473d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.00818955610688335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.2517579918542614E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 292240496);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6108845);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(184.2894949557855d);
//     org.apache.commons.math3.distribution.IntegerDistribution var4 = null;
//     int var5 = var1.nextInversionDeviate(var4);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
    int var11 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0d, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     java.lang.String var13 = var1.nextHexString(41);
//     double var16 = var1.nextGaussian(0.6218279334086521d, 0.9354099024706016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 89L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1597852552636051d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5445741933391985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2777L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "13a567aeebf9c4fae326db74e5f8995e10579aaa3"+ "'", var13.equals("13a567aeebf9c4fae326db74e5f8995e10579aaa3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.8702831673476699d);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     var1.reSeed();
//     var1.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 66L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2402526466439451d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8006737532369039d);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var7 = var1.nextExponential(433.8473116074771d);
//     long var10 = var1.nextLong(32L, 2865512416584424448L);
//     int var14 = var1.nextHypergeometric(861133202, 49461254, 346212920);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.033938134911843d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6030298168839285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 193.20489943113452d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1928050374740634112L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1429);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.0714245743247656d, (java.lang.Number)(-1219167678), (java.lang.Number)2.114400155898581E24d);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     int var7 = var1.nextSecureInt(8, 1629366900);
//     var1.reSeed();
//     var1.reSeed(22L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextHypergeometric(292240496, 0, 1378651682);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1326198244);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(41);
    double var4 = var3.nextDouble();
    var3.clear();
    int[] var8 = new int[] { 0, 10};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    var3.setSeed(var8);
    var1.setSeed(var8);
    var1.setSeed(0L);
    org.apache.commons.math3.random.RandomDataGenerator var14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var14.nextGamma((-5.567555414936907E11d), 0.02946791864504028d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0.1945318675277668d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    java.lang.Comparable[] var10 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var18 = var17.getSuppressed();
    boolean var19 = var17.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = var17.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var20, false);
    boolean var24 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var20, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var26 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1L, (java.lang.Number)1, 100, var20, true);
    boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var20, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var29, false);
    org.apache.commons.math3.exception.MathIllegalStateException var32 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var5 = var4.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
//     long var7 = var4.nextLong();
//     int var9 = var4.nextInt(100);
//     int[] var12 = new int[] { 0, 10};
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
//     var4.setSeed(var12);
//     var1.setSeed(var12);
//     org.apache.commons.math3.random.RandomGenerator var16 = null;
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl(var16);
//     int var20 = var17.nextSecureInt((-1), 0);
//     int[] var23 = var17.nextPermutation(10, 8);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance(var12, var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1722448868039600408L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 5.385164807134504d);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    long var12 = var1.nextLong();
    long var13 = var1.nextLong();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-833491931516635789L));

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    int[] var14 = new int[] { 0, 10};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(41);
    double var18 = var17.nextDouble();
    var17.clear();
    int[] var22 = new int[] { 0, 10};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    var17.setSeed(var22);
    int var25 = org.apache.commons.math3.util.MathArrays.distance1(var14, var22);
    int var26 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var14);
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(89L);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     double var7 = var1.nextCauchy(0.1945318675277668d, 1426.887198243755d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var1.nextLong(46L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1486.4197506115165d));
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    float var7 = var1.nextFloat();
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(41);
    double var10 = var9.nextDouble();
    byte[] var14 = new byte[] { (byte)100, (byte)100, (byte)10};
    var9.nextBytes(var14);
    var1.nextBytes(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.15053642f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var11 = var1.nextUniform(0.5587862084152698d, 1.5324442802669078d, false);
//     org.apache.commons.math3.distribution.RealDistribution var12 = null;
//     double var13 = var1.nextInversionDeviate(var12);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    int[] var2 = new int[] { 0, 10};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    int[] var6 = new int[] { 0, 10};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 0);
    double var10 = org.apache.commons.math3.util.MathArrays.distance(var3, var6);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.8952814046994416d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.10588996378510665d);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(41);
//     double var4 = var3.nextDouble();
//     var3.clear();
//     int[] var8 = new int[] { 0, 10};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     var3.setSeed(var8);
//     var1.setSeed(var8);
//     java.util.List var12 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var13 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var12);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextSecureInt((-1), 0);
//     int[] var7 = var1.nextPermutation(10, 8);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     var8.clear();
//     int[] var10 = null;
//     var8.setSeed(var10);
//     org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     double var16 = var1.nextBeta(0.348176533212522d, 1.28390985328776d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var1.nextSecureLong(70L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.3524769890096038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 152.5304341179508d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.07958920368923077d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.20490495280989288d);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var23 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var27 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var23, var27);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     double var8 = var1.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var11 = var1.nextZipf(2, 0.8082030461156922d);
//     double var13 = var1.nextChiSquare(45.24674473641221d);
//     org.apache.commons.math3.distribution.IntegerDistribution var14 = null;
//     int var15 = var1.nextInversionDeviate(var14);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     int var6 = var1.nextSecureInt(0, 1028812019);
//     var1.reSeed();
//     var1.reSeedSecure(83L);
//     long var11 = var1.nextPoisson(20001.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("8fee", "79ddff2083");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0070873992183149446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 993972164);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 20197L);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.7881833486097136d), (java.lang.Number)1.0d, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    int var5 = var3.getIndex();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var6 = var1.nextExponential(0.1637736129994477d);
//     double var9 = var1.nextBeta(1.845734920494461d, 0.9472890462734886d);
//     long var11 = var1.nextPoisson(2840.6711051053326d);
//     java.lang.String var13 = var1.nextHexString(41);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextSecureLong(27L, (-1538904934532245248L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 88L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.07064600423240866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8278456222847481d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2906L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "4759da9266ac7a766f1f56c1be6929c11c9e8e1b5"+ "'", var13.equals("4759da9266ac7a766f1f56c1be6929c11c9e8e1b5"));
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double[] var30 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var34 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var30, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var25);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var7, var12);
    java.lang.Comparable[] var40 = new java.lang.Comparable[] { 0.03282615243296957d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var48 = var47.getSuppressed();
    boolean var49 = var47.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = var47.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var52 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)(short)(-1), 514406009, var50, false);
    boolean var54 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var40, var50, true);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12, var50, false);
    double[] var60 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var64 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance(var60, var64);
    double var66 = org.apache.commons.math3.util.MathArrays.linearCombination(var12, var60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var60);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 20001.0d);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     int var11 = var1.nextSecureInt(1, 1028812019);
//     double var13 = var1.nextChiSquare(0.03609112308169037d);
//     double var16 = var1.nextBeta(0.38398822491146434d, 0.21199833658750666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 481111419);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0986632072019959E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9825246586659446d);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var14 = var1.nextBeta(0.9893766669763007d, 0.5172264847508324d);
//     double var16 = var1.nextExponential(94.0834911443809d);
//     double var19 = var1.nextGaussian(10.0d, 0.12216901612395477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3648848276971787264L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.025756867152442804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 55.134717261181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 9.964612130852498d);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1755678109);
    var1.setSeed(1487516304763058176L);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var9);
    int[] var15 = new int[] { 0, 10};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var9, var16);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var20 = var19.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var21 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var19);
    long var22 = var19.nextLong();
    int var24 = var19.nextInt(100);
    int[] var27 = new int[] { 0, 10};
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
    var19.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var27);
    int[] var33 = new int[] { 0, 10};
    int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var27, var34);
    int var36 = org.apache.commons.math3.util.MathArrays.distance1(var16, var34);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var16);
    var37.setSeed(53L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)201.0d);
    boolean var8 = var6.equals((java.lang.Object)66L);
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var6);
    java.lang.Object var10 = var6.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 201.0d+ "'", var10.equals(201.0d));

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1028812019);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var3.reSeedSecure();

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.348375436479345d, 2.3523601350829413d, 0.3974920595329054d, 148667.53843714943d, 136.1891660715202d, 0.910874940635856d, 60.17437051555126d, 51.110525772770934d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 62296.9329173498d);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     double var10 = var1.nextExponential(2.5331613618987565d);
//     double var13 = var1.nextBeta(3.910310725123449d, 1.7619943088504275d);
//     var1.reSeed();
//     var1.reSeedSecure(17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.5746387404349753d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4295369697283599d);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     double var9 = var1.nextBeta(200.58085083797894d, 0.9991548839151001d);
//     long var12 = var1.nextSecureLong(1L, 50L);
//     double var14 = var1.nextChiSquare(2.677146259383745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9907939940356641d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.2459198552950013d);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var43 = var42.getSuppressed();
    boolean var44 = var42.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = var42.getDirection();
    boolean var47 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var45, false);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var51);
    double var58 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 141.42489172702236d);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
//     double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var13 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var17 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance(var13, var17);
//     double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance1(var17, var26);
//     double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
//     double[] var41 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var45 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
//     double[] var50 = new double[] { (-1.0d), 100.0d, 100.0d};
//     double[] var54 = new double[] { (-1.0d), 1.0d, 1.0d};
//     double var55 = org.apache.commons.math3.util.MathArrays.distance(var50, var54);
//     double var56 = org.apache.commons.math3.util.MathArrays.distance1(var45, var54);
//     double var57 = org.apache.commons.math3.util.MathArrays.linearCombination(var32, var45);
//     double var58 = org.apache.commons.math3.util.MathArrays.distance(var17, var45);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var45);
//     double[] var61 = org.apache.commons.math3.util.MathArrays.normalizeArray(var45, 1.5324442802669078d);
//     double[] var62 = null;
//     double var63 = org.apache.commons.math3.util.MathArrays.distance(var61, var62);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)6L, (java.lang.Number)62L, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextGamma(200.47512588065464d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(0.5219515461396678d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextF(2.3900651718683252d, (-3368.8741687352244d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.25149220014844d);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.7881833486097136d), (java.lang.Number)1.0d, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    int var5 = var3.getIndex();
    int var6 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     double var9 = var1.nextCauchy(2.800491802932956E8d, 27.108625880646407d);
//     double var11 = var1.nextT(0.00580589354629837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.800492109194079E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.955389919065439E8d);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var19, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var6, var19);
    double[] var35 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var39 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var40 = org.apache.commons.math3.util.MathArrays.distance(var35, var39);
    double[] var44 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var48 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance(var44, var48);
    double[] var53 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var57 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance(var53, var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var48, var57);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var35, var48);
    double[][] var61 = new double[][] { var35};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var61);
    org.apache.commons.math3.exception.MathInternalError var63 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var61);
    org.apache.commons.math3.exception.MathIllegalStateException var64 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var61);
    org.apache.commons.math3.exception.MathIllegalStateException var65 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(41);
    double var4 = var3.nextDouble();
    byte[] var8 = new byte[] { (byte)100, (byte)100, (byte)10};
    var3.nextBytes(var8);
    var1.nextBytes(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var5.nextT(2.0805938937575448E8d);
    double var9 = var5.nextChiSquare(0.9954119943753462d);
    double var12 = var5.nextGaussian(51.110525772770934d, 143.02175845384292d);
    double var14 = var5.nextT(0.8018791158561639d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.4649256620524505d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.043086182780309096d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-87.44577999312179d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.2807808114260228d));

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     var1.reSeed(26L);
//     org.apache.commons.math3.random.RandomGenerator var16 = null;
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl(var16);
//     double var19 = var17.nextChiSquare(1.145389752706889d);
//     double var21 = var17.nextChiSquare(1.145389752706889d);
//     double var24 = var17.nextCauchy(0.1945318675277668d, 0.326843498449728d);
//     int var27 = var17.nextZipf(2, 0.8082030461156922d);
//     double var29 = var17.nextChiSquare(45.24674473641221d);
//     org.apache.commons.math3.util.Pair var30 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var17);
//     double var33 = var1.nextF(0.37904438697113213d, 0.9807757175132036d);
//     double var36 = var1.nextUniform(0.0d, 1.3421345892228325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.2590144035324324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 131.31375388212714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.10756930352427577d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.12211960071194489d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.1345511885173756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.14478803215522817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 53.05885633911678d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 9.184977956017108E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.957342361544519d);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    int var4 = var1.nextZipf(100, 141.42489172702236d);
    var1.reSeed(10L);
    double var9 = var1.nextGamma(0.03449238325907719d, 0.05272999253983823d);
    double var13 = var1.nextUniform(1.8277479254844478E-9d, 0.11256102582221152d, true);
    double var16 = var1.nextCauchy(0.0d, 4.10136947356167d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var1.nextPascal((-1169327278), 1.5435297800309093d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.140285621523964E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.053747440646447896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-48.776277892868045d));

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextGamma(0.9487345360513418d, 2.0805938937575448E8d);
//     double var15 = var1.nextExponential(0.9798395551529173d);
//     long var18 = var1.nextLong(88L, 4560884032503238656L);
//     double var21 = var1.nextWeibull(4.201220679773407E-6d, 136.1891660715202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 60L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03182041532096633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 201.622404204307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.275827997978778E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6471378401759809d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2577875824542179328L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    long var2 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-414028722650554365L));

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(1.145389752706889d);
//     double var5 = var1.nextChiSquare(1.145389752706889d);
//     int var8 = var1.nextInt(0, 10);
//     double var11 = var1.nextBeta(1426.887198243755d, 1.2375875452562675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.30182395293499903d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.37734442316560013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9990728526090791d);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var6 = var1.nextFloat();
    var1.setSeed(1104140038992463488L);
    float var9 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.32099235f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.48667526f);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeed();
//     int var6 = var1.nextHypergeometric(1028812019, 100, 10);
//     long var8 = var1.nextPoisson(1.145389752706889d);
//     var1.reSeed();
//     java.lang.String var11 = var1.nextHexString(108894710);
//     int var14 = var1.nextInt(7095798, 35839364);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 34120202);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var10 = var1.nextCauchy(201.0d, 0.9487345360513418d);
//     double var13 = var1.nextWeibull(198.0d, 436827.027760391d);
//     long var15 = var1.nextPoisson(0.9998367706742745d);
//     int var18 = var1.nextPascal(1689900776, 0.3218150568087583d);
//     double var20 = var1.nextChiSquare(0.9606147597499597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 70L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0334673291224936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 203.90114992282528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 436197.4584260491d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.4190925355901569d);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Number var4 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)(-1)+ "'", var4.equals((short)(-1)));

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-59.948544411642054d), (java.lang.Number)(-0.992704106562092d), 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0738576919282752d, (java.lang.Number)(-0.1722013776235398d), 861133202, var10, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.03334200658556004d, (java.lang.Number)2856L, 1372527618, var10, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-67433603712874944L), var2, (java.lang.Number)139.459481210174d);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     int var2 = var0.nextInt();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1838574643);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2031395217);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var26 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var27 = org.apache.commons.math3.util.MathArrays.distance(var22, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var35 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var26, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var7, var26);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var43 = var42.getSuppressed();
    boolean var44 = var42.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = var42.getDirection();
    boolean var47 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var45, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var7);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(131.74990902618083d, 3.3154807820136662d, 2.955389919065439E8d, 436197.4584260491d, 0.17966370825140088d, 1.5875044512381463E-4d, 0.6008196088319883d, 11.778860840139426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.2891335713587503E14d);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var10 = var7.nextSecureLong(85L, 434516L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1722448868039600408L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 68695L);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var3 = var1.nextT(10.0d);
//     double var6 = var1.nextGaussian(141.42489172702236d, 10.0d);
//     double var9 = var1.nextCauchy((-0.00621860083647843d), 0.1945318675277668d);
//     var1.reSeed();
//     int var13 = var1.nextSecureInt(0, 1);
//     double var15 = var1.nextExponential(0.9606147597499597d);
//     var1.reSeedSecure();
//     double var19 = var1.nextCauchy(0.08248062861843473d, 0.05831133798747233d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.2723880709246647d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 149.26554082144384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.06056979050769218d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.4869231123824576d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.06618874476816025d);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    byte[] var5 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var9 = var8.nextInt();
    byte[] var12 = new byte[] { (byte)100, (byte)10};
    var8.nextBytes(var12);
    var1.nextBytes(var12);
    var1.setSeed(659309102);
    int[] var19 = new int[] { 0, 10};
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    int[] var25 = new int[] { 0, 10};
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance(var19, var26);
    var1.setSeed(var19);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     int var5 = var2.nextSecureInt(692191003, 907608747);
//     double var7 = var2.nextT(131.74990902618083d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 846654310);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 724888905);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.0083289696755164d);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)(-1), (java.lang.Number)(short)(-1), 100);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var7 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance(var3, var7);
    double[] var12 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var16 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
    double[] var21 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var25 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var21, var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var3, var16);
    double[] var32 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var36 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var32, var36);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    double[] var42 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var46 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var42, var46);
    double[] var51 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var55 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance(var51, var55);
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var46, var55);
    double[] var61 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var65 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var61, var65);
    double[] var70 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var74 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var70, var74);
    double[] var79 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var83 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var84 = org.apache.commons.math3.util.MathArrays.distance(var79, var83);
    double var85 = org.apache.commons.math3.util.MathArrays.distance1(var74, var83);
    double var86 = org.apache.commons.math3.util.MathArrays.linearCombination(var61, var74);
    double var87 = org.apache.commons.math3.util.MathArrays.distance(var46, var74);
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeDivide(var32, var74);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var74);
    double[] var90 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var74);
    double[] var92 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 0.0011265566860152974d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var16);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 141.42489172702236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var3.nextExponential(4.497671471910009d);
//     int var8 = var3.nextSecureInt(41, 1629366900);
//     double var11 = var3.nextUniform(0.10588996378510665d, 5482391.468199281d);
//     long var13 = var3.nextPoisson(0.7111788733105245d);
//     long var16 = var3.nextSecureLong(70L, 2852L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5172264847508324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 243753491);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3165323.7539757295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 977L);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }
// 
// 
//     int[] var2 = new int[] { 0, 10};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 0);
//     int[] var8 = new int[] { 0, 10};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
//     double var11 = org.apache.commons.math3.util.MathArrays.distance(var2, var9);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
//     int[] var15 = new int[] { 0, 10};
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     int[] var19 = new int[] { 0, 10};
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
//     double var23 = org.apache.commons.math3.util.MathArrays.distance(var16, var19);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance(var12, var16);
//     int[] var25 = null;
//     int var26 = org.apache.commons.math3.util.MathArrays.distance1(var16, var25);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     var1.reSeed();
//     int var8 = var1.nextSecureInt(0, 1);
//     long var11 = var1.nextSecureLong(66L, 5141685311728891869L);
//     double var13 = var1.nextT(1.4184088203104963d);
//     double var16 = var1.nextF(0.9338216241499386d, 0.75650268282136d);
//     var1.reSeed(0L);
//     double var21 = var1.nextGaussian((-1.9004211692006052d), 0.800421916980158d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1384284778512981504L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.6226080393197292d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.5902498554384293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.935224429173529d));
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)80L, (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var4 = var1.nextSecureLong(10L, 100L);
//     double var7 = var1.nextWeibull(10.0d, 0.03510480520930032d);
//     double var11 = var1.nextUniform(0.15749857420679597d, 8.11989620793123d, true);
//     double var13 = var1.nextChiSquare(160.94037419925016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 82L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03518386688993139d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.475607587642807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 168.84244404782862d);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(41);
    double var2 = var1.nextDouble();
    byte[] var6 = new byte[] { (byte)100, (byte)100, (byte)10};
    var1.nextBytes(var6);
    int[] var10 = new int[] { 0, 10};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    var1.setSeed(var11);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var17 = new int[] { 0, 10};
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var17, 0);
    int[] var23 = new int[] { 0, 10};
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 0);
    int[] var29 = new int[] { 0, 10};
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var29);
    int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance(var23, var30);
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    int[] var36 = new int[] { 0, 10};
    int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    int[] var40 = new int[] { 0, 10};
    int[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    int[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 0);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var37, var40);
    double var45 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var20, var33);
    var1.setSeed(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1991753248498107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextBeta(201.0d, 10.0d);
//     double var6 = var1.nextExponential(0.9487345360513418d);
//     java.lang.String var8 = var1.nextSecureHexString(9);
//     double var11 = var1.nextCauchy(0.03421277657519566d, 203.90114992282528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9649833079238653d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1369572668966535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "105feaf6e"+ "'", var8.equals("105feaf6e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 353.99054392049146d);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     int var4 = var1.nextZipf(100, 141.42489172702236d);
//     int var7 = var1.nextSecureInt(8, 1629366900);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1575207403);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     int var2 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var5.reSeed(19L);
//     int var10 = var5.nextZipf(8, 0.6420589260774159d);
//     int var13 = var5.nextInt(0, 1532920128);
//     int var16 = var5.nextSecureInt((-1169327278), 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1028812019);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1722448868039600408L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 73741537);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1033832066));
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.49948825038985073d);
    java.lang.Number var2 = var1.getArgument();
    java.lang.Number var3 = var1.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.49948825038985073d+ "'", var2.equals(0.49948825038985073d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var2 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong();
    int var6 = var1.nextInt(100);
    int[] var9 = new int[] { 0, 10};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var1.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var14 = var12.nextPoisson(0.0341747204280877d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1028812019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0L);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(byte)100, (java.lang.Number)0.9298969240097741d, false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    double[] var1 = new double[] { 0.0d};
    double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    double[] var6 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var10 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var6, var10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var19 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var20 = org.apache.commons.math3.util.MathArrays.distance(var15, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var28 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var24, var28);
    double[] var33 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var37 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var33, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var28, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.linearCombination(var15, var28);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var10, var15);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var15);
    double[] var46 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var50 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var51 = org.apache.commons.math3.util.MathArrays.distance(var46, var50);
    double[] var55 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var59 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var60 = org.apache.commons.math3.util.MathArrays.distance(var55, var59);
    double[] var64 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var68 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var64, var68);
    double[] var73 = new double[] { (-1.0d), 100.0d, 100.0d};
    double[] var77 = new double[] { (-1.0d), 1.0d, 1.0d};
    double var78 = org.apache.commons.math3.util.MathArrays.distance(var73, var77);
    double var79 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
    double var80 = org.apache.commons.math3.util.MathArrays.linearCombination(var55, var68);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var68);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var68, 7);
    double var84 = org.apache.commons.math3.util.MathArrays.distance1(var15, var83);
    double[] var86 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 6108845);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 140.0071426749364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 201.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 198.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

}
