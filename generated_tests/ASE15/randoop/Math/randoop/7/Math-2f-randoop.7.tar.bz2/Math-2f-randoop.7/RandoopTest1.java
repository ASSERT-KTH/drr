
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     double var12 = var1.nextExponential(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextHypergeometric(752916846, (-1), 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999967333015053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0716006288289979d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 124.58489908444417d);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.7071067811865475d), (-0.49356463521584415d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7071067811865475d));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.9532394928969042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9532394928969042d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.76195765f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.76195765f);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 1, 0, 0);
    org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var8.nextBeta((-0.49356463521584415d), 0.10727204268430017d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     double var12 = var1.nextUniform(0.06571011146367788d, 1.445648259877762d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextGaussian(0.5669767943827976d, (-0.7853981633974483d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4.833777966120487d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.4151533354010364d);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextBeta(0.0d, (-0.8009428790252594d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     int var12 = var1.nextZipf(1, 0.06571011146367788d);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var1.nextSample(var13, 130457894);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    var2.reSeedSecure(54831737849439661L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.5639623740100898d, (java.lang.Number)(byte)10, (java.lang.Number)(-1.525589885284922d));
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)10+ "'", var5.equals((byte)10));

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var5);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    java.lang.Number var17 = var16.getMin();
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    int[] var19 = new int[] { };
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    org.apache.commons.math3.random.RandomDataImpl var21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var20);
    double var24 = var21.nextCauchy(0.0d, 0.12417937830488368d);
    double var27 = var21.nextBeta(1.219806453049797d, 1.2312404863020072d);
    java.lang.Object[] var28 = new java.lang.Object[] { 1.2312404863020072d};
    org.apache.commons.math3.exception.MathIllegalStateException var29 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var16, var18, var28);
    org.apache.commons.math3.exception.MathInternalError var30 = new org.apache.commons.math3.exception.MathInternalError(var12, var28);
    org.apache.commons.math3.exception.NotFiniteNumberException var31 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, (java.lang.Number)0.9999992134249283d, var28);
    var9.addSuppressed((java.lang.Throwable)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 0.11705332797771173d+ "'", var17.equals(0.11705332797771173d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(4.9E-324d, 2.157315450679182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.157315450679182d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSupportLowerBound();
    int var5 = var3.sample();
    int[] var7 = var3.sample(130457894);
    double var9 = var3.cumulativeProbability(752916846);
    double var10 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, (-20));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)9.908525742497584E21d, false);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.756644699807056d, 376458423);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.6691806567293276d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6691806567293276d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    double var4 = var1.nextGaussian();
    org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var10 = var8.sample(100);
    var1.setSeed(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.06571011146367788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSampleSize();
    double var6 = var3.cumulativeProbability(0);
    double var7 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(675534908, 26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 675534908);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric(0, 15, 1085619743);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7904327564050461d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8.997783256992165E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.4142135623730951d));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var3, var4);
    var2.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int[] var3 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    var1.setSeed(var3);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var6.nextBeta(0.0d, 6.494156047958096d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.017453292519943295d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 752916846, 100, 0);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var6.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(752916846);
    long var4 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1722448868039600408L));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var7 = var3.upperCumulativeProbability(10);
    int var8 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var3, var4);
    var2.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)5);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(4.546466837977001d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.546466837977001d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.157315450679182d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(4.777671619489421E12d, 7.94877528443898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.94877528443898d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    java.lang.String var9 = var2.nextHexString(23);
    long var12 = var2.nextLong(0L, 10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var2.nextPascal(14, 7.94877528443898d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "0451cd5c0e0bc7a2161ab78"+ "'", var9.equals("0451cd5c0e0bc7a2161ab78"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 8L);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8291573013481451d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.563098594430906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.972665739922891d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var9 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var5, (java.lang.Number)2.7182818009955825d, (java.lang.Number)1.3329738931785933d, false);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    java.lang.Throwable[] var11 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    java.lang.Number var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.lang.Object[] var24 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var25 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var24);
    org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var21, var24);
    org.apache.commons.math3.exception.NotFiniteNumberException var27 = new org.apache.commons.math3.exception.NotFiniteNumberException(var20, var24);
    org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, var24);
    org.apache.commons.math3.exception.MathIllegalStateException var29 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var14, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var12 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var9, var12);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var12);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.308138534565753d, var12);
    java.lang.Number var19 = var18.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 0.308138534565753d+ "'", var19.equals(0.308138534565753d));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.332973893178593d, var1, true);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    long var7 = var2.nextLong((-1L), 0L);
    int var10 = var2.nextZipf(2, 140.01498023729022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var5 = var2.nextPermutation(100, 1);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(99.99999f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var1, (java.lang.Number)2.7182818009955825d, (java.lang.Number)1.3329738931785933d, false);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.1848349190787427d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-10.590260769854055d));

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.01178648078137136d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     long var5 = var0.nextPoisson(1.2312404863020072d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1629912717264998710L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.6220111893733224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2735820308772114d);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     int var16 = var1.nextInt((-17), 675534908);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextF((-0.043481143175376734d), 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.8106242215531347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.9526949173850694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 99676061);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var1.nextHypergeometric((-3), (-96398574), 675534908);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(8);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportLowerBound();
    var3.reseedRandomGenerator(3134652191960553436L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var3 = var0.nextPermutation(26, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.8948290239814146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4456482598777622d);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextZipf(0, (-2.6551558902114336d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 16);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.74324155f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.7968810768565665d, 1.3545493732010783d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7352459588364817d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(9.908525742497584E21d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 51.34082970607832d);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.tanh(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-10.590260769854055d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(14, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(4.9E-324d, 1.0684732215128296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     org.apache.commons.math3.random.RandomGenerator var18 = var1.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var1.nextInt(0, (-23));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.8318719335021232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     org.apache.commons.math3.random.RandomGenerator var18 = var1.getRandomGenerator();
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var1.nextZipf(13, (-2.131776110801955d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.674006613713901d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    var2.reSeedSecure();
    var2.reSeed(3134652191960553436L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(101.44573580065675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.312646920029849d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(162.57253213649173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.784280893229112d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)394.0226454253637d, (java.lang.Number)(-0.8390715290764523d), true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 394.0226454253637d+ "'", var5.equals(394.0226454253637d));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)550771151206886582L, (java.lang.Number)0.8948290239814146d, (java.lang.Number)1L);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     long var11 = var2.nextSecureLong(0L, 6L);
//     java.lang.String var13 = var2.nextHexString(23);
//     double var16 = var2.nextUniform(0.6373589277942243d, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var18 = var2.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "d73499f12d13c39d36a784c9892f2cf77d4680da46d992c18684a9cb634aa40bf16c9a369d7ae9338d12644ed7861928df1b"+ "'", var6.equals("d73499f12d13c39d36a784c9892f2cf77d4680da46d992c18684a9cb634aa40bf16c9a369d7ae9338d12644ed7861928df1b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 41.95856178028037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "e349bc46c8ea14fa089d2f0"+ "'", var13.equals("e349bc46c8ea14fa089d2f0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 37.72292365758171d);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var8 = var3.cumulativeProbability(0, 100);
    double var11 = var3.cumulativeProbability((-1), 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var5);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var0, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int[] var3 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    var1.setSeed(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var1.nextLong((-1740262975033857731L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.3545493732010783d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8189977931963526d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.9376703551450964d, (java.lang.Number)100.0f, (java.lang.Number)23);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 23+ "'", var4.equals(23));

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.49356463521584415d), 2.082295905353213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.49356463521584415d));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(3, 1085619743);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1085619743);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(58.59140771455618d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 59.0d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.756644699807056d, (java.lang.Number)(-3.4929149895375864d), false);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    double var6 = var2.nextExponential(0.9526367852214799d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.nextUniform(1.618958628864691d, 0.7949577687638787d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5268878066689038d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.38743261320474714d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.219806453049797d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)15.548416769665122d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100, var2, (java.lang.Number)(-2.131776110801955d));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-2.131776110801955d)+ "'", var5.equals((-2.131776110801955d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.8189977931963526d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var4);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var2.nextPascal((-96398574), 2.837425959086072d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 752916846, 100, 0);
    int var6 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-96398574));

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(4.546466837977001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 94.29864664794613d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var18 = var2.nextUniform(0.6691806567293276d, 0.8291573013481451d);
    long var21 = var2.nextLong((-1L), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.6840812884202282d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 84L);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.06571011146367788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5050388358222293d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.74324155f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7432416f);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.4456482598777622d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.16006263778805105d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 101L);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var5 = var2.nextPermutation(100, 1);
    var2.reSeed((-1L));
    int var10 = var2.nextZipf(23, 2.157315450679182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     double var10 = var2.nextChiSquare(0.9376703551450964d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "36814b3e5095a49eba9317806971a09678993bc468df07462ad06de9d8b6f5bc6e9646f9ef9055186953306dea715bcf03ed"+ "'", var6.equals("36814b3e5095a49eba9317806971a09678993bc468df07462ad06de9d8b6f5bc6e9646f9ef9055186953306dea715bcf03ed"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 164.2937684106714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.029345178584147927d);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    long var3 = var1.nextLong(550771151206886582L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 6272384587263753L);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextBinomial(10, 0.0d);
//     int var8 = var2.nextInt(0, 15);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var2.nextSample(var9, 8);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(4, (-24));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-24));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var5 = var2.nextPermutation(100, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextGamma((-21.87440112427276d), 0.308138534565753d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)9.227628765002294d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2035706397, (java.lang.Number)0.10727204268430017d, (java.lang.Number)1.131857934747715d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.131857934747715d+ "'", var5.equals(1.131857934747715d));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1000377107798907052L);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }


    int[] var1 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 675534908, 0, 40);
    int var7 = var6.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.02404834254948618d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(49.378775571836364d, 3.8029265598457256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2756826.599645119d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    long var7 = var2.nextLong((-1L), 0L);
    int var10 = var2.nextZipf(40, 1.2312404863020072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.18989547062833476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18875624565924518d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.9148029677149534d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.299199408512118d));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 0.7432416f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.563098594430906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.44667012969996406d);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-1.6026412528167446d), 0.3382758842816609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    var3.reseedRandomGenerator(0L);
    double var10 = var3.upperCumulativeProbability(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.260591836521356d, 1.1986211422292476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.06197069429210833d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)1, (java.lang.Number)Double.POSITIVE_INFINITY, (java.lang.Number)0.7949577687638787d);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-1.0531597456711106d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)(-0.7071067811865475d), (java.lang.Number)10.000685050614816d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.7071067811865475d)+ "'", var5.equals((-0.7071067811865475d)));

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var5 = var0.nextGamma(7.20877718996389d, 0.563098594430906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.334428966773409d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.7367502609782424d);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.381780321520509d), 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14575621390030322d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    var1.setSeed(54831737849439661L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.7654659033750127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7654659033750129d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.5659742383512718d, 3.650574011986194d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5659742383512718d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.05541733358459507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05538900752795655d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.7657425514272789d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeed(320948475447706239L);
    double var22 = var2.nextBeta(1.260591836521356d, 0.5659742383512718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8938633170041805d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 40, 0, 40);
    int var8 = var7.getPopulationSize();
    int var9 = var7.sample();
    double var11 = var7.cumulativeProbability(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.8813735128605069d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.414213383337351d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(19638.208794283993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.293101873153882d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(byte)1, (java.lang.Number)10L, (java.lang.Number)1.3329738931785933d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10L+ "'", var5.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10L+ "'", var6.equals(10L));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    int var16 = var2.nextPascal(23, 0.5659742383512718d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var2.nextUniform(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 13);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var8 = var4.nextUniform(0.9999999958776927d, 4.546466837977001d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var4.nextBeta((-2.667005950681052d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.6217031390950436d);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.359814909860294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    int[] var1 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 675534908, 0, 40);
    double var7 = var2.nextGaussian();
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var10 = new int[] { };
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
    var11.setSeed(10);
    byte[] var17 = new byte[] { (byte)100, (byte)(-1), (byte)100};
    var11.nextBytes(var17);
    var9.nextBytes(var17);
    var2.nextBytes(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.3674175180023106d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.999999f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     double var12 = var1.nextExponential(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextUniform(0.9532394928969042d, (-0.02404834254948618d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999988668118d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5299853250032025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 262.16036864326014d);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var5 = var2.nextPermutation(100, 1);
    var2.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var9 = var2.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     var1.reSeedSecure();
//     double var14 = var1.nextGaussian(0.0d, 1.1986211422292476d);
//     double var18 = var1.nextUniform(0.5305258769231836d, 1.4456482598777622d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999852974904073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03731493224547659d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.6028043952898969d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.9283829554531774d);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.20235113834427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0633521323368431d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999f));

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-96398574), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 0.41194829313946263d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    int var11 = var2.nextPascal(3, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextGaussian(0.6149624301072181d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(5.9604645E-8f, 99.999985f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.999985f);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextExponential((-0.6753156040846356d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     double var12 = var1.nextExponential(100.0d);
//     var1.reSeed(50L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextF(0.06197069429210833d, (-1.4142135623730951d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.4922985827533785E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8518323345005651d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.5902400281402347d);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    var1.reSeed();
    int var12 = var1.nextZipf(1, 0.06571011146367788d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var1.nextPascal(1, (-0.8390715290764523d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var5 = var3.sample(100);
    int var6 = var3.getPopulationSize();
    int var7 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(130457894, 1, 3);
    double var4 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.2995925413298486E-8d);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     org.apache.commons.math3.random.RandomGenerator var18 = var1.getRandomGenerator();
//     var1.reSeedSecure();
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var1.nextHypergeometric((-13), 14, 752916846);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.6435928919030798d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     org.apache.commons.math3.random.RandomGenerator var18 = var1.getRandomGenerator();
//     var1.reSeedSecure();
//     var1.reSeedSecure();
//     double var23 = var1.nextGaussian(0.7352459588364817d, 0.5268878066689038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-5));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.167212967057799d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.6645111083124131d);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var8 = var3.inverseCumulativeProbability(0.06571011146367788d);
    int var9 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeedSecure();
    double var21 = var2.nextUniform(1.1986211422292476d, 1.756042086747289d);
    int[] var24 = var2.nextPermutation(26, 8);
    double var27 = var2.nextWeibull(0.4887708362197951d, 14.28345980396731d);
    double var30 = var2.nextCauchy(0.0d, 1.557407690046052d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.3123830243980872d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.866925088633149d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.1182217952757596d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.407268278476896d));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.3382758842816609d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.33827588428166094d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int[] var3 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    var1.setSeed(var3);
    float var6 = var1.nextFloat();
    int[] var7 = new int[] { };
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
    var8.setSeed(10);
    double var11 = var8.nextGaussian();
    int[] var12 = new int[] { };
    var8.setSeed(var12);
    var1.setSeed(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.6862626f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.06571011146367788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(10, 130457894, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.0226129779974114d, 0.7654659033750129d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0226129779974114d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    var1.reSeedSecure((-1722448868039600408L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var1.nextBinomial(0, (-0.5996555078851037d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9999999967888756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999967888757d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.getNumberOfSuccesses();
    int var10 = var3.getPopulationSize();
    int var11 = var3.getSupportUpperBound();
    int var12 = var3.getSampleSize();
    int var13 = var3.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(3134652191960553436L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(9.258050142912936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)164.2937684106714d, var1, (java.lang.Number)1.6645111083124131d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(550771151206886582L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 550771151206886582L);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.OutOfRangeException var11 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100, var9, (java.lang.Number)(-2.131776110801955d));
    java.lang.Object[] var12 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var1, var12);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)48.876897400506486d, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    var2.reSeedSecure();
    double var9 = var2.nextGamma(6.741289558459683d, 1.230865209494995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 13.720880297171636d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2470096362876148374L, (java.lang.Number)1, true);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(3.708445464724037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var2.nextSecureLong(2177253655836675545L, 101L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "69d43a3965a9e0379495a5601a66e37b9a0ecabe5ff99eecc99b7b62dd7c7d86f0fd023a8fc7b95eeb806b3d0a091dd663ff"+ "'", var6.equals("69d43a3965a9e0379495a5601a66e37b9a0ecabe5ff99eecc99b7b62dd7c7d86f0fd023a8fc7b95eeb806b3d0a091dd663ff"));
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     var2.reSeedSecure((-1L));
//     var2.reSeedSecure(0L);
//     double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
//     double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
//     double var17 = var2.nextExponential(153.33277579697418d);
//     var2.reSeedSecure();
//     double var21 = var2.nextUniform(1.1986211422292476d, 1.756042086747289d);
//     int[] var24 = var2.nextPermutation(26, 8);
//     java.util.Collection var25 = null;
//     java.lang.Object[] var27 = var2.nextSample(var25, 6);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.3329738931785933d, (-2.131776110801955d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.541886338211227d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    var2.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var14 = var2.nextPoisson((-0.1729143413471307d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2108499566);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.8009428790252594d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9288683334870875d));

  }

//  public void test185() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
//
//
//    int[] var0 = new int[] { };
//    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//    var2.reSeedSecure((-1L));
//    var2.reSeedSecure(0L);
//    double var11 = var2.nextT(0.06571011146367788d);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      java.lang.String var13 = var2.nextHexString(752916846);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == (-0.20221127419725435d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var11 == 3.621907632906563E7d);
//
//  }
//
  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    double var10 = var2.nextT(0.8530627877982958d);
    double var13 = var2.nextF(2.837425959086072d, 35.23475180425246d);
    double var16 = var2.nextF(0.9999984268504751d, 1.6645111083124131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-2.589860825112713d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.58629622320762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.26049206414944576d);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     java.lang.String var16 = var1.nextHexString(13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextInt(3, (-3));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "8291a2010c0ef"+ "'", var16.equals("8291a2010c0ef"));
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.01538287103360378d));

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var3 = var1.nextInt();
//     double var4 = var1.nextDouble();
//     double var5 = var1.nextDouble();
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var8 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//     var9.setSeed(10);
//     byte[] var15 = new byte[] { (byte)100, (byte)(-1), (byte)100};
//     var9.nextBytes(var15);
//     var7.nextBytes(var15);
//     var1.nextBytes(var15);
//     byte[] var19 = null;
//     var1.nextBytes(var19);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     org.apache.commons.math3.random.RandomGenerator var18 = var1.getRandomGenerator();
//     var1.reSeedSecure();
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var22 = var1.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-21));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.3081541702018147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    var1.reSeed();
    var1.reSeedSecure();
    var1.reSeedSecure(2177253655836675545L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.getNumberOfSuccesses();
    int var10 = var3.getPopulationSize();
    int var11 = var3.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var3.inverseCumulativeProbability(6.741289558459683d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.18875624565924518d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17290758883568633d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSupportLowerBound();
    int var5 = var3.sample();
    int var6 = var3.getSupportLowerBound();
    int var7 = var3.getSupportLowerBound();
    double var9 = var3.cumulativeProbability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     double var12 = var1.nextUniform(0.06571011146367788d, 1.445648259877762d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextZipf((-1), 2.414213383337351d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6821653916790549d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0815945439186612d);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.136102024090793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1146040209876107d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.9999852974904073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6.385265726060406E-6d));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextT(153.33277579697418d);
    double var13 = var2.nextBeta(48.876897400506486d, 1.4711276743037347d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var2.nextCauchy(0.9999984268504751d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.6026412528167446d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9376703551450964d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(94.29864664794613d, 0.07729528392594412d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 94.29864664794613d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.7853981633974482d), 1.3545493732010783d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5657759352817755d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var5 = var2.nextPermutation(100, 1);
    var2.reSeed((-1L));
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-1.4142135623730951d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9553166181245093d));

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     org.apache.commons.math3.random.RandomGenerator var18 = var1.getRandomGenerator();
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var1.nextGamma(1.0d, (-9.714723000591938d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-177.42460785849465d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.6028043952898969d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8237488908136895d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.131857934747715d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(41.68186418036695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(2.837425959086072d, 132088406);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var9 = var3.inverseCumulativeProbability(0.11705332797771173d);
    double var11 = var3.probability(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    long var7 = var2.nextLong((-1L), 0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextWeibull(Double.NEGATIVE_INFINITY, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0L);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 1, 0, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, (-3), 376458423, 40);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     org.apache.commons.math3.random.RandomGenerator var8 = var1.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator(var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var9.nextBinomial(8, 3.1146040209876107d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6099965704598191d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.2767189370086316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportLowerBound();
    double var8 = var3.cumulativeProbability(26);
    int var10 = var3.inverseCumulativeProbability(0.1370495062037017d);
    int var11 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 1, 0, 0);
    org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var8.nextPascal((-23), (-3.4160534760971524E-7d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSampleSize();
    double var6 = var3.cumulativeProbability(0);
    double var7 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var6, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(-1L), var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0628567339711192d, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.2995925413298486E-8d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2995925413298486E-8d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.76195765f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.76195765f);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int[] var9 = var3.sample(13);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    double var11 = var10.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.22609424527046035d));

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.6373589277942243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.011124011806990014d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.1920928E-7f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920928E-7f);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.473974825082335d, (-2.037677266640974d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0920757103406324d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(5.312646920029849d, 0.541886338211227d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.340211428440133d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.00001f);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.563098594430906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7561055373981006d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextF(0.2478736222527921d, 0.06571011146367788d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.9270047273772683E9d);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(99.99999f, 99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9999999898967565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999949483782d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.2312404863020072d, 1.2308652094949952d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.231240486302007d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.12482164366779293d);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     java.lang.String var16 = var1.nextHexString(13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var18 = var1.nextHexString((-17));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "40df9ef0a11d4"+ "'", var16.equals("40df9ef0a11d4"));
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var5 = var3.sample(100);
    int var6 = var3.getPopulationSize();
    var3.reseedRandomGenerator(2472679844610678315L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    long var7 = var2.nextLong((-1L), 0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextWeibull((-0.8009428790252594d), 0.12417937830488368d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0L);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextSecureInt(2035706397, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9753974853640064d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.2943922621506574d);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(94.29864664794613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.645821864181374d);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     int var5 = var0.nextSecureInt(10, 15);
//     double var7 = var0.nextExponential(1.111350542302613d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGamma(153.33277579697418d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7562331291796216d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0569750161358153d);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.4E-45f, 26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.403955E-38f);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)Float.POSITIVE_INFINITY);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9526367852214799d, 0.2994538297962787d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05427529583264373d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     double var12 = var1.nextExponential(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var1.nextPoisson((-0.8390715290764523d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0011023208556432613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.6711217927205775d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 97.42421919295879d);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.9999999f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9999999f));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 100.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.00001f);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.nextExponential((-1.6026412528167446d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var5 = var2.nextPermutation(100, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var2.nextPermutation(0, 2);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.5403023941188468d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5169658851857125d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(752916846);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var2.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    double var4 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var5.nextCauchy(0.07960895200719602d, 4.777671619489421E12d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var5.nextPascal((-13), 1.618958628864691d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4887708362197951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-2.710528153089538E13d));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var18 = var2.nextUniform(0.6691806567293276d, 0.8291573013481451d);
    int var21 = var2.nextZipf(1, 0.9999999958776927d);
    double var23 = var2.nextExponential(2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var26 = var2.nextLong(2601703043079604093L, 6272384587263753L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.6840812884202282d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.3781384949352722d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var6 = var3.getNumericalMean();
    double var8 = var3.probability(0);
    int var9 = var3.getPopulationSize();
    var3.reseedRandomGenerator((-1740262975033857731L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(4.293101873153882d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 72.19315262034397d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var4.nextHypergeometric(2035706397, 10, (-3));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var11 = var2.nextLong(935500050423093910L, 293141324453066497L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(752916846);
    var1.clear();

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)2.7182818009955825d, (java.lang.Number)1.3329738931785933d, false);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)3.1146040209876107d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(10L, 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     var2.reSeedSecure((-1L));
//     var2.reSeedSecure(0L);
//     double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
//     double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
//     double var18 = var2.nextUniform(0.6691806567293276d, 0.8291573013481451d);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var2.nextSample(var19, 0);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(142.78488571751902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1546822382743223d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.14575621390030322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14575621390030324d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    byte[] var7 = new byte[] { (byte)100, (byte)(-1), (byte)100};
    var1.nextBytes(var7);
    float var9 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.91588104f);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(44);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.7071067811865475d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.7432416f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(6L, 3050288269871742267L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.1920928E-7f, 1.1920928E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920928E-7f);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.0174774264994466d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.07960895200719602d, 0.12482164366779294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14804738419713304d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)Double.NEGATIVE_INFINITY, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.403955E-38f, 0.76195765f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.76195765f);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.33213557751171413d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.9999999f), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.9999998f));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-1), (-13), 1085619743);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt((-23));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.8512271908466933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-2.8353556711096726d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9931328331574297d));

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(9.258050142912936d, (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.470287810588242E-5d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.1986211422292476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3155421084517607d);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     int var5 = var0.nextSecureInt(10, 15);
//     double var7 = var0.nextExponential(1.111350542302613d);
//     var0.reSeedSecure(53118080855161933L);
//     int var12 = var0.nextBinomial(1, 0.9283829554531774d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextZipf((-24), 1.8003617275912993d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6733524472454128d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.8526363566740347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.8189977931963526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.08671726845195996d));

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     long var11 = var2.nextSecureLong(0L, 6L);
//     java.lang.String var13 = var2.nextHexString(23);
//     double var16 = var2.nextUniform(0.6373589277942243d, 100.0d);
//     var2.reSeedSecure();
//     long var20 = var2.nextLong((-632531912162527059L), 550771151206886582L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b256676c8f4acf2e90614d0a8b5de337c5307c568597ba4b8b3e64963a6962f3d6328f20bd77e4483e724b85897fca474969"+ "'", var6.equals("b256676c8f4acf2e90614d0a8b5de337c5307c568597ba4b8b3e64963a6962f3d6328f20bd77e4483e724b85897fca474969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 22.518886850744124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "d2320971a6bac4e665d10bb"+ "'", var13.equals("d2320971a6bac4e665d10bb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 34.68243206466104d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-598068589977130356L));
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    java.lang.String var9 = var2.nextHexString(23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextZipf(2147483647, (-0.381780321520509d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "0451cd5c0e0bc7a2161ab78"+ "'", var9.equals("0451cd5c0e0bc7a2161ab78"));

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.44667012969996406d, (-17.37923146202725d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-17.37923146202725d));

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }


    int[] var1 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var5 = var0.nextGamma(11.079397880425052d, 1.230865209494995d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextLong(1000377107798907052L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.1679863915645883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15.622453848581099d);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var8, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(short)0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.12482164366779293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12482164366779294d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 326202023);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.95263678522148d, 0.12482164366779293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.04593636412086344d));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var10);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var7, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.1920929E-7f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920929E-7f);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.645821864181374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-13.303776996769555d));

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.01538287103360378d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.015382871033603779d));

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
    var1.reSeedSecure(2L);
    var1.reSeed(4187054274462996441L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var1.nextHypergeometric(13, 15, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.5268878066689038d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    double var2 = var1.nextGaussian();
    int[] var3 = null;
    var1.setSeed(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2478736222527921d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, var2, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    boolean var6 = var4.getBoundIsAllowed();
    java.lang.Number var7 = var4.getArgument();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var9 = null;
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var8, var9);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
    var4.addSuppressed((java.lang.Throwable)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)0+ "'", var7.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    var2.reSeed(6272384587263753L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var2.nextUniform(142.78488571751902d, 0.95263678522148d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.6862626f, (java.lang.Number)0.9999999949483782d, false);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.9459540284714764d, (java.lang.Number)1.2308652094949952d, (java.lang.Number)7.151753374050393d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    var1.reSeed();
    int var12 = var1.nextZipf(1, 0.06571011146367788d);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var1.nextUniform(2.8224185856954223d, 0.18989547062833476d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     int var16 = var1.nextInt((-17), 675534908);
//     org.apache.commons.math3.random.RandomGenerator var17 = var1.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8036431768800762d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.10751859704747677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 254773876);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var2.nextCauchy(2.5974978553141077d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(53118080855161933L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 53118080855161933L);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-632531912162527059L), 833719514626151726L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 833719514626151726L);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeed(8L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var1.nextPascal((-23), 0.9999999949483782d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(100.0f, 99.999985f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.999985f);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Number var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     java.lang.Object[] var9 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var9);
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var6, var9);
//     org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, var9);
//     org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(-1L), var9);
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)2, var9);
//     org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var0, var9);
//     java.lang.String var16 = var15.toString();
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var3 = var1.nextInt();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 752916846);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9447191412588156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.382889417089179d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     int var5 = var0.nextSecureInt(10, 15);
//     double var7 = var0.nextExponential(1.111350542302613d);
//     var0.reSeedSecure(53118080855161933L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextPascal(132088406, (-1.525589885284922d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.018838064378818273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.12473372983364532d);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-3.4160534760971524E-7d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.293955920339377E-23d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    double var7 = var2.nextChiSquare(0.06571011146367788d);
    var2.reSeedSecure((-1740262975033857731L));
    double var11 = var2.nextT(0.9447191412588156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.012006336300978443d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-6.234098543068828d));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    int var8 = var5.nextZipf(23, 1.7610576579556785d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var5.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3233753233997579692L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 5);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)2.2995925413298486E-8d, var6);
    java.lang.Number var12 = var11.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 2.2995925413298486E-8d+ "'", var12.equals(2.2995925413298486E-8d));

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.8237488908136895d, 0.4589530617518622d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0624789843382798d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    int var16 = var2.nextPascal(23, 0.5659742383512718d);
    long var18 = var2.nextPoisson(0.5055845672881804d);
    long var21 = var2.nextLong(0L, 2L);
    long var23 = var2.nextPoisson(0.6953957962869728d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var26 = var2.nextZipf(675534908, (-0.6753156040846356d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0L);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.8737484983160598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4066295125657005d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    int var16 = var2.nextPascal(23, 0.5659742383512718d);
    long var18 = var2.nextPoisson(0.5055845672881804d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var2.nextGamma((-0.7853981633974483d), 3.7367502609782424d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2L);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var7 = var3.upperCumulativeProbability(10);
    double var9 = var3.probability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-10.590260769854055d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0L, (java.lang.Number)0.76195765f, false);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int[] var3 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    var1.setSeed(var3);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(1362564568071945760L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed(3134652191960553436L);
//     org.apache.commons.math3.distribution.RealDistribution var5 = null;
//     double var6 = var2.nextInversionDeviate(var5);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.07722623227629755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var17 = var1.nextHexString((-24));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-5));
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.String var2 = var1.toString();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.0d), (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var2.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.8189977931963526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8189977931963527d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.sample();
    var3.reseedRandomGenerator(2470096362876148374L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.6840812884202282d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.6149624301072181d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5513487045994631d);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     long var11 = var2.nextSecureLong(0L, 6L);
//     java.lang.String var13 = var2.nextHexString(23);
//     double var16 = var2.nextUniform(0.6373589277942243d, 100.0d);
//     var2.reSeedSecure();
//     org.apache.commons.math3.distribution.RealDistribution var18 = null;
//     double var19 = var2.nextInversionDeviate(var18);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)0.11705332797771173d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Object[] var7 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var7);
    var3.addSuppressed((java.lang.Throwable)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(2L);
    double var2 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.604776607991365d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.8390715290764524d), 0.7210596238295536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8608966854929103d));

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(8192.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.765625E-4f);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextUniform(0.0d, (-0.6753156040846356d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextBinomial(10, 0.0d);
//     int var8 = var2.nextInt(0, 15);
//     double var11 = var2.nextBeta(5.72574711174442d, 2.0d);
//     double var13 = var2.nextChiSquare(0.3382758842816608d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var2.nextSample(var14, 284337143);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(1, 100);
    org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var14 = var12.sample(100);
    int var15 = var12.getPopulationSize();
    int var16 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var2.nextZipf((-1), 0.972665739922891d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)5.72574711174442d, (java.lang.Number)0.9376703551450964d, (java.lang.Number)(-0.8390715290764523d));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.8390715290764523d)+ "'", var5.equals((-0.8390715290764523d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.8390715290764523d)+ "'", var6.equals((-0.8390715290764523d)));

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    int var16 = var2.nextPascal(23, 0.5659742383512718d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var2.nextGaussian(11.079397880425052d, Double.NEGATIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 13);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-598068589977130356L));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var5, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(-1L), var8);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var1, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(99.999985f, 9.765625E-4f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.999985f);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.260591836521356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.022001478071059764d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.sample();
    int var9 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)142.78488571751902d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8L);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(94.29864664794613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210854715202004E-14d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    double var4 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var5.reSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4887708362197951d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    boolean var8 = var3.isSupportConnected();
    boolean var9 = var3.isSupportConnected();
    double var11 = var3.probability(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSampleSize();
    int var5 = var3.getPopulationSize();
    int var6 = var3.getSampleSize();
    int var7 = var3.getSampleSize();
    double var9 = var3.upperCumulativeProbability((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     var0.reSeed();
//     double var7 = var0.nextWeibull(3.708445464724037d, 1.111350542302613d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt(376458423, 40);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1952326980067419199L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9325969056522956d);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     int var12 = var1.nextInt((-24), 3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextGamma(1.7560420867472888d, (-0.8813735870195429d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-15));
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(14.531995745214504d);
//     org.apache.commons.math3.distribution.RealDistribution var3 = null;
//     double var4 = var0.nextInversionDeviate(var3);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(10.0d, 1.3329738931785933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6637911454287462d));

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportLowerBound();
    double var8 = var3.cumulativeProbability(26);
    boolean var9 = var3.isSupportConnected();
    double var10 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var1.nextSecureHexString((-20));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9.534362544098597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.8468393679842026d);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var5, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(-1L), var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1.167212967057799d, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var8 = var3.cumulativeProbability(0, 100);
    double var10 = var3.cumulativeProbability(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var3.cumulativeProbability(1085619743, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.6960300197422588d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5282902375327906d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)1, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var10);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var7, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, var10);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var5, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var10);
    java.lang.Throwable[] var16 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextBinomial(10, 0.0d);
//     int var8 = var2.nextInt(0, 15);
//     int var11 = var2.nextPascal(3, 0.0d);
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var18 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var14, 752916846, 0, 100);
//     int var19 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var18);
//     java.util.Collection var20 = null;
//     java.lang.Object[] var22 = var2.nextSample(var20, (-1));
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-0.2838693433687199d), var1, true);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 40);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    double var11 = var2.nextBeta(5.72574711174442d, 2.0d);
    var2.reSeedSecure(6272384587263753L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var2.nextBeta(0.26049206414944576d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5659742383512718d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(51.34082970607832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9817051484995168E22d);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     var1.reSeedSecure();
//     int var14 = var1.nextHypergeometric(15, 10, 13);
//     double var17 = var1.nextCauchy((-1.4142135623730951d), 1.4035340560729603d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextZipf((-5), (-17.37923146202725d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9911066200116527d);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)6L, var1, (java.lang.Number)4.506353702662211d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, 0, (-24));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.6840812884202282d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5999621800237206d);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     int var16 = var1.nextZipf(40, 1.136102024090793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.9189026591453611d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.021638335491554795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 11);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.17125344463613587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15807449555753486d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    var2.reSeed(10L);
    double var15 = var2.nextF(1.1043047119603162d, 0.5659742383512718d);
    int var18 = var2.nextInt((-24), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0287702751273755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-8));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var5.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3233753233997579692L);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    int[] var1 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(550771151206886582L, (-1722448868039600408L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 550771151206886582L);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    long var3 = var1.nextLong(54831737849439661L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 26756221275095315L);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.0f, 99.999985f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.01178648078137136d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.734723475976807E-18d);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     java.lang.String var11 = var1.nextHexString(2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3966852724139922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "02"+ "'", var11.equals("02"));
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.9718532847495456d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5637698131160296d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var2);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var7, (java.lang.Number)2.7182818009955825d, (java.lang.Number)1.3329738931785933d, false);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    java.lang.Throwable[] var13 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.756644699807056d, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    var1.setSeed(0L);
    float var4 = var1.nextFloat();
    boolean var5 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.74324155f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.8210298852208764d, (java.lang.Number)0.07960895200719602d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.07960895200719602d+ "'", var5.equals(0.07960895200719602d));

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     var1.reSeedSecure();
//     int var14 = var1.nextHypergeometric(15, 10, 13);
//     double var17 = var1.nextCauchy((-1.4142135623730951d), 1.4035340560729603d);
//     double var19 = var1.nextExponential(11.975951657450514d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var22 = var1.nextSecureLong(32377152420278742L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-16.963446629761187d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 8.1574061016057d);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    double var4 = var1.nextGaussian();
    float var5 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4887708362197951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.055535913f);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var4);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var15 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    java.lang.Number var16 = var15.getMin();
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    int[] var18 = new int[] { };
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var18);
    org.apache.commons.math3.random.RandomDataImpl var20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var19);
    double var23 = var20.nextCauchy(0.0d, 0.12417937830488368d);
    double var26 = var20.nextBeta(1.219806453049797d, 1.2312404863020072d);
    java.lang.Object[] var27 = new java.lang.Object[] { 1.2312404863020072d};
    org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var15, var17, var27);
    org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var11, var27);
    org.apache.commons.math3.exception.NotFiniteNumberException var30 = new org.apache.commons.math3.exception.NotFiniteNumberException(var9, (java.lang.Number)0.9999992134249283d, var27);
    var7.addSuppressed((java.lang.Throwable)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 0.11705332797771173d+ "'", var16.equals(0.11705332797771173d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(118802413304362069L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 118802413304362069L);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.12482164366779293d, 326202023);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
//     java.lang.Number var5 = var4.getMin();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     int[] var7 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var8);
//     double var12 = var9.nextCauchy(0.0d, 0.12417937830488368d);
//     double var15 = var9.nextBeta(1.219806453049797d, 1.2312404863020072d);
//     java.lang.Object[] var16 = new java.lang.Object[] { 1.2312404863020072d};
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, var16);
//     org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError(var0, var16);
//     org.apache.commons.math3.exception.util.Localizable var19 = null;
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Number var23 = null;
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     java.lang.Object[] var27 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var28 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var27);
//     org.apache.commons.math3.exception.MathInternalError var29 = new org.apache.commons.math3.exception.MathInternalError(var24, var27);
//     org.apache.commons.math3.exception.NotFiniteNumberException var30 = new org.apache.commons.math3.exception.NotFiniteNumberException(var23, var27);
//     org.apache.commons.math3.exception.NotFiniteNumberException var31 = new org.apache.commons.math3.exception.NotFiniteNumberException(var21, (java.lang.Number)(-1L), var27);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var32 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var20, var27);
//     org.apache.commons.math3.exception.MathIllegalStateException var33 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, var27);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
    var1.reSeedSecure(2L);
    var1.reSeed(4187054274462996441L);
    double var16 = var1.nextCauchy(0.7561055373981006d, 0.011124011806990014d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.7406723831325803d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 1, 0, 0);
    int var8 = var7.sample();
    int var9 = var7.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    double var7 = var2.nextT(0.6579544231599213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.3361742793920452d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var6, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var9);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    var2.reSeed(6272384587263753L);
    double var15 = var2.nextChiSquare(0.6459203537059701d);
    double var18 = var2.nextGamma(5.725827877519875d, 0.09388966872108925d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.013015622557213214d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.36707033892490126d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    int[] var1 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 675534908, 0, 40);
    boolean var7 = var2.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var2.nextSecureHexString((-23));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextUniform(0.2994538297962787d, (-0.6981152095798223d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var8 = var3.cumulativeProbability(0, 100);
    int var9 = var3.getSampleSize();
    double var11 = var3.probability(675534908);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.String var1 = var0.toString();
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var8);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var5, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(-1L), var8);
    var0.addSuppressed((java.lang.Throwable)var12);
    java.lang.String var14 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var1.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var14.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(909182017881509741L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
//     double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
//     var2.reSeed(6272384587263753L);
//     double var16 = var2.nextF(0.9675739059096364d, 1.6220111893733224d);
//     org.apache.commons.math3.distribution.RealDistribution var17 = null;
//     double var18 = var2.nextInversionDeviate(var17);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.30321196946857537d, (-2.131776110801955d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.729189998362866d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.618958628864691d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0174774264994466d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(550771151206886582L, 32377152420278742L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32377152420278742L);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1L), 26756221275095315L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextSecureLong(100L, (-632531912162527059L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(2.082295905353213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4430162526296137d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-2.131776110801955d), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.46909241309764416d));

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(byte)1, (java.lang.Number)10L, (java.lang.Number)1.3329738931785933d);
//     java.lang.Number var5 = var4.getLo();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     java.lang.Number var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     java.lang.Object[] var13 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var13);
//     org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var10, var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, var13);
//     org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, var13);
//     org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError(var7, var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, var13);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextSecureInt((-1), 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextUniform(0.0d, (-1.6026412528167446d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.05538900752795655d, 1.231240486302007d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0718960554794247d));

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var8 = var1.nextGaussian(Double.NaN, 2.0d);
//     long var10 = var1.nextPoisson(4.546466837977001d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextBeta(0.0d, (-2.6198971179968926d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9797931675715639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
    var1.reSeedSecure(2L);
    var1.reSeed(4187054274462996441L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var16 = var1.nextLong(0L, (-598068589977130356L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     int var5 = var0.nextSecureInt(10, 15);
//     double var7 = var0.nextExponential(1.111350542302613d);
//     double var9 = var0.nextExponential(2.2995925413298486E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8914186821429264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.9489420841230134d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.4871172143876154E-9d);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     int var16 = var1.nextInt((-17), 675534908);
//     var1.reSeed(50L);
//     int var21 = var1.nextSecureInt(40, 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3912707045123993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.347864817075586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 64378680);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1151705153);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    double var7 = var2.nextChiSquare(0.06571011146367788d);
    var2.reSeedSecure((-1740262975033857731L));
    double var12 = var2.nextCauchy(0.5305258769231836d, 0.5553045636165086d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var2.nextSecureInt(254773876, 9);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.012006336300978443d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-2.6198971179968926d));

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(5.312646920029849d, (-2.1317761108019555d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 752916846, 100, 0);
    int var6 = var5.getNumberOfSuccesses();
    double var9 = var5.cumulativeProbability(11, 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(14.531995745214504d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextPascal(40, 4.293101873153882d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.7462234265951966d);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextBinomial(10, 0.0d);
//     int var8 = var2.nextInt(0, 15);
//     int var11 = var2.nextInt(8, 376458423);
//     int var14 = var2.nextSecureInt(8, 1142493068);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 287557071);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 154108614);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextSecureInt(2035706397, 40);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 990497257390825717L);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.0d, (java.lang.Number)1.4E-45f, (java.lang.Number)0.11705332797771173d);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
//     double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
//     var2.reSeed(6272384587263753L);
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var2.nextInversionDeviate(var14);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(19638.208794283993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.11360163361635774d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeed(8L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var1.nextGamma((-6.234098543068828d), 2.837425959086072d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(100.00001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.00001f);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSupportLowerBound();
    double var6 = var3.upperCumulativeProbability((-17));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     double var12 = var1.nextUniform(0.06571011146367788d, 1.445648259877762d);
//     java.lang.String var14 = var1.nextSecureHexString(40);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextF(1.445648259877762d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.2926162988207126d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.07362034679127297d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "a683fad3d4fa1b465a83ab3515254ef8829be573"+ "'", var14.equals("a683fad3d4fa1b465a83ab3515254ef8829be573"));
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9999852974904073d, 0.17125344463613587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0145434133129643d);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.9718532847495457d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextPascal((-24), 9.227628765002294d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.0717333162682749d));
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9999982968618759d, 3.3361742793920452d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999982968618759d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9999984268504751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8414701348305396d);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     double var7 = var2.nextGaussian(0.12482164366779294d, 1.0d);
//     long var10 = var2.nextSecureLong(1L, 935500050423093910L);
//     double var12 = var2.nextT(7.20877718996389d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextInt((-1), (-20));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3482869991460242d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 366300788464773751L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.16647195906754597d);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.7432416f, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3716208f);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    int[] var4 = new int[] { };
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    var1.setSeed(var4);
    var1.setSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.OutOfRangeException var11 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100, var9, (java.lang.Number)(-2.131776110801955d));
    java.lang.Object[] var12 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var1, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1L, (java.lang.Number)2.8374259590860724d, (java.lang.Number)0.8894389697993161d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.8894389697993161d+ "'", var6.equals(0.8894389697993161d));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1000377107798907052L, 26756221275095315L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 26756221275095315L);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var1.nextGamma(Double.NEGATIVE_INFINITY, (-0.9931328331574297d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-0.9999999f), 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.8189977931963527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     int var16 = var1.nextInt((-17), 675534908);
//     var1.reSeed(50L);
//     int var21 = var1.nextBinomial(44, 0.30321196946857537d);
//     int var24 = var1.nextSecureInt((-5), 130457894);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6.835397182078164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.148242159388813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 73705308);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 10069743);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     var0.reSeed();
//     double var7 = var0.nextWeibull(3.708445464724037d, 1.111350542302613d);
//     double var10 = var0.nextGamma(0.7561055373981006d, 35.23475180425246d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3128016474246375627L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9384746592619848d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20.47653745857958d);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     long var13 = var1.nextSecureLong(32377152420278742L, 935500050423093910L);
//     double var15 = var1.nextT(0.18875624565924518d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.671930192904739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 491781158816751194L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9257665025911263d);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextWeibull(0.9999992134249283d, 0.5403023058681398d);
//     var1.reSeedSecure(32377152420278742L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextHypergeometric(4, 0, 1142493068);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.07232538253771699d);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(58.59140771455618d, 0.6028043952898969d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 58.59450854058198d);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     double var12 = var1.nextGamma(1.0226129779974114d, 3.621748041405217E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.9430204333214194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.2792426218132878E7d);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    double var4 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var5.nextCauchy(0.07960895200719602d, 4.777671619489421E12d);
    double var11 = var5.nextCauchy((-0.381780321520509d), 1.4066295125657005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4887708362197951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-2.710528153089538E13d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-5.050874460566523d));

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportLowerBound();
    int var7 = var3.getSupportLowerBound();
    int var8 = var3.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    double var4 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var5.nextBeta(0.0d, 0.9999984268504751d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4887708362197951d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9999999967888757d, 0.604776607991365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1686550984577497d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", "0451cd5c0e0bc7a2161ab78");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)5.72574711174442d, (java.lang.Number)(byte)0, false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)0+ "'", var4.equals((byte)0));

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(72.19315262034397d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.1729143413471307d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.030412091907585977d, var1, (java.lang.Number)94.29864664794613d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, (-0.8390715290764523d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4E-45f));

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.9553166181245093d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     org.apache.commons.math3.random.RandomGenerator var8 = var1.getRandomGenerator();
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator(var8);
//     double var12 = var9.nextUniform((-0.5379756673784256d), 1.0005802266423802d);
//     var9.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9488530554154536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.7677528141015872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.053685308829511835d);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.9967258730180175d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.2066063957172197d));

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(10L);
    double var5 = var1.nextT(1.20235113834427d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var1.nextWeibull(3.621748041405217E7d, (-0.5379756673784256d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.2838693433687199d));

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextChiSquare(1.2792426218132878E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9971595087651498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.2804846320346452E7d);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(8.419052874627646d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-5));

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var5 = var0.nextGamma(11.079397880425052d, 1.230865209494995d);
//     var0.reSeedSecure(53118080855161933L);
//     double var9 = var0.nextExponential(1.0005802266423802d);
//     double var12 = var0.nextCauchy(0.0d, 1.6220111893733224d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextHypergeometric((-96398574), 2, 73705308);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.35707081683567987d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14.418731770750599d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.789840732338351d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.020028419891815558d));
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(5.784280893229112d, 0.6459203537059701d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.02900229012461919d));

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     org.apache.commons.math3.random.RandomGenerator var18 = var1.getRandomGenerator();
//     var1.reSeedSecure();
//     var1.reSeedSecure(10L);
//     long var24 = var1.nextLong((-632531912162527059L), 1836572524937022264L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-24));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.479378538017092d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 746655807892822235L);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.8587477027164937d, 0.19299439529296336d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9710384551102957d);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     int var16 = var1.nextInt((-17), 675534908);
//     var1.reSeedSecure(1836572524937022264L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6.111716117802738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.07903214188102678d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6216880);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    var3.reseedRandomGenerator(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var3.cumulativeProbability(675534908, (-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(3134652191960553436L, 2472679844610678315L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2472679844610678315L);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    int var7 = var4.nextInt(9, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 44);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(9.403955E-38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-123));

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0000001f, (java.lang.Number)Float.POSITIVE_INFINITY, (java.lang.Number)(-1.4142135623730951d));

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     var1.reSeedSecure();
//     double var14 = var1.nextGaussian(0.0d, 1.1986211422292476d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextUniform(0.06197069429210833d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9949197460156582d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.09912697705587746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-2.0632635373916792d));
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var3 = var1.nextInt();
    double var4 = var1.nextDouble();
    double var5 = var1.nextDouble();
    long var7 = var1.nextLong(3233753233997579692L);
    int var9 = var1.nextInt(4);
    boolean var10 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 752916846);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8894389697993161d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.1339041896989337d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3050288269871742267L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)675534908, (java.lang.Number)14.531995745214504d, (java.lang.Number)48.876897400506486d);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 48.876897400506486d+ "'", var4.equals(48.876897400506486d));

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var8 = var3.cumulativeProbability(0, 100);
    double var9 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var3.inverseCumulativeProbability((-0.20221127419725435d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(5.784280893229112d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.914608302884361d);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4331763560234572d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    int var16 = var2.nextPascal(23, 0.5659742383512718d);
    long var18 = var2.nextPoisson(0.5055845672881804d);
    double var20 = var2.nextT(3.621748041405217E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.8397810204666825d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeed(10L);
    double var5 = var1.nextT(1.20235113834427d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSecureAlgorithm("4c60b8f1fb7877bd0886512", "8ab99d2f56b1a09839548c62dee9df5a2fe33d50453cb43a2bdfcbde54b5bc04a07429e4748e20f91cc779b2e94ba7bc8577");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.2838693433687199d));

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, var4);
//     java.lang.String var8 = var7.toString();
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9999984268504752d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5574023358148001d);

  }

}
