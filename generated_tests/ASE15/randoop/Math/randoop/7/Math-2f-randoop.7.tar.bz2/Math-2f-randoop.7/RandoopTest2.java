
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-15));
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    java.lang.Number var4 = var3.getMin();
    java.lang.Number var5 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.11705332797771173d+ "'", var4.equals(0.11705332797771173d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.11705332797771173d+ "'", var5.equals(0.11705332797771173d));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-21.87440112427276d));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 752916846);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1151705153);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1151705153);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    double var11 = var2.nextBeta(5.72574711174442d, 2.0d);
    double var13 = var2.nextT(7.20877718996389d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5659742383512718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.6441925846801777d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.3966852724139922d, 101.44573580065675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3966852724139924d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.7432416f, 1.1920928E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7432416f);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    double var11 = var2.nextBeta(5.72574711174442d, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextSecureInt(0, (-23));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5659742383512718d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var4, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-1L), var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    int var7 = var4.nextBinomial(32, 0.5637698131160296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 15);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(9.258050142912936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 530.4471997093998d);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.9967258730180175d), 1.2792426218132878E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     int var12 = var1.nextInt((-24), 3);
//     var1.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-9));
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.3818891261280042d));

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var8 = var1.nextGaussian(Double.NaN, 2.0d);
//     long var11 = var1.nextLong((-1L), 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999809519754114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var6 = var1.nextWeibull(0.056421365758840616d, 0.7210596238295536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.9468082282377363E-5d);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.5553045636165086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.6028043952898969d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6882617065022432d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException(var6, (java.lang.Number)100, var8, (java.lang.Number)(-2.131776110801955d));
    java.lang.Object[] var11 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var0, var11);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(7.6293945E-6f, 1085619743);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(254773876, 64378680);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 254773876);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    long var7 = var2.nextLong((-1L), 0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("", "73d795addc27f791908a3f997e31f001153a4de6a6c3b289070465a394f13719b720dbe9a72d45041494e358e66b111aff09");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0L);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    double var10 = var2.nextT(0.8530627877982958d);
    double var13 = var2.nextF(2.837425959086072d, 35.23475180425246d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var2.nextHypergeometric(9, 0, 44);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-2.589860825112713d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.58629622320762d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.3852663407562762d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.sample();
    int var6 = var3.inverseCumulativeProbability(0.7949577687638787d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.0718960554794247d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.07177243314763156d));

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.9999999958776927d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.079985986933498E-5d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.8036431768800762d, 0.547610845558001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9726558361786892d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    var1.clear();
    double var5 = var1.nextGaussian();
    double var6 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.06571011146367788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.08738583894899854d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.9675739059096364d, (-3.4929149895375864d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.4929149895375864d));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.332973893178593d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8699742930877878d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    var2.reSeed(10L);
    double var15 = var2.nextF(1.1043047119603162d, 0.5659742383512718d);
    var2.reSeedSecure();
    double var19 = var2.nextGaussian(100.00000000000001d, 1.7585303362849791d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0287702751273755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 102.05259766249432d);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     var1.reSeedSecure();
//     double var13 = var1.nextCauchy((-0.7071067811865475d), 48.876897400506486d);
//     double var15 = var1.nextT(0.1640874555593985d);
//     double var17 = var1.nextT(0.053685308829511835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 27.442506905545176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 22.63989892833655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-35.722730595840375d));
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.3382758842816609d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
    var1.reSeedSecure(2L);
    var1.reSeed(4187054274462996441L);
    double var16 = var1.nextCauchy(0.0d, 0.9969954566802464d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1.3832046344377706d));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.525589885284922d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.151187150959623d));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(2472679844610678315L);
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    double var4 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var5.nextBeta(0.8512271908466933d, 1.9489420841230134d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4887708362197951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.01683904259535762d);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var5);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, var5);
//     org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var5);
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.7071067811865475d), var5);
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator(var11);
//     var12.reSeedSecure();
//     int var17 = var12.nextHypergeometric(752916846, 10, 752916846);
//     double var21 = var12.nextUniform((-1.0d), 10.0d, false);
//     java.lang.String var23 = var12.nextSecureHexString(100);
//     java.lang.Object[] var24 = new java.lang.Object[] { var23};
//     org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, var24);
//     org.apache.commons.math3.exception.util.ExceptionContext var26 = var25.getContext();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 7.895249563626026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "b5046b68be76e9eba8960bc2c6d1a441c069cba68964f32046408eee1415f74cde88a8b0d663791f0745aa9acaeaf4330061"+ "'", var23.equals("b5046b68be76e9eba8960bc2c6d1a441c069cba68964f32046408eee1415f74cde88a8b0d663791f0745aa9acaeaf4330061"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     org.apache.commons.math3.random.RandomGenerator var3 = var1.getRandomGenerator();
//     int var6 = var1.nextSecureInt(1085619743, 1151705153);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var1.nextPermutation(8, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1135811506);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)100.0f, (java.lang.Number)(short)0, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMin();
    java.lang.Number var7 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)0+ "'", var6.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)0+ "'", var7.equals((short)0));

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.0d));
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)"));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var5 = var0.nextGamma(11.079397880425052d, 1.230865209494995d);
//     var0.reSeedSecure(53118080855161933L);
//     double var9 = var0.nextExponential(1.0005802266423802d);
//     double var12 = var0.nextCauchy(0.0d, 1.6220111893733224d);
//     org.apache.commons.math3.random.RandomGenerator var13 = var0.getRandomGenerator();
//     double var16 = var0.nextF(48.876897400506486d, 5.725827877519875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.957824498845954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.603106470120057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.1991772381335718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.7812516467108089d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9578395297015346d);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     double var10 = var1.nextChiSquare(0.9741002264519731d);
//     var1.reSeedSecure(2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.4073822515610317d);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 512.0f);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(512.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSupportLowerBound();
    int var5 = var3.sample();
    double var6 = var3.getNumericalMean();
    int var7 = var3.getNumberOfSuccesses();
    int var8 = var3.getSampleSize();
    boolean var9 = var3.isSupportConnected();
    var3.reseedRandomGenerator(1362564568071945760L);
    boolean var12 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(10.0f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     org.apache.commons.math3.random.RandomGenerator var8 = var1.getRandomGenerator();
//     double var11 = var1.nextBeta(8.419052874627646d, 0.44667012969996406d);
//     double var14 = var1.nextF(0.07960895200719602d, 5.784280893229112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.038694982229765425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9997031501347015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.300368040066861E-9d);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.05538900752795655d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05541733358459507d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.0531597456711106d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0174148767746818d));

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.203614950366202d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8161240378034935d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-96398574), 11, 10069743);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var5 = var0.nextGamma(11.079397880425052d, 1.230865209494995d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
//     double var9 = var0.nextF(9.227628765002294d, 0.18989547062833476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.15248079742841625d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.503963573507402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 22.28127079604099d);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.19299439529296336d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.057764319966282d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.8948290239814146d, 7.369363146397535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8948290239814147d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-123), 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = var2.nextZipf(0, 0.9999809519754114d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var5 = var2.nextT(0.06197069429210833d);
//     int var8 = var2.nextZipf(32, 0.3987022779441262d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3983721959161515E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9971595087651498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-4.9E-324d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     long var13 = var1.nextSecureLong(32377152420278742L, 935500050423093910L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var16 = var1.nextPermutation((-8), 254773876);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.6321539361272652d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 166906705535380285L);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    double var4 = var1.nextGaussian();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4887708362197951d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    var1.setSeed(2147483647);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(27.442506905545176d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.005572138709164d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSampleSize();
    int var5 = var3.getPopulationSize();
    boolean var6 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     double var16 = var1.nextGaussian(0.26049206414944576d, 0.11360163361635774d);
//     int var19 = var1.nextInt(376458423, 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 8.100369443058526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0027380949224319563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.40507186913034765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1454253532);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.0d, (java.lang.Number)1.4E-45f, (java.lang.Number)0.11705332797771173d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.4E-45f+ "'", var4.equals(1.4E-45f));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-15), 325877260);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-15));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var2.nextPoisson((-0.02900229012461919d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     var2.reSeedSecure((-1L));
//     var2.reSeedSecure(0L);
//     double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
//     double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
//     double var18 = var2.nextUniform(0.6691806567293276d, 0.8291573013481451d);
//     int var21 = var2.nextZipf(1, 0.9999999958776927d);
//     java.util.Collection var22 = null;
//     java.lang.Object[] var24 = var2.nextSample(var22, 132088406);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    var2.reSeedSecure();
    double var12 = var2.nextCauchy(0.2478736222527921d, 1.756042086747289d);
    long var14 = var2.nextPoisson(0.9741002264519731d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-9.714723000591938d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0L);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(8, (-3));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.837425959086072d, 0.07903214188102678d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.007731148630892082d));

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-0.9999999f), 1.1920928E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920928E-7f);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.9999999898967565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999966322521d);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextF(1.7585303362849791d, 0.17125344463613587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3228.476832631564d);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     double var20 = var1.nextUniform(0.970455801871072d, 1.2804846320346452E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-16));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.435619674998943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 7222853.593781732d);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var8 = var1.nextF(0.95263678522148d, 0.2478736222527921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9994215703818765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.5936600193725037E11d);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    var2.reSeed(10L);
    double var14 = var2.nextChiSquare(3.621748041405217E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6215516362376735E7d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     int var12 = var1.nextZipf(1, 0.06571011146367788d);
//     double var15 = var1.nextF(0.7972686805079129d, 1.557407690046052d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.090755302015798E-4d);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.5430806348152437d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)15, (java.lang.Number)0.006807647666488568d, true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)(short)0, var6, true);
    var3.addSuppressed((java.lang.Throwable)var8);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(59.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.105427357601002E-15d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-24), (java.lang.Number)9, true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-24)+ "'", var4.equals((-24)));

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(2.8224185856954223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    int var16 = var2.nextPascal(23, 0.5659742383512718d);
    long var18 = var2.nextPoisson(0.5055845672881804d);
    long var21 = var2.nextLong(0L, 2L);
    double var24 = var2.nextCauchy(3.1146040209876107d, 0.5128598528002078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 3.0744810577123722d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.7654659033750129d, (java.lang.Number)0.7432416f, true);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.12482164366779294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12417739958983902d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(512.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.8608966854929103d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    int var11 = var2.nextPascal(3, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextF(1.136102024090793d, (-0.8009428790252594d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.6953957962869728d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7689705215270332d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.9488530554154536d, 0.9686759836186158d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9488530554154536d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.15807449555753486d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.8446888662015912d));

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    var1.reSeed();
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var1.nextExponential((-0.5379756673784256d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getMin();
    java.lang.Throwable[] var4 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    var1.clear();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var5.nextBeta(0.6568245451603922d, 1.2804846320346452E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.320286242972687E-8d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(752916846);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var9 = var7.sample(100);
    var1.setSeed(var9);
    boolean var11 = var1.nextBoolean();
    long var12 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4837327815468231799L);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     double var12 = var1.nextExponential(100.0d);
//     var1.reSeed(50L);
//     double var17 = var1.nextGamma(1.040463486539541d, 0.40877566087838346d);
//     int var20 = var1.nextSecureInt((-15), 326202023);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.08010664850378298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 170.42446137992172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4.999226356811587E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 207633866);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    long var3 = var1.nextLong(909182017881509741L);
    var1.setSeed(2108499566);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 833719514626151726L);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9.403955E-38f, (java.lang.Number)99.999985f, true);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.46909241309764416d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4386172523068361d));

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 40, 0, 40);
    int var8 = var7.sample();
    int var10 = var7.inverseCumulativeProbability(0.8948290239814146d);
    double var12 = var7.cumulativeProbability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.055535913f);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    double var7 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.029345178584147927d, (-16));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.306830167359816E24d);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     int var12 = var1.nextZipf(1, 0.06571011146367788d);
//     var1.reSeedSecure();
//     double var17 = var1.nextUniform(0.18875624565924518d, 13.860024011017138d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5.66129936588372d);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.22322050797770493d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeedSecure();
    int var21 = var2.nextInt((-20), 0);
    int var24 = var2.nextBinomial(0, 0.0d);
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-13));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     long var13 = var1.nextSecureLong(32377152420278742L, 935500050423093910L);
//     double var15 = var1.nextT(0.18875624565924518d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextBeta(1.131857934747715d, (-0.08671726845195996d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.749630391967287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 565713965105453569L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 89337.76764338832d);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.91588104f, 0.6579544231599213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.915881f);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     java.lang.String var16 = var1.nextHexString(13);
//     double var20 = var1.nextUniform(0.0d, 3.3361742793920452d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "225c4a241848e"+ "'", var16.equals("225c4a241848e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.1814796280231714d);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    double var8 = var2.nextUniform(0.0d, 2.0920757103406324d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.nextGaussian(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.8003617275912993d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.17290758883568633d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, (-0.007731148630892082d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(2.9468082282377363E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.7367502609782424d, 0.1339041896989337d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.739148679170152d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(118802413304362069L);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var9 = var3.inverseCumulativeProbability(0.11705332797771173d);
    double var10 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     java.lang.String var12 = var1.nextSecureHexString(100);
//     long var15 = var1.nextLong(0L, 80953983022125473L);
//     int var18 = var1.nextSecureInt((-9), 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6.199708300885857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "7af0401dea0939bc4ae0cd85c8b124e55134a3e3e7e21644864eca7255d05cdfec31afbf613d39c9e38c872d71f8d5c4da75"+ "'", var12.equals("7af0401dea0939bc4ae0cd85c8b124e55134a3e3e7e21644864eca7255d05cdfec31afbf613d39c9e38c872d71f8d5c4da75"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5940383931179396L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-5));
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     double var13 = var1.nextWeibull(0.5305258769231836d, 1.5707963267948966d);
//     int var16 = var1.nextInt((-17), 675534908);
//     double var19 = var1.nextBeta(58.59450854058198d, 7.725997217242875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.716246883029882d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.296597557613191d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 492902519);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.9216870609696813d);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 1142493068);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.9931328331574297d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9931328331574297d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var1.nextInt(2108499566, (-123));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(142.78488571751902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.968318333486949d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeedSecure();
    double var21 = var2.nextUniform(1.1986211422292476d, 1.756042086747289d);
    int[] var24 = var2.nextPermutation(26, 8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var27 = var2.nextPermutation(675534908, 2147483647);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.3123830243980872d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     double var6 = var0.nextCauchy(0.81813319405674d, 0.6568245451603922d);
//     org.apache.commons.math3.distribution.RealDistribution var7 = null;
//     double var8 = var0.nextInversionDeviate(var7);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeedSecure();
    double var21 = var2.nextUniform(1.1986211422292476d, 1.756042086747289d);
    double var23 = var2.nextT(1.9817051484995168E22d);
    int var26 = var2.nextInt((-23), 1);
    long var28 = var2.nextPoisson(22.63989892833655d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.3123830243980872d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0166517562129022E-10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 21L);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.01178648078137136d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var6, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(-1L), var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)2, var9);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var0, var9);
    org.apache.commons.math3.exception.util.ExceptionContext var16 = var15.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int[] var9 = var3.sample(13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var3.inverseCumulativeProbability((-0.7853981633974483d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.9969954566802464d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var5 = var2.nextT(0.8036431768800762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.08578906495906032d));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(2108499566);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeedSecure();
    double var21 = var2.nextUniform(1.1986211422292476d, 1.756042086747289d);
    var2.reSeed(1629912717264998710L);
    long var26 = var2.nextLong(8L, 2472679844610678315L);
    double var29 = var2.nextCauchy(2.2995925413298486E-8d, 1.3123830243980872d);
    double var32 = var2.nextWeibull(0.9675739059096364d, 0.9999999966322521d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.3123830243980872d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1624466543229279340L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.2718100420857898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.42958601579679806d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.219806453049797d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)3.3361742793920452d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 40, 0, 40);
    int var8 = var7.getPopulationSize();
    int var10 = var7.inverseCumulativeProbability(0.8894389697993161d);
    int var11 = var7.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 40);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    var2.reSeed(10L);
    double var15 = var2.nextF(1.1043047119603162d, 0.5659742383512718d);
    var2.reSeedSecure(935500050423093910L);
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0287702751273755d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(1, 100);
    org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var14 = var12.sample(100);
    int var15 = var12.getPopulationSize();
    int var16 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
    int var19 = var2.nextInt((-17), 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var22 = var2.nextLong(6272384587263753L, (-598068589977130356L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 32);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.1986211422292476d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(752916846);
    long var2 = var1.nextLong();
    long var3 = var1.nextLong();
    int var4 = var1.nextInt();
    long var6 = var1.nextLong(1000377107798907052L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1740262975033857731L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-3482344208705029123L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2108499566);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 424440088738440003L);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(7.20877718996389d, 7.20877718996389d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-24));

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     var1.reSeed(3134652191960553436L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var1.nextWeibull((-0.9288683334870875d), 35.23475180425246d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-4));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-11.249245899463554d));
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 512.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-14.684905996294638d));

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     double var10 = var1.nextCauchy(0.0d, 0.035254409771664955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9990175513456887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.5845489388301877d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.08431855823043892d));
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(102.05259766249432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.2838693433687199d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure((-1722448868039600408L));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 40, 0, 40);
    int var8 = var7.sample();
    int var10 = var7.inverseCumulativeProbability(0.8948290239814146d);
    double var11 = var7.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    double var11 = var2.nextBeta(5.72574711174442d, 2.0d);
    double var14 = var2.nextF(59.0d, 0.5394299883730779d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5659742383512718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 6911.715511398774d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportLowerBound();
    double var8 = var3.cumulativeProbability(26);
    int var10 = var3.inverseCumulativeProbability(0.1370495062037017d);
    var3.reseedRandomGenerator(1624466543229279340L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.5639623740100898d, (java.lang.Number)(byte)10, (java.lang.Number)(-1.525589885284922d));
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.525589885284922d)+ "'", var5.equals((-1.525589885284922d)));

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.getSupportUpperBound();
    int var10 = var3.getNumberOfSuccesses();
    int var11 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.2478736222527921d, 0.9718532847495457d);
//     long var8 = var1.nextSecureLong((-509399413869688601L), 80953983022125473L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.18528382838211493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-372105608784214497L));
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 73705308);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.055535913f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05553591f);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(7222853.593781732d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 752916846, 100, 0);
    int var6 = var5.getSupportUpperBound();
    double var8 = var5.probability(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     var1.reSeedSecure();
//     int var14 = var1.nextHypergeometric(15, 10, 13);
//     double var17 = var1.nextCauchy((-1.4142135623730951d), 1.4035340560729603d);
//     double var19 = var1.nextExponential(11.975951657450514d);
//     double var22 = var1.nextWeibull(1.470287810588242E-5d, 0.021638335491554795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 7.894134702135447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 13.119210470796286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     var1.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.getNumberOfSuccesses();
    int[] var10 = var3.sample(14);
    var3.reseedRandomGenerator(53118080855161933L);
    boolean var13 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.15807449555753486d, (java.lang.Number)2147483647, true);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    var1.reSeedSecure((-1722448868039600408L));
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var1.nextLong(427988133796442264L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2035706397, (java.lang.Number)99.99999f, true);
    java.lang.Number var4 = var3.getMin();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 99.99999f+ "'", var4.equals(99.99999f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSupportLowerBound();
    int var5 = var3.sample();
    double var6 = var3.getNumericalMean();
    int var7 = var3.getNumberOfSuccesses();
    int var8 = var3.getSampleSize();
    int var9 = var3.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     double var7 = var2.nextGaussian(0.12482164366779294d, 1.0d);
//     long var10 = var2.nextSecureLong(1L, 935500050423093910L);
//     int var13 = var2.nextPascal(2035706397, 1.0166517562129022E-10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.9334944639832103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 811591638164391233L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2147483647);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var1, var2);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.220446049250313E-16d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     double var17 = var1.nextCauchy(0.0d, 1.7560420867472888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.14260736786870118d);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.17290758883568633d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18875624565924518d);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)675534908, (java.lang.Number)80953983022125473L, (java.lang.Number)69.11161494800152d);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     java.lang.Number var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     java.lang.Object[] var13 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var13);
//     org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var10, var13);
//     org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var9, var13);
//     org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)(-1L), var13);
//     org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError(var6, var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var13);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeed();
//     double var13 = var1.nextCauchy(0.9999702721723022d, 0.12482164366779293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.168973146166263d);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.1920928E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed(3134652191960553436L);
//     double var6 = var2.nextExponential(0.9526367852214799d);
//     double var9 = var2.nextGaussian(15.302739584460415d, 0.8813735128605069d);
//     long var12 = var2.nextSecureLong(1799313801253988809L, 2177253655836675545L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5268878066689038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 15.823630098926369d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1940994128446618832L);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.9578395297015346d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.473974825082335d);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     long var5 = var0.nextPoisson(1.2312404863020072d);
//     double var9 = var0.nextUniform(2.3841289907787343E-8d, 0.6028043952898969d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9121101033184803L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.29979618451441764d);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)675534908, (java.lang.Number)14.531995745214504d, (java.lang.Number)48.876897400506486d);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-2.1317761108019555d));
    java.lang.Number var3 = var2.getMin();
    boolean var4 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    var2.clear();
    int var5 = var2.nextInt(752916846);
    double var6 = var2.nextGaussian();
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    var7.reSeed((-3482344208705029123L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 376458423);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.5406011899523415d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(752916846);
    float var2 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.90566015f);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(72.19315262034397d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.279345202347866d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.1920928E-7f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.3373857493432328d, (java.lang.Number)1.0d, (java.lang.Number)162.57253213649173d);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(5.479378538017092d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(0L, 293141324453066497L);
    int var8 = var2.nextBinomial(32, 1.4210854715202004E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 54831737849439661L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(13.119210470796286d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.268674158476818d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.7406723831325803d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.810276020036809d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-20), 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    var2.reSeed(6272384587263753L);
    double var15 = var2.nextChiSquare(0.6459203537059701d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var2.nextPascal(675534908, 2.9430204333214194d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.013015622557213214d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var6 = var3.cumulativeProbability(1, 100);
    int var7 = var3.getSupportLowerBound();
    boolean var8 = var3.isSupportConnected();
    int var9 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     int var12 = var1.nextBinomial(64378680, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.705300651835807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.8237488908136895d, Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8237488908136896d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(73705308);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 73705308);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(6L, 2470096362876148374L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)11.975951657450514d);
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 11.975951657450514d+ "'", var2.equals(11.975951657450514d));

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6281693917512327d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.getNumberOfSuccesses();
    int[] var10 = var3.sample(14);
    var3.reseedRandomGenerator(53118080855161933L);
    double var13 = var3.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var3.cumulativeProbability(675534908, 132088406);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2, (java.lang.Number)0.76195765f, false);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextT(153.33277579697418d);
    double var14 = var2.nextUniform(0.0d, 164.2937684106714d, false);
    double var17 = var2.nextGaussian(3.268674158476818d, 0.3800837795011248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.6026412528167446d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15.302739584460415d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.331535203850989d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(2177253655836675545L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2177253655836675545L);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     var1.reSeedSecure();
//     long var13 = var1.nextPoisson(0.7972686805079129d);
//     double var16 = var1.nextBeta(5.479378538017092d, 1.6441925846801777d);
//     double var18 = var1.nextT(0.33213557751171413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.49230312607826476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.1608835064252195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.7845679142282883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.874666847850496d);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(1.5050388358222293d, (-17.37923146202725d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextWeibull(0.9999999949483782d, 11.975951657450514d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 23.594279968507085d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var17 = var2.nextExponential(153.33277579697418d);
    var2.reSeedSecure();
    double var21 = var2.nextUniform(1.1986211422292476d, 1.756042086747289d);
    double var23 = var2.nextT(1.9817051484995168E22d);
    int var26 = var2.nextInt((-23), 1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var30 = var2.nextBinomial(0, (-0.5379756673784256d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 394.0226454253637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.3123830243980872d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0166517562129022E-10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-5));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-9.714723000591938d), (java.lang.Number)(-0.01178648078137136d), true);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.2312404863020072d, 8.100369443058526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2312404863020072d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.403955E-38f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int[] var9 = var3.sample(13);
    int var10 = var3.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextChiSquare((-0.5379756673784256d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.8938633170041805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 51.21459552590394d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.clear();
    var1.setSeed((-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(287557071, 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    boolean var8 = var3.isSupportConnected();
    boolean var9 = var3.isSupportConnected();
    double var11 = var3.cumulativeProbability(44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var3.cumulativeProbability(32, (-17));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.1729143413471307d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.17377730206546999d));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.334428966773409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.204301440351224d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var3 = var1.nextBoolean();
    int var4 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var5.nextGaussian(1.3123830243980872d, 0.5169658851857125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 325877260);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.5967444877682144d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-0.99999994f), 0.6862626f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6862626f);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    int var13 = var2.nextInt((-96398574), 675534908);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 349083977);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var5 = var0.nextGamma(11.079397880425052d, 1.230865209494995d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var6, (-24), 492902519, 4);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.677827366787326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.381432948156731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-2.1317761108019555d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.5637698131160296d, (java.lang.Number)0.03571149328003235d, true);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     double var7 = var2.nextGaussian(0.12482164366779294d, 1.0d);
//     int var10 = var2.nextBinomial(0, 0.6149624301072181d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var2.nextWeibull(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.6466292823216434d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.0d, (java.lang.Number)0.38743261320474714d, true);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     var1.reSeed(4187054274462996441L);
//     java.lang.String var15 = var1.nextSecureHexString(2);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "59"+ "'", var15.equals("59"));
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var4, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-1L), var7);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, var7);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.String var14 = var13.toString();
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    java.lang.Number var17 = null;
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    java.lang.Object[] var21 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var21);
    org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError(var18, var21);
    org.apache.commons.math3.exception.NotFiniteNumberException var24 = new org.apache.commons.math3.exception.NotFiniteNumberException(var17, var21);
    org.apache.commons.math3.exception.NotFiniteNumberException var25 = new org.apache.commons.math3.exception.NotFiniteNumberException(var15, (java.lang.Number)(-1L), var21);
    var13.addSuppressed((java.lang.Throwable)var25);
    var12.addSuppressed((java.lang.Throwable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var14.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(7222853.593781732d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    int var11 = var2.nextPascal(3, 0.0d);
    int[] var12 = new int[] { };
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var12);
    org.apache.commons.math3.distribution.HypergeometricDistribution var18 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var14, 752916846, 0, 100);
    int var19 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var18);
    org.apache.commons.math3.distribution.HypergeometricDistribution var23 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var25 = var23.cumulativeProbability(10);
    int var26 = var23.getSupportUpperBound();
    int var28 = var23.inverseCumulativeProbability(0.06571011146367788d);
    boolean var29 = var23.isSupportConnected();
    int var30 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)53118080855161933L);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.1920929E-7f, 0.3716208f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920929E-7f);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportLowerBound();
    double var8 = var3.cumulativeProbability(26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var3.cumulativeProbability(514406009, (-13));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.999999895123288d, (java.lang.Number)0.9999999999992155d, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.9999999999992155d+ "'", var5.equals(0.9999999999992155d));

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.3329738931785933d, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.3329738931785933d+ "'", var4.equals(1.3329738931785933d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3329738931785933d+ "'", var5.equals(1.3329738931785933d));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1L, var2, true);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(22.518886850744124d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5828828567074007d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.621907632906563E7d, (java.lang.Number)59.0d, (java.lang.Number)0.756644699807056d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)8.0d, (java.lang.Number)0.41194829313946263d, (java.lang.Number)(-5.050874460566523d));

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     var1.reSeedSecure();
//     double var14 = var1.nextGaussian(0.0d, 1.1986211422292476d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextBeta((-0.3674175180023106d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999839855530105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.684231643529525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.9457285967923021d));
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     double var17 = var1.nextT(0.8291573013481451d);
//     org.apache.commons.math3.random.RandomGenerator var18 = var1.getRandomGenerator();
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.5784690787586363d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.525589885284922d), 8.100369443058526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.1861552808020703d));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    double var7 = var2.nextChiSquare(0.06571011146367788d);
    var2.reSeedSecure((-1740262975033857731L));
    double var12 = var2.nextCauchy(0.5305258769231836d, 0.5553045636165086d);
    long var14 = var2.nextPoisson(0.44667012969996406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.012006336300978443d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-2.6198971179968926d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0L);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextBinomial(4, 0.7404467304847557d);
//     var0.reSeed(1799313801253988809L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextCauchy((-0.007731148630892082d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var5 = var3.sample(100);
    boolean var6 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var3 = var1.nextGaussian();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 1, 0, 0);
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var9 = null;
//     var1.nextBytes(var9);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
//     double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
//     double var13 = var2.nextChiSquare(1.230865209494995d);
//     int var16 = var2.nextPascal(23, 0.5659742383512718d);
//     long var18 = var2.nextPoisson(0.5055845672881804d);
//     long var21 = var2.nextLong(0L, 2L);
//     long var23 = var2.nextPoisson(0.6953957962869728d);
//     int var26 = var2.nextSecureInt((-15), (-13));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.20221127419725435d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8291573013481451d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.006807647666488568d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.03571149328003235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-13));
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.3123830243980872d, (java.lang.Number)32377152420278742L, false);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.7654659033750127d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var8 = var3.cumulativeProbability(0, 100);
    boolean var9 = var3.isSupportConnected();
    int var10 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     long var13 = var1.nextSecureLong(32377152420278742L, 935500050423093910L);
//     var1.reSeedSecure((-598068589977130356L));
//     double var18 = var1.nextCauchy(58.59450854058198d, 0.9999984268504752d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6.2212666830793655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 106487905849024995L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 61.78356912325569d);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    double var4 = var1.nextGaussian();
    int[] var5 = new int[] { };
    var1.setSeed(var5);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.06571011146367788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.08431855823043892d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.08421896439502999d));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-0.9999999f), 0.3716208f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3716208f);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     var0.reSeed();
//     var0.reSeed(0L);
//     double var8 = var0.nextChiSquare(0.32374292923788744d);
//     double var10 = var0.nextExponential(0.12417739958983902d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1754843063713983525L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.22322050797770493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.022803061763813314d);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    java.lang.String var9 = var2.nextHexString(23);
    var2.reSeed(1362564568071945760L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "0451cd5c0e0bc7a2161ab78"+ "'", var9.equals("0451cd5c0e0bc7a2161ab78"));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)32377152420278742L, false);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.8914186821429264d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1004660950218432d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(3.650574011986194d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 37.49675730822629d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var6 = var3.nextCauchy(0.0d, 0.12417937830488368d);
    double var9 = var3.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var3.nextT(153.33277579697418d);
    java.lang.Object[] var12 = new java.lang.Object[] { 153.33277579697418d};
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-21.87440112427276d), var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.6026412528167446d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    var2.reSeed(10L);
    double var15 = var2.nextF(1.1043047119603162d, 0.5659742383512718d);
    var2.reSeedSecure(935500050423093910L);
    long var19 = var2.nextPoisson(1.3123830243980872d);
    int var22 = var2.nextZipf(1, 0.36707033892490126d);
    double var24 = var2.nextT(0.07722623227629755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0287702751273755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-71.3754276835496d));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)2.2995925413298486E-8d, var6);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var10);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var7, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)(-1L), var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)2, var10);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var1, var10);
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var16.getContext();
    java.lang.Object[] var18 = new java.lang.Object[] { var17};
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)514406009, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.91588104f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)(-2.1317761108019555d));
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.1686550984577497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0810435229248403d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(170.42446137992172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5649286918585918d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    double var2 = var1.nextGaussian();
    int[] var3 = new int[] { };
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
    double var6 = var4.nextGaussian();
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 1, 0, 0);
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var14 = new int[] { };
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
    var15.setSeed(10);
    byte[] var21 = new byte[] { (byte)100, (byte)(-1), (byte)100};
    var15.nextBytes(var21);
    var13.nextBytes(var21);
    var4.nextBytes(var21);
    var1.nextBytes(var21);
    float var26 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.92855334f);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.999999895123288d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.043481143175376734d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7.588891109413862E-4d));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.07729528392594412d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeed(8L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var11 = var1.nextPermutation(752916846, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2601703043079604093L);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(550771151206886582L);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     double var12 = var1.nextT(0.4629351200464951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.08669580785729325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7296509835063935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-2.9294615153521923d));
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    int var11 = var2.nextPascal(3, 0.0d);
    int[] var12 = new int[] { };
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var12);
    org.apache.commons.math3.distribution.HypergeometricDistribution var18 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var14, 752916846, 0, 100);
    int var19 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var18);
    int var20 = var18.getSupportLowerBound();
    double var21 = var18.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    int var11 = var2.nextInt(8, 376458423);
    double var14 = var2.nextUniform(0.9990175513456887d, 1.1043047119603162d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 287557071);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0048647744810122d);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     double var7 = var2.nextGaussian(0.12482164366779294d, 1.0d);
//     long var10 = var2.nextSecureLong(1L, 935500050423093910L);
//     double var12 = var2.nextT(7.20877718996389d);
//     java.lang.String var14 = var2.nextSecureHexString(8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.19778272018610524d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 720304545793395872L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.2070043910364703d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "8d9f32fb"+ "'", var14.equals("8d9f32fb"));
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextBinomial(0, 0.006807647666488568d);
//     double var17 = var1.nextWeibull(0.756644699807056d, 0.1991772381335718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.03931626498593468d);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    int var3 = var1.nextInt(752916846);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var5 = var4.getRandomGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 514406009);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextCauchy(17.59247980937991d, 1.5121289312892812d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 15.590155751618859d);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.08431855823043892d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.08086158965213922d));

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-3.2626557414084827d), 0.604776607991365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.3875133138751845d));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100, var2, (java.lang.Number)(-2.131776110801955d));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-2.131776110801955d)+ "'", var5.equals((-2.131776110801955d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-2.131776110801955d)+ "'", var6.equals((-2.131776110801955d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)3134652191960553436L, true);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(2.0920757103406324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4464009507535014d);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var8 = var1.nextGaussian(Double.NaN, 2.0d);
//     long var10 = var1.nextPoisson(4.546466837977001d);
//     double var13 = var1.nextF(0.4331763560234572d, 0.03607191294686202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9998739902659034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 786448.4637444422d);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)11);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1754843063713983525L);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    var2.clear();
    int var5 = var2.nextInt(752916846);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 376458423);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)6L, (java.lang.Number)4187054274462996441L, false);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    int var11 = var2.nextInt(8, 376458423);
    double var13 = var2.nextChiSquare(0.16398521682072548d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var2.nextChiSquare((-2.037677266640974d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 287557071);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    int var16 = var2.nextPascal(23, 0.5659742383512718d);
    var2.reSeedSecure();
    long var19 = var2.nextPoisson(4.506353702662211d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 7L);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.10751859704747677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.11351156858149d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    int var15 = var2.nextPascal(1, 0.06571011146367788d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var2.nextGamma((-0.08578906495906032d), 394.0226454253637d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var5 = var3.sample(100);
    int var6 = var3.sample();
    double var8 = var3.upperCumulativeProbability(752916846);
    double var10 = var3.cumulativeProbability(32);
    int var11 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(7.94877528443898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.0d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.055535913f);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000002f);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     var1.reSeedSecure();
//     double var14 = var1.nextGaussian(0.0d, 1.1986211422292476d);
//     int var17 = var1.nextPascal(32, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9765949618470814d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7991597379056216d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.4429212378436769d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2147483647);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(1, 100);
    org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var14 = var12.sample(100);
    int var15 = var12.getPopulationSize();
    int var16 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
    int var19 = var2.nextInt((-17), 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var23 = var2.nextHypergeometric(4, 2, 6216880);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 32);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-2572169446717682802L), (java.lang.Number)(-0.04593636412086344d), (java.lang.Number)(-0.99999994f));

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1722448868039600408L));
    int[] var2 = null;
    var1.setSeed(var2);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var18 = var2.nextUniform(0.6691806567293276d, 0.8291573013481451d);
    int var21 = var2.nextZipf(1, 0.9999999958776927d);
    var2.reSeedSecure(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.6840812884202282d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     double var12 = var1.nextExponential(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextHypergeometric((-1), (-24), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03839191204518649d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 68.22393147906266d);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextChiSquare(51.34082970607832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 41.86004326290229d);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     int var12 = var1.nextZipf(1, 0.06571011146367788d);
//     double var15 = var1.nextF(0.7972686805079129d, 1.557407690046052d);
//     double var17 = var1.nextT(0.7654659033750129d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "f72f3bd47f33c5143e3dce119e11c6f3a18a02d366894fdc8a66a12b6bce8b15cd69befb93045a9f81e929a59b4bbb09b237");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.2707627336180067E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-12.771403287268795d));
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0287702751273755d, (java.lang.Number)(-0.015382871033603779d), false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.015382871033603779d)+ "'", var5.equals((-0.015382871033603779d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.015382871033603779d)+ "'", var6.equals((-0.015382871033603779d)));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)32);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     double var10 = var1.nextChiSquare(0.9741002264519731d);
//     long var13 = var1.nextSecureLong((-3482344208705029123L), (-509399413869688601L));
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextF(0.1339041896989337d, (-0.01538287103360378d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3970135205459008d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1817468291625425653L));
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    boolean var3 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.5996555078851037d));

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     long var13 = var1.nextSecureLong(32377152420278742L, 935500050423093910L);
//     var1.reSeedSecure((-598068589977130356L));
//     org.apache.commons.math3.random.RandomGenerator var16 = var1.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.7277165849294693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 530553540710288325L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

//  public void test325() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }
//
//
//    int[] var0 = new int[] { };
//    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//    var2.reSeedSecure((-1L));
//    var2.reSeedSecure(0L);
//    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
//    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
//    double var17 = var2.nextExponential(153.33277579697418d);
//    var2.reSeedSecure();
//    double var21 = var2.nextUniform(1.1986211422292476d, 1.756042086747289d);
//    int[] var24 = var2.nextPermutation(26, 8);
//    double var27 = var2.nextWeibull(0.4887708362197951d, 14.28345980396731d);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      java.lang.String var29 = var2.nextHexString(325877260);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == (-0.20221127419725435d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var12 == 0.970455801871072d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var15 == 0.030412091907585977d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var17 == 394.0226454253637d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var21 == 1.3123830243980872d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var24);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var27 == 0.866925088633149d);
//
//  }
//
//}
