
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8813735870195429d));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.8813735870195429d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-1), 0, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1L));

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var1 = null;
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var4 = null;
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var3, var4);
//     var2.addSuppressed((java.lang.Throwable)var5);
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-1.0d), (-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3329738931785933d);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.toDegrees(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.copySign(Double.NaN, 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.3329738931785933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12482164366779294d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.1317761108019555d));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.lang.Object[] var2 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.12482164366779294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12417937830488368d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.3329738931785933d, 0.12417937830488368d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3329738931785933d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(10L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-2.1317761108019555d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.12482164366779294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.445648259877762d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(byte)1, (java.lang.Number)10L, (java.lang.Number)1.3329738931785933d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3329738931785933d+ "'", var5.equals(1.3329738931785933d));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextPascal(1, 1.3329738931785933d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.cos(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextBinomial(100, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, var2, true);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.0f, 0.12482164366779294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.12417937830488368d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.11705332797771173d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextBinomial((-1), 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.11705332797771173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextUniform(1.3329738931785933d, (-1.0d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextZipf(10, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = var0.nextInt((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7071067811865475d));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.nextUniform(0.12417937830488368d, (-0.7071067811865475d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.4E-45f, (-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(10.0d, 0.11705332797771173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000685050614816d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var2.nextLong(1L, 1L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(100.0d, 1.445648259877762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(99.99999f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextCauchy(Double.NaN, (-0.20221127419725435d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-2.1317761108019555d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.131776110801955d));

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     double var0 = org.apache.commons.math3.util.FastMath.random();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == 0.5305258769231836d);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextInt(100, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var5 = var3.sample(100);
    int var6 = var3.sample();
    int var7 = var3.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.tan(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var5 = var3.sample(100);
    int var6 = var3.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var3.inverseCumulativeProbability((-2.131776110801955d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.max(Double.NaN, 0.11705332797771173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var6 = var3.getNumericalMean();
    double var8 = var3.probability(0);
    var3.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextZipf((-1), (-2.131776110801955d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextBinomial(10, 0.0d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var2.nextSample(var6, 0);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)10.0f);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.12417937830488368d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12386047256581567d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8390715290764524d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 0, 100, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.3329738931785933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9718532847495457d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(99.99999f, 0.5305258769231836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.999985f);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.445648259877762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.94877528443898d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    long var9 = var2.nextPoisson(9.227628765002294d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextLong(6L, 1L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6L);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextLong(100L, 1L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

//  public void test84() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
//
//
//    org.apache.commons.math3.random.RandomGenerator var0 = null;
//    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var4 = var1.nextPermutation(752916846, 100);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//
//  }
//
  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.7071067811865475d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.260591836521356d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.445648259877762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.445648259877762d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.445648259877762d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.7071067811865475d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.8813735870195429d), 0.9526367852214799d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9526367852214799d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.7071067811865475d), 0.999999895123288d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7071067811865475d));

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(6L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 7.94877528443898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.5305258769231836d, 0.999999895123288d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5305258769231836d);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     org.apache.commons.math3.distribution.RealDistribution var4 = null;
//     double var5 = var2.nextInversionDeviate(var4);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var1.nextPoisson((-2.1317761108019555d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.12482164366779294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.151753374050393d);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextPascal(100, (-2.1317761108019555d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.30540193022982715d);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.3329738931785933d, 0.5305258769231836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.332973893178593d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.8530627877982958d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 48.876897400506486d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.7071067811865475d), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4142135623730951d));

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.11705332797771173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var11 = var1.nextLong(6L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    long var9 = var2.nextPoisson(9.227628765002294d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var2.nextUniform(1.332973893178593d, (-1.4142135623730951d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6L);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5430806348152437d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.445648259877762d, 9.227628765002294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.227628765002294d);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     double var7 = var2.nextGaussian(0.12482164366779294d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var2.nextInt(40, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.5000412072313509d);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.9718532847495457d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.445648259877762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.20235113834427d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.12386047256581567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.131857934747715d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.12417937830488368d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12482164366779294d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.6149624301072181d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 35.23475180425246d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = var0.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)752916846);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.20235113834427d, (-2.131776110801955d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.20235113834427d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.8390715290764524d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6981152095798223d));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, 10, 752916846);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999958776927d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.6149624301072181d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.547610845558001d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.260591836521356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6220111893733224d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(10.000685050614816d, 1.1043047119603162d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1043047119603162d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextZipf(100, (-0.8813735870195429d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2478736222527921d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403023058681398d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    java.lang.Object[] var2 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)100, var7, (java.lang.Number)(-2.131776110801955d));
    java.lang.Object[] var10 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var10);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.9526367852214799d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6691806567293276d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.8390715290764524d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8390715290764523d));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.445648259877762d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.445648259877762d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.20221127419725435d));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.4591080569252062d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1640874555593985d);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextCauchy(0.999999895123288d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4005069698870034d);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.9999999898967565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.557407690046052d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.2312404863020072d, 1.20235113834427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7972686805079129d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    long var9 = var2.nextPoisson(9.227628765002294d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextBinomial(40, 10.000685050614816d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6L);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var2.nextLong(6L, 6L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextGaussian(1.3329738931785933d, (-0.8813735870195429d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7.867772329434647d);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var1.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.6220111893733224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.6691806567293276d, 3.708445464724037d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.2626557414084827d));

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.6220111893733224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.999999895123288d, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999984268504751d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var4);
    java.lang.Number var8 = var7.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.nextUniform(7.94877528443898d, 0.0d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     var1.reSeedSecure();
//     double var13 = var1.nextCauchy((-0.7071067811865475d), 48.876897400506486d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextBeta(0.9999999958776927d, (-3.2626557414084827d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-64.6355043857247d));
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9999984268504751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999992134249283d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextZipf(0, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.056365241225742733d);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var2.nextSample(var9, 100);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.131857934747715d, var2, true);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.8291573013481451d, 0.06571011146367788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14.531995745214504d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.219806453049797d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0684732215128296d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2478736222527921d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.6691806567293276d, (-2.1317761108019555d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8374259590860724d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.111350542302613d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.0684732215128296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     double var12 = var1.nextUniform(0.06571011146367788d, 1.445648259877762d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextF(0.2478736222527921d, Double.NaN);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 13.53958766715352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.847903580106549d);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextZipf(10, (-0.9967258730180175d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.1043047119603162d, (java.lang.Number)1.131857934747715d, true);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextSecureInt(100, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     var1.reSeed();
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var1.nextSample(var12, 14);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    long var4 = var3.nextLong();
    long var5 = var3.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3233753233997579692L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2572169446717682802L));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)100, (java.lang.Number)1.0684732215128296d, true);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 752916846, 0, 100);
    int var8 = var2.nextInt(40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 23);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    boolean var8 = var3.isSupportConnected();
    double var10 = var3.probability(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var4.nextBeta(0.8894389697993161d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var1.nextCauchy(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var6 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var6);
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-1L), var6);
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var10);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.6840812884202282d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 1.445648259877762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(10, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (-1.4142135623730951d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.9E-324d));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9999999898967565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7182818009955825d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(99.999985f, 752916846);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.5403023058681398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5669767943827976d);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextInt((-1), (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.8390715290764523d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.131857934747715d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    double var7 = var2.nextChiSquare(0.06571011146367788d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextPascal(13, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.012006336300978443d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    double var7 = var2.nextChiSquare(0.06571011146367788d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextBeta(1.0d, (-0.8390715290764523d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.012006336300978443d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    int var15 = var2.nextPascal(1, 0.06571011146367788d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var2.nextHypergeometric(14, 752916846, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(153.33277579697418d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.72574711174442d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.6149624301072181d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.9526367852214799d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.95263678522148d);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var2.nextHypergeometric((-1), 752916846, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "621cee982ee07b0b1f795617d3f2ea5e67c4a81fe3f64639e9bcefb23360970527933a45e3c6c3eba28821e6235a1ad6097a"+ "'", var6.equals("621cee982ee07b0b1f795617d3f2ea5e67c4a81fe3f64639e9bcefb23360970527933a45e3c6c3eba28821e6235a1ad6097a"));
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var5 = var3.sample(100);
    int var6 = var3.getPopulationSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var3.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.3382758842816608d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.33827588428166083d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextPoisson((-0.20221127419725435d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.1339041896989337d, (java.lang.Number)0.8530627877982958d, false);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var2.nextSample(var9, 100);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.8390715290764524d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var8 = var3.cumulativeProbability(0, 100);
    int var9 = var3.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var2.nextSecureInt(14, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.getSampleSize();
    boolean var10 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var1.nextPermutation(10, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1335819288447146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.3839598157993132d);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.8374259590860724d, 0.07722623227629755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.837425959086072d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.111350542302613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var2.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.6373589277942243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.563098594430906d);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, var2, true);
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
//     boolean var6 = var4.getBoundIsAllowed();
//     java.lang.Number var7 = var4.getArgument();
//     java.lang.String var8 = var4.toString();
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var18 = var2.nextUniform(0.6691806567293276d, 0.8291573013481451d);
    int var21 = var2.nextZipf(1, 0.9999999958776927d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var23 = var2.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.6840812884202282d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextGamma(0.0d, 1.0684732215128296d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.1986211422292476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.8737484983160598d, 0.7654659033750127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8737484983160598d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.1920929E-7f, (-2.131776110801955d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920928E-7f);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4711276743037347d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextF(4.9E-324d, 0.2478736222527921d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1513126829116856311L);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-3482344208705029123L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3482344208705029123L));

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     var1.reSeedSecure();
//     double var13 = var1.nextCauchy((-0.7071067811865475d), 48.876897400506486d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextF((-2.131776110801955d), Double.NaN);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-15.241497449522056d));
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
//     java.lang.Throwable var1 = null;
//     var0.addSuppressed(var1);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.6373589277942243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7404467304847557d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.12386047256581567d, 1.6220111893733224d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12386047256581567d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    int var15 = var2.nextPascal(1, 0.06571011146367788d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var2.nextPascal(14, 1.1986211422292476d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    double var4 = var1.nextGaussian();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 0, 14, 23);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.06571011146367788d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var1.nextZipf(14, (-0.6981152095798223d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.33827588428166083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.33213557751171413d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.6691806567293276d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.17445662120206445d));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.2312404863020072d, (java.lang.Number)11, true);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(10, 15, 2);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeed(8L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var1.nextExponential((-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.547610845558001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.81813319405674d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.5659742383512718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5394299883730779d);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var1 = null;
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var4 = null;
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var3, var4);
//     var2.addSuppressed((java.lang.Throwable)var5);
//     org.apache.commons.math3.exception.util.ExceptionContext var7 = var2.getContext();
//     java.lang.String var8 = var2.toString();
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.5669767943827976d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5669767943827976d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.20235113834427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0174774264994466d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.99999994f));

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     double var11 = var2.nextWeibull(1.557407690046052d, 1.260591836521356d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var2.nextExponential((-4.9E-324d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e716c7203bbd158b26d1c1b9e6b77747a17993ac1dd92a04f2c6fffda278db3a87389cad21f3c69fe4326cda9cbdbdb277f0"+ "'", var6.equals("e716c7203bbd158b26d1c1b9e6b77747a17993ac1dd92a04f2c6fffda278db3a87389cad21f3c69fe4326cda9cbdbdb277f0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.616748782728065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.431873986722599d);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.8009428790252594d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6960300197422588d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.837425959086072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 162.57253213649173d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var4 = var0.nextChiSquare(0.3382758842816608d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5055845672881804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.546466837977001d);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    double var2 = var1.nextGaussian();
    var1.setSeed(3134652191960553436L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2478736222527921d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
    double var18 = var2.nextUniform(0.6691806567293276d, 0.8291573013481451d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var2.nextWeibull((-1.4142135623730951d), 1.131857934747715d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.6840812884202282d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)(byte)0, true);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var1.nextHypergeometric(0, 23, 2035706397);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.566980506216421d);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var4 = var3.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var5.nextSample(var6, 40);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.1043047119603162d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9532394928969042d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.12482164366779294d, 0.12386047256581567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12482164366779293d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var5.nextSecureLong(0L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3233753233997579692L);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.030412091907585977d, 5.72574711174442d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.725827877519875d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.33827588428166083d, 1.557407690046052d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3382758842816609d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(99.99999f, 1.1920928E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.6981152095798223d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     int var5 = var0.nextSecureInt(10, 15);
//     double var7 = var0.nextExponential(1.111350542302613d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextF((-4.9E-324d), (-0.8390715290764524d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.03488087309877072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.7708813832269574d);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    double var11 = var2.nextBeta(5.72574711174442d, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var14 = var2.nextSecureLong(10L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5659742383512718d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(7.151753374050393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6459203537059701d);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, var2, true);
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
//     boolean var6 = var4.getBoundIsAllowed();
//     java.lang.Number var7 = var4.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
//     java.lang.Number var13 = var12.getMin();
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     int[] var15 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
//     double var20 = var17.nextCauchy(0.0d, 0.12417937830488368d);
//     double var23 = var17.nextBeta(1.219806453049797d, 1.2312404863020072d);
//     java.lang.Object[] var24 = new java.lang.Object[] { 1.2312404863020072d};
//     org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var12, var14, var24);
//     org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var8, var24);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.00000000000001d);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform(0.012006336300978443d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9329972277758187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.17245255389026412d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.230865209494995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2308652094949952d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var14 = var2.nextHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.970455801871072d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var6 = var3.getNumericalMean();
    int var7 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     var2.reSeedSecure((-1L));
//     java.lang.String var9 = var2.nextHexString(23);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var2.nextSample(var10, 2);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var2.nextExponential((-1.4142135623730951d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "c9d9772830916ce61f8af5837c9a87cd14bf9173c873af2bb1f133bc5da1ce4a9db84a8c01b0c5ed31cbb3ac7165fe3cf12e"+ "'", var6.equals("c9d9772830916ce61f8af5837c9a87cd14bf9173c873af2bb1f133bc5da1ce4a9db84a8c01b0c5ed31cbb3ac7165fe3cf12e"));
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var2.nextGamma(4.546466837977001d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "1cdb30dfb790bba3ba718f15090f1ba0940d0dc0154b0319f4bac6eeeab57d7ab23d3ffeebcc1f84356ecb7f1929c7cbc687"+ "'", var6.equals("1cdb30dfb790bba3ba718f15090f1ba0940d0dc0154b0319f4bac6eeeab57d7ab23d3ffeebcc1f84356ecb7f1929c7cbc687"));
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.11705332797771173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9931570777413035d);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     var1.reSeed();
//     int var12 = var1.nextZipf(1, 0.06571011146367788d);
//     int var15 = var1.nextSecureInt((-1), 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 11);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.1920928E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-24));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.8737484983160598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0628567339711192d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    var1.reSeed();
    int var12 = var1.nextZipf(1, 0.06571011146367788d);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var1.nextInt(514406009, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(100, (-24));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-24));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextPascal(0, 1.2312404863020072d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(13);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-3482344208705029123L));

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(11.079397880425052d, 4.546466837977001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11.975951657450514d);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.atan2(0.030412091907585977d, Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.getNumberOfSuccesses();
    int var10 = var3.getSupportUpperBound();
    int var11 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.3329738931785933d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     org.apache.commons.math3.random.RandomGenerator var8 = var1.getRandomGenerator();
//     int var11 = var1.nextBinomial(23, 0.10727204268430017d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9282699537332176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.7610576579556785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(3, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextSecureLong(80953983022125473L, 100L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Number var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var7);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var4, var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-1L), var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     java.lang.Object[] var17 = new java.lang.Object[] { 100L};
//     org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var17);
//     org.apache.commons.math3.exception.util.Localizable var19 = null;
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     java.lang.Number var22 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var24 = new org.apache.commons.math3.exception.OutOfRangeException(var20, (java.lang.Number)100, var22, (java.lang.Number)(-2.131776110801955d));
//     java.lang.Object[] var25 = new java.lang.Object[] { var22};
//     org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, var25);
//     org.apache.commons.math3.exception.MathInternalError var27 = new org.apache.commons.math3.exception.MathInternalError(var14, var25);
//     org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var12, var13, var25);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.4E-45f, (java.lang.Number)0.999999895123288d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.2312404863020072d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.17445662120206445d), (java.lang.Number)2.7182818009955825d, false);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.136102024090793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05541733358459507d);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     var2.reSeedSecure((-1L));
//     var2.reSeedSecure(0L);
//     double var12 = var2.nextBeta(0.8530627877982958d, 0.5305258769231836d);
//     double var15 = var2.nextUniform(0.0d, 0.547610845558001d);
//     double var17 = var2.nextExponential(153.33277579697418d);
//     int var20 = var2.nextSecureInt(13, 752916846);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.20221127419725435d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.970455801871072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.030412091907585977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 394.0226454253637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 675534908);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8192.0f);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int var8 = var3.getNumberOfSuccesses();
    int var9 = var3.getSampleSize();
    int[] var11 = var3.sample(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)100.0f, (java.lang.Number)(-0.7071067811865475d), (java.lang.Number)10.000685050614816d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.000685050614816d+ "'", var5.equals(10.000685050614816d));

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(32377152420278742L, 80953983022125473L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 80953983022125473L);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    double var2 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5996555078851037d));

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var1.nextSample(var10, 10);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.0174774264994466d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.618958628864691d);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin((-21.87440112427276d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.03406377960730741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0005802266423802d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.33827588428166083d, 0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9675739059096364d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(10L, 3233753233997579692L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3233753233997579692L);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9675739059096364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var3 = var1.nextInt();
    double var4 = var1.nextDouble();
    var1.setSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 752916846);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8894389697993161d);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(1.20235113834427d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9741002264519731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.21406876050576273d);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.5055845672881804d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6579544231599213d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(15.548416769665122d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.495908869762139d);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var5 = var0.nextGamma(11.079397880425052d, 1.230865209494995d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform(394.0226454253637d, 0.9532394928969042d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1110288765102647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 11.634619119020192d);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.0174774264994466d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.0f, 8192.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSampleSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var3.sample((-3));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.7182818009955825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 99.999985f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.999985f);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.7071067811865475d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1L));

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     double var7 = var2.nextGaussian(0.12482164366779294d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var2.nextF(0.0d, 10.000685050614816d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.5156417315879416d);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(1, 100);
    org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var14 = var12.sample(100);
    int var15 = var12.getPopulationSize();
    int var16 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var2.nextT((-0.8009428790252594d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(40, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.006807647666488568d, 14.531995745214504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.006807647666488568d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    boolean var8 = var3.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var3.inverseCumulativeProbability(1.0174774264994466d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(14.28345980396731d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999992155d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    var2.reSeedSecure((-2572169446717682802L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     long var11 = var2.nextSecureLong(0L, 6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextHypergeometric(14, (-24), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "0fe04e60a9869853abcdd47fb1c6ad593291e948e8dc19c2f0e1132b76859266ca45e4f8313b932675eb96b9417a39c4d44c"+ "'", var6.equals("0fe04e60a9869853abcdd47fb1c6ad593291e948e8dc19c2f0e1132b76859266ca45e4f8313b932675eb96b9417a39c4d44c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 23.45270831608465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.7972686805079129d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.7972686805079129d, var2, var3);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 752916846, 100, 0);
    int var6 = var5.getNumberOfSuccesses();
    double var7 = var5.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)53118080855161933L, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, var2, true);
//     org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.837425959086072d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7657425514272789d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSupportLowerBound();
    int var5 = var3.sample();
    double var6 = var3.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.cumulativeProbability(514406009, 2);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.8813735870195429d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    java.lang.Object[] var2 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var2);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextInt(11, 4);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(51.34082970607832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.908525742497584E21d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.8009428790252594d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6753156040846356d));

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(32377152420278742L, (-2572169446717682802L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32377152420278742L);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.5669767943827976d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(8L, 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8L);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, (-0.6953957962869728d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6953957962869728d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.111350542302613d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.9718532847495457d, 0.1640874555593985d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4035340560729603d);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var8 = var1.nextGaussian(Double.NaN, 2.0d);
//     long var10 = var1.nextPoisson(4.546466837977001d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("0451cd5c0e0bc7a2161ab78", "f72f3bd47f33c5143e3dce119e11c6f3a18a02d366894fdc8a66a12b6bce8b15cd69befb93045a9f81e929a59b4bbb09b237");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9208314857088363d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6L);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var11 = var2.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    org.apache.commons.math3.random.RandomGenerator var7 = var1.getRandomGenerator();
    var1.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
//     var2.reSeedSecure((-1L));
//     long var9 = var2.nextPoisson(9.227628765002294d);
//     org.apache.commons.math3.distribution.RealDistribution var10 = null;
//     double var11 = var2.nextInversionDeviate(var10);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    int var2 = var1.nextInt();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextInt((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2035706397);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(5.725827877519875d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999787365135255d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    long var7 = var2.nextLong((-1L), 0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var2.nextLong(53118080855161933L, 1L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0L);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     double var11 = var2.nextWeibull(1.557407690046052d, 1.260591836521356d);
//     int var14 = var2.nextSecureInt(0, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var2.nextSecureHexString((-24));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e6e8be64a66da7e40dd776be0e8ba9e29e6880bc7e7942d1b56d4337b2d834420a70263acb3f344d13514668857f591393db"+ "'", var6.equals("e6e8be64a66da7e40dd776be0e8ba9e29e6880bc7e7942d1b56d4337b2d834420a70263acb3f344d13514668857f591393db"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 150.1641275229202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5338352400157921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017453292519943295d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.0d, (java.lang.Number)1.4E-45f, (java.lang.Number)0.11705332797771173d);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0d+ "'", var4.equals(0.0d));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(3233753233997579692L, 32377152420278742L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32377152420278742L);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeed(8L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var1.nextInt(100, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.3329738931785933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7949577687638787d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.756042086747289d, 1.260591836521356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7560420867472888d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.8530627877982958d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(100, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9718532847495457d, (java.lang.Number)0.5403023058681398d, true);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(0.999999895123288d);
//     double var5 = var0.nextGamma(11.079397880425052d, 1.230865209494995d);
//     var0.reSeedSecure(53118080855161933L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextBeta((-0.6953957962869728d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.23791181248993795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.259505066331716d);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("b753903658df121dc0899700864dd245c015fe7897c15ff2269ad93101e6adb4ec87262ca8b54c5bc7380a36850cedfece4c", "8ab99d2f56b1a09839548c62dee9df5a2fe33d50453cb43a2bdfcbde54b5bc04a07429e4748e20f91cc779b2e94ba7bc8577");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)(-1), (java.lang.Number)1.7560420867472888d, false);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.9073161258037498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5121289312892812d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, var6);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var1, var6);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    var2.setSeed(10);
    float var5 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.76195765f);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     java.lang.String var16 = var1.nextHexString(13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var1.nextLong(6L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "2de9f54061c76"+ "'", var16.equals("2de9f54061c76"));
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.6753156040846356d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.01178648078137136d));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)8);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    double var6 = var3.getNumericalMean();
    var3.reseedRandomGenerator(2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
//     java.lang.Number var7 = var6.getMin();
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     int[] var9 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var10);
//     double var14 = var11.nextCauchy(0.0d, 0.12417937830488368d);
//     double var17 = var11.nextBeta(1.219806453049797d, 1.2312404863020072d);
//     java.lang.Object[] var18 = new java.lang.Object[] { 1.2312404863020072d};
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, var18);
//     org.apache.commons.math3.exception.MathInternalError var20 = new org.apache.commons.math3.exception.MathInternalError(var2, var18);
//     org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.9999992134249283d, var18);
//     org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var21);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextWeibull(0.9999992134249283d, 0.5403023058681398d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextUniform(0.6953957962869728d, 0.012006336300978443d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.4147105977894117d);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)100.0f, (java.lang.Number)(short)0, false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    int var5 = var1.nextInt(376458423);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 130457894);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(8, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(6.494156047958096d, 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.667005950681052d));

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     double var7 = var2.nextGaussian(0.12482164366779294d, 1.0d);
//     long var10 = var2.nextSecureLong(1L, 935500050423093910L);
//     double var13 = var2.nextCauchy(0.6579544231599213d, 0.5639623740100898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.1848349190787427d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 909182017881509741L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.482325304754773d);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, var2, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    boolean var6 = var4.getBoundIsAllowed();
    java.lang.Number var7 = var4.getArgument();
    java.lang.Throwable[] var8 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)0+ "'", var7.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.557407690046052d, var1, false);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    double var7 = var2.nextChiSquare(0.06571011146367788d);
    var2.reSeedSecure((-1740262975033857731L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("f70f8bfec891d6b013617b069127ccf0c184a3e5a85cfbaadef741824d2fee51ac45fc0161e1f517dbd2a63c0e938303b53f", "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.012006336300978443d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, (-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(9.227628765002294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.5121289312892812d, (java.lang.Number)1.0174774264994466d, (java.lang.Number)0.10727204268430017d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    float var4 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.76195765f);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(130457894, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999f);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.5379756673784256d), 0.9999999898967565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.49356463521584415d));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    var1.setSeed(0L);
    double var4 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-0.043481143175376734d));

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.618958628864691d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("c837893e589c7", "8ab99d2f56b1a09839548c62dee9df5a2fe33d50453cb43a2bdfcbde54b5bc04a07429e4748e20f91cc779b2e94ba7bc8577");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9999984268504751d, 1.1986211422292476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999984268504752d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.49356463521584415d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5379756728137248d));

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     int var17 = var1.nextPascal(130457894, 0.10727204268430017d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1085619743);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    long var9 = var2.nextPoisson(48.876897400506486d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextHypergeometric(675534908, (-3), 5);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 50L);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (-3.2626557414084827d)};
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(48.876897400506486d, 1.618958628864691d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.308138534565753d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, var2, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMin();
    java.lang.Number var7 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.5659742383512718d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5659742383512718d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var11 = var2.nextBeta(0.7972686805079129d, 3.708445464724037d);
    double var13 = var2.nextChiSquare(1.230865209494995d);
    int var16 = var2.nextPascal(23, 0.5659742383512718d);
    long var18 = var2.nextPoisson(0.5055845672881804d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var20 = var2.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.006807647666488568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03571149328003235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2L);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(1, 100);
    org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var14 = var12.sample(100);
    int var15 = var12.getPopulationSize();
    int var16 = var2.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var2.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 752916846, 100, 0);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var6.nextCauchy(0.8530627877982958d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var2.nextPermutation(0, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(80953983022125473L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(2.0d, 0.5305258769231836d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextHypergeometric((-24), 0, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.136102024090793d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.1920928E-7f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.1986211422292476d, 14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19638.208794283993d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(3134652191960553436L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextChiSquare((-2.589860825112713d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.445648259877762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8948290239814146d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int[] var5 = var3.sample(100);
    int var6 = var3.sample();
    int var7 = var3.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.03607191294686202d, 2035706397);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var2.nextInt(3, (-23));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "67c73cbe6cdd984c1719e0c88517a3089d022a373cca18bebe7cbae1ca60e508251a9787484bb666255f79a4873ceb93e58e"+ "'", var6.equals("67c73cbe6cdd984c1719e0c88517a3089d022a373cca18bebe7cbae1ca60e508251a9787484bb666255f79a4873ceb93e58e"));
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    double var8 = var2.nextBeta(1.219806453049797d, 1.2312404863020072d);
    double var10 = var2.nextExponential(0.012006336300978443d);
    var2.reSeed(10L);
    double var15 = var2.nextF(1.1043047119603162d, 0.5659742383512718d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var2.nextF(0.0d, (-0.5996555078851037d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.03406377960730741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0287702751273755d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-21.87440112427276d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.381780321520509d));

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     double var12 = var1.nextUniform(0.06571011146367788d, 1.445648259877762d);
//     double var14 = var1.nextExponential(0.9931570777413035d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.525589885284922d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.756644699807056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.18989547062833476d);
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.17445662120206445d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextBinomial(10, 0.0d);
    int var8 = var2.nextInt(0, 15);
    double var11 = var2.nextBeta(5.72574711174442d, 2.0d);
    var2.reSeedSecure(1362564568071945760L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5659742383512718d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.5379756728137248d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8587477027164937d);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.445648259877762d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(23, 0, (-3));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.030412091907585977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.4929149895375864d));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var3 = var1.nextInt();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 2147483647, (-1), 2);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 752916846);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-4.9E-324d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.9E-324d));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.7071067811865475d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7853981633974482d));

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.260591836521356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8512271908466933d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var3 = var1.nextInt();
    boolean var4 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var7 = new int[] { };
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
    var8.setSeed(10);
    byte[] var14 = new byte[] { (byte)100, (byte)(-1), (byte)100};
    var8.nextBytes(var14);
    var6.nextBytes(var14);
    var1.nextBytes(var14);
    long var18 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 752916846);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2470096362876148374L);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0f), (java.lang.Number)(short)1, true);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)1+ "'", var4.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)1+ "'", var5.equals((short)1));

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.999999895123288d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8813735128605069d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(101.44573580065675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 101L);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.8737484983160598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(10L, 3233753233997579692L);
//     long var5 = var0.nextPoisson(1.2312404863020072d);
//     double var7 = var0.nextChiSquare(0.07960895200719602d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2472679844610678315L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.3841289907787343E-8d);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(2.3841289907787343E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    var1.reSeed();
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var1.nextHypergeometric(15, 1, 376458423);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var8 = var1.nextGaussian(Double.NaN, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextLong(909182017881509741L, (-3482344208705029123L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.45058111020542446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(40, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    int[] var4 = new int[] { };
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    var1.setSeed(var4);
    long var7 = var1.nextLong();
    long var9 = var1.nextLong(1000377107798907052L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4187054274462996441L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 550771151206886582L);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.12386047256581567d, (-0.8009428790252594d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12386047256581567d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(99.999985f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.9999992134249283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.4160534760971524E-7d));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure();
    int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
    var1.reSeedSecure(100L);
    org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var1.nextLong(1362564568071945760L, 100L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.9073161258037498d, 376458423);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9526367852214799d, (java.lang.Number)0.11705332797771173d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    int[] var7 = new int[] { };
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var8);
    double var12 = var9.nextCauchy(0.0d, 0.12417937830488368d);
    double var15 = var9.nextBeta(1.219806453049797d, 1.2312404863020072d);
    java.lang.Object[] var16 = new java.lang.Object[] { 1.2312404863020072d};
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.11705332797771173d+ "'", var5.equals(0.11705332797771173d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-0.20221127419725435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.8291573013481451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(11.975951657450514d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.02404834254948618d));

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.clear();

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.7654659033750127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7210596238295536d);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     java.lang.String var6 = var2.nextSecureHexString(100);
//     double var8 = var2.nextExponential(100.0d);
//     long var11 = var2.nextSecureLong(0L, 6L);
//     java.lang.String var13 = var2.nextHexString(23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var2.nextInt(44, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e6806eee7f356351bcdf7e3e036bc324e1d07721f5a0009d8c1c990ce73c070834fa063b3977e67a7c83af4ef4277db36564"+ "'", var6.equals("e6806eee7f356351bcdf7e3e036bc324e1d07721f5a0009d8c1c990ce73c070834fa063b3977e67a7c83af4ef4277db36564"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 65.38995575056346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "0241ecd25dcd198fbd2662f"+ "'", var13.equals("0241ecd25dcd198fbd2662f"));
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(54831737849439661L, 2472679844610678315L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2177253655836675545L);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     double var5 = var1.nextBeta(0.5305258769231836d, 0.11705332797771173d);
//     double var7 = var1.nextExponential(0.9718532847495457d);
//     int var10 = var1.nextZipf(100, 1.260591836521356d);
//     var1.reSeed();
//     double var14 = var1.nextCauchy(1.0684732215128296d, 0.11705332797771173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9999999942134883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.3987022779441262d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0226129779974114d);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-17));

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeed();
//     double var7 = var2.nextGaussian(0.12482164366779294d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var2.nextGamma(0.06571011146367788d, (-4.9E-324d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.36384244448991454d);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    double var5 = var3.cumulativeProbability(10);
    int var6 = var3.getSupportUpperBound();
    int var7 = var3.sample();
    int[] var9 = var3.sample(13);
    int var10 = var3.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2472679844610678315L, (java.lang.Number)11.079397880425052d, (java.lang.Number)0.006807647666488568d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7853981633974483d));

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.OutOfRangeException var11 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100, var9, (java.lang.Number)(-2.131776110801955d));
    java.lang.Object[] var12 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var1, var12);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)11, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.999999895123288d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403023941188468d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(2470096362876148374L, 293141324453066497L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2470096362876148374L);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var4);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
    java.lang.Number var9 = var7.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var10 = var1.nextUniform((-1.0d), 10.0d, false);
//     java.lang.String var12 = var1.nextSecureHexString(100);
//     long var15 = var1.nextLong(0L, 80953983022125473L);
//     double var18 = var1.nextGamma(0.6373589277942243d, 0.1339041896989337d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextGaussian(0.0d, (-0.1848349190787427d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 8.877448544153978d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "f8f27c4bc0eb131049b899a6bed2522a48f75f0ff6bfa2ff2678919779db3017933a848fa6c992e199d0e18ff3c3a0b9fcfc"+ "'", var12.equals("f8f27c4bc0eb131049b899a6bed2522a48f75f0ff6bfa2ff2678919779db3017933a848fa6c992e199d0e18ff3c3a0b9fcfc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 7039038404803512L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.17908795455860083d);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.8813735128605069d, (-2.667005950681052d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8224185856954223d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    var1.setSeed(0L);
    float var4 = var1.nextFloat();
    long var5 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.74324155f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-509399413869688601L));

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 40, 0, 40);
    int var8 = var7.sample();
    int var10 = var7.inverseCumulativeProbability(0.8948290239814146d);
    var7.reseedRandomGenerator(2177253655836675545L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(32);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.970455801871072d, (java.lang.Number)0.06571011146367788d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     var1.reSeedSecure(100L);
//     org.apache.commons.math3.random.RandomGenerator var9 = var1.getRandomGenerator();
//     var1.reSeedSecure(2L);
//     int var14 = var1.nextInt((-24), 40);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("8ab99d2f56b1a09839548c62dee9df5a2fe33d50453cb43a2bdfcbde54b5bc04a07429e4748e20f91cc779b2e94ba7bc8577", "c837893e589c7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-23));
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(99.99999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextBinomial(10, 0.0d);
//     int var8 = var2.nextInt(0, 15);
//     double var11 = var2.nextBeta(5.72574711174442d, 2.0d);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var2.nextSample(var12, 44);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    var1.setSeed(10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 40, 0, 40);
    var7.reseedRandomGenerator(320948475447706239L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 752916846, 100, 0);
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-96398574));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(4.546466837977001d, 14.531995745214504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.30321196946857537d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = var1.nextPermutation(11, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(4.482325304754773d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var0);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var8 = var5.nextUniform(0.7972686805079129d, 162.57253213649173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3233753233997579692L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 140.01498023729022d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.3329738931785933d, false);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.3329738931785933d+ "'", var4.equals(1.3329738931785933d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9718532847495457d, 0.756644699807056d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9718532847495456d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 1, 0, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var7.inverseCumulativeProbability((-9.714723000591938d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2478736222527921d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(100, 10, 0);
    int var4 = var3.getSupportLowerBound();
    int var5 = var3.sample();
    int var6 = var3.getSupportLowerBound();
    boolean var7 = var3.isSupportConnected();
    double var9 = var3.probability(2035706397);
    double var11 = var3.probability((-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.0226129779974114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 58.59140771455618d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var4);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.OutOfRangeException var11 = new org.apache.commons.math3.exception.OutOfRangeException(var7, (java.lang.Number)100, var9, (java.lang.Number)(-2.131776110801955d));
    java.lang.Object[] var12 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var1, var12);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var8, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)(-1L), var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)2, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.0d, 0.12417937830488368d);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextLong(935500050423093910L, 8L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.20221127419725435d));

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.8948290239814146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9459540284714764d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(2.0d, 0.5305258769231836d);
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.136102024090793d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 100L};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.3329738931785933d, var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var4, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, var7);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var2, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure();
//     int var6 = var1.nextHypergeometric(752916846, 10, 752916846);
//     double var9 = var1.nextCauchy(1.260591836521356d, 0.9526367852214799d);
//     double var12 = var1.nextUniform(0.06571011146367788d, 1.445648259877762d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextInt(675534908, (-24));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2682432732383346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.544435554199747d);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(514406009);

  }

}
