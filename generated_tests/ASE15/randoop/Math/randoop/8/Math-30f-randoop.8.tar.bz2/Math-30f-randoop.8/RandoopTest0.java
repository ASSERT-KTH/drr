
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.0f), 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1L), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8390715290764524d));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(100, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.332621544395286E157d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1622776601683795d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)100);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.14778027539684d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-1), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-100));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(10.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 1024.0f, (-0.99999994f), (-100));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.0d, 3.1622776601683795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.15729146283385384d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.8390715290764524d), 3.1622776601683795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8390715290764524d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(13.14778027539684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.0d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9223372036854775807L);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-1.0d), 13.14778027539684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13.14778027539684d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.99999994f), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.0d), 3.1622776601683795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-1.0d), 3.1622776601683795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.3166247903554003d);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var1);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3.1622776601683795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(9.332621544395286E157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.5359460963350345E52d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.15729146283385384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 27.12061425361551d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.15729146283385384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.412848953997996d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var3 = var0.nextPermutation(0, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.8390715290764524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.014644560842127431d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.0d, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(27.12061425361551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2817446668755537d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1813229557370451d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.256762363328148d);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 0.0f, 1024.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var0.nextSample(var4, (-100));
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.2132396021992005d, Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(3.2132396021992005d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(10.0d, 6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7781512503836435d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(9223372036854775807L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
    double[] var3 = new double[] { };
    double[] var5 = new double[] { 10.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.mannWhitneyUTest(var3, var5);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1L), 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7L);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(100L, 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 93L);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, (-0.0f), (-0.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(Double.POSITIVE_INFINITY, 3.2817446668755537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.4657978658424197E-6d));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.2132396021992005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.213239602199201d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(100, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 30.48232336227865d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.0f, (-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0000000000000004d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("hi!", "hi!");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = var0.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextWeibull(4.5359460963350345E52d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.263097627657226d);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var5 = var0.nextT(0.8390715290764524d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.7753414994721d);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-3.4657978658424197E-6d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-100), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.993222846126381d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(10, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10));

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.1813229557370451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17936156675857706d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.408529442330648d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.010620014682896545d);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, (-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(6.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextLong(10L, 2L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2928850742512834d);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-3.4657978658424197E-6d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.4657978658285428E-6d));

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextHypergeometric((-10), 0, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.5289352313727194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.5343748793761005d);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10L);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(8L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8L);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-10), (-0.02172004731721395d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 10.0f, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 13.14778027539684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.0d, 8.033816814586373d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(3.3166247903554003d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0406823393269602d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, 9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-100), (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-100), 3.0000000000000004d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 9.536743E-7f, (-0.99999994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(13.14778027539684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07902415835395639d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var4 = new double[] { (-1.0d), 100.0d, 10.0d};
    double[] var5 = new double[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.mannWhitneyU(var4, var5);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.1813229557370451d, 3.2132396021992005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6836289098502112d));

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.cbrt(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    java.math.BigInteger var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.15729146283385384d, 0.007748145938530172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5002669897290136d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.5359460963350345E52d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.535946096335034E52d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(8L, 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56L);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5063656411097588d));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor((-0.99999994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var0.nextPermutation((-127), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.923083811596294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.029620337533308862d);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.exp(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.4E-45f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(3.215653939400476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8360738684267854d);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(3.3166247903554003d, 1.412848953997996d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextInt(0, (-100));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4999546567715707d);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-127), 4.535946096335034E52d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(0.8390715290764524d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.substituteMostRecentElement(3.2817446668755537d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(100, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.7871088143391114d, 4.535946096335034E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.535946096335034E52d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var1 = null;
    double[] var3 = new double[] { 1.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.mannWhitneyUTest(var1, var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.4E-45f, (-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var0.substituteMostRecentElement(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
//     java.lang.Number var10 = var9.getLo();
//     var4.addSuppressed((java.lang.Throwable)var9);
//     java.lang.String var12 = var9.toString();
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements((-127));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-3.4657978658424197E-6d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-100), (-0.99999994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(4.5359460963350345E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var3 = new double[] { (-1.0d), 100.0d};
    double[] var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.mannWhitneyUTest(var3, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(100, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-1), (-1.0d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.MathIllegalStateException var1 = new org.apache.commons.math3.exception.MathIllegalStateException();
    var0.addSuppressed((java.lang.Throwable)var1);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.8360738684267854d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2245129522199552d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0f);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1L), 56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-10), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.8360738684267854d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1024.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.1377077104187023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.3900553644082354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(3.2817446668755537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-127), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.230325591810731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.7871088143391114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8709381773848226d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.probability(0.007907055323073179d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.cumulativeProbability(3.3900553644082354d, 0.21400263603676362d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.15729146283385384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 41.752984630466926d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2207031E-4f);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var6 = new double[] { 1.0d};
//     var4.addElements(var6);
//     double[] var8 = var2.rank(var6);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.util.Collection var1 = null;
//     java.lang.Object[] var3 = var0.nextSample(var1, (-10));
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.0f), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(30.48232336227865d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.351004290131115d));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.47712125471966244d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor((-0.99999994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1L), (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2L));

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(100, 99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9900);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024.0f);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "hi!");
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.1995641250475069d, 0.47712125471966244d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.46350505080872756d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.5063656411097588d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1309659398685306d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.227226180092589d, 3.213239602199201d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9962928771299543d);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextZipf((-100), 0.15729146283385384d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6699891206621797d);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(0, (-10), (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.13168443408321873d);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(0.8390715290764524d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.substituteMostRecentElement(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextPascal((-100), 0.03428444643176393d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(98.78234435786233d, 2.3932364423299792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 98.81133101777444d);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextPoisson((-0.6836289098502112d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2639436925942746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004538607600884483d);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.383931628367152d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.383931628367152d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NoDataException var1 = new org.apache.commons.math3.exception.NoDataException(var0);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.99999994f), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.49999997f));

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(3.3166247903554003d, 1.412848953997996d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextSecureLong(8L, 3L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.15021620548101391d);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 2L);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.383931628367152d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.383931628367152d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-10), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.8360738684267854d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.233351086493488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9968961379767788d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.014644560842127431d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01453836480175214d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.993222846126381d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0963506818711306d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1270);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9223372036854775807L);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextZipf(0, 3.230325591810731d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(1.2207031E-4f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextBeta(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.147270995574832d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.240940713449634E-4d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.4794792759154962d);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(3.3166247903554003d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.801711757320268d);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 1.8360738684267854d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.8390715290764524d, 0.0d, 0.0d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-10), (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-127));

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-127), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(9900, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.17936156675857706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17747447229466043d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.8390715290764524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.discardMostRecentElements((-100));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    float var9 = var0.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7L);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-1.351004290131115d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.476254319231334d));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.094947E-13f);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-100), 0.020769319996080778d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     double[] var6 = new double[] { (-1.0d), 100.0d, (-1.0d)};
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var7.setContractionCriteria(1024.0f);
//     var7.setElement(0, 3.0000000000000004d);
//     float var13 = var7.getContractionCriteria();
//     boolean var15 = var7.equals((java.lang.Object)0.21400263603676362d);
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = var7.copy();
//     double[] var19 = new double[] { 100.0d, 0.0d};
//     var7.addElements(var19);
//     double var21 = var2.mannWhitneyUTest(var6, var19);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     long var11 = var0.nextLong(3L, 100L);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.8390715290764524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9160084765308957d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(1270);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.6104227919456581d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6104227919456581d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.discardFrontElements(9900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-10), 1.4E-45f, 100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.002217427235567818d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0022174236012274633d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-10), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.17747447229466043d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17936156675857706d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(13.801711757320268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(3.1622776601683795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.7871088143391114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9233044426883612d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.3932364423299792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.221784168705742d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(9223372036854775807L, 18L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9223372036854775807L);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-10));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.0022174236012274633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(7.6293945E-6f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0078125f);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(5.64539685894143d, 98.81133101777444d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = var2.sample((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-10), (-10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.1377077104187023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.063722427580958d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(18L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5832L);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(4.5359460963350345E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var5 = var2.cumulativeProbability(Double.NaN);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var2.inverseCumulativeProbability(27.12061425361551d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.993222846126381d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.15729146283385384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     double var0 = org.apache.commons.math3.util.FastMath.random();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == 0.7504519561054462d);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var2.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var8 = var7.getElements();
//     double[] var9 = var2.rank(var8);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(3.3751854960563317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed((-1L));
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var1.nextSample(var4, 10);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024.0001f);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(1.0406823393269602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.022147517156860363d));

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
//     java.lang.Number var10 = var9.getLo();
//     var4.addSuppressed((java.lang.Throwable)var9);
//     java.lang.Number var12 = var9.getHi();
//     org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var9);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(30.48232336227865d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5320169063293507d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.412848953997996d, 6.034340389202805d, Double.NaN, (-100));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var5 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3721572629395604d);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3.383931628367152d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 201.7156361224559d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-100));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7L);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.3932364423299792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6068334162420739d);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var0.nextPermutation((-10), (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.0d, (java.lang.Number)0.0f, true);
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    var7.addSuppressed((java.lang.Throwable)var11);
    var3.addSuppressed((java.lang.Throwable)var7);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1024.0001f, 0.9962928771299543d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(4.535946096335034E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.535946096335034E52d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)3.233351086493488d, var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var5);
//     java.lang.Object[] var8 = new java.lang.Object[] { var1};
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var0, var8);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var9);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.150583739608087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5363287730003797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 153.1018959226765d);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000001f);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
    java.lang.Number var10 = var9.getLo();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1024.0f+ "'", var10.equals(1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 3.233351086493488d+ "'", var12.equals(3.233351086493488d));

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1270);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 0.0078125f, (-0.99999994f), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.03428444643176393d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.346069909771813E28d);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.35153725339165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.024066614594820103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2787171237383692d);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(3.1622776601683795d, 0.3223349576087434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3223349576087434d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.inverseCumulativeProbability(0.007748145938530172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.420567737873968d));

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria((-0.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.5521977843425779d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.230325591810731d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1725829345725258d);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException();
//     org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     java.lang.Object[] var12 = new java.lang.Object[] { 10.0d};
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var9, var12);
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var6, var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var12);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0078125f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0078125f);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(98.81133101777444d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.18871602462383E42d);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(3.230325591810731d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var1.nextPermutation((-1), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.19389359333853515d);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    var9.setElement(0, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.discardFrontElements((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536744E-7f);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.getElement(99);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9233044426883612d, (java.lang.Number)(short)(-1), false);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextGaussian(3.2132396021992005d, 0.17936156675857706d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    int var4 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(100.0f, (-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(56L, (-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.320026378961567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4632615084784795d);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGaussian(0.01453836480175214d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "aeaefe04ebc57f8638bede69f2eafb67f039716fa8361ec5c22749dbdde2c94cb9449f9a2c5edd3bff24102881101b16add2cfacdf902609825bfa61a22b3e7035b35f3ab76151391177ea6ba73279c1f7871a5371de68a773c28940a4c9fc80ee63667a198dad24a29b6b92598fda9b216b753a63d6377909dd09103ae33cfc363202c17aae1081711717298b0d27d405a9233c43549b6a5f04fe5788780c23a7dc8c999e8f254efd2ee7dcb97316ab4d3227d54100799360999b5bb6708ad85d3973c632b693edbd57c50d5a89e459ed35edc6161ba385f4656bd6fdbaa0fc67d6545f7003738c72f44ae2bbfda84e56fb8cbdfc8706991387e954dadaa5124269ddce96aa5f316df02d01dabe4ed29dd9058cef8bb4b4e4b72b8c0761157e4d3d225b78551e2efe1bdb0279f3127057d04830d2b1c3424a71298a46cb80602252f5614a967c8be7593502d1fbc4ad6d431684b4ee9930472d9f915407515d8e38520e4dc802b154d74ea7b77f58f4dc27a640537882e7a01b75b54b1dc8877b785893413662bc0245ff65e3db8c28877772ae0d3719315e9f02e8cdd01e67c582cb815c1125e5832e60db47f02e1e5f75069c780d1e01a07e1de34d278add2afa3c8302134f84114f9480e4857e2c9c5b29ff99b567cbb6f50d2a892abcbacdb92b7d45982a1e187d36a5640d445828a2a49a94f00c4bf73670dbd5ab52726221ec5b86fc31755db8e77cb3505c80d0d9822ec16de64db898a385614132e9772257311a81aaf836e8e84495825f2439b06ccefd9a340343aefa08828ce0d5ce37a74bfba8e327c580a8bfe1acea1ef1a9f85052c5b22958b68e4618ff688b20f03f17228ac30bdcca9b8e056da69163c4bf76f500f5edcea31b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6087136436716681d);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)5.780270116065924d, (java.lang.Number)3.3166247903554003d, false);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6L);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(56L, (-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 127);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.17747447229466043d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.95258268614213d));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1024.0001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2207031E-4f);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(93L, 18L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var10 = var0.nextChiSquare(3.227226180092589d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextBinomial(0, 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3399285149619655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.3606340500629923E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.2405351763661763d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.312779248516162d);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.8390715290764524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-1.351004290131115d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3L, (java.lang.Number)3.272211577652278d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.213239602199201d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    var3.addSuppressed((java.lang.Throwable)var7);
    boolean var9 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var3.getContext();
    java.lang.Number var12 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 3.233351086493488d+ "'", var12.equals(3.233351086493488d));

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var3.cumulativeProbability(201.7156361224559d, 0.02240694992560174d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    int var6 = var5.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.629395E-6f);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.005325222439319957d, 24.013235187792638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999999999919d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(3.320026378961567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5211415343642575d);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 10);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0f), 7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.6293945E-6f);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(56L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-56L));

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.220446049250313E-16d, 3.215653939400476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.03240600299334935d));

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(8.18871602462383E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 42.913215810535064d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(3.1622776601683795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.984925048774637d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.3932364423299792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3376070089627754d);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextPoisson((-638.3703397929479d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1476591990780682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.6755260861563833d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-43.21895774668431d));
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.007907055323073179d, (-0.03240600299334935d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.007907055323073179d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.03428444643176393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5));

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.01453836480175214d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.01453836480175214d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(8.18871602462383E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 6L);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)Double.POSITIVE_INFINITY);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.5707963267948966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8794632640771181d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-2L), 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-16L));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-638.3703397929479d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1368683772161603E-13d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(9900, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9900);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.5699328711844167d, 3.853702795813156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 37.994147737115796d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)9.332621544395286E157d, (java.lang.Number)3.215653939400476d, true);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(9900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 81188.39044958311d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(byte)(-1), (java.lang.Number)0.9968961379767788d, true);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.02240694992560174d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.022405075367622047d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.037803534264273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(9900, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.8794632640771181d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9973002184105607d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.535946096335034E52d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-2.420567737873968d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.5211415343642575d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(58L, (-16L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-16L));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(9.536744E-7f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536744E-7f);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(9.094947E-13f, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8189894E-12f);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.3970832209142864d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4255844847533664d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(99, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-5));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.984925048774637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8706737131905523d);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(5, (-10), (-100));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3680106757567065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.041049471436156344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.630009311542957d);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.02240694992560174d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.469446951953614E-18d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(99, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1024.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var6 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)3.233351086493488d, var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var6);
//     java.lang.Object[] var9 = new java.lang.Object[] { var2};
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var1, var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var9);
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.NoDataException var13 = new org.apache.commons.math3.exception.NoDataException();
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var12, (java.lang.Object[])var14);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.atan2(0.1813229557370451d, Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(127, 99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 291729791);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.233351086493488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8897644350211715d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-2L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var0.nextSecureHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.42010362282406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004862987762721517d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.682813735796534d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.727245716661153d);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(3.230325591810731d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextSecureInt(100, (-5));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.3462163436729929d));
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.002217427235567818d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.654150622549162d));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(99, 127);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(9.094947E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.094948E-13f);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.3142072789405845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 27.50058504859484d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-948.6589633412129d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(4.5359460963350345E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9223372036854775807L);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-5.95258268614213d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 447.9102432789676d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1024.0001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.0f), 7.629395E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var12 = var0.nextUniform(0.8390715290764524d, 3.215653939400476d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextCauchy(0.5676831367550988d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1462796949796803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.009687496956546693d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.980594703762393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.41526778897485d);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed((-1L));
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var1.nextSample(var4, 291729791);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.1368683772161603E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.04100350918060158d, (-0.03240600299334935d), 0.9962928771299543d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(100L, (-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.probability(0.007907055323073179d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var7 = var2.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-948.6589633412129d), 1.2245129522199552d, (-0.02172004731721395d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var3.cumulativeProbability(13.14778027539684d, 0.02240694992560174d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.305530002646725d, 0.014644560842127431d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.3055624425443724d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.018734606752382445d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9998245123878073d);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var9 = var0.nextSecureHexString((-100));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.8897644350211715d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.264559356917848d);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     var0.reSeedSecure(5832L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3954865640363336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.020294450361988292d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.283760323497615d);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5f);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(9900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.2207031E-4f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(58L, 45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.3166247903554003d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 27.567148453340938d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1024.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(5.64539685894143d, (-2.654150622549162d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.010275321846272d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(58L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 58L);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(9.332621544395286E157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 363.7393755555636d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.203543756687526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.583731940621995d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(2.2184258106909835d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6032975776636309d));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(8.033816814586373d, 3.3791583060607677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1726441408056698d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.49999997f), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.49999994f));

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(9900, 127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9900);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed();
//     double var12 = var0.nextGamma(0.0d, 0.4255844847533664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.31456926834144955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextZipf((-10), 0.9973002184105607d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3831667922053329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.0110227779598469d));
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1, 99);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.1102230246251565E-16d, 0.04100350918060158d, 0.5211415343642575d, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.022147517156860363d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2040.3837802863068d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.8706737131905523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3885194886694814d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(24.013235187792638d, 27.12061425361551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7247032922278211d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(24.013235187792638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8721855928581603d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(5, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.281783181607902d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3.3306435445317306d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.03428444643176393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.501720002936757d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(8.18871602462383E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 98.81133101777444d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.1725829345725258d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(3.272211577652278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0249511467302783d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.027472359321754035d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.027468903747454535d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(3.2622146137297445d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5135125288969639d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-10), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.094947E-13f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var1.nextPermutation(9900, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(8L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.000000000000001d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(3.5024195390363198d, 81188.39044958311d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 81188.39044958311d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-17));

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(3.158982217932436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1589822179324365d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.8189894E-12f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.9998245123878073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1749304202020776d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(27.50058504859484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.295915671195673d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6321205588285577d));

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 81188.39044958311d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setExpansionFactor(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(99, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    var0.clear();
    var0.setContractionCriteria(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-17));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-948.6589633412129d), 1.2245129522199552d, (-0.02172004731721395d));
    double var4 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-948.6589633412129d));

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextBinomial(0, 12.063722427580958d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.07031404236938041d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8263389624961907d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "8e43def3ff4e5087b492eec09febe8c591735329f7a2f14c2b09879b958045c8e857dbf7bb3aab4b2d0bd932df8defb48b7f577b40946bff67f7b163cc6851cc5ef9dd8bf00e1c4133efd68cf9341843832a745e66ee1aad9e7f8d8bef4c59f67cf18e31aedc32fe717668b279e0bdb606b8c99175a594a5ce754f91ee511c3ccb0ae366f4a0328a288d6e5a1ca5f964d18392395d8258eab0ab1643d4c7a83b90f0b29ca0f1393aaad41be3f97e88df8032f914ecfae41fc5504c8d99952ddba1743d77642d0ab62ff933ffe7282eeccadbae755d17349f8ae237ef8d9140e48ea086a4dfc81d7994bb3fe33678e329dd656356b175b247169d2f773bd61318c0ab04c14eff18491d72936c306510edc7664285fb392deccff4a2d88b95a243ca1903ac374729351f09d28374cae9e2a0dc395b1b90970aba3a7da4d62b15328447c35c0b1f0d930de54a55cb30e9ddacbd91df7e01b7246d49fb086397fad0a7fa43cf80db16143b65aaad59ae18e168e7114e838503d85b9e6e7f787c52100fe0f3c82e86fdd140934eef0b36cc06af995baf9849b9d64f01ce4b43251b6baaa1800b78a33c49eb25a37b95427b0e9701f838c684cd2aa5a250dffd94a4610dfdd2bf49d2a7791cb505b99bf13863047b28fcaf0161f300ebef991adf5e6d43c49058452795ffb12963c675a2a8e7f7ffaf14ce9322cb19edf5158651b74c3a6c651820a72d30a6db1ebf655354991798742549436644bd792e2226e28941db3e9964894214cca3eda30be158555900c69af99dbedfade84bd00877f7fd338225f226ab382e88a6b5d899174b97e9881479f1a540c917881f007afe6acbc4e05d7afdde2057830a91d34dd1042ee12ade3eb8eadf0a54788cc0"+ "'", var13.equals("8e43def3ff4e5087b492eec09febe8c591735329f7a2f14c2b09879b958045c8e857dbf7bb3aab4b2d0bd932df8defb48b7f577b40946bff67f7b163cc6851cc5ef9dd8bf00e1c4133efd68cf9341843832a745e66ee1aad9e7f8d8bef4c59f67cf18e31aedc32fe717668b279e0bdb606b8c99175a594a5ce754f91ee511c3ccb0ae366f4a0328a288d6e5a1ca5f964d18392395d8258eab0ab1643d4c7a83b90f0b29ca0f1393aaad41be3f97e88df8032f914ecfae41fc5504c8d99952ddba1743d77642d0ab62ff933ffe7282eeccadbae755d17349f8ae237ef8d9140e48ea086a4dfc81d7994bb3fe33678e329dd656356b175b247169d2f773bd61318c0ab04c14eff18491d72936c306510edc7664285fb392deccff4a2d88b95a243ca1903ac374729351f09d28374cae9e2a0dc395b1b90970aba3a7da4d62b15328447c35c0b1f0d930de54a55cb30e9ddacbd91df7e01b7246d49fb086397fad0a7fa43cf80db16143b65aaad59ae18e168e7114e838503d85b9e6e7f787c52100fe0f3c82e86fdd140934eef0b36cc06af995baf9849b9d64f01ce4b43251b6baaa1800b78a33c49eb25a37b95427b0e9701f838c684cd2aa5a250dffd94a4610dfdd2bf49d2a7791cb505b99bf13863047b28fcaf0161f300ebef991adf5e6d43c49058452795ffb12963c675a2a8e7f7ffaf14ce9322cb19edf5158651b74c3a6c651820a72d30a6db1ebf655354991798742549436644bd792e2226e28941db3e9964894214cca3eda30be158555900c69af99dbedfade84bd00877f7fd338225f226ab382e88a6b5d899174b97e9881479f1a540c917881f007afe6acbc4e05d7afdde2057830a91d34dd1042ee12ade3eb8eadf0a54788cc0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 11.951305511384506d);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.146128035678238d);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.6836289098502112d), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6836289098502112d));

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextLong(0L, (-2L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.509117930202384d);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(3.1936453631680304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05209977259005042d);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var0.nextPermutation((-10), 99);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.5231365292266257d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.028505294206505005d);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(4.86927073907222d, 0.5320169063293507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.898248617516793d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(3.32964908430422d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05811333945712289d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.022405075367622047d, 4.283760323497615d);
    double var3 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.NEGATIVE_INFINITY);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(10, 1270);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var5 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)0, (java.lang.Number)98.78234435786233d, false);
    java.lang.Number var5 = var4.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 98.78234435786233d+ "'", var5.equals(98.78234435786233d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7568024953079282d));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(127, 127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1024, 291729791);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(291729791);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 291729791);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.99999994f);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    boolean var6 = var0.equals((java.lang.Object)(-0.99999994f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1024.0001f, 0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0001f);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.47712125471966244d, var1, (java.lang.Number)0.984925048774637d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("aeaefe04ebc57f8638bede69f2eafb67f039716fa8361ec5c22749dbdde2c94cb9449f9a2c5edd3bff24102881101b16add2cfacdf902609825bfa61a22b3e7035b35f3ab76151391177ea6ba73279c1f7871a5371de68a773c28940a4c9fc80ee63667a198dad24a29b6b92598fda9b216b753a63d6377909dd09103ae33cfc363202c17aae1081711717298b0d27d405a9233c43549b6a5f04fe5788780c23a7dc8c999e8f254efd2ee7dcb97316ab4d3227d54100799360999b5bb6708ad85d3973c632b693edbd57c50d5a89e459ed35edc6161ba385f4656bd6fdbaa0fc67d6545f7003738c72f44ae2bbfda84e56fb8cbdfc8706991387e954dadaa5124269ddce96aa5f316df02d01dabe4ed29dd9058cef8bb4b4e4b72b8c0761157e4d3d225b78551e2efe1bdb0279f3127057d04830d2b1c3424a71298a46cb80602252f5614a967c8be7593502d1fbc4ad6d431684b4ee9930472d9f915407515d8e38520e4dc802b154d74ea7b77f58f4dc27a640537882e7a01b75b54b1dc8877b785893413662bc0245ff65e3db8c28877772ae0d3719315e9f02e8cdd01e67c582cb815c1125e5832e60db47f02e1e5f75069c780d1e01a07e1de34d278add2afa3c8302134f84114f9480e4857e2c9c5b29ff99b567cbb6f50d2a892abcbacdb92b7d45982a1e187d36a5640d445828a2a49a94f00c4bf73670dbd5ab52726221ec5b86fc31755db8e77cb3505c80d0d9822ec16de64db898a385614132e9772257311a81aaf836e8e84495825f2439b06ccefd9a340343aefa08828ce0d5ce37a74bfba8e327c580a8bfe1acea1ef1a9f85052c5b22958b68e4618ff688b20f03f17228ac30bdcca9b8e056da69163c4bf76f500f5edcea31b");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(3.5321218005364248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.061647155000831025d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1L, (-16L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16L);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-638.3703397929479d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.744920421363131E-278d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5574077246549023d));

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.3223349576087434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.31181957426375756d);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var10 = var0.nextChiSquare(3.227226180092589d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var0.nextSample(var11, (-5));
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(6L, 93L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99L);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.158982217932436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(9.094947E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.094947E-13f);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(27.567148453340938d, 0.8706737131905523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.04175569827445511d));

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)Double.NaN);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.000001f, 9.536744E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getElement((-5));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.020769319996080778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.8626412474598433d);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(8L, 535514000795646464L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-535514000795646456L));

  }

}
