
import junit.framework.*;

public class RandoopTest3 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.0574806988857035E105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0574806988857035E105d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.751338028074459d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1198345179668387d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test4"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.7081386520500382d), (-21.78306364600953d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7081386520500382d));

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test5"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var0.nextPermutation(27326631, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.54255426770317d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.019884455932989736d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.5846579889741164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.368284921749995d);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test6"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1010, 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1010);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test7"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     long var12 = var0.nextPoisson(3.230325591810731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4665531328750507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8667636572706984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5L);
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     double var15 = var0.nextCauchy(6.0d, 0.6104227919456581d);
//     var0.reSeedSecure();
//     double var19 = var0.nextGamma(4.898248617516793d, 3.5321218005364248d);
//     double var22 = var0.nextCauchy(0.6057997097623945d, 0.9998245123878073d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var24 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.9814148328335985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.001312370093315066d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8.723202706503082d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6.124920599305958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 18.150551687447013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-5.255015627339142d));
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test9"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportConnected();
    double var4 = var2.getNumericalVariance();
    double var5 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.02077230715275626d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.8741345662445585d));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test11"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(4064528);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(5.551115123125784E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125784E-17d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test13"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)0, (java.lang.Number)98.78234435786233d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.0d, (java.lang.Number)0.0f, true);
    var4.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var10 = var8.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0f+ "'", var10.equals(0.0f));

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test14"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var8.setContractionCriteria(1024.0f);
    var8.setElement(0, 3.0000000000000004d);
    float var14 = var8.getContractionCriteria();
    boolean var16 = var8.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var8.copy();
    double[] var20 = new double[] { 100.0d, 0.0d};
    var8.addElements(var20);
    double[] var22 = var8.getElements();
    double[] var23 = var7.rank(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     double var11 = var0.nextCauchy(0.5211415343642575d, 1.098418460323332d);
//     double var14 = var0.nextCauchy((-0.16320402005311493d), 2.010275321846272d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var0.nextPermutation((-31393204), 2083303935);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.140577792227739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.012271909836453314d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21.9909865785825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.04759823598317586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.884014159425981d);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test16"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var18);
//     int var20 = var2.ordinal();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.35673251118415d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test17"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, 6937L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6937L);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test18"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var7, (java.lang.Number)3.233351086493488d, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var10);
    java.lang.Object[] var13 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var5, var13);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var13);
    org.apache.commons.math3.exception.MaxCountExceededException var17 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, var2, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test19"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     long var6 = var0.nextSecureLong(7L, 58L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextCauchy((-3.2583251035713006d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 29L);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test21"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.nextF(1.1368683772161603E-13d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test22"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     java.lang.String var11 = var0.nextHexString(127);
//     double var14 = var0.nextGamma((-0.022147517156860363d), 5.0191180244969094E-6d);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var0.nextInversionDeviate(var15);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test23"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, (-535514000795646456L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test24"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(43L, 1794L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1837L);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test26"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.3970832209142864d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.370405536544812d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test27"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    boolean var11 = var9.equals((java.lang.Object)(short)10);
    java.lang.Class var12 = var9.getDeclaringClass();
    java.lang.Class var13 = var9.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var21);
    java.lang.String var24 = var21.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var21);
    boolean var27 = var21.equals((java.lang.Object)2.203543756687526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "AVERAGE"+ "'", var24.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.8442914302025525d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2359321581335148d);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation((-100), 1270);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1617119680496677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.0039952577613442d));
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(3.4077945219161934d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8969546064642915d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test31"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test32"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportConnected();
    boolean var4 = var2.isSupportConnected();
    double[] var6 = var2.sample(5);
    double var8 = var2.cumulativeProbability(0.004997851075629565d);
    double var9 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3, (-31393204));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test34"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(2.981543319583938d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9154687859139277d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test35"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(96L, 360L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 24L);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test36"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7810.893058144583d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test37"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getMean();
    boolean var5 = var2.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.cumulativeProbability(1.3027476538919007d, (-1.987808884207606d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0574806988857035E105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test38"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.23799934003749132d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.14595944790464d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test39"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(4.394517941340612d, 5.652949755988041d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4308.687015814714d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test40"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.3126332425372544E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-13));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.0470950839904387d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test42"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(79.5653545715429d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test43"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)8.033816814586373d, (java.lang.Number)3.1132389726050125d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test44"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    boolean var4 = var3.isSupportUpperBoundInclusive();
    double var5 = var3.getNumericalMean();
    double var6 = var3.getSupportLowerBound();
    boolean var7 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("1ba5fbde505b375f2f4da3f7b7a76a616d352dc6d5e5201754d9cf7062cd0d853abac052dbf16f31ac4cad4e9a31509259f74ff0074b5e2956e80f626fee6838272814a725121f5eb3448f88ac6f6488c586425c33629dd4734113b9cdc4d571db23fef2daa8ca9b900d00365dcf65c5d975d12887ccd261e486184a8ee4462979df8ba25f93cff994c9ede6c9ce3b1364bb679afdfe0c35276e0fc77d6706ba12a253fa7c739c18b26f9857a04276d23d122523c28719f6d30bf6569807007ce8f61fd0fb8ee71341d4d0693d21b3953bfaff8b3ffedb943e312557767787af05d10f11aea063fc4e5bc98e9ed971510930209846e89ebf306036cb3985a647b6b962acd130f60da3e8f008a4b2d49774a1ce68f61c5a73e9efe3ac5109e89d17aea20160feaa67e1697bd3d0c80fc07550bb38d2220978c964fa89bddebe945a8929bac40929c9dd7bef71b29fe8b1ca10d20efd9a97c1db60d1d550dc9517e45418eb5f716b4eed0322cfdb96abc64f7282988dd0f499095c2e75c5eb2e345a7efef9aac20e7508bdf45f158368a8d0a5e16dcdcb35c105f4635ff72dd212ebe6f21e0dac4e9b7f41c1c4094485b97f3ee29e2718b56e0793e44fd1ba655530175f019b844149e6382286f878944b820ab094a95c8605321657dd37afd687ca24dce39590549284cc74713a965c34ba6b32cad57201b12217bd14a9f4d9945bfd90093def8aadea161a99842d8473ed888b294fc039851025b73843f794bb0d28eaa0db977916f3e4576d72e00b5d01ee4a6d57466f5fc18410ace00cd0353b9348141868f8b7458cd07e32e48707fffb536524b5742a2f283ff05952506828e194552106757fe443decf700fb40f87754de06d5f4db1e4b7c0", "a3ad55ba789c44653d5d5116871df2de220c78d5e8f730161754b4d39f9982a6f0f325ec2c81687c3553487e035c641342f0a");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.41675221519412836d);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test46"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(751, (-144705876426790031L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test47"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var0.setExpansionFactor(100.0f);
    int var6 = var0.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test48"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(7.516125731000207d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.7568024953079281d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.013208695330432282d));

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     double var11 = var0.nextT(0.007748145938530172d);
//     double var14 = var0.nextGamma(3.0623483795315067d, 1.0001683942492827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3095305122016874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.022138664342771914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.346303882324496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.7830471997385823E34d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.213819765354574d);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeedSecure();
//     long var18 = var0.nextLong(3L, 18L);
//     double var20 = var0.nextT(0.7316474682224907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.337520748342898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.016202209945442483d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.277605418661542d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.555515029090211d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.8826632846165132d);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test53"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var11.setContractionCriteria(1024.0f);
    var11.setElement(0, 3.0000000000000004d);
    float var17 = var11.getContractionCriteria();
    boolean var19 = var11.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = var11.copy();
    double[] var23 = new double[] { 100.0d, 0.0d};
    var11.addElements(var23);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    boolean var26 = var0.equals((java.lang.Object)var23);
    float var27 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.5f);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test54"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.4665531328750507d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(3.2049838556295356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 183.63204833513834d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.0000000000379432d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7182818285621857d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test57"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.215653939400476d, 3.347298099822646d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6021412357545937d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test58"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, (-17));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.6293945E-4f);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test59"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.2245129522199552d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2245129522199552d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test60"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(291729791, 662);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test61"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.5061825189236513d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test62"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    int var4 = var0.getExpansionMode();
    double[] var5 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test63"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    java.lang.String var7 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test64"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(100.87002939710754d, 0.01985674547213255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9775970065495919d));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.3126332425372544E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3126332387677962E-4d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test66"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.setContractionCriteria(1024.0f);
    var3.setElement(0, 3.0000000000000004d);
    float var9 = var3.getContractionCriteria();
    boolean var11 = var3.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    double[] var15 = new double[] { 100.0d, 0.0d};
    var3.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    double[] var18 = var1.rank(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setElement(5, 0.3845071169264922d);
    int var23 = var19.getExpansionMode();
    double var25 = var19.addElementRolling(5.410633957762126d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test67"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test68"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    var5.addSuppressed((java.lang.Throwable)var9);
    boolean var11 = var5.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var5.getContext();
    java.lang.Number var14 = var5.getArgument();
    java.lang.Throwable[] var15 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test69"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)0.47712125471966244d, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     java.lang.Object[] var15 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var12, (java.lang.Number)3.233351086493488d, var15);
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, var15);
//     java.lang.Object[] var18 = new java.lang.Object[] { var11};
//     org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var10, var18);
//     org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, (java.lang.Number)1.1749304202020776d, var18);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var18);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var18);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test70"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(7.629395E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-17));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test71"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var4 = var2.inverseCumulativeProbability(0.0d);
    double var6 = var2.probability(0.7316474682224906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test72"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-1.5114751022172106d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test73"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-10.711234508240691d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.477706240770957d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test74"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 10100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     var0.reSeedSecure(545642504737558400L);
//     int var18 = var0.nextPascal(127, 0.5320169063293507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3569341577596736d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0726310930754699d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 93);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test76"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.1093108789247763d, (java.lang.Number)0.99999994f, false);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test77"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.83119038428777d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test78"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 4.86927073907222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test79"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(5.0191180244969094E-6d, 4.6220390880797995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.0191180244969094E-6d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test80"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.0916297253956488d), (-0.98028680545127d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.984559915656705d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test81"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(919965907, (-10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 919965907);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test82"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1024.0001f, 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test83"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.337520748342898d, 128270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test84"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.023807852794796608d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test85"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test86"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("9a3054b1");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test87"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 4064528);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test88"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)8.590595999805713E106d, (java.lang.Number)0.99764962345751d, (java.lang.Number)4975.561694056367d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test89"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1195, (-13));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1195);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test90"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.3027476538919007d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.97558824312578d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test91"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(20L, 1794L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1794L);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test92"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1837L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1837L);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test93"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(456L, 6937L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6481L));

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test94"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.8189894E-12f, (-10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7763568E-15f);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test95"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-1.0d), 0.9999999999999919d, 2.993222846126381d, 1073);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test96"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(98.89025936182746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1154275644726788d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.469859050413197d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4973568757822817d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test98"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1531225969699204352L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test99"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-144705876426790031L), 6937L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextUniform(0.0d, 0.7316474682224906d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextSecureInt(2, (-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1748206436455586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.5238801186327837d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-523.2082682813844d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4820763968402444d);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test101"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-127), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test102"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.7297716605398856d, (java.lang.Number)99.76434593142625d, false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 99.76434593142625d+ "'", var5.equals(99.76434593142625d));

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test103"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test104"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.1444428812273078d, (-0.005771153194535552d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test105"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test106"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(8.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test107"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test108"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(7.6293945E-4f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.820766E-11f);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test109"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-14.653632351686364d), 3.2118528414560354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test110"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.0653404632565278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3877787807814457E-17d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test111"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var11 = var10.getContractionCriteria();
    var10.setNumElements(1195);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var23.setContractionCriteria(1024.0f);
    var23.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    org.apache.commons.math3.distribution.NormalDistribution var31 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var32 = var31.isSupportConnected();
    double[] var34 = var31.sample(127);
    var23.addElements(var34);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
    double[] var37 = var22.rank(var34);
    var10.addElements(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextUniform(0.0d, 0.7316474682224906d);
//     int var18 = var0.nextZipf(751, 0.21400263603676362d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.057912223393073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.03915048017514179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-118.79542840366751d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.12298977526892457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 321);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test113"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardMostRecentElements(919965907);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test114"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-127353.53036079442d), 0.4730946691978376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test115"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var5 = var2.cumulativeProbability(Double.NaN);
//     double var6 = var2.sample();
//     double var7 = var2.getMean();
//     double var8 = var2.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 99.71436561992991d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test116"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     java.lang.String var16 = var0.nextSecureHexString(16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3379265410482173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.00929392015692091d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0008905179136072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.2561593054129965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "37d468ca831081c7"+ "'", var16.equals("37d468ca831081c7"));
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test117"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)7.6293945E-6f, (java.lang.Number)(-10.118903838959886d), false);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test118"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(8);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test119"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(9.569347564413189E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999995421379709d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2.954874930442047d, 3.1604400618552324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.326623075694761d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.022508601831614856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9997466921166627d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test122"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.02172004731721395d), (java.lang.Number)(-0.022147517156860363d), true);
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)3.305530002646725d, false);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var10);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var12, (java.lang.Number)(-0.9610045870274099d), (java.lang.Number)0.3591731072391348d, (java.lang.Number)(-7.113883993924793d));
    var10.addSuppressed((java.lang.Throwable)var16);
    var4.addSuppressed((java.lang.Throwable)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 3.305530002646725d+ "'", var9.equals(3.305530002646725d));

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test123"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     java.lang.String var13 = var0.nextHexString(1025);
//     java.lang.String var15 = var0.nextSecureHexString(8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextUniform(32.0d, (-2.1680794060836064d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004677201572965155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0313458230076727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6417520535807888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "b449837cd257a54551e7af0cea607f7a6a7a62554e49e6a90eaac0a90b266adad49750fac4725f7ed384910e01b89985b564a799dbbed1bba2d16aa07e91feb62dc36f5aa1bfa6b945f95038e9928a1a5d298a0483be0319bd28c82b97af09bec1b7b3835f0985a14c9942103d86e825845e118925b37f8c78c93e9400840adc4a71a2b69b49691c733ee5bc4c239d50cee6650c7859008f1f8ed9bcd5f9a836975a91eeb452533db8e095b7ccc41f13234dc560e9c71f5d36c4b6eda196d6a8c59eac7a7cf5283d7276291726f28671f0d6b3bdec80159470f74af6ee924d574e33666c0160fa4836e3650a45db16fdab936d041df2034814c57f1bc77eac9a4e199c889282dd25593d1857c01e93964c4d15deba800436f3a84bebd397f98a90e5751a38b2a8ff2ba155a2aac9ea7d3826fb39569383cafe536d179475f156682aeab6c37fab47b505020afcf1b1c46da500e91486f59c13158f4cc42e9c0de27e3db4c1c7450596dfb475b2fb729e71e7511cd1f5173fd430131a9a391b925613b62a4475f92e887462d32146bda7da91a259f1b20143424150e8c8bf6c50dd7f7d6d29593b318a68b07ffd3ebcbf38b967550a21ea41bf3815aab309ca384117e0293be0abdf8113ac136015adacbcebf10a74e6f776180e014ff63c68f19a31633255a4b55e136aad47f5258b31905f1ea47bf783daa37e563471c04446f"+ "'", var13.equals("b449837cd257a54551e7af0cea607f7a6a7a62554e49e6a90eaac0a90b266adad49750fac4725f7ed384910e01b89985b564a799dbbed1bba2d16aa07e91feb62dc36f5aa1bfa6b945f95038e9928a1a5d298a0483be0319bd28c82b97af09bec1b7b3835f0985a14c9942103d86e825845e118925b37f8c78c93e9400840adc4a71a2b69b49691c733ee5bc4c239d50cee6650c7859008f1f8ed9bcd5f9a836975a91eeb452533db8e095b7ccc41f13234dc560e9c71f5d36c4b6eda196d6a8c59eac7a7cf5283d7276291726f28671f0d6b3bdec80159470f74af6ee924d574e33666c0160fa4836e3650a45db16fdab936d041df2034814c57f1bc77eac9a4e199c889282dd25593d1857c01e93964c4d15deba800436f3a84bebd397f98a90e5751a38b2a8ff2ba155a2aac9ea7d3826fb39569383cafe536d179475f156682aeab6c37fab47b505020afcf1b1c46da500e91486f59c13158f4cc42e9c0de27e3db4c1c7450596dfb475b2fb729e71e7511cd1f5173fd430131a9a391b925613b62a4475f92e887462d32146bda7da91a259f1b20143424150e8c8bf6c50dd7f7d6d29593b318a68b07ffd3ebcbf38b967550a21ea41bf3815aab309ca384117e0293be0abdf8113ac136015adacbcebf10a74e6f776180e014ff63c68f19a31633255a4b55e136aad47f5258b31905f1ea47bf783daa37e563471c04446f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "4d6cbc24"+ "'", var15.equals("4d6cbc24"));
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test124"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    int var4 = var0.getExpansionMode();
    double[] var5 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    boolean var14 = var6.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var6.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var16);
    float var18 = var16.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(3.4496806839002896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3032372470426154d));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test126"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-10));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-645.5247180070609d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5692472006775318d));

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test129"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)10100, (java.lang.Number)3.233351086493488d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test130"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    int var5 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test131"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1010, 98822);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test132"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-2106148007), 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-785605799));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.014818296952278905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.014819381657606202d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.49983239787941475d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5234052561490371d));

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test135"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var4.setContractionCriteria(1024.0f);
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var4);
    float var9 = var0.getContractionCriteria();
    float var10 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test136"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(670, (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test137"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.004997851075629565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test138"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(4.000000000000001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.5453090700369303E-9d, 0.005782818123521263d, 0.0d, 16);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test140"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1179);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1179);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test141"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 98.67130165541344d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test142"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(5832L);
//     double var8 = var0.nextGamma(45.24030222698074d, 100.77847174078188d);
//     var0.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4975.561694056367d);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test143"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-56L), 19L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-75L));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test144"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(3.137998624157977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05476840791460877d);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextGaussian(0.0d, (-638.3703397929479d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4022012673016025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.5729487118660999d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "5942ddfa59feb198b55e0f2afd0cf5288db77985873b457ca9eb157adf6a488d29410f0dbf5610706e81412bfeb5427cbf2c05d11293749438d1fb6f690cd279332792ab99d004bea8baceec3c7e25a3ee3587fe841d7b2da6adceb74f85bc4cfb377d5e976d612899116e2312bc9c51dbe817eefe7dd2d6e9f55e11a53dd3c20e1bfb6255df947610da9596bdc82df1e4502b8c3684c8c1f27ab8302d323746a996bda66aa71fa8fe44b65198f7555683732b01a203cdf2f5d8fce2265e4f05bc8f6cfab39184db14c5cc87b2499e24bfe78c703dd449cef5b657ddaf9ca7664ae47e9f5b315feb82b42cb1dabca3ebd438ee3aa7e42c73b0a60db8d099b5d393fb79a19b0c8353cb6d5368786264a7bfdf2c634613f75057715507cfecaed6e9b35a9b4855b3f8a6c9dcb935fd465588acfc4b1957f42c960b9d4cb747aaa528a2b7da59e5b0bb9c965568a9eba8dfaee59f3189b2f14666f60a5d90ab182330fcab7a4b96dd34c9bfcf271efef1620ec5ebd256ffb1960229f91ec0eb44aa9d2562784ba5a422735dd3f3c6c02a7841e73e38f1cce96ee0cf97cd9eee61ce747f90eda021a69a40867702ad0117c5dc3582017b77ea7e25d51d2f42f492521bc27a3dcbe90ab33d80bb45e5aa2e9952b8d6dcc111d225fb830c8ca2b0b2eaa11dd6f27d345f3aacffcc219a938dcb5a50dfa742f48f1188db84a3185463d4ecfe415d07947b3d48ee7c21b242cdc3b455c891fb4defa6583981df55614da698c25d83a85cf5e8beb54d011e2c4f3dd7764f97de7f482673ccc3ebc0447ce7534f155f265bd1922b2d080abb02bc5402e7140bc4a1445b6f42f60234f7fae7d2543fec5ce8c81431aecf7cb2d2c52eb2ef75f44a533f1e109564"+ "'", var13.equals("5942ddfa59feb198b55e0f2afd0cf5288db77985873b457ca9eb157adf6a488d29410f0dbf5610706e81412bfeb5427cbf2c05d11293749438d1fb6f690cd279332792ab99d004bea8baceec3c7e25a3ee3587fe841d7b2da6adceb74f85bc4cfb377d5e976d612899116e2312bc9c51dbe817eefe7dd2d6e9f55e11a53dd3c20e1bfb6255df947610da9596bdc82df1e4502b8c3684c8c1f27ab8302d323746a996bda66aa71fa8fe44b65198f7555683732b01a203cdf2f5d8fce2265e4f05bc8f6cfab39184db14c5cc87b2499e24bfe78c703dd449cef5b657ddaf9ca7664ae47e9f5b315feb82b42cb1dabca3ebd438ee3aa7e42c73b0a60db8d099b5d393fb79a19b0c8353cb6d5368786264a7bfdf2c634613f75057715507cfecaed6e9b35a9b4855b3f8a6c9dcb935fd465588acfc4b1957f42c960b9d4cb747aaa528a2b7da59e5b0bb9c965568a9eba8dfaee59f3189b2f14666f60a5d90ab182330fcab7a4b96dd34c9bfcf271efef1620ec5ebd256ffb1960229f91ec0eb44aa9d2562784ba5a422735dd3f3c6c02a7841e73e38f1cce96ee0cf97cd9eee61ce747f90eda021a69a40867702ad0117c5dc3582017b77ea7e25d51d2f42f492521bc27a3dcbe90ab33d80bb45e5aa2e9952b8d6dcc111d225fb830c8ca2b0b2eaa11dd6f27d345f3aacffcc219a938dcb5a50dfa742f48f1188db84a3185463d4ecfe415d07947b3d48ee7c21b242cdc3b455c891fb4defa6583981df55614da698c25d83a85cf5e8beb54d011e2c4f3dd7764f97de7f482673ccc3ebc0447ce7534f155f265bd1922b2d080abb02bc5402e7140bc4a1445b6f42f60234f7fae7d2543fec5ce8c81431aecf7cb2d2c52eb2ef75f44a533f1e109564"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 7.256298928332558d);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test146"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var9 = var8.getElements();
    int var10 = var8.getExpansionMode();
    float var11 = var8.getExpansionFactor();
    var8.setElement(127, 3.1936453631680304d);
    var8.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var8.copy();
    int var19 = var18.getNumElements();
    int var20 = var18.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var7, var18);
    int var22 = var7.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test147"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var7.nextF(1.166847979797118d, (-0.5063656411097588d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.2705174836714468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test148"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(321, (-144705876426790031L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test149"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(10, 10239145);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10239145);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test150"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, 3.334057105157501d, 3.8040919077431283d, 93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test151"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var0, var1, var2);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test152"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("37d468ca831081c7");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test153"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(27326631, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27326631);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     double var17 = var0.nextGamma(1.1844123836172259E-5d, 3.3788948268513095d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextSecureInt(919965907, 1073);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4214817518136367d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.025321882831935677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.299497472338786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6.911670032343197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test155"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 850355429512472704L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 8);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 80674L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test156"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0842022E-19f, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test157"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0922789888E13d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test158"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(99, 10239145);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test159"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var4 = var2.getSupportLowerBound();
//     double var5 = var2.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var7 = var2.sample(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 98.6287149508591d);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(2040.3837802863068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test161"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)3.3489254350599653d, (java.lang.Number)18L, false);
//     java.lang.Throwable[] var7 = var6.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     java.lang.Object[] var11 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var10, var11);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test162"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("687dd3253fb04958c9875563c0da7fe7f05a53ea7d6f7bdb9f0dfe8e66c5d818f6b5b60f0c6a1ef08cf05ad25373bec1aaf00861622db65fd227833ab9f1b08b32026bfb6ea58a2a9e4607bb64d1f3b610949daeb53b5dedf2ca827a0515656ce2231b47725c2aeb6449a900274a31ba0002bd5528971eabbf588954e27e6e932b045fb3e0457e8732a2c02d9200b5053b8dff8669ddd1e32d408c8326a2bf2f47975bc41c8c97cb00bb645281e2819792c1c1c0a6d50385fc51f63e9fe76830d96f1d781c3f4e844099d35b8434ab9b600a72c010af45d4a86be79253a886e6041e53dc66bb4577aadbdcbb4a11c022618857b1a1481361813b95479675f984796447be8eb7eaab423657c64ef70099919be619e1389dda04b8dc2310253421ee8d6bab67cae015e93142a060e8b64d4d4a781eff069122943225c1ef66b9208219f7ae81e3187458b1b053844e5cd9d2631f8bdafbe4c6de339094d9886893a2c84f946dbc422dc62b654d4e7541bae016e3b7344c56f48adea8dfe0729cbb5a81c0d849f2e5a10accee3ac0d3e7727ee9cfd454b3a1001bde46fd9440ae2cfaaafc24d72f1728c05cdbaae1972dc621443cf71a1b20e719b29d8237c70a6317a2cd464479e70372b1da054a6a990b951758aecf2060a4d73b0cc86b33807727b6e1ded1c70f9438b62742ec0670945fe4a8c2148513d554e04e8fa2b474c823e91dfc777e6e508ef3ce6b4f3ae49f374ec7960abe2d1e07f480a6835f772d4ae9367fe7146930b8cd646607abbf526264ceceee555b07800d978388554fb552e931b72ae43a5d788574a277b52eb845d176b50cf8ea46e29701d8570fd37d13c2a9d861b3a603a1437efec9d3f735e31f07242069abfdca2266", "37d468ca831081c7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004325538057366513d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7623058711007796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7883574154002931d);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test163"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(5.183028998081309d, 2.3932364423299792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9198781753124942d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test164"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(3.2132396021992005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 184.10506777030974d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test165"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(4.3368086899420177E-19d, 1.037803534264273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.769814382465272E-20d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test166"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.5769681036283701d, 1401359.6943629922d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5769681036283701d);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGamma(0.5769681036283701d, 6.232928512989213d);
//     long var6 = var1.nextPoisson(3.194723088062764d);
//     double var9 = var1.nextGaussian(0.1995641250475069d, 29.605465286259054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextSecureInt(1270, 1024);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.7977812430402755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 13.67888185493254d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.246534960233099d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(3.3166247903554003d, 1.412848953997996d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextSecureLong(1124L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4660240053192411d);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test170"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    int var4 = var0.getNumElements();
    int var5 = var0.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.8189894E-12f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test171"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(96L, 19L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 96L);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test172"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(129, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test173"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    java.lang.String var8 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var9);
    java.lang.Class var11 = var2.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test174"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.substituteMostRecentElement(1.8643992372211438d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test175"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.2207031E-4f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2207033E-4f);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test176"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.1952992143315761d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.21760154721811903d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test177"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = var1.getElements();
    int var3 = var1.getExpansionMode();
    float var4 = var1.getExpansionFactor();
    var1.setElement(127, 3.1936453631680304d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var10 = var9.getElements();
    int var11 = var9.getExpansionMode();
    float var12 = var9.getExpansionFactor();
    var9.setElement(127, 3.1936453631680304d);
    var9.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var9.copy();
    int var20 = var19.getNumElements();
    int var21 = var19.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var8, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test178"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.setContractionCriteria(1024.0f);
    var18.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var24.setContractionCriteria(1024.0f);
    var24.setElement(0, 3.0000000000000004d);
    float var30 = var24.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var18, var24);
    double[] var32 = var18.getInternalValues();
    var0.addElements(var32);
    double[] var34 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(10100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(5.026525695313479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test180"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.3466798807130602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9749908530486963d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test181"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 27.12061425361551d};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test182"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    var3.addSuppressed((java.lang.Throwable)var7);
    boolean var9 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var3.getContext();
    java.lang.Number var12 = var3.getArgument();
    java.lang.Throwable[] var13 = var3.getSuppressed();
    java.lang.Number var14 = var3.getMax();
    java.lang.Number var15 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1)+ "'", var12.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 3.233351086493488d+ "'", var14.equals(3.233351086493488d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 3.233351086493488d+ "'", var15.equals(3.233351086493488d));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test183"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(3748598005569525248L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3748598005569525248L);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test184"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     java.lang.String var11 = var0.nextHexString(127);
//     double var14 = var0.nextGamma((-0.022147517156860363d), 5.0191180244969094E-6d);
//     long var16 = var0.nextPoisson(3.239052890822646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.9737836962784687d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.8210807539321783d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-23.95915697465193d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "77eb160ee683d34d86cb919147341ce3731656d382904619a9e956ec2f3989644e9132892b5822097e34f2bbdd567212c4d3116fd2827715484b6b5b54bf507"+ "'", var11.equals("77eb160ee683d34d86cb919147341ce3731656d382904619a9e956ec2f3989644e9132892b5822097e34f2bbdd567212c4d3116fd2827715484b6b5b54bf507"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 9.911077798205748E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3L);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.5521977843425779d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5045290032551004d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test187"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    double[] var11 = var0.getElements();
    double[] var12 = var0.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    var13.contract();
    var13.setNumElements(762);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test188"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var8 = java.lang.Enum.<java.lang.Enum>valueOf(var6, "0e79d052373295d113e8b064e56b795379556db65668c4ad7747c18fad55047486926f7db230d4d8d611874b7f79221559172a064eed2d10fa6394c93536ae4");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test189"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.14550003380861354d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.1460183660255169d));

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test190"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(9223372036854775807L, 96L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.9737836962784687d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7534324315490821d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test192"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.0851300358994307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-12.192011680272092d));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test193"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)4.9E-324d);
    int var9 = var0.getExpansionMode();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test194"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test195"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2, (-27326631));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test196"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)98.89025936182746d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test197"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardFrontElements((-31393204));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test198"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    boolean var20 = var12.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var12.copy();
    double[] var24 = new double[] { 100.0d, 0.0d};
    var12.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var37 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var39 = var26.equals((java.lang.Object)var38);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var38);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var41 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var42.setContractionCriteria(1024.0f);
    var42.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
    org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var48.setContractionCriteria(1024.0f);
    var48.setElement(0, 3.0000000000000004d);
    float var54 = var48.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var42, var48);
    double[] var56 = var42.getInternalValues();
    var42.setElement(100, 27.12061425361551d);
    var42.contract();
    org.apache.commons.math3.distribution.NormalDistribution var63 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var64 = var63.isSupportConnected();
    boolean var65 = var63.isSupportConnected();
    double[] var67 = var63.sample(5);
    var42.addElements(var67);
    org.apache.commons.math3.util.ResizableDoubleArray var69 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var69.setContractionCriteria(1024.0f);
    var69.setElement(0, 3.0000000000000004d);
    float var75 = var69.getContractionCriteria();
    boolean var77 = var69.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var78 = var69.copy();
    double[] var79 = var69.getElements();
    double[] var80 = var69.getElements();
    double[] var81 = var69.getInternalValues();
    double var82 = var41.mannWhitneyUTest(var67, var81);
    var11.addElements(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 9.569347564413189E-4d);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test199"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test200"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(535514000795646456L, 45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test201"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841858E-7f);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     org.apache.commons.math3.distribution.NormalDistribution var15 = new org.apache.commons.math3.distribution.NormalDistribution(4.226139957689864d, 1.4632615084784795d, 4.394517941340612d);
//     double var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.011810325200376332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.0019184733637148d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.564999534280986d);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(4.346069909771813E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.11666398836735097d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test204"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(80674L, 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-9223372036854695133L));

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.0329713608269496E53d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 123.43965555664278d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test206"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.probability(0.007907055323073179d);
    double var6 = var2.getSupportUpperBound();
    double var8 = var2.probability(0.0d);
    double var9 = var2.getMean();
    boolean var10 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test207"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.probability(0.007907055323073179d);
    double var6 = var2.getStandardDeviation();
    double var7 = var2.getMean();
    boolean var8 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test208"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(762, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test209"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(29, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test210"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(3.6178058981865213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test211"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var5 = var2.cumulativeProbability(Double.NaN);
//     double var6 = var2.getSupportUpperBound();
//     double var7 = var2.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test212"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.0916297253956488d), 3.5288105345286316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test213"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1099, 27326631);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1099);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test214"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test215"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(130048, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 130048);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test216"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(321);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1535.4375192248224d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test217"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.0963506818711306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 62.81626693750576d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test218"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(93L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.3459244966620778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test220"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 2.5699328711844167d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test221"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1073);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(4.678155320865237d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5429038700189306d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test223"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(884124501032112248L, (-6481L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6481L));

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test224"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 27.12061425361551d};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, var3);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NotPositiveException var8 = new org.apache.commons.math3.exception.NotPositiveException(var6, (java.lang.Number)100L);
    boolean var9 = var8.getBoundIsAllowed();
    java.lang.Number var10 = var8.getArgument();
    var5.addSuppressed((java.lang.Throwable)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 100L+ "'", var10.equals(100L));

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test225"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var21 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var24);
//     java.lang.String var26 = var24.name();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.34386069837598404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.32636528176104257d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3950672760536102d));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test227"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.setContractionCriteria(1024.0f);
    var10.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var19 = var18.isSupportConnected();
    double[] var21 = var18.sample(127);
    var10.addElements(var21);
    double[] var23 = var9.rank(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.49680155820993377d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4595980351548252d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.7286806727681631d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 41.75032716236916d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test230"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 58L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, (-727379968));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test231"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(456L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test232"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 130048);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test233"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.5f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test234"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(751);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = var1.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test235"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.094947E-13f, 0.3836624416669226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.094948E-13f);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test236"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.4714877841868557d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test237"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1024, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test238"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(12.063722427580958d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var19 = var0.nextChiSquare(4.1495472005154115d);
//     int var22 = var0.nextZipf(130048, 3.3954865640363336d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextF((-0.11238141480796804d), (-1.0460227205454609d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.218300412708098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.02208584053170837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.523881154826105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.7594082682352425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 36L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.997219013841889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test240"); }
// 
// 
//     org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var0.setContractionCriteria(1024.0f);
//     var0.setExpansionFactor(10.0f);
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var9 = var8.isSupportConnected();
//     double[] var11 = var8.sample(127);
//     var0.addElements(var11);
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var17 = var14.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var19 = var14.nextT(0.47712125471966244d);
//     double var22 = var14.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var14.reSeed();
//     java.lang.String var25 = var14.nextHexString(127);
//     double var28 = var14.nextGamma((-0.022147517156860363d), 5.0191180244969094E-6d);
//     boolean var29 = var13.equals((java.lang.Object)5.0191180244969094E-6d);
//     org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var31 = var30.getElements();
//     int var32 = var30.getExpansionMode();
//     float var33 = var30.getExpansionFactor();
//     var30.setElement(127, 3.1936453631680304d);
//     var30.setElement(1024, 3.215874911574371d);
//     org.apache.commons.math3.util.ResizableDoubleArray var40 = var30.copy();
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var41.setContractionCriteria(1024.0f);
//     var41.setElement(0, 3.0000000000000004d);
//     float var47 = var41.getContractionCriteria();
//     boolean var49 = var41.equals((java.lang.Object)0.21400263603676362d);
//     org.apache.commons.math3.util.ResizableDoubleArray var50 = var41.copy();
//     double[] var53 = new double[] { 100.0d, 0.0d};
//     var41.addElements(var53);
//     org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var53);
//     boolean var56 = var30.equals((java.lang.Object)var53);
//     var13.addElements(var53);
//     var13.contract();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.2680301537493377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.06520344674258512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-96.50604730818554d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "ebed90d7f61005d7e2fe37ef3beacd28827ae8d1e63d63572f25ac21107028cc3ef9a2f500b394c6b7e580dd6705d72a5f245096663a7ef99da4dac5d67068c"+ "'", var25.equals("ebed90d7f61005d7e2fe37ef3beacd28827ae8d1e63d63572f25ac21107028cc3ef9a2f500b394c6b7e580dd6705d72a5f245096663a7ef99da4dac5d67068c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 7.400159832691739E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1024.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test241"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1107);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6656.83940678656d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test242"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.0f, 4.7689580620524925d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0000005f);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test243"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)3.2722646632737273d, (java.lang.Number)81188.39044958311d, false);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-5), 1073);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test245"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(7.629395E-6f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.629395E-6f);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test246"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9431910296713536d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Number var3 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0.9431910296713536d+ "'", var3.equals(0.9431910296713536d));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(100.22056007056258d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test248"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)919965907);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test249"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1099, 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test250"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)Double.NaN, (java.lang.Number)Double.NaN);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + Double.NaN+ "'", var6.equals(Double.NaN));

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test251"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 751);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test252"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-2.420567737873968d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.0d));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test253"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.7871088143391114d, var7);
    java.lang.Number var11 = var10.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0.7871088143391114d+ "'", var11.equals(0.7871088143391114d));

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test254"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1, 16L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test255"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(39.8253719986887d, 0.0037606833841678563d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 39.8253719986887d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test256"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(7.629395E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test257"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
//     boolean var6 = var4.equals((java.lang.Object)(short)10);
//     java.lang.Class var7 = var4.getDeclaringClass();
//     java.lang.Class var8 = var4.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var13 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var16);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var16);
//     java.lang.String var19 = var16.name();
//     java.lang.String var20 = var16.toString();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
//     double[] var22 = null;
//     org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var23.setContractionCriteria(1024.0f);
//     var23.setExpansionFactor(10.0f);
//     org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
//     org.apache.commons.math3.distribution.NormalDistribution var31 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var32 = var31.isSupportConnected();
//     double[] var34 = var31.sample(127);
//     var23.addElements(var34);
//     org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
//     org.apache.commons.math3.random.RandomDataImpl var37 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var40 = var37.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var42 = var37.nextT(0.47712125471966244d);
//     double var45 = var37.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var37.reSeed();
//     java.lang.String var48 = var37.nextHexString(127);
//     double var51 = var37.nextGamma((-0.022147517156860363d), 5.0191180244969094E-6d);
//     boolean var52 = var36.equals((java.lang.Object)5.0191180244969094E-6d);
//     org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var54 = var53.getElements();
//     int var55 = var53.getExpansionMode();
//     float var56 = var53.getExpansionFactor();
//     var53.setElement(127, 3.1936453631680304d);
//     var53.setElement(1024, 3.215874911574371d);
//     org.apache.commons.math3.util.ResizableDoubleArray var63 = var53.copy();
//     org.apache.commons.math3.util.ResizableDoubleArray var64 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var64.setContractionCriteria(1024.0f);
//     var64.setElement(0, 3.0000000000000004d);
//     float var70 = var64.getContractionCriteria();
//     boolean var72 = var64.equals((java.lang.Object)0.21400263603676362d);
//     org.apache.commons.math3.util.ResizableDoubleArray var73 = var64.copy();
//     double[] var76 = new double[] { 100.0d, 0.0d};
//     var64.addElements(var76);
//     org.apache.commons.math3.util.ResizableDoubleArray var78 = new org.apache.commons.math3.util.ResizableDoubleArray(var76);
//     boolean var79 = var53.equals((java.lang.Object)var76);
//     var36.addElements(var76);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var81 = var21.mannWhitneyU(var22, var76);
//       fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
//     } catch (org.apache.commons.math3.exception.NullArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 2.991598632535152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 9.174828707297126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == (-126.2895899479878d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "2c68308a08d8db3f7387c4c7a4c636ff2bd3558c7c14cbab6d12ff21d49b63867a74d5e890977b464450cb042cced3bbc9b7064221461c35fb3da2a3fc50c7b"+ "'", var48.equals("2c68308a08d8db3f7387c4c7a4c636ff2bd3558c7c14cbab6d12ff21d49b63867a74d5e890977b464450cb042cced3bbc9b7064221461c35fb3da2a3fc50c7b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 7.298627403918159E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 1024.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.4077945219161934d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9400763120828695d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.3580075104073004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8884379060286705d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test260"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(2.345946087254834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6246679930507074d);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGamma(0.5769681036283701d, 6.232928512989213d);
//     long var6 = var1.nextPoisson(3.194723088062764d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextZipf(0, 3.9434847900511714d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.7414206706453716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5L);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test262"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    double var4 = var3.getMean();
    double var7 = var3.cumulativeProbability(0.31456926834144955d, 3.230325591810731d);
    double var9 = var3.probability(3.577868738045182d);
    double var10 = var3.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.038157775941106545d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.NEGATIVE_INFINITY);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test263"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-2L), (-1843921677838435301L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3687843355676870602L);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test264"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-535514000795646456L), 383341803785389312L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test265"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    double var4 = var2.cumulativeProbability((-3.4657978658285428E-6d));
    double var5 = var2.getNumericalVariance();
    double var7 = var2.probability(27.567148453340938d);
    boolean var8 = var2.isSupportLowerBoundInclusive();
    boolean var9 = var2.isSupportConnected();
    boolean var10 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextExponential((-0.5234052561490371d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.339759629591686d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.169607443369915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 415.17758010212987d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1L));
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test267"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)3.305530002646725d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test268"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var22 = var21.isSupportConnected();
    boolean var23 = var21.isSupportConnected();
    double[] var25 = var21.sample(5);
    var0.addElements(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var29 = new double[] { 1.0d};
    var27.addElements(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
    var0.addElements(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var33.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
    double[] var38 = var33.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var33);
    int var40 = var33.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextWeibull(100.22056007056258d, 81188.39044958311d);
//     int var14 = var0.nextZipf(1, 10.140709416791422d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.357317247090617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4420311997281562d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 78021.47903283725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test270"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.4496806839002896d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test271"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.9610045870274099d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8258742358750042d));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test272"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(Double.POSITIVE_INFINITY, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test273"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.5574077246549023d));
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Object[] var13 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var10, (java.lang.Number)3.233351086493488d, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, var13);
    java.lang.Object[] var16 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var8, var16);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var7, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var16);
    org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, var5, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var16);
    org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError(var0, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     java.lang.String var11 = var0.nextHexString(127);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation(2083303935, 1025);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4235286423728977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.6001014450232648d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-540.6799670659595d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "31e8d48af40160104b6b934861e5634c5d4930dc2fca19a987a2678e4f79d583c851900ffbf2fa54d6800310250b7668de234c72ffb26aeae6054d8755bc1c5"+ "'", var11.equals("31e8d48af40160104b6b934861e5634c5d4930dc2fca19a987a2678e4f79d583c851900ffbf2fa54d6800310250b7668de234c72ffb26aeae6054d8755bc1c5"));
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test275"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2106148007), 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test276"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.6224247951349726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6224247951349728d);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeedSecure();
//     double var20 = var0.nextGamma(2.0574806988857035E105d, 41.752984630466926d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextZipf((-1), 6.686727934632684d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.05278033751155775d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.9248015869026303d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "1e27ab4c7e2169ae369413dea27e63b2528959cc26c7886b1dba2efa1ad33448b64918c2bbd311e94b1d2b5c0f2332b477ce4e9f462473319feb37afa07f155f51a07747aef62ee0074204270e29b93026520fedb7a8edf51edf60637f8a8cf5954045416016a4dec87bdb64d6e457d8af76c6a5ba17be52496b8890b0ae242074229b65c6a342da1d792a09fe012fb48cc79fb03ee0670da3edd21a0f78295294410dd72945659b7b4432c6da09d6ee2c67f3808969f371ed894cd784d70c6c374ddbfefddea15f77cf306b68475f90c2c2158aed406e623c9778fcb0c4cb2ca0cdcaf014216573802cae8b701cadcf47ef0fce4890f6fddbe982f3de168e5d59e0a35ca10b84cc76e009253bce2039a4908950edf819d336bcfc4b3c821682662b45ed12a6bdbf7ec5ca6c84497647c1a39d8729b5f1df11fffecd7073ad3b5ea3e94701fd7bbb68076101d61e7a3d59056b165aac4fa163eae5568037551f8c81349a3f056e3527976eada2a145815145b6047a63c4efbf4e1efe8c2a14ed8d664aedb62d560905bd95b8e26ced695df0810c9715e77df3c46dda264bdf6e790cab67643c0fd3c01fd1cd320c4fa6c656dcb08ba25b498fa4c762bdea56561faa25cf1283b49e885d85bc0ea84c1ab7b934b8d678fdaf834a2e60f830ce80cd28f8732193cd7c907ad3d1da00acd28330dea5e0e5c857390dbecb0bb17e1b08d7e2b661f2f5c3a0d3c0dc22fffad37b168149bdd3d46a514b4fbe1f182e5aa8d4ef5dace1840d0ac1d28ecb0370e922f168274077e1db0247d4f881219ab526216b46acb02e842cc48e4b197c57bfb1d15263a2abe689929a487a6f2c63bab9dc45ead5140e5c05245b7ab4b83e7afba83b9d916cd419576d73"+ "'", var13.equals("1e27ab4c7e2169ae369413dea27e63b2528959cc26c7886b1dba2efa1ad33448b64918c2bbd311e94b1d2b5c0f2332b477ce4e9f462473319feb37afa07f155f51a07747aef62ee0074204270e29b93026520fedb7a8edf51edf60637f8a8cf5954045416016a4dec87bdb64d6e457d8af76c6a5ba17be52496b8890b0ae242074229b65c6a342da1d792a09fe012fb48cc79fb03ee0670da3edd21a0f78295294410dd72945659b7b4432c6da09d6ee2c67f3808969f371ed894cd784d70c6c374ddbfefddea15f77cf306b68475f90c2c2158aed406e623c9778fcb0c4cb2ca0cdcaf014216573802cae8b701cadcf47ef0fce4890f6fddbe982f3de168e5d59e0a35ca10b84cc76e009253bce2039a4908950edf819d336bcfc4b3c821682662b45ed12a6bdbf7ec5ca6c84497647c1a39d8729b5f1df11fffecd7073ad3b5ea3e94701fd7bbb68076101d61e7a3d59056b165aac4fa163eae5568037551f8c81349a3f056e3527976eada2a145815145b6047a63c4efbf4e1efe8c2a14ed8d664aedb62d560905bd95b8e26ced695df0810c9715e77df3c46dda264bdf6e790cab67643c0fd3c01fd1cd320c4fa6c656dcb08ba25b498fa4c762bdea56561faa25cf1283b49e885d85bc0ea84c1ab7b934b8d678fdaf834a2e60f830ce80cd28f8732193cd7c907ad3d1da00acd28330dea5e0e5c857390dbecb0bb17e1b08d7e2b661f2f5c3a0d3c0dc22fffad37b168149bdd3d46a514b4fbe1f182e5aa8d4ef5dace1840d0ac1d28ecb0370e922f168274077e1db0247d4f881219ab526216b46acb02e842cc48e4b197c57bfb1d15263a2abe689929a487a6f2c63bab9dc45ead5140e5c05245b7ab4b83e7afba83b9d916cd419576d73"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.46195725546793925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 8.590595999805713E106d);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test278"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Throwable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException(var4, (java.lang.Number)13.801711757320268d);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test280"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     double var14 = var0.nextWeibull(0.9999999999999919d, 4.5359460963350345E52d);
//     long var17 = var0.nextLong(24L, 96L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004167582076964242d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.591224861358376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7099776159634059d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.637530384417789E51d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 59L);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeedSecure();
//     double var20 = var0.nextGamma(2.0574806988857035E105d, 41.752984630466926d);
//     java.util.Collection var21 = null;
//     java.lang.Object[] var23 = var0.nextSample(var21, 4);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test282"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), (-20332865));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test283"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(59L, 42L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 17L);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test284"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    var0.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.setContractionCriteria(1024.0f);
    var18.setElement(0, 3.0000000000000004d);
    float var24 = var18.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var12, var18);
    double[] var26 = var12.getInternalValues();
    var12.setElement(100, 27.12061425361551d);
    var12.contract();
    org.apache.commons.math3.distribution.NormalDistribution var33 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var34 = var33.isSupportConnected();
    boolean var35 = var33.isSupportConnected();
    double[] var37 = var33.sample(5);
    var12.addElements(var37);
    var0.addElements(var37);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.distribution.NormalDistribution var43 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var44 = var43.isSupportConnected();
    double[] var46 = var43.sample(127);
    double[] var48 = new double[] { 10.0d};
    double var49 = var40.mannWhitneyU(var46, var48);
    var0.addElements(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 127.0d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test285"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.6321205588285577d), 3.3900553644082354d, 3.2132396021992005d);
    boolean var4 = var3.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test286"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportConnected();
//     double var7 = var2.getNumericalVariance();
//     double var9 = var2.probability(6.441186357863409d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.57860120573436d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test287"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)1.0f, (java.lang.Number)var5, false);
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 58L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 2);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 850355429512472704L);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 8);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var20);
    java.math.BigInteger var22 = null;
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 58L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var24);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 56L);
    org.apache.commons.math3.exception.util.Localizable var30 = null;
    java.math.BigInteger var32 = null;
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 0L);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var34, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var38 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var30, (java.lang.Number)1.0f, (java.lang.Number)var34, false);
    java.math.BigInteger var39 = null;
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 0L);
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, 58L);
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var41, 2);
    java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 850355429512472704L);
    java.math.BigInteger var49 = org.apache.commons.math3.util.ArithmeticUtils.pow(var47, 8);
    java.math.BigInteger var50 = org.apache.commons.math3.util.ArithmeticUtils.pow(var34, var49);
    java.math.BigInteger var51 = null;
    java.math.BigInteger var53 = org.apache.commons.math3.util.ArithmeticUtils.pow(var51, 0L);
    java.math.BigInteger var55 = org.apache.commons.math3.util.ArithmeticUtils.pow(var53, 58L);
    java.math.BigInteger var56 = org.apache.commons.math3.util.ArithmeticUtils.pow(var49, var53);
    org.apache.commons.math3.exception.NumberIsTooSmallException var58 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)var29, (java.lang.Number)var49, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test288"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    boolean var7 = var0.equals((java.lang.Object)3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria((-0.49999997f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test289"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(7.629395E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test290"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.7488710927029982d, 1.3376070089627754d);
    double var3 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.NEGATIVE_INFINITY);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test291"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test292"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    double[] var11 = var0.getElements();
    double[] var12 = var0.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    var13.contract();
    var13.setElement(4066573, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test293"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(762, (-56L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test294"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(101.72275192089097d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test295"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-31393204));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test296"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.7763568E-15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7763568E-15f);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test297"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.233351086493488d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.1377077104187023d, (java.lang.Number)0L, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0L+ "'", var6.equals(0L));

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test299"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.28680180181229414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.33216015558007217d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(4.632543379969219d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.667016243379964d);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test301"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 42L);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test302"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.7488710927029982d, (java.lang.Number)20L, false);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextGaussian(3.3142072789405845d, 0.1995641250475069d);
//     java.lang.String var10 = var0.nextSecureHexString(5);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.335772310426724d);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test305"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(8.72051698654943d, 99.0489000519552d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.444353738085465E93d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test306"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0, (-20332865));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test307"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test308"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    double var6 = var2.getNumericalMean();
    double var7 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test309"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)58L);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test310"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.2132396021992005d, 0.8390715290764524d);
    boolean var3 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test311"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    float var1 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test312"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, 39L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 39L);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test313"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(3.442523153288516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 30.26574700072199d);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test314"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 58L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 2);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 850355429512472704L);
//     java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
//     java.math.BigInteger var12 = null;
//     java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 58L);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 2);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var14);
//     java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 155L);
//     java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 56L);
//     java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var23);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test315"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var3 = var2.getElements();
    int var4 = var2.getExpansionMode();
    int var5 = var2.start();
    var2.clear();
    java.lang.Object[] var7 = new java.lang.Object[] { var2};
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.020769319996080778d, var7);
    java.lang.Number var9 = var8.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.020769319996080778d+ "'", var9.equals(0.020769319996080778d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test316"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-351L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(7.219421939597738d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 413.6424076631011d);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test318"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var4 = var2.getSupportLowerBound();
//     double var5 = var2.sample();
//     double var7 = var2.inverseCumulativeProbability(0.1635534192908262d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 101.3970117354133d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 99.0200419746827d);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test319"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(7.629395E-5f, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test320"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test321"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(45.24030222698074d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 46.0d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.03915048017514179d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1978648027698251d);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test323"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test324"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.4802139752840215d, 3.3213905690642505d, 4.583731940621995d, 762);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7919764730028226d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test325"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test326"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(0, (-0.49999997f), 4.0000005f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test327"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)201.7156361224559d, var2, (java.lang.Number)5.286789518603281d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test328"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)3.233351086493488d, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, var6);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var6);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test329"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.098418460323332d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test330"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.Class var17 = var2.getDeclaringClass();
    org.apache.commons.math3.exception.NotPositiveException var19 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)100);
    boolean var20 = var19.getBoundIsAllowed();
    java.lang.Number var21 = var19.getArgument();
    boolean var22 = var2.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (short)100+ "'", var21.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test331"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3L);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test332"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
//     java.lang.Number var10 = var9.getLo();
//     var4.addSuppressed((java.lang.Throwable)var9);
//     org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test333"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test334"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.9951907593468033d), 0.14211423187667926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test335"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.2879738713425515d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooLargeException: 99 is larger than, or equal to, the maximum (1,024)", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2685148475471846d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1443599828069619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-158.4948843213567d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test337"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(5.026525695313479d, 3.4802139752840215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.026525695313479d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test338"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(5, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.5487448944692996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9182522458320695d));

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test340"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(919965907);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test341"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(127);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test342"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 1025);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test343"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.setSecureAlgorithm("9a3054b1", "80003bfa100420754a5c172b3d15d4baa86b452cbf24fe4ea70809cdcaff4223075c602f395e8523b824c6a9b35a2b114b88463623a999562736cec8407e3544398e0328c23d564599fdd005ef94b35b7673062aacf36e883c40760a3bc02da1c5b7da8fc21690e22c53ea74f8473e69a3e13b1b8b1f3117b08c6e8e818bab0c88585c7e66330363f68acb3725dc48203e3e38ae607394cf541fb3362dd7c2cddf776b1b03e194036da412600c94dec1202257fd85922c815f61cabdf030c33fc00cf29b662f080565904a16aedc3c5b23375370928ccb9e094e942a9bb02e6166866be02c38b8fcb54b6335e65ff3cbb0c229f5541010b57a6a19287f3d3d92a3be90e17f9d8ce051e13610c50713eb90212fbc77401f3fde79d48fef4f6082451fe39dfa58f2b5ce4624c39af1558807e0c71c349d12f4ed1d034fdea98edc2c1e41b513a90c8c73ea784a5048eacef99d36520b0e38931cdfeecc7d569789c697edbd8d95c5cd0cd5a2a760e3aa59187e7cbd293b996a55a09caebf8aea18f04dfa4f456de821d07fc282d8ff7ee030459bd794727d005be0ac5e3e2e7f1304a73e4ad926b5cfe40685814ef9f216111490fa7cd7aab05788dccb1c19d135304af9c2c32412902c7bf0f78f54c0f1a37d1485cc80ec2cc1f34b3e830397e6b6dea60714baac658ae09839ff443e834b25690a62e8624205a36d5adc7652364");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.06832163615582347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test344"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("090e33be2466e57a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test345"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.9434847900511714d, 0.5576973912328268d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.42559125097417d));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test346"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var10.setExpansionFactor(100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var9, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var9.getElement(10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test347"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)0, (java.lang.Number)98.78234435786233d, false);
    java.lang.Number var5 = var4.getMax();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 58L);
    java.lang.Number var12 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)var11, var12, false);
    var4.addSuppressed((java.lang.Throwable)var14);
    java.lang.Number var16 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 98.78234435786233d+ "'", var5.equals(98.78234435786233d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 98.78234435786233d+ "'", var16.equals(98.78234435786233d));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test348"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(101.3970117354133d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 101.3970117354133d);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test349"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     double var17 = var0.nextGamma(1.1844123836172259E-5d, 3.3788948268513095d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("687dd3253fb04958c9875563c0da7fe7f05a53ea7d6f7bdb9f0dfe8e66c5d818f6b5b60f0c6a1ef08cf05ad25373bec1aaf00861622db65fd227833ab9f1b08b32026bfb6ea58a2a9e4607bb64d1f3b610949daeb53b5dedf2ca827a0515656ce2231b47725c2aeb6449a900274a31ba0002bd5528971eabbf588954e27e6e932b045fb3e0457e8732a2c02d9200b5053b8dff8669ddd1e32d408c8326a2bf2f47975bc41c8c97cb00bb645281e2819792c1c1c0a6d50385fc51f63e9fe76830d96f1d781c3f4e844099d35b8434ab9b600a72c010af45d4a86be79253a886e6041e53dc66bb4577aadbdcbb4a11c022618857b1a1481361813b95479675f984796447be8eb7eaab423657c64ef70099919be619e1389dda04b8dc2310253421ee8d6bab67cae015e93142a060e8b64d4d4a781eff069122943225c1ef66b9208219f7ae81e3187458b1b053844e5cd9d2631f8bdafbe4c6de339094d9886893a2c84f946dbc422dc62b654d4e7541bae016e3b7344c56f48adea8dfe0729cbb5a81c0d849f2e5a10accee3ac0d3e7727ee9cfd454b3a1001bde46fd9440ae2cfaaafc24d72f1728c05cdbaae1972dc621443cf71a1b20e719b29d8237c70a6317a2cd464479e70372b1da054a6a990b951758aecf2060a4d73b0cc86b33807727b6e1ded1c70f9438b62742ec0670945fe4a8c2148513d554e04e8fa2b474c823e91dfc777e6e508ef3ce6b4f3ae49f374ec7960abe2d1e07f480a6835f772d4ae9367fe7146930b8cd646607abbf526264ceceee555b07800d978388554fb552e931b72ae43a5d788574a277b52eb845d176b50cf8ea46e29701d8570fd37d13c2a9d861b3a603a1437efec9d3f735e31f07242069abfdca2266", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1481177130495337d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.050736359277803934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.7325172795719443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.5067997053573405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test350"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(8.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test351"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2.642566250494787d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4220258841019385d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(8.590595999805713E106d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test353"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.311200623279588d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test354"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.8969546064642915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2553086822669244d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test355"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.7763568E-15f, 4.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7763568E-15f);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test356"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)9L);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test357"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.0d, (java.lang.Number)3.0000000000000004d, false);
    java.lang.Number var9 = var8.getMax();
    boolean var10 = var8.getBoundIsAllowed();
    boolean var11 = var2.equals((java.lang.Object)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 3.0000000000000004d+ "'", var9.equals(3.0000000000000004d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(5.744920421363131E-278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.744920421363131E-278d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test359"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.791508962278884d);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test360"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)100);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test361"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-7.255164963514517d), 0.9198781753124942d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7.255164963514516d));

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.5321218005364248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8793939982176235d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test363"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.587644237017741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2020236378673774d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test365"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.0309692022248409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1044.2268768183505d);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test366"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.8210807539321783d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test367"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(919965907, 1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var0.nextPermutation((-20332865), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.492768678109866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.008810171738416642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 141794364874516416L);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var12 = var0.nextUniform(5.652949755988041d, 79.5653545715429d, false);
//     org.apache.commons.math3.distribution.RealDistribution var13 = null;
//     double var14 = var0.nextInversionDeviate(var13);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test370"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-727379968), 4.0000005f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test371"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 130048);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test372"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
//     double var4 = var2.inverseCumulativeProbability(0.0d);
//     double var5 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.1870506156236346E52d));
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test373"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(884124501032112248L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test374"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("70bb9b01252f6f275a66ad08267fc726a22c273746d43115cc9aceda78850aa247458329ddf6ac64c125225b2e40875021d2368c823d123d05fccc3318e9647703c48b664f35a42b3be757b0a7945cf9d7209345ece04cf1edaa72d3a530cb68fef4a5de9fac2f05ae47ca5f6d94d7a8edb14a2d8a9e0e38e852e94917e44a810075727952989c4b4eef1a277a8f92f2d441895c442dfc3d2fa341432e140421dd2f76eb3a932cb115ae323fe3fdcb873927c8567e9f46a52ac4fc3c09f2b940940666019158c9c356d38f42f2ff902f390e1505eb63abecbe39bcdf9f380cde0486ed9c9c9c193027a49e11feab56edd582d8eb9027fc0f2d69b5eeb3f88d9b2dd113f426c66cd0ac2134786cce0e60f5b2815a91236a91a19a8783028674ff88763b2233dbf2b5976c91c57e78fd8ab8bc395ebb2e156c3fa75d41de798337ced26617fb83cc1700537084b51941f929f96c06a6ee08ea90fdc800eb58ad0e40f81f0e8caacc5577c677476d788e6cfe324babd910f52a208d174692a44f736764c3b33423292d97ab9f96683876be19e9d490eeb6bcf67cdc45a5729d98edf9943a34a146dce6e5f26210ec5a68764fff0dc6886d1a12ca1fd031254e724db281ba55138a2c450310c8961c3ce73ca81e6dfda55edbebec3d63c768842f6648d2220ce94f98204264706f68c55453718610891f9b68d9f86eea1b01e0f833c");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test376"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.getNumericalMean();
//     double var9 = var2.probability(12.063722427580958d);
//     double var11 = var2.cumulativeProbability(3.0623483795315067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 101.6850389965755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test377"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    var0.discardFrontElements(0);
    float var7 = var0.getContractionCriteria();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Object[] var15 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var12, (java.lang.Number)3.233351086493488d, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, var15);
    java.lang.Object[] var18 = new java.lang.Object[] { var11};
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var10, var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, var18);
    boolean var22 = var0.equals((java.lang.Object)var21);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var23.setContractionCriteria(1024.0f);
    var23.setElement(0, 3.0000000000000004d);
    float var29 = var23.getContractionCriteria();
    boolean var31 = var23.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var32 = var23.copy();
    double[] var35 = new double[] { 100.0d, 0.0d};
    var23.addElements(var35);
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    int var38 = var37.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var41 = var0.getElement(1099);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test378"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3.233351086493488d+ "'", var5.equals(3.233351086493488d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 3.233351086493488d+ "'", var6.equals(3.233351086493488d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 3.233351086493488d+ "'", var7.equals(3.233351086493488d));

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed(0L);
//     double var12 = var0.nextT(1.7534324315490821d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.00536992171734232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.8091093623830543d);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     double var11 = var0.nextChiSquare(3.1132389726050125d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextT((-0.6720442913294674d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.484207662263534d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01762768098481067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.259635749990726d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.2736128853135716d);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test381"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(99.0200419746827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010150131838024495d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test382"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2083303935), 762);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 762);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test383"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)99.4891568023885d, true);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test384"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.461707587098562d, 4.226139957689864d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7126814855251578d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test385"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var1, var2);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test386"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100+ "'", var6.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 100+ "'", var7.equals(100));

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test387"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5377404962722813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test388"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.0842022E-19f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test389"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.6720442913294674d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test390"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(9900, 10100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99990000);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test391"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)13.14778027539684d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)(-0.02172004731721395d), (java.lang.Number)(-0.022147517156860363d), true);
    var1.addSuppressed((java.lang.Throwable)var6);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test392"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    boolean var4 = var3.isSupportUpperBoundInclusive();
    double var5 = var3.getNumericalMean();
    double var6 = var3.getSupportLowerBound();
    double var7 = var3.getNumericalMean();
    boolean var8 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test393"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    double var8 = var0.substituteMostRecentElement(3.171384080773366d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.0000000000000004d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test394"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(4066573, 9.094948E-13f, 10.000001f, 4);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test395"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var12 = var0.getInternalValues();
    float var13 = var0.getExpansionFactor();
    var0.clear();
    var0.addElement(1.1015674805733365E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     double var10 = var0.nextGaussian(0.0d, 0.3970832209142864d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var0.nextPermutation(16, 1179);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.7081386520500382d));
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test397"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var2.inverseCumulativeProbability((-0.07612931540406859d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.71291064860327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test398"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test399"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var4 = var3.getElements();
//     int var5 = var3.getExpansionMode();
//     float var6 = var3.getExpansionFactor();
//     var3.setElement(127, 3.1936453631680304d);
//     var3.setElement(1024, 3.215874911574371d);
//     org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var16, var17);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var19 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var16, var25);
//     org.apache.commons.math3.random.RandomGenerator var27 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var27);
//     org.apache.commons.math3.distribution.NormalDistribution var31 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var32 = var31.isSupportConnected();
//     double[] var34 = var31.sample(127);
//     org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
//     double[] var36 = var28.rank(var34);
//     var3.addElements(var34);
//     org.apache.commons.math3.distribution.NormalDistribution var40 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var41 = var40.isSupportConnected();
//     boolean var42 = var40.isSupportConnected();
//     boolean var43 = var40.isSupportLowerBoundInclusive();
//     double[] var45 = var40.sample(1270);
//     double var46 = var2.mannWhitneyUTest(var34, var45);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test400"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var22 = var21.isSupportConnected();
    boolean var23 = var21.isSupportConnected();
    double[] var25 = var21.sample(5);
    var0.addElements(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var29 = new double[] { 1.0d};
    var27.addElements(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
    var0.addElements(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var34 = var33.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(1270);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var33, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test401"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1023));

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test402"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-13), 127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-140));

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test403"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.281783181607902d, var1, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getArgument();
    boolean var6 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.281783181607902d+ "'", var5.equals(2.281783181607902d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test404"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(7.6293945E-6f, 0.49999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.49999994f);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test405"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(8, 919965907);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test406"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1024, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1034);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test407"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("93f8d4250cbaae49901c80648dcf96d7cd93e5f8709466e0ce9d5de6e4fcf9192f937b9ddbef6bba6b505df5c5b1a880b8f5192b603e8ccd9c2db0f359977c7");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test408"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var12 = var11.isSupportConnected();
//     boolean var13 = var11.isSupportConnected();
//     double[] var15 = var11.sample(5);
//     double var16 = var11.getNumericalMean();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextSecureInt(5, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.003687931153928777d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.027358645889586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 99.29797653998682d);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("22", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1940015319094517d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0034539750644175544d);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test410"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)3.305530002646725d, false);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.305530002646725d+ "'", var4.equals(3.305530002646725d));

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test411"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(98.78234435786233d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7240771518835414d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test412"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.9380858908743853E-9d, 0.021788688782829028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1907310973016802d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test413"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.46350505080872756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4878509785248136d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test414"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)9900, (java.lang.Number)100.0d, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100.0d+ "'", var4.equals(100.0d));

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test415"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test416"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    double var4 = var3.getMean();
    double var5 = var3.getStandardDeviation();
    boolean var6 = var3.isSupportUpperBoundInclusive();
    double var7 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.17747447229466043d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test417"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var7.nextSecureInt(0, (-17));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.048115230513988d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test418"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(751, 4.0000005f, 1.7763568E-15f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test419"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.02240694992560174d, false);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test420"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.413804170012311d, 0.005168829664818467d, 0.0d, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     double var12 = var0.nextBeta(3.5480122537930616d, 3.5480122537930616d);
//     int var15 = var0.nextZipf(9, 0.38805925492513493d);
//     double var18 = var0.nextGaussian(0.8022140792099908d, 2.7182818285621857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4072408652311243d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.285466362193911d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.4476774222301757E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5199097191729691d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2.1256574851009358d);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test422"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var10.setExpansionFactor(100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var9, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var9.copy();
    double[] var18 = var17.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(3.6559346743185963d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test424"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var6 = var5.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.2536155909097118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8957348895940744d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test426"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(129, (-27326631));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test427"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, (-1843921677838435301L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test428"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.6104227919456581d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5444246445011277d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test429"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(7.629395E-6f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(5.7788687978395656E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.7788687E7d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test431"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1195);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test432"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-0.99999994f));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.022138664342771914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.022135048535245543d);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     double var10 = var0.nextGaussian(0.0d, 0.3970832209142864d);
//     var0.reSeed();
//     double var14 = var0.nextF(3.2132396021992005d, 2.0574806988857035E105d);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     double var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     double var20 = var0.nextChiSquare(6.232928512989213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.7081386520500382d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.622424794828497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 99.09793987313363d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 10.858348916882946d);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test435"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(14.014111025031722d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7763568394002505E-15d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test436"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test437"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("77eb160ee683d34d86cb919147341ce3731656d382904619a9e956ec2f3989644e9132892b5822097e34f2bbdd567212c4d3116fd2827715484b6b5b54bf507");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9968773290157855d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9984374437168237d);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     int var10 = var0.nextZipf(1, 0.38805925492513493d);
//     var0.reSeedSecure(45L);
//     double var15 = var0.nextGamma(3.230325591810731d, 3.215874911574371d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextPoisson((-1.5574077246549023d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 15.722689315548793d);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test440"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 40320L);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test441"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.9951907593468033d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.337216075685272d));

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test442"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1023), (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1023);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.9490176542425028d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.8218006731952756d));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test444"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.6102681742310754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test445"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)3.233351086493488d, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var2, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test446"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(20.774887498992896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.7263123566673326d);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test447"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 535514000795646464L);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test448"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10L, (-6481L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6491L);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test449"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     double var11 = var0.nextCauchy(0.5211415343642575d, 1.098418460323332d);
//     double var14 = var0.nextCauchy((-0.16320402005311493d), 2.010275321846272d);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var0.nextSample(var15, 99);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform(2.0917147927829527d, 1.0726310930754699d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2401585236467816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.871509423611952d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test451"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)0, (java.lang.Number)98.78234435786233d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.0d, (java.lang.Number)0.0f, true);
    var4.addSuppressed((java.lang.Throwable)var8);
    java.lang.String var10 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 3 is smaller than the minimum (0)"+ "'", var10.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 3 is smaller than the minimum (0)"));

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test452"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    int var19 = var0.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var0.getElement((-13));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 101);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test453"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-727379968));

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test454"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(535514000795646456L, 39L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test455"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1551199137, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1551199137);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test456"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     long var15 = var0.nextLong((-1L), 9223372036854775807L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextSecureLong(35L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.33758561035546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.0074976608992975875d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.40856775280716484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 7046575859791251456L);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test457"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    double[] var11 = var0.getElements();
    float var12 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test458"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(1179);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test459"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var3 = var2.getNumericalMean();
    double var4 = var2.getStandardDeviation();
    double var5 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.535946096335034E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test460"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.0d, 1.5118744235457728d, 29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test461"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    int var4 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var6 = var2.name();
    int var7 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test462"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(3.4802139752840215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test463"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(3.6559346743185963d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5650731921841152d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test464"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(100.67443225050037d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.652000253260331d);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test465"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.getStandardDeviation();
//     double var9 = var2.probability(0.0d);
//     double var10 = var2.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.7122747073287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test466"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(4975.561694056367d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.094947017729282E-13d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test467"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    double var20 = var0.addElementRolling(7.831124312758536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test468"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(2.33467759294052d, (-7.113883993924793d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test469"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-127), 7.1054274E-15f, 1.0f, (-13));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test470"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(127, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test471"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)100.7011985441339d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 58L);
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var2, (java.lang.Number)var7, var8, false);
    var1.addSuppressed((java.lang.Throwable)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test472"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(7.756711837645648d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test473"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.3836624416669226d, (java.lang.Number)1.4905488366463986d, (java.lang.Number)3.6408852451715354d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test474"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1107, 2083303935);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test475"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.005771153194535552d));

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test476"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(3.4497934339984417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999989323682928d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test477"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test478"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.7871088143391114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.357887982222818d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test479"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)3.233351086493488d, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var9);
    java.lang.Object[] var12 = new java.lang.Object[] { var5};
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var4, var12);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var12);
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var1, var12);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test480"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-0.49999994f), 8.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.49999994f);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test481"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.03915048017514179d, 3.1936828330503824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.03915048017514179d);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test482"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test483"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.7247032922278211d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6945826528851498d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test484"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test485"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test486"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(42L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 42L);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test487"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var2 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test488"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1L), (java.lang.Number)1.0f, false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0f+ "'", var4.equals(1.0f));

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test489"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(80596.80471926239d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test490"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.getStandardDeviation();
//     double var8 = var2.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.339804479383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test491"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.022405075367622047d, 4.283760323497615d);
//     double var3 = var2.sample();
//     double var4 = var2.getSupportUpperBound();
//     double var5 = var2.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.488745585512574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.283760323497615d);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test492"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.setContractionCriteria(1024.0f);
    var3.setElement(0, 3.0000000000000004d);
    float var9 = var3.getContractionCriteria();
    boolean var11 = var3.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    double[] var15 = new double[] { 100.0d, 0.0d};
    var3.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    double[] var18 = var1.rank(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var20.setContractionCriteria((-0.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test493"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     double var12 = var0.nextBeta(3.5480122537930616d, 3.5480122537930616d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("80003bfa100420754a5c172b3d15d4baa86b452cbf24fe4ea70809cdcaff4223075c602f395e8523b824c6a9b35a2b114b88463623a999562736cec8407e3544398e0328c23d564599fdd005ef94b35b7673062aacf36e883c40760a3bc02da1c5b7da8fc21690e22c53ea74f8473e69a3e13b1b8b1f3117b08c6e8e818bab0c88585c7e66330363f68acb3725dc48203e3e38ae607394cf541fb3362dd7c2cddf776b1b03e194036da412600c94dec1202257fd85922c815f61cabdf030c33fc00cf29b662f080565904a16aedc3c5b23375370928ccb9e094e942a9bb02e6166866be02c38b8fcb54b6335e65ff3cbb0c229f5541010b57a6a19287f3d3d92a3be90e17f9d8ce051e13610c50713eb90212fbc77401f3fde79d48fef4f6082451fe39dfa58f2b5ce4624c39af1558807e0c71c349d12f4ed1d034fdea98edc2c1e41b513a90c8c73ea784a5048eacef99d36520b0e38931cdfeecc7d569789c697edbd8d95c5cd0cd5a2a760e3aa59187e7cbd293b996a55a09caebf8aea18f04dfa4f456de821d07fc282d8ff7ee030459bd794727d005be0ac5e3e2e7f1304a73e4ad926b5cfe40685814ef9f216111490fa7cd7aab05788dccb1c19d135304af9c2c32412902c7bf0f78f54c0f1a37d1485cc80ec2cc1f34b3e830397e6b6dea60714baac658ae09839ff443e834b25690a62e8624205a36d5adc7652364", "org.apache.commons.math3.exception.NumberIsTooSmallException: 3 is smaller than the minimum (0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2212686998225917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.3876347744444804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.42844683206066714d);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test494"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeed();
//     double var18 = var0.nextF(0.014644560842127431d, 3.1444428812273078d);
//     int var22 = var0.nextHypergeometric(1195, 0, 93);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var0.nextInt(9900, (-20332865));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.292138340717519d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0307972560018069d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.3330971124738016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6.137265542014898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test495"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    int var9 = var6.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    boolean var16 = var14.equals((java.lang.Object)(short)10);
    java.lang.Class var17 = var14.getDeclaringClass();
    java.lang.Class var18 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var26);
    java.lang.String var29 = var26.name();
    java.lang.String var30 = var26.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var35.setContractionCriteria(1024.0f);
    var35.setElement(0, 3.0000000000000004d);
    float var41 = var35.getContractionCriteria();
    boolean var43 = var35.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var44 = var35.copy();
    double[] var45 = var35.getElements();
    double[] var46 = var35.getElements();
    double[] var47 = var35.getInternalValues();
    double[] var48 = var34.rank(var47);
    org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var48);
    org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var50.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray(var50);
    org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray(var50);
    org.apache.commons.math3.distribution.NormalDistribution var55 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var56 = var55.getMean();
    double[] var58 = var55.sample(12700);
    var50.addElements(var58);
    double var60 = var33.mannWhitneyUTest(var48, var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 4.404032694083071E-12d);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     double var12 = var0.nextBeta(3.5480122537930616d, 3.5480122537930616d);
//     int var15 = var0.nextZipf(9, 0.38805925492513493d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(1.791508962278884d, 1.1901655306023455d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.033581639457897d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.745084237580807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.1731604256882146E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.3704053863771745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test497"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.171384080773366d, (java.lang.Number)456L, false);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test498"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-20332865), 130048);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-20202817));

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test499"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    var0.clear();
    var0.setContractionCriteria(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test500"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.9997633029397283d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

}
