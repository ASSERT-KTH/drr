
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.3856829362664274d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(93L, 1124L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     double var11 = var0.nextCauchy(0.5211415343642575d, 1.098418460323332d);
//     int var14 = var0.nextInt(127, 1270);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var18 = var17.isSupportConnected();
//     double[] var20 = var17.sample(127);
//     double var21 = var17.getSupportLowerBound();
//     var17.reseedRandomGenerator(9223372036854775807L);
//     double var24 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var27 = var0.nextF(0.0d, (-589.6871983837793d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4243812281339854d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.5529284591565269d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-59.01946930187329d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.2471281810374024d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 998);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 97.19385573588546d);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-2083303935));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.577868738045182d, 37.994147737115796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1015674805733365E-13d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    double var6 = var2.getNumericalMean();
    double var8 = var2.inverseCumulativeProbability(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var10 = var2.sample((-8));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.485437011111235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4854370111112352d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.9499029663101612d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-19.406218909794774d));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(9, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, (-27326631));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27326631);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 437317876998765120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 437317876998765120L);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.31456926834144955d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3045882046997586d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 9.332621544395286E157d, 0.015347240909315647d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(5.983764724579021E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.92012974757845d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.5707963267948966d, 3.2201322996148285d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.45384402236258964d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-2.420567737873968d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9843276199673533d));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.2830087616199811d, 98.78234435786233d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2830087616199811d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.4579391968126888d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4928847159655941d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-8));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-2083303935), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2083303935));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.3751854960563317d, 1.4905488366463986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.03503312277121968d));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.7538814657117759d, (-17));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.751659131712158E-6d);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 101.32486090663886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(3.1589822179324365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3718497479906007d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode((-100));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    int var10 = var2.ordinal();
    java.lang.String var11 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     int[] var9 = var0.nextPermutation(1124, 10);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    int var17 = var14.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-100), 4064528);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(5.9604645E-8f, 751);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.1995641250475069d, 0.07902415835395639d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1995641250475069d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.2999483368158655d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2999483368158655d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.791759469228055d);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextPascal((-10), 4.283760323497615d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4466188395601276d);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3.8626412474598433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("e5567ab24438df853764a369c63dc5418bc2b932ca3251cfa77741e48e99c27eea62c91daf1a3b74792419ca510e10d5db61700b2afc0a1aef214730e86f1009eaa49359d95b178f162efeb341c6610844db73ef21dda09ed2f46db63af3c99e9e4c93112a72331c42efb5ac880b122750599c4c2cd6ce7240c16fe5f002d0a158b067a0fff97ad916887823bc3e91655441270360700e635ec1d6b0f4c093d0e3271e78cc80738ae2089d45cb4634ffcfd50d51a0d4db66325a92d9380b9c3a8b2706141f52481762888bead1d2f1f498b1383908b54077dfcfd35747ba094015b0f5b38a43baa2a402299d872c06f4f2962e197e749b7e4d816a9971c6c62fc839800f7b805a5bc70367d231dcd323037aa071bd8e774bef015f80f0c67622fadde6b102acff39c1fa08a98b68bf0abac07a37acc02c83248b6c6ce4031b6e0d57054ff66972219c1178d0f0af44a2a70ac31dff124eac07c4ec7efcdad0622e19f8badc1631b9c58f84c68d3eb942700ac1133944d007189c721c9766d2d898208821d365c4618a3898077956ffd3c66e2181b43059a87bf9eb3b2b4ea8823ce4015ffb2e6dedc2dbb7d2986fa1233aea68921d47b8e703e453e080f72ad0d39c63cd8c68f36c481d38c8f6330234775a8e31dba859e4dfeaac66f3b33a8911662bd0051613aab49a27b3c0e060069f6790aceb2931e9d66b4ed4d4d07ee4b636bbd4258d162c7a56fe00d8b4516e01f685c007c0b4cb86af6924a23ce26d23ab26b254b2ab6d3798cf66a41a98c0eb736a3fd3a0249c77c47a9a35f1283a83f8e1eaade6559420da8b5afc36631600581cc56e573fde5acd68bf1f817b9ad871672b19add3d49688f6fdadf61432275774881af7af0f236317");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.446743189812706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(3.2369140053717915d, (-527.8438038563128d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(5.0191180244969094E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.019118024539056E-6d);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var6 = var2.cumulativeProbability(6.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var8 = var2.sample((-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.63138038608729d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor((-0.49999994f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(3.3176882611728495d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3513259474452035d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(100.7011985441339d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.6220390880797995d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.0323416025546303d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(3);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     java.lang.String var13 = var0.nextHexString(1025);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "hi!");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.005414542257602141d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4145016566458487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6633491429562044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "ef9f3d3d0f9dce17b3384d510c149baa69b69dc41b59be445a8d057a4fa9c6f664c1f9297e0bf3bda5f19593f82a7b969f2015cc6d260e1d3cb9435f91b14832e5893925a2bba3cfc1c42514f70fb653813160ce4a5156667981fa0ee1d3105ea795c315461b44cef5102dde34a4ab6e22acbeff79adc36c25c1f5d44df4a0cd0489d137ac72648901837a53141f64c27e83db5eea9506ff3ac181485fd69880823019fe7d1678ea1405e8360202aab60d5f4ae3b79a1dd8684f337e3422c1b26509ebac53fbad7d1d1e2b7cdab0ad1c9fb2f3dac7e818761cd5aec85a53061a41971da04ac6845ebd813791cc444ea2522c4eeec46909043df0f45161545deae9f0044f01a6a8299f528a4742ebd17a75a3f3b83e2982de86e22c5cf8bfa4167ee3bf43fe6d5eeb9289c805b74f1023de69a22daec482b1e3efc5bcc3232f58644dc859732f568dacdb411e7ae294c7a1b22b6f9dc482a9105e2d86dd9ada6c4b1d927c1f7ecf68de918869bba18c3af7b1e786946dc1c3bdb722b9c1fa4189a200b5a568fe4072742c3d86aa098aa7877ef31e3bd01084d8707117f9c8f0167460b27d822488bddaf6a2ee8aa78b8a6eb3df9ccded7756ec99cdb7b336a8b3eba0a703a768266eaffd2f059d6a181039176d422556cbd532e2215d00b1d8851fd17172996445490d84bb0e835f4444b3ff245ad2756246b572862ba0d82904a"+ "'", var13.equals("ef9f3d3d0f9dce17b3384d510c149baa69b69dc41b59be445a8d057a4fa9c6f664c1f9297e0bf3bda5f19593f82a7b969f2015cc6d260e1d3cb9435f91b14832e5893925a2bba3cfc1c42514f70fb653813160ce4a5156667981fa0ee1d3105ea795c315461b44cef5102dde34a4ab6e22acbeff79adc36c25c1f5d44df4a0cd0489d137ac72648901837a53141f64c27e83db5eea9506ff3ac181485fd69880823019fe7d1678ea1405e8360202aab60d5f4ae3b79a1dd8684f337e3422c1b26509ebac53fbad7d1d1e2b7cdab0ad1c9fb2f3dac7e818761cd5aec85a53061a41971da04ac6845ebd813791cc444ea2522c4eeec46909043df0f45161545deae9f0044f01a6a8299f528a4742ebd17a75a3f3b83e2982de86e22c5cf8bfa4167ee3bf43fe6d5eeb9289c805b74f1023de69a22daec482b1e3efc5bcc3232f58644dc859732f568dacdb411e7ae294c7a1b22b6f9dc482a9105e2d86dd9ada6c4b1d927c1f7ecf68de918869bba18c3af7b1e786946dc1c3bdb722b9c1fa4189a200b5a568fe4072742c3d86aa098aa7877ef31e3bd01084d8707117f9c8f0167460b27d822488bddaf6a2ee8aa78b8a6eb3df9ccded7756ec99cdb7b336a8b3eba0a703a768266eaffd2f059d6a181039176d422556cbd532e2215d00b1d8851fd17172996445490d84bb0e835f4444b3ff245ad2756246b572862ba0d82904a"));
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.32964908430422d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.7081386520500382d), 0.446743189812706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7081386520500381d));

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    var0.addElement(2.281783181607902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(5.983764724579021E-4d, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.009574023559326433d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.003920326239751834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-127353.53036079442d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127353.0d));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    var0.contract();
    double[] var12 = var0.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.1472677414926801d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14674055198112168d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.6104227919456581d, 4.099334543506968d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14782158757850195d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(850355429512472704L, 18L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-727379968));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2, 27326631);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.0309692022248409d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10.0d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.7436204767426449d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 42.60631487685974d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    var0.clear();
    float var5 = var0.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.2207031E-4f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1270, 4064528);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4064528);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.010942683132023883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(1.1015674805733365E-13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0078125f, 9.094947E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.094947E-13f);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(8, 1099);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1107);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(42.913215810535064d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.105427357601002E-15d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var6 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    var0.discardMostRecentElements(1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    java.lang.Enum var8 = java.lang.Enum.<java.lang.Enum>valueOf(var6, "MAXIMAL");
    java.lang.String var9 = var8.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1024.0f, 1024.0001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "");
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(506.84313389487073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.578793360216593E219d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0126600184580075E213d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var0.copy();
    float var4 = var0.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(1.2207031E-4f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements(12700);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    double[] var4 = var2.sample(99);
    boolean var5 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.014644560842127431d, 42.913215810535064d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.02172004731721395d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.469446951953614E-18d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(8.193092887159683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.String var17 = var14.name();
    java.lang.String var18 = var14.toString();
    int var19 = var14.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    double var4 = var3.getMean();
    double var7 = var3.cumulativeProbability(0.31456926834144955d, 3.230325591810731d);
    double var9 = var3.inverseCumulativeProbability(0.8709381773848226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.038157775941106545d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.1963563118498035d);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportConnected();
//     double var8 = var2.inverseCumulativeProbability(0.0037646581280288047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 97.97198016599408d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 97.32752133680152d);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getMean();
    boolean var5 = var2.isSupportUpperBoundInclusive();
    double var6 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0574806988857035E105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4.535946096335034E52d);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextGaussian(3.3142072789405845d, 0.1995641250475069d);
//     double var10 = var0.nextExponential(97.8210147035919d);
//     int var13 = var0.nextBinomial(101, 0.28913202075094463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.305530002646725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 110.00093092971615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 29);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(201.7156361224559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3047395641448527d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(6.6401884929809825d, 3.0841429669768945d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.053038244402958984d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    int var5 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)98.38824842905983d, (java.lang.Number)100.22056007056258d, true);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(5.9604645E-8f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.9604645E-8f);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.getElement((-2083303935));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)9.094947E-13f);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.4690178139687315d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9980615336321373d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-527.8438038563128d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8.682030875269907E228d));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(3.469446951953614E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.469446951953614E-18d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(4066573, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2.0329713608269496E53d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 53.30813126062405d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(5);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)130048);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(363.7393755555636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.89918305896102d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.10170633440773788d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 37.983227333021844d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.0037606833841678563d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0037606922486185224d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.0329713608269496E53d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 122.74650837608283d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.021409936943280722d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3L, (java.lang.Number)(-0.015704685053792435d), false);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    java.lang.Number var6 = var5.getMax();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 3.233351086493488d+ "'", var6.equals(3.233351086493488d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double var16 = var14.addElementRolling(3.5321218005364248d);
    int var17 = var14.getNumElements();
    double[] var18 = var14.getElements();
    float var19 = var14.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.5f);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.probability(0.007907055323073179d);
    double var6 = var2.getSupportUpperBound();
    double var8 = var2.cumulativeProbability(4.583731940621995d);
    double var10 = var2.probability(4.9E-324d);
    boolean var11 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.950581586494586d), 0.004370191867052881d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.950581586494586d));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportConnected();
    double var4 = var2.getSupportLowerBound();
    double var5 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     java.lang.String var8 = var0.nextSecureHexString(9900);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal((-100), 3.322073347110264d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0036318689565848d);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.Class var17 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var19 = java.lang.Enum.<java.lang.Enum>valueOf(var17, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)363.7393755555636d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.31181957426375756d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(128270, 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 128270);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(9900, (-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(120.0d, 3.194723088062764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.24261147090679988d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(16.215207606048914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.4781445519135112d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.05248863084328934d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0013778444769301d);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 58L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 2);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 850355429512472704L);
//     java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
//     java.math.BigInteger var12 = null;
//     java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 58L);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 2);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var14);
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var14);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(Float.POSITIVE_INFINITY, 9.094948E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.020294450361988292d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)0);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (short)0+ "'", var2.equals((short)0));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.112299877947022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)4.9E-324d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(128270);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(2, (-0.49999997f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(3.230325591810731d);
//     double var5 = var1.nextT(0.8442914302025525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.1486695554781443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.7205001824963827d));
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, 0.984925048774637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.984925048774637d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(7.105427357601002E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var11.setContractionCriteria(1024.0f);
    var11.setElement(0, 3.0000000000000004d);
    float var17 = var11.getContractionCriteria();
    boolean var19 = var11.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = var11.copy();
    double[] var23 = new double[] { 100.0d, 0.0d};
    var11.addElements(var23);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    boolean var26 = var0.equals((java.lang.Object)var23);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var0.copy();
    var27.addElement(0.027468903747454535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     int var6 = var1.nextInt(1107, 27326631);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10239145);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeed();
//     double var19 = var0.nextT(100.8121795774414d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1369836194465787d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.9131532497398577d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "67f38e912e30a4fc9e21556222b3eb97251ec2725ae0f8919f43607a1c7908015e548aa5b3a20c6a848ded807ba525845b36e67ca397d8e54324765125bc5b5e59abd6153953f37ebaf9098ff2024b4160a8ba0f232e2f656d668d9c143f0ae90413cd4572b2c05ae7cbb580b4977a4d85a6c46b9125da78f72f28a3490a11229d45766ee31cb5f97526d033245401c8746490fc089668f4bc039a66561a4d134cf42da29099b64f27334dd69573db73317ec199e13864212b5d4e27d98a59e37874e57cae4f668d92fb9080db8ca1c57333a0a1b58fd30ebfa486074bc7575f0ba8ab1985177d58639de3ba3c1b9f9ad2f7a351cc34ca61d461cf88d290a7cf28690fc4fceabe1bd5b8dcab1ac479359a2b3ff362f3b6fd96d7c7735112528b5305e981db1701994129c640c7918b42a6035d77a61ddaffd8c0eaa454fe7f2358a7a8cd9a86d6d25cf774cc7917a61ffae0f9ead797a8ab396d9937dcd5da5998f21fa3f430d82b314e7c4f0f5a0799f9418c9e4c08bac65ade6681fc8cf93ce9f929fd8df264182bded64b4acb631eaa41a13341b957c50ca1c3154744cd2d05aa0e0a17807418eed1e3a98bc8370ef1a9a2765c8bd8559f445e6950354ea745cdf302dab82f2e993e43397b485391f4f26dff4f62f8c8a2266300a02338ed1043ee2b8ff019429185c88035b4303535c4aa5427c5b413786bff5f4e39b36af975fde341582d7398f57bc74e3baa77d98fdebd2fd8d2d5bf193a90a1972be688238ca2a3f4ca1522e8679f675936903e6de30564308efd2652f7e90cc26a694b7ccf9b7e46991668135111fd14f4e95fc99c591fb57ab3bc34edf2aacc2c0e304a4fe42e6b20de8a7236cf859d1f113959e5b1395bdc420e6fd7"+ "'", var13.equals("67f38e912e30a4fc9e21556222b3eb97251ec2725ae0f8919f43607a1c7908015e548aa5b3a20c6a848ded807ba525845b36e67ca397d8e54324765125bc5b5e59abd6153953f37ebaf9098ff2024b4160a8ba0f232e2f656d668d9c143f0ae90413cd4572b2c05ae7cbb580b4977a4d85a6c46b9125da78f72f28a3490a11229d45766ee31cb5f97526d033245401c8746490fc089668f4bc039a66561a4d134cf42da29099b64f27334dd69573db73317ec199e13864212b5d4e27d98a59e37874e57cae4f668d92fb9080db8ca1c57333a0a1b58fd30ebfa486074bc7575f0ba8ab1985177d58639de3ba3c1b9f9ad2f7a351cc34ca61d461cf88d290a7cf28690fc4fceabe1bd5b8dcab1ac479359a2b3ff362f3b6fd96d7c7735112528b5305e981db1701994129c640c7918b42a6035d77a61ddaffd8c0eaa454fe7f2358a7a8cd9a86d6d25cf774cc7917a61ffae0f9ead797a8ab396d9937dcd5da5998f21fa3f430d82b314e7c4f0f5a0799f9418c9e4c08bac65ade6681fc8cf93ce9f929fd8df264182bded64b4acb631eaa41a13341b957c50ca1c3154744cd2d05aa0e0a17807418eed1e3a98bc8370ef1a9a2765c8bd8559f445e6950354ea745cdf302dab82f2e993e43397b485391f4f26dff4f62f8c8a2266300a02338ed1043ee2b8ff019429185c88035b4303535c4aa5427c5b413786bff5f4e39b36af975fde341582d7398f57bc74e3baa77d98fdebd2fd8d2d5bf193a90a1972be688238ca2a3f4ca1522e8679f675936903e6de30564308efd2652f7e90cc26a694b7ccf9b7e46991668135111fd14f4e95fc99c591fb57ab3bc34edf2aacc2c0e304a4fe42e6b20de8a7236cf859d1f113959e5b1395bdc420e6fd7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 10.249736966119416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.32636528176104257d));
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(9, 4066573);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999f);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0035555880210079d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var1.setContractionCriteria(1024.0f);
    var1.setElement(0, 3.0000000000000004d);
    float var7 = var1.getContractionCriteria();
    boolean var9 = var1.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var1.copy();
    double[] var11 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var13 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var14.setContractionCriteria(1024.0f);
    var14.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var20.setContractionCriteria(1024.0f);
    var20.setElement(0, 3.0000000000000004d);
    float var26 = var20.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var20);
    double[] var28 = var14.getInternalValues();
    var1.addElements(var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = var31.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var33.setContractionCriteria(1024.0f);
    var33.setElement(0, 3.0000000000000004d);
    float var39 = var33.getContractionCriteria();
    boolean var41 = var33.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var42 = var33.copy();
    double[] var45 = new double[] { 100.0d, 0.0d};
    var33.addElements(var45);
    org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    double[] var48 = var31.rank(var45);
    org.apache.commons.math3.util.ResizableDoubleArray var49 = new org.apache.commons.math3.util.ResizableDoubleArray(var48);
    double var50 = var0.mannWhitneyU(var28, var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 32.0d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.439066159319773d, 42.3294109093513d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.032288075739338d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.7568024953079281d), 27.50058504859484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7568024953079281d));

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(8L, (-16L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16L);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(42.3294109093513d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6266422245194085d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)6.108372449228323d);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.9314281945454969d), 10.140709416791422d, 6.686727934632684d, 1025);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.37673098872466215d, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7534619774493243d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(101.79837155550794d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.009871746838973326d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(36L, 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2153214848064815104L));

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0078125f, 12700);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(5.631057176970199d, 0.004997851075629565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.0658773521358076d));

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-1.0035555880210079d), 3.0927921673007823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     int[] var9 = var0.nextPermutation(1124, 10);
//     var0.reSeed(1124L);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var15 = var14.isSupportLowerBoundInclusive();
//     double var16 = var14.getNumericalMean();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1093108789247763d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.019880797494679102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 99.65424284771464d);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("45f8d6150ba25c98d41710820119b73faf9d6a3af31c0c30e48aeab928d245d1228a62348fc4d9b80669afe0fddfe7086502433d02bf472b956874ce35db63e", "MAXIMAL");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.498220551780782d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03226345989263875d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.7895431961062007d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.3176882611728495d, 6.108372449228323d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.706533175782903E-6d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(6776.136847418304d, 3.2817446668755537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.735126366291157E12d);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(5832L, (-16L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8L);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-5), 4066573);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-20332865));

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var12 = var11.isSupportConnected();
//     boolean var13 = var11.isSupportConnected();
//     double[] var15 = var11.sample(5);
//     double var16 = var11.getNumericalMean();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     double var19 = var11.cumulativeProbability((-1.351004290131115d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.005841951193309029d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12.542998460851345d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 100.2721168426461d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 0);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(7L, 535514000795646464L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3748598005569525248L);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.28680180181229414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.29074983096826307d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var15 = var14.isSupportLowerBoundInclusive();
    double var17 = var14.probability(0.007907055323073179d);
    double var18 = var14.getStandardDeviation();
    boolean var19 = var11.equals((java.lang.Object)var18);
    double var21 = var11.addElementRolling(2040.3837802863068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3.0000000000000004d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1));
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)99);
    var2.addSuppressed((java.lang.Throwable)var4);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(4L, (-17));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.Class var17 = var14.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1010, 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     int[] var9 = var0.nextPermutation(1124, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextLong(3748598005569525248L, 3748598005569525248L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1198952488540934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.008748095633446275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-2.654150622549162d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.49983239787941475d));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(16, 12700);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(291729791, 291729791);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 291729791);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1025, 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 924);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.011466459304525554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9870620532286489d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(99, 7.523165E-37f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.9971623372532816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(3.255364039133607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.11426482339170634d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(20518787866943904L, (-437317876998765120L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 96L);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NotPositiveException var11 = new org.apache.commons.math3.exception.NotPositiveException(var9, (java.lang.Number)13.801711757320268d);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var8, (java.lang.Object[])var12);
    boolean var14 = var2.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.194723088062764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.161500413670511d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 101);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.22788969386187025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.4345638372360525d, 1.412848953997996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.07677059707394329d);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(3.0401488806678563d, (-527.8438038563128d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(99.32415977361578d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.291561363273996d);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var21 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var24);
//     java.lang.Class var26 = var2.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var27 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
//     boolean var31 = var29.equals((java.lang.Object)(short)10);
//     java.lang.Class var32 = var29.getDeclaringClass();
//     java.lang.Class var33 = var29.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var34 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var36 = var35.getNanStrategy();
//     boolean var38 = var36.equals((java.lang.Object)(short)10);
//     java.lang.Class var39 = var36.getDeclaringClass();
//     java.lang.Class var40 = var36.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var41 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var42 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var42);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var44 = var43.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var45 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44, var45);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var48 = var47.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var49 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var41, var48);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var50 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var36, var48);
//     java.lang.String var51 = var48.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var52 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var48);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5267163312899819d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + "AVERAGE"+ "'", var51.equals("AVERAGE"));
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     int var7 = var1.nextHypergeometric(4064528, 1024, 0);
//     long var10 = var1.nextLong(3L, 535514000795646464L);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var1.nextInversionDeviate(var11);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(34L, (-56L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.05248863084328934d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0073770197406784d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(3.4378417503557683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     var0.reSeed(58L);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 924);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9870620532286489d, (-10.118903838959886d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9870620532286488d);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     int var15 = var0.nextInt(2, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextUniform(39.8253719986887d, (-1.0035555880210079d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3163894126633866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.356243460168481d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 59.68952386646107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("cc99bc1b76f3be316a81b18852f12f5659eea2b79ee5e899184ac97c42948d487f78b0188940ca7e24eb0921be72306737ad6d9797bce1907d5ae6e414fe2122abdff0888a814d67ef1ece4ea37ba41c8219286c59291bd5c3822797a470a5910477709c2583b9e288f6d339ad24678cc396a0091943d5ba66bde5d8b5ec63064a3fd9d7aa1cd03cf9b674266dabd08cd6e7cedad8f8efe4e5210124a4099b3f45920c86ce1b6a0fcc198d5e59d0eedc7061a4ad7bde62ee58fe215bd7a119be987bd321d5e4f16cf59f048f65394387734a69feeb3e5c006c9844da95f31830d11206f97326fbb7bcf104f40db502758511df583cb53cdb85068eb27b495fb3f3ba7abea58a251572211236c0ecb465f7906d04ca0d61378049d591038ded0e9cf713cfafb3aefe1ecd90ecae5b201987f982084e8ec0e3b1339bd5d8a359fca6bfb96c2c9f5d282af78bb777bc394ff1132d8d06b29ce7a43bfa6405630d17a940a95938a85cecc9b8222fbc4f6ff3fb71416cc698f2ad16592c5183a7d293ce53f3cb1892c8ca7b488030f67dfb8f0de887f7844b2c1bde4a4024679506819a30073c6c353e36b6e2b2881c7e2e926f454956a9155c1d164ae9fedd90a78c3c2ba4a7e40d7cad3afa774a78a10e02d5e08e66c85a033e8296fd882130da9b9b043d355ad227f2519e7a184a8fdc6315d78e400cebdd80f2207d865e2ccd4a07db4927b3843a7f5ccd03b64fed7b6f790fe075a2c51c96eb411a979bb62efcc8039984bb89caa9c18c18c69a31636565e384e8607b18b717f7de3d12dd7acfeaf2acc4617ecc79e332b5b9c0f42fdf80b8e751e411cc0cba52efb2e83fc1bf57070109a7d3168a25d4b6cf1633aee69eb700fcf6884b4db15c18");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(1270, 0.9999999f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(7.1054274E-15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.9610045870274099d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-55.06150692938321d));

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric(1, 2, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2201646331071663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0010604280021618093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1488361790196930304L);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(5.9604645E-8f, (-0.49999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.9604645E-8f);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.7205001824963827d), 29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.868155900729994E8d));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-0.49999994f), 7.523165E-37f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.49999994f);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }


    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 58L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 2);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 850355429512472704L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.2184258106909835d, (java.lang.Number)8, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7L, (-437317876998765120L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7L);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(3.2536155909097118d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextSecureLong(99L, 7L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.168174704605739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-88.9793037832315d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 144.16448751723877d);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(2.533863737028583d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04422426500803653d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(360L, 2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 360L);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.022405075367622047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.022403200903740438d);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var20 = var0.nextBeta(5.282094375738045d, 3.5480122537930616d);
//     double var22 = var0.nextChiSquare(3.246534960233099d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var0.nextHypergeometric(924, 1179, (-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.297516361187394d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004088298881155949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 11.869773687792785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.0801960443689795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 33L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.628565682939202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.9806458150772808d);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-100), 99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-100));

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(3.322073347110264d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3507906957892059d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.194723088062764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4338273277434563d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-8), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.06321879551527536d, var2);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextF(1.1377077104187023d, 201.7156361224559d);
//     double var11 = var0.nextGaussian(0.3774867637513935d, 30.48232336227865d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("45f8d6150ba25c98d41710820119b73faf9d6a3af31c0c30e48aeab928d245d1228a62348fc4d9b80669afe0fddfe7086502433d02bf472b956874ce35db63e", "d5c329bd9a60cc2fc4c845b0d1fb7c8dea6d19f45dd1a0ba56784cd1d861783f1de2a271ff7dd17a0c6d29eb94a6a81134f7f00a0ec08be5cbc79a323fd7d13641c4c4380152ea099c82099eed866cd93c5edbc30289ffaecf21ac5e33d91d98352be3eb484f91112a68af16b0b1d443243018397fdedcfb0213bf609de13a32355e76e5b420cad89aaeda804aa3afd64d4a4405383371e49efa420725433f9c0e0dab019424c37f764c757c7602bff33ead750538c25973cc210a368e06ea37aecfcfb11062a58d958675dd43ce1c20129a1183f7c77ae9f2c1feabd841c3871ccc2f89fa5b47dd9108585e77efd7ecdb11664967b3d51479410a6a906bcf0fb0fb123d76f7fff3977c614a9d731d584cf5b717abb0271209d74f6d5a8d07a15d2e6717e73fa05c575c61fc13969971bdec4c9a6394c6793a5f06f3600e26b1e228912c10dd32322769e5b4976ebd2061b4d1f306f8c07e05d3aa0d0609590a3c8abc40e060a86f54bf50fdb0e1ca822bdc3dd8cce3903ee89b6825fb6e7ee0d943c3744de6f91fe5dc36cf18bf04ae160fa80ac991e1bcfc9cbd72babd455b7bd99dc797455663283eda593d2847eaee6e30a737cf1ce4bd6b601eb23cd6da9df829d245ea0c73965a3929b9adcf2a9eb6b049301f7ebf83d5ef904391c92405e42b2495770715a67ef82a5af515f90da79ea9c7a7508cc7dc3a78a917af870");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3018212102982267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.992587936414787d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.028987351354493276d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 50.83268989818178d);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalMean();
//     double var7 = var2.probability(0.8332364716232395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.4891568023885d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(3.272211577652278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13136687189114007d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.47712125471966244d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.39009509545358606d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.4840480658487383d, 3.5300603552863166d, 1.460540061869762d, 9900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9315603992489111d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.0037606833841678563d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(4.898248617516793d, 0.45384402236258964d, 162.89837633952882d, 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.3126332425372544E-4d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.217283190854277d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7936786754751468d);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var18);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var20.setContractionCriteria(1024.0f);
//     var20.setElement(0, 3.0000000000000004d);
//     float var26 = var20.getContractionCriteria();
//     boolean var28 = var20.equals((java.lang.Object)0.21400263603676362d);
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = var20.copy();
//     double[] var32 = new double[] { 100.0d, 0.0d};
//     var20.addElements(var32);
//     org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
//     double var36 = var34.addElementRolling(3.5321218005364248d);
//     int var37 = var34.getNumElements();
//     double[] var38 = var34.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var39.setContractionCriteria(1024.0f);
//     var39.setElement(0, 3.0000000000000004d);
//     float var45 = var39.getContractionCriteria();
//     boolean var47 = var39.equals((java.lang.Object)0.21400263603676362d);
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = var39.copy();
//     double[] var49 = var39.getElements();
//     double[] var50 = var39.getElements();
//     double[] var51 = var39.getInternalValues();
//     double var52 = var19.mannWhitneyU(var38, var51);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)99.4891568023885d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.setContractionCriteria(1024.0f);
    var3.setElement(0, 3.0000000000000004d);
    float var9 = var3.getContractionCriteria();
    boolean var11 = var3.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    double[] var15 = new double[] { 100.0d, 0.0d};
    var3.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    double[] var18 = var1.rank(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setElement(5, 0.3845071169264922d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.discardMostRecentElements(291729791);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.020769319996080778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02077230715275626d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, (-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     int var7 = var1.nextHypergeometric(4064528, 1024, 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var1.nextPermutation(1, (-2083303935));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(46L, 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(31.501720002936757d, (-0.015704685053792435d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.14550003380861354d));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(16, 1179);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1195);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5114643739263908d, (java.lang.Number)36L, (java.lang.Number)(-122.91669130357494d));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.01901555094517132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01901325932480203d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2742988879220016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.010925354806213946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.985884790561161d);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(545642504737558400L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 545642504737558400L);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(291729791, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    boolean var20 = var12.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var12.copy();
    double[] var24 = new double[] { 100.0d, 0.0d};
    var12.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var37 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var39 = var26.equals((java.lang.Object)var38);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var38);
    double var42 = var38.addElementRolling(0.984925048774637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 3.0000000000000004d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.1377077104187023d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.01985674547213255d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(8.033816814586373d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7806580354865353d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    double var4 = var3.getMean();
    double var6 = var3.density(363.7393755555636d);
    double var7 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(5832L, (-47L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(3, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.2359321581335148d, (java.lang.Number)0.7316474682224906d, (java.lang.Number)(-0.23799934003749132d));

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0000002f);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(437317876998765120L, 45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 437317876998765165L);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(101, 80674L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2106148007));

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.9999963726652458d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999963726652458d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.14211423187667926d, 1.1015674805733365E-13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267941214d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.094947E-13f, 1024.0001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.094947E-13f);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    int var14 = var0.start();
    float var15 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1024.0f);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(27326631, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27326631);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     java.lang.String var13 = var0.nextHexString(1025);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextHypergeometric(127, 924, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004189284250355179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0096609062958881d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6092370051138164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "92e4c3bb2a6ddad48ab76546e57bfb7344a91d4f253c20e5f54353f8323b6cf717bc695a81e97cd4c8b5c244fbf97e68acdac4c9a7d29a0c10f434ff7b033a4dc93fcbf3fc74e6f26bf0ac92bf3bb966e63f11a69d2b75cf77dd7c8715dc1caade1666bf164a571907ac042ef86b6e5406aaa83c2b5c2e1a1d57e004385102471f30625cb4fb49ec61f18c69a015b6ebac821be304dcf819472b37f4a5a29ebf47d95c7b5604eb3db6e6f5f3e8be28ee95ea5ea07a700fc0cb76e807188acdec0cb827a21643ed215cd70611703b791ebbad384034c6a2d642c39800f38ad2a232c512da248cdf30627f8615ab80970fe28d4f427041e8cd42725d6ae80d9d14b6b627c5fc270cf4413bc75eeaf19addea39007efd01fb1b6034e05a70372e60ba6a38ba3165610679a5e81fd11ebe688fb55d671b28ce73be372420c688c9fa0c485e2099eabb42b2278b72a3b648bf1796571a4af2f9d52b0c50738da0fd4701637ac5bff58dbbf8e80f03b88780bada0de17a65100b3b20f01ccac54fa25e26b18d084071a518ce6ad8fb5a537a4d171796e471e574caf22029090c63b9ba96990b6c8ba4bd586147151ddf8c6e1191c33bfc6829df945e0ef178ae6768ede3e38be6ec42b3cfe252cf6c4f8d89e391c6fdebd18eee7c470d9d9439202a8ccba1609e7f051bcd83d7bdefbd6c419c2cf0d87fc51826071623005e9924de961"+ "'", var13.equals("92e4c3bb2a6ddad48ab76546e57bfb7344a91d4f253c20e5f54353f8323b6cf717bc695a81e97cd4c8b5c244fbf97e68acdac4c9a7d29a0c10f434ff7b033a4dc93fcbf3fc74e6f26bf0ac92bf3bb966e63f11a69d2b75cf77dd7c8715dc1caade1666bf164a571907ac042ef86b6e5406aaa83c2b5c2e1a1d57e004385102471f30625cb4fb49ec61f18c69a015b6ebac821be304dcf819472b37f4a5a29ebf47d95c7b5604eb3db6e6f5f3e8be28ee95ea5ea07a700fc0cb76e807188acdec0cb827a21643ed215cd70611703b791ebbad384034c6a2d642c39800f38ad2a232c512da248cdf30627f8615ab80970fe28d4f427041e8cd42725d6ae80d9d14b6b627c5fc270cf4413bc75eeaf19addea39007efd01fb1b6034e05a70372e60ba6a38ba3165610679a5e81fd11ebe688fb55d671b28ce73be372420c688c9fa0c485e2099eabb42b2278b72a3b648bf1796571a4af2f9d52b0c50738da0fd4701637ac5bff58dbbf8e80f03b88780bada0de17a65100b3b20f01ccac54fa25e26b18d084071a518ce6ad8fb5a537a4d171796e471e574caf22029090c63b9ba96990b6c8ba4bd586147151ddf8c6e1191c33bfc6829df945e0ef178ae6768ede3e38be6ec42b3cfe252cf6c4f8d89e391c6fdebd18eee7c470d9d9439202a8ccba1609e7f051bcd83d7bdefbd6c419c2cf0d87fc51826071623005e9924de961"));
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     var0.reSeed(884124501032112256L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.089779771268506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.022022435167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3337176013585617E-9d);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)4.9E-324d);
    int var9 = var0.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.02077230715275626d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1901655306023455d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(20518787866943904L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20518787866943904L);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(20.538117523235602d, 3.127567616786903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20.774887498992896d);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeedSecure();
//     double var20 = var0.nextF(0.8442914302025525d, 31.501720002936757d);
//     var0.reSeedSecure();
//     double var24 = var0.nextUniform((-0.32636528176104257d), 0.09272622225462313d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5866899859268174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.98028680545127d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "f95df6a51b0302a13e5b937df5b6c95ad7a6eba2cac3d8be9765c3c984fad8658fe2af042cbc469ee32232b661e62040fa922004cb31dd067be5bca94f64a52736ec02958848384cfb1fbc6124cb637ebc026fd0af8346acfcfcf63207a889bdcbb5a7b85869f09f3998051a6fb0bdb6c291c97dbca0bee28ce4843f83b3ba81c1d2c12fde607e7026dc4801d73d9167a906a5c2c92e6ffb96916da5eb17ffeaae9e96bea864d44ae6c7b5e4c38ac55d1bc77755b6413958f876de60a20a635ab100637e16193ff7830ebfc208744d48c785132d17df3c385c75e50b50dae9451d9e93e03f3ae462c7fc58e8afc12af1f740f48c122244bbeccbc6e91e51e4dd6770889732213e3a8b504787f8e8274150b0ca2ee4221d1a9f93911102cb5ad99137e13860c269912d4fae6dca74fcb37c23884e60cdeb5b1a7a8f444a44c9dd3ce399ede6f180b6a72cc445d0576fcf54e942e9e76939a6b69504ebb108ed707650600d2ed270e08772d33d66639b84fb9cba989996c431016c707a0c87770e66e44bbdeb513cdaf69f49fad83eff12cf1f66790464c72b87c4bab46edc0a197b18956518e6051b6054111d4a9202a998dd134834a5584d62b8c42ab92d155e521fa675d9aa6f3e0dc8504bb964e29182f0e12b8c543d1fae284db4afb6bee977b799d57d753e89efb3eb30249cde043b254ad3bd8fceefa7016075ab1b16af3ff4291b3a73a75fe06feb20c098d18708bf591793a3550ece569b9b6833ef54c069736d81b93fbc18fedd4af5b0ebe6ecce360ceb899c6e2b0baf35b286bcb49706970312da638de5c21d07916ef9f28f5f949dcc7e00ffaf40109aba8070f436c5d184e80f75bc8a82b56364e83f2173167b180605a72e6fde92"+ "'", var13.equals("f95df6a51b0302a13e5b937df5b6c95ad7a6eba2cac3d8be9765c3c984fad8658fe2af042cbc469ee32232b661e62040fa922004cb31dd067be5bca94f64a52736ec02958848384cfb1fbc6124cb637ebc026fd0af8346acfcfcf63207a889bdcbb5a7b85869f09f3998051a6fb0bdb6c291c97dbca0bee28ce4843f83b3ba81c1d2c12fde607e7026dc4801d73d9167a906a5c2c92e6ffb96916da5eb17ffeaae9e96bea864d44ae6c7b5e4c38ac55d1bc77755b6413958f876de60a20a635ab100637e16193ff7830ebfc208744d48c785132d17df3c385c75e50b50dae9451d9e93e03f3ae462c7fc58e8afc12af1f740f48c122244bbeccbc6e91e51e4dd6770889732213e3a8b504787f8e8274150b0ca2ee4221d1a9f93911102cb5ad99137e13860c269912d4fae6dca74fcb37c23884e60cdeb5b1a7a8f444a44c9dd3ce399ede6f180b6a72cc445d0576fcf54e942e9e76939a6b69504ebb108ed707650600d2ed270e08772d33d66639b84fb9cba989996c431016c707a0c87770e66e44bbdeb513cdaf69f49fad83eff12cf1f66790464c72b87c4bab46edc0a197b18956518e6051b6054111d4a9202a998dd134834a5584d62b8c42ab92d155e521fa675d9aa6f3e0dc8504bb964e29182f0e12b8c543d1fae284db4afb6bee977b799d57d753e89efb3eb30249cde043b254ad3bd8fceefa7016075ab1b16af3ff4291b3a73a75fe06feb20c098d18708bf591793a3550ece569b9b6833ef54c069736d81b93fbc18fedd4af5b0ebe6ecce360ceb899c6e2b0baf35b286bcb49706970312da638de5c21d07916ef9f28f5f949dcc7e00ffaf40109aba8070f436c5d184e80f75bc8a82b56364e83f2173167b180605a72e6fde92"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.013802676407201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 15.324021276261647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0851300358994307d);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(4, (-1.0f), (-1.0f), 1195);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.094948E-13f, 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.094948E-13f);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    float var4 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double[] var5 = var2.sample(127);
//     double var6 = var2.getSupportLowerBound();
//     double var7 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 100.73525494526655d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.03005264204018276d, 3.4496806839002896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9997633029397283d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 27.12061425361551d};
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var2, var4);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.3507906957892059d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)93L, var2, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    var0.clear();
    var0.discardMostRecentElements(0);
    float var7 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     int var15 = var0.nextInt(0, 130048);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextZipf(0, 27.567148453340938d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4656964356496376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.04561022452166791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.37284430738340024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 23790);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.99999994f, 127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7014117E38f);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0037646581280288047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(58L, 884124501032112256L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(130048);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.08614178931870753d, (java.lang.Number)2.950006289924106E-8d, (java.lang.Number)1025);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.probability(0.007907055323073179d);
    double var6 = var2.getSupportUpperBound();
    double var7 = var2.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.NullArgumentException var4 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
//     java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 850355429512472704L);
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 8);
//     java.math.BigInteger var11 = null;
//     java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
//     java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 58L);
//     java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 2);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var13);
//     java.math.BigInteger var19 = null;
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var19);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    var3.addSuppressed((java.lang.Throwable)var7);
    boolean var9 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.49999994f, 7.523165E-37f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.523165E-37f);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeed();
//     int var20 = var0.nextPascal(130048, 0.03097415474563565d);
//     java.util.Collection var21 = null;
//     java.lang.Object[] var23 = var0.nextSample(var21, 1);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.1367639833139664d, (java.lang.Number)(-2.2937895310710235d), false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.5f, (java.lang.Number)0.7871088143391114d, true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.5f+ "'", var5.equals(2.5f));

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, false);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(39L, 19L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20L);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var12 = var0.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria((-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-36.93313360551038d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999999999999d));

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(437317876998765165L, (-535514000795646456L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.2695135139523783d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.4338273277434563d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1780538303479458d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(99, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 919965907);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(2.9033321156646354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.23480472979733d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(884124501032112256L, 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 884124501032112248L);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(8.0f, 1.8189894E-12f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.0f);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-27326631), 4066573);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-31393204));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0, (-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-1.987808884207606d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.02178868878282903d, 13.14778027539684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0016572127294455649d);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var10 = var0.nextT(1.1725829345725258d);
//     java.lang.String var12 = var0.nextSecureHexString(2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.300615440167265d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.219421939597738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5015996327207589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "22"+ "'", var12.equals("22"));
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed(0L);
//     int var13 = var0.nextInt(0, 1010);
//     double var15 = var0.nextExponential(3.322073347110264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1954937332433339d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 751);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6100421169092672d);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100L);
    boolean var3 = var2.getBoundIsAllowed();
    java.lang.Number var4 = var2.getArgument();
    java.lang.Throwable[] var5 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100L+ "'", var4.equals(100L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    int var14 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var15.setContractionCriteria(1024.0f);
    var15.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var24 = var23.isSupportConnected();
    double[] var26 = var23.sample(127);
    var15.addElements(var26);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    var0.addElements(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(1025);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(7.523165E-37f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.8408623877672396d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9962928771299543d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8394622403005243d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MathArithmeticException var1 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var6);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var13 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.2541246823682386d);
    boolean var14 = var13.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    java.lang.Object[] var22 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var19, (java.lang.Number)3.233351086493488d, var22);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException(var18, var22);
    java.lang.Object[] var25 = new java.lang.Object[] { var18};
    org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var17, var25);
    org.apache.commons.math3.exception.MathArithmeticException var27 = new org.apache.commons.math3.exception.MathArithmeticException(var16, var25);
    org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var13, var15, var25);
    org.apache.commons.math3.exception.MathIllegalArgumentException var29 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, var25);
    var9.addSuppressed((java.lang.Throwable)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.Class var17 = var2.getDeclaringClass();
    java.lang.String var18 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "MAXIMAL"+ "'", var18.equals("MAXIMAL"));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException(var2, (java.lang.Number)13.801711757320268d);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test326"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.5576973912328267d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5576973912328268d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test327"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.2118528414560354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.166847979797118d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test328"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test329"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test330"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(6.0d, 0.9968961379767788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.0d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test331"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, var7);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var7);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(4975.561694056367d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.512293546547506d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test333"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test334"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1401359.6943629924d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1401359.6943629922d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(6.578793360216593E219d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 219.8181462454294d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test336"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(437317876998765165L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test337"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(39L, 46L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1794L);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.7262772900781184d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0673700455051527d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.158982217932436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.158982217932436d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test340"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.0309692022248409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-32.817539051988156d));

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test341"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    boolean var20 = var12.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var12.copy();
    double[] var24 = new double[] { 100.0d, 0.0d};
    var12.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var37 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var39 = var26.equals((java.lang.Object)var38);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var38);
    double[] var41 = var11.getInternalValues();
    double[] var42 = var11.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test342"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(100.8121795774414d, 0.04191377835100361d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5703805657617391d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test343"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-8), 10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test344"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.15729146283385384d, (java.lang.Number)(-0.0f), true);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     int var17 = var0.nextSecureInt(0, 1010);
//     int var20 = var0.nextInt(255, 130048);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2676855983885d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.014818296952278905d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.10562244753459d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.9434847900511714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 662);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 98822);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test346"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.39009509545358606d, (java.lang.Number)0.5866899859268174d, (java.lang.Number)3.8626412474598433d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test347"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.0d), 3.022022435167d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test348"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.006925146002330119d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.08321746212382422d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)98.38824842905983d, false);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test350"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.551115123125783E-17d, 32.92012974757845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.551115123125784E-17d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test351"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var5);
    int var7 = var4.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    boolean var14 = var12.equals((java.lang.Object)(short)10);
    java.lang.Class var15 = var12.getDeclaringClass();
    java.lang.Class var16 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var17, var24);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var24);
    java.lang.String var27 = var24.name();
    java.lang.String var28 = var24.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var24);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var24);
    org.apache.commons.math3.random.RandomGenerator var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "AVERAGE"+ "'", var28.equals("AVERAGE"));

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test352"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(4.6220390880797995d, 0.1995641250475069d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3573034046268144d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.16320402005311493d), (java.lang.Number)130048, (java.lang.Number)0.023743591158329934d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test354"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-535514000795646456L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 535514000795646456L);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test355"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(4.440892098500626E-16d, 2.1512597642081674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9976525399559268d);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(3.9434847900511714d, 3.1589822179324365d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2900730816616766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.02431505454707119d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7.79165678281604d);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test357"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1025, (-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test358"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-527.8438038563128d), 3.215874911574371d, 0.004315834183219217d, 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test359"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(99.39563540955159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.010111583546381493d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test360"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)3.233351086493488d, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var9);
    java.lang.Object[] var12 = new java.lang.Object[] { var5};
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var4, var12);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var12);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, var12);
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var16.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test361"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.2879738713425515d);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test362"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    java.lang.String var12 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test363"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var1.setContractionCriteria(1024.0f);
    var1.setElement(0, 3.0000000000000004d);
    float var7 = var1.getContractionCriteria();
    boolean var9 = var1.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var1.copy();
    double[] var11 = var1.getElements();
    double[] var12 = var1.getElements();
    double[] var13 = var1.getInternalValues();
    double[] var14 = var0.rank(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    float var16 = var15.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.5f);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test364"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(360L, 96L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 456L);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextUniform(162.89837633952882d, 0.009939019418199392d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03142996646361644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.0130297953706753d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "cf6ee83bf86dc8ce9c8e8e2c835d5a374ecf9990b9ea30f90986b710651447618325b43b593a29ad085f5af30550480735dd8a2894c6223834def441cf9ffd0e356b372e1a572aa0a13e67dc9ebf54bff277a271338909ffcad3c36dc089e36db2acc07dcecbd7516037269bdc80d900e4e42a1592f48e5666acc8c6e5bbc1e6549dd3d7c8c7a058b170a48bde936b5302857f141129161edfa7261da9b1422e560b7cc638ff7699ef6744cdd4d75d916c7b2f95d0f964e8b6b90a82326b78d54cb12450d10c445d120596470a6dcef3e9928550acabc0a5060688b853985f61c99db777b2bd690d506495efe79bf3e47057e038d8a2946f77d863db40d34a33d1ddee040b88c0206622a9fbd90acc1e07aed9781f382a03de1798c9d5cf86d3852aca881336c5e2ee58f7689c2befc8e7e4a8346367e849ac1433534082cea2a1d32e86860b68ca06157124f480e0fcffa9bf23391ac3e95c1ac3849a1832617c375035463275c870ab15c5410925d50a364c4084194e1ee09c5a5deaec70658ab4bc750914545b049f8a8341bc900cf930b6f900431d1d6e82059089604445b27b905c31b6906c2a0563e7cf6308e644e1c43a2c55cee0d324ec644dce11540d389c96c953aac610309fe2b0de5493ba7dbe4af45f231b3140d25d438835aadba481d65abeab693f5dc39d831379ba77acbfa76e8418144b3f6e6e0dad2d4916a23a48cbf706e5977eff7b63f6ac562fca1607a9ecd8584c813ebacadc32ee8d852b4a8cf765e9bb1978ddf48609fecafae25dafd6b19075e9f3a03939f52a1587b9c33dfb77cd9303689fe8e6f85e3aeb194d7c0495ee48de295044aa4e7b403aed7002d870a675ca6a296b1d7048e923ac6b5e8be93a3aba64"+ "'", var13.equals("cf6ee83bf86dc8ce9c8e8e2c835d5a374ecf9990b9ea30f90986b710651447618325b43b593a29ad085f5af30550480735dd8a2894c6223834def441cf9ffd0e356b372e1a572aa0a13e67dc9ebf54bff277a271338909ffcad3c36dc089e36db2acc07dcecbd7516037269bdc80d900e4e42a1592f48e5666acc8c6e5bbc1e6549dd3d7c8c7a058b170a48bde936b5302857f141129161edfa7261da9b1422e560b7cc638ff7699ef6744cdd4d75d916c7b2f95d0f964e8b6b90a82326b78d54cb12450d10c445d120596470a6dcef3e9928550acabc0a5060688b853985f61c99db777b2bd690d506495efe79bf3e47057e038d8a2946f77d863db40d34a33d1ddee040b88c0206622a9fbd90acc1e07aed9781f382a03de1798c9d5cf86d3852aca881336c5e2ee58f7689c2befc8e7e4a8346367e849ac1433534082cea2a1d32e86860b68ca06157124f480e0fcffa9bf23391ac3e95c1ac3849a1832617c375035463275c870ab15c5410925d50a364c4084194e1ee09c5a5deaec70658ab4bc750914545b049f8a8341bc900cf930b6f900431d1d6e82059089604445b27b905c31b6906c2a0563e7cf6308e644e1c43a2c55cee0d324ec644dce11540d389c96c953aac610309fe2b0de5493ba7dbe4af45f231b3140d25d438835aadba481d65abeab693f5dc39d831379ba77acbfa76e8418144b3f6e6e0dad2d4916a23a48cbf706e5977eff7b63f6ac562fca1607a9ecd8584c813ebacadc32ee8d852b4a8cf765e9bb1978ddf48609fecafae25dafd6b19075e9f3a03939f52a1587b9c33dfb77cd9303689fe8e6f85e3aeb194d7c0495ee48de295044aa4e7b403aed7002d870a675ca6a296b1d7048e923ac6b5e8be93a3aba64"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 17.841862658590014d);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test366"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test367"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Float.POSITIVE_INFINITY);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test368"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(3.364770999664135d, 0.5576973912328268d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.3647709996641346d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test369"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(9L, 360L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-351L));

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test370"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-20332865), 101);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test371"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NoDataException var1 = new org.apache.commons.math3.exception.NoDataException();
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var3 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     double var19 = var0.nextGaussian(0.3845071169264922d, 0.04191377835100361d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextHypergeometric((-31393204), 1099, (-27326631));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4766622549405155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.022824114469501385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.6203502027662608d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.6999071795734517d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 46L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.3562116741683175d);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test373"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.2817446668755537d, (-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.588840068615677E-30d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test374"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var0.setElement(100, 1.2245129522199552d);
    double[] var9 = var0.getInternalValues();
    float var10 = var0.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(1124);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1024.0f);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test376"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double var12 = var10.substituteMostRecentElement(0.005325222439319957d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setContractionCriteria(9.536744E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.215874911574371d);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test377"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setExpansionFactor(1.0842022E-19f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test378"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test379"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test380"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(5.9604645E-8f, 1124);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test381"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(3.1936453631680304d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test382"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.01768834252748158d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.017687420276706205d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test383"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-17), (-31393204));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-17));

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test384"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(2.0574806988857035E105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test385"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)93L, var2, true);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test386"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.010275321846272d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.010275321846272d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test387"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.0037606833841678563d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     double var19 = var0.nextGaussian(0.3845071169264922d, 0.04191377835100361d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextUniform(0.021137266976184718d, 0.01453836480175214d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1233776757188196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0124973560082855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.8406269818427208d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.954753337976477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 41L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.3989933614370223d);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test390"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(20.538117523235602d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test391"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.6068334162420739d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.986994462827701d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test392"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.6931471805599453d, 0.17936156675857706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9363758521403108d);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     int var15 = var0.nextInt(0, 130048);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextZipf(4066573, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.981480652001119d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03263667102074075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.204405515017915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 54198);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test394"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    var0.discardFrontElements(0);
    float var7 = var0.getContractionCriteria();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    java.lang.Object[] var15 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var12, (java.lang.Number)3.233351086493488d, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, var15);
    java.lang.Object[] var18 = new java.lang.Object[] { var11};
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var10, var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, var18);
    boolean var22 = var0.equals((java.lang.Object)var21);
    int var23 = var0.start();
    int var24 = var0.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(7.629395E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test395"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.098418460323332d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7999302109750811d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(98.38824842905983d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5535647408430824d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test397"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1, 1099);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test398"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.01768834252748158d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test400"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.272211577652278d, 3.985884790561161d, (-0.9490176542425028d), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test401"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24L);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     var0.reSeed(7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextInt(128270, (-727379968));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.362762989094834d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.017862756071839504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 411318176982656064L);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test403"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-10), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test404"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7484183916512467d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test405"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(437317876998765120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 437317876998765120L);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test406"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.3094435918563348d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3199299628391793d);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test407"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.412848953997996d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var3, (java.lang.Number)1.412848953997996d);
//     var2.addSuppressed((java.lang.Throwable)var5);
//     java.lang.Number var7 = var2.getArgument();
//     java.lang.String var8 = var2.toString();
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test408"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(751);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria((-0.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     double var10 = var0.nextGaussian(0.0d, 0.3970832209142864d);
//     var0.reSeed();
//     double var14 = var0.nextF(3.2132396021992005d, 2.0574806988857035E105d);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     double var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 5);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test410"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.2879738713425515d, 5.751659131712158E-6d, 0.011993192308645846d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test411"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)201.7156361224559d);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    boolean var11 = var2.equals((java.lang.Object)var9);
    java.lang.String var12 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test412"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.6768120060085324d));

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     double var10 = var0.nextGaussian(0.0d, 0.3970832209142864d);
//     var0.reSeed();
//     double var14 = var0.nextF(3.2132396021992005d, 2.0574806988857035E105d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextHypergeometric(5, 1025, 128270);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.7081386520500382d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.622424795709812d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test414"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(3.6408852451715354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3027476538919007d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test415"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.2207031E-4f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test416"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(8, 662);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 670);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test417"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9363758521403108d, 2.3047395641448527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3047395641448527d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test418"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-56L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56L);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test419"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(56L, 1124L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56L);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.99764962345751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0023531430131176695d));

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test421"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(456L, 130048);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test422"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-127), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 127);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test423"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var3.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test424"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.4905488366463986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9649650643112703d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test425"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)3.322073347110264d, (java.lang.Number)3.8626412474598433d, (java.lang.Number)1.7512099012666158d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.8626412474598433d+ "'", var4.equals(3.8626412474598433d));

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test426"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("45f8d6150ba25c98d41710820119b73faf9d6a3af31c0c30e48aeab928d245d1228a62348fc4d9b80669afe0fddfe7086502433d02bf472b956874ce35db63e");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test427"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var8 = var2.density((-0.07612931540406859d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.37235403537579d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test428"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var19 = var0.nextChiSquare(3.4496806839002896d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.0623483795315067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03305825906913078d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.6351182596917955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6.433334133891699d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 49L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4.685393094455317d);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test429"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(97.97198016599408d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5613.380974050871d);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test430"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
//     double var4 = var3.getMean();
//     double var7 = var3.cumulativeProbability(0.31456926834144955d, 3.230325591810731d);
//     double var8 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.038157775941106545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.2745173498669733d));
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test431"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-8));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test432"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 2.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0000002f);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test433"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextWeibull(6.0d, 5.183028998081309d);
//     int var18 = var0.nextInt((-727379968), (-10));
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 2);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test434"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.2830087616199811d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2830087616199812d);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var12 = var0.nextUniform(0.8390715290764524d, 3.215653939400476d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextZipf((-20332865), 0.5320169063293507d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.6434201841725615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.020457289138241255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.7109879849129719d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.9162050026301247d);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test436"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (3.233)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test437"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(8.512293546547506d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.83119038428777d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.353223934874788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3459244966620778d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test439"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(19L, 291729791);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1843921677838435301L));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test440"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test441"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(100L, (-1531225969699204352L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1531225969699204352L));

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(9.92484747815762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3910397800748298d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test443"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0000000000379432d, (java.lang.Number)1.0963506818711306d, (java.lang.Number)(-0.2759086387217901d));
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0963506818711306d+ "'", var4.equals(1.0963506818711306d));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test444"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(10, 1010);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10100);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test445"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.6800947867508726d, 0.6931471805599453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6642825700552095d);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test446"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(99.32415977361578d, (-285.0810761538832d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test447"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.09724295972011165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-10.711234508240691d));

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, (-0.49999997f), 9.536743E-7f, 1195);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test449"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     double var17 = var0.nextUniform(0.0d, 0.4928847159655941d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextBinomial((-2083303935), 0.1970105693253613d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3771660319843564d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.015494884707656338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.048078040166809013d);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test450"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)2.33467759294052d);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (2.335) exceeded"+ "'", var2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (2.335) exceeded"));

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test451"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var19 = var0.nextChiSquare(4.1495472005154115d);
//     int var22 = var0.nextZipf(130048, 3.3954865640363336d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var0.nextPascal(100, 3.2369140053717915d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.309246539782948d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.008990508513615386d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 15.042025417225826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.833629732270516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 47L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.9535594492292442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.5576973912328268d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test453"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.4730946691978376d, 3.0073770197406784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5034380980459074d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test454"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)3.233351086493488d, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var7);
    java.lang.Object[] var10 = new java.lang.Object[] { var3};
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var2, var10);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)1.1749304202020776d, var10);
    java.lang.Number var13 = var12.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 1.1749304202020776d+ "'", var13.equals(1.1749304202020776d));

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test455"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    boolean var20 = var12.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var12.copy();
    double[] var24 = new double[] { 100.0d, 0.0d};
    var12.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var37 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var39 = var26.equals((java.lang.Object)var38);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var38);
    double[] var41 = var11.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setContractionCriteria(9.094947E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test456"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.7262772900781184d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.31982339482235594d));

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     double var12 = var0.nextGaussian(1.0001683942492827d, 4.81548573505896d);
//     double var14 = var0.nextExponential(0.04100350918060158d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextSecureLong(5L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4030157076972336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01208701659639606d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.6970860133668731d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.1551310614109218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.036680559183455225d);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test458"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.cumulativeProbability(98.471698070287d, 1.7155019267144769d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test459"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     java.lang.String var13 = var0.nextSecureHexString(16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2591705085020712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.012812083397006109d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.09191520949975578d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "090e33be2466e57a"+ "'", var13.equals("090e33be2466e57a"));
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test460"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test461"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     long var8 = var0.nextPoisson(0.06857547421121805d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextSecureHexString((-27326631));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4368426315605016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.013807029790275408d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test462"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(100, 1.2207031E-4f, 1.4E-45f, 8);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test463"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(99L, (-8568224012730343296L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8568224012730343395L);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test464"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MathArithmeticException var3 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var2, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)2.0329713608269496E53d, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test465"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var2.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test466"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test467"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0f, (java.lang.Number)var4, false);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 58L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 2);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 850355429512472704L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 8);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, (-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test468"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.7205001824963827d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7205001824963826d));

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test469"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(850355429512472704L, 545642504737558400L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test470"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    int var14 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-20332865), 3.2879738713425515d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test471"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2.5699328711844167d, (java.lang.Number)(byte)(-1), false);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test472"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 919965907);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test473"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.6057997097623945d, 18.23480472979733d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5453090700369303E-9d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-55.06150692938321d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-56.0d));

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(100.87002939710754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test476"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(3.3217250713308624d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.870162609038243d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test477"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(16L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test478"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("cc99bc1b76f3be316a81b18852f12f5659eea2b79ee5e899184ac97c42948d487f78b0188940ca7e24eb0921be72306737ad6d9797bce1907d5ae6e414fe2122abdff0888a814d67ef1ece4ea37ba41c8219286c59291bd5c3822797a470a5910477709c2583b9e288f6d339ad24678cc396a0091943d5ba66bde5d8b5ec63064a3fd9d7aa1cd03cf9b674266dabd08cd6e7cedad8f8efe4e5210124a4099b3f45920c86ce1b6a0fcc198d5e59d0eedc7061a4ad7bde62ee58fe215bd7a119be987bd321d5e4f16cf59f048f65394387734a69feeb3e5c006c9844da95f31830d11206f97326fbb7bcf104f40db502758511df583cb53cdb85068eb27b495fb3f3ba7abea58a251572211236c0ecb465f7906d04ca0d61378049d591038ded0e9cf713cfafb3aefe1ecd90ecae5b201987f982084e8ec0e3b1339bd5d8a359fca6bfb96c2c9f5d282af78bb777bc394ff1132d8d06b29ce7a43bfa6405630d17a940a95938a85cecc9b8222fbc4f6ff3fb71416cc698f2ad16592c5183a7d293ce53f3cb1892c8ca7b488030f67dfb8f0de887f7844b2c1bde4a4024679506819a30073c6c353e36b6e2b2881c7e2e926f454956a9155c1d164ae9fedd90a78c3c2ba4a7e40d7cad3afa774a78a10e02d5e08e66c85a033e8296fd882130da9b9b043d355ad227f2519e7a184a8fdc6315d78e400cebdd80f2207d865e2ccd4a07db4927b3843a7f5ccd03b64fed7b6f790fe075a2c51c96eb411a979bb62efcc8039984bb89caa9c18c18c69a31636565e384e8607b18b717f7de3d12dd7acfeaf2acc4617ecc79e332b5b9c0f42fdf80b8e751e411cc0cba52efb2e83fc1bf57070109a7d3168a25d4b6cf1633aee69eb700fcf6884b4db15c18", "9a3054b1");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6753091213496465d);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     int var8 = var0.nextZipf(1010, 1.3126332425372544E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4181411504456887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-8.764508098242358d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 129);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.14674055198112168d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.14569630083882143d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test481"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 8.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test482"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(8.014685878351596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test483"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.010275321846272d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0102753218462723d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test484"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(100.73525494526655d, 1.7155019267144769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.015262649202204078d));

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test485"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)7L, (java.lang.Number)(-1.3224571453632747d), (java.lang.Number)0.022403200903740438d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test486"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    double var4 = var3.getMean();
    double var7 = var3.cumulativeProbability(0.31456926834144955d, 3.230325591810731d);
    double var9 = var3.density(4.346069909771813E28d);
    double var11 = var3.probability(3.5487448944692996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.038157775941106545d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test487"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
//     org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
//     var4.addSuppressed((java.lang.Throwable)var8);
//     boolean var10 = var4.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
//     org.apache.commons.math3.exception.util.ExceptionContext var12 = var4.getContext();
//     java.lang.Number var13 = var4.getArgument();
//     java.lang.Throwable[] var14 = var4.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var14);
//     java.lang.Throwable var16 = null;
//     var15.addSuppressed(var16);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var10 = var0.nextUniform(0.9580227822788078d, 1.460540061869762d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextUniform(5.291561363273996d, 0.021409936943280722d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.006894154751043008d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.4096842926634654d);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test489"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     int[] var9 = var0.nextPermutation(1124, 10);
//     var0.reSeed(1124L);
//     long var13 = var0.nextPoisson(6776.136847418304d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.375928704199537d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.008096233594794201d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6937L);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test490"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     double var11 = var0.nextChiSquare(3.1132389726050125d);
//     double var13 = var0.nextExponential(0.9870620532286489d);
//     var0.reSeed((-3847095399992368128L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.461707587098562d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.017749314150728758d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.865840722195883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.30903939704698563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.274381943317341d);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test491"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(3.469446951953614E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test492"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-1531225969699204352L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1531225969699204352L);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test493"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1010, 2147483647);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test494"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var4 = var2.getSupportLowerBound();
//     double var5 = var2.sample();
//     double var6 = var2.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 101.72275192089097d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test495"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 1.2541246823682386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     java.lang.String var14 = var0.nextHexString(129);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.954874930442047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 23.180072439923652d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-63.56607050790779d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "3a3b9f9228c85c5881d80e6dbbb4d9f5dd8a5cd11b6cd314f16d7ef4d819c18004c037e6c473bf870ee61f846dda541093b7bca35bb804faa763fa3fa0e53f79d"+ "'", var14.equals("3a3b9f9228c85c5881d80e6dbbb4d9f5dd8a5cd11b6cd314f16d7ef4d819c18004c037e6c473bf870ee61f846dda541093b7bca35bb804faa763fa3fa0e53f79d"));
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test497"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(49L, 29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-144705876426790031L));

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test498"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.08614178931870753d, 3.2369140053717915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08614178931870753d);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     double var11 = var0.nextExponential(0.021246670571198962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.488442646053552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.005771153194535552d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.379372734797432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0018161174326008552d);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test500"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.0329713608269496E53d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.475071648092547E55d);

  }

}
