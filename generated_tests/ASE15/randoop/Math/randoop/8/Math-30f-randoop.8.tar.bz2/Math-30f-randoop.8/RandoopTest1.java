
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)99, (java.lang.Number)1024.0f, false);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 99+ "'", var4.equals(99));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1024, (-1.0f), 9.094947E-13f, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.1309659398685306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(45L, 56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 5);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var5 = var2.cumulativeProbability(Double.NaN);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var7 = var2.sample(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
// 
//   }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     org.apache.commons.math3.distribution.IntegerDistribution var1 = null;
//     int var2 = var0.nextInversionDeviate(var1);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0f, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0f);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-3.4657978658285428E-6d), 1.1749304202020776d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.4657978658285428E-6d));

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     double var11 = var0.nextExponential(0.9973002184105607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4378417503557683d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.541569075991355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.9380858908743853E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.2541246823682386d);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(3.227226180092589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.008763513567425d);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var10 = var0.nextChiSquare(3.227226180092589d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextUniform(0.07813596190804502d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.478372316915518d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0012934104083743795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.426238460005546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.183376941278582d);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(58L, 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8L);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     double var6 = var2.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.7011985441339d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var12 = var0.nextUniform(0.8390715290764524d, 3.215653939400476d, false);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var0.nextInversionDeviate(var13);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NoDataException var2 = new org.apache.commons.math3.exception.NoDataException();
//     java.lang.Throwable[] var3 = var2.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)9.332621544395286E157d, (java.lang.Object[])var3);
//     java.lang.Number var5 = var4.getMax();
//     java.lang.Throwable var6 = null;
//     var4.addSuppressed(var6);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextHypergeometric(9900, (-100), 9900);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4691107492239857d);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)100);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getArgument();
    boolean var4 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)100+ "'", var3.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 1024);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-100), 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-100));

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(3.3166247903554003d, 1.412848953997996d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextInt(5, 5);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9262261542401429d);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.021788688782829028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02178868878282903d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.018734606752382445d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.021137266976184718d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-17), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    double[] var5 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var8 = new double[] { 1.0d};
    var6.addElements(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.mannWhitneyUTest(var5, var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1024, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 130048);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(9, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.8721855928581603d, 3.383931628367152d, 0.0d, 9);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.7297716605398856d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(3.230325591810731d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8408623877672396d);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(130048, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 130048);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.02172004731721395d), (java.lang.Number)(-0.022147517156860363d), true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.02172004731721395d)+ "'", var5.equals((-0.02172004731721395d)));

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.94631867978169d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.7568024953079282d), 3.275083049119101d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.7568024953079281d));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.03428444643176393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.464902858407186d));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.2879738713425515d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2879738713425515d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var12 = var0.nextUniform(0.8390715290764524d, 3.215653939400476d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.083410973656385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.02313429762563917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.638101929826075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.6927690998855d);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.022147517156860363d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9780959384763808d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-100), 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-727379968));

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.5114643739263908d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1336742313097214d);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextLong(45L, 3L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.0434599898149655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0012802374438097598d);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(3.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.9999999999999996d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 120.0d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(9, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 36L);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.1635534192908262d, (java.lang.Number)(-638.3703397929479d), (java.lang.Number)7L);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    var0.clear();
    var0.discardMostRecentElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.substituteMostRecentElement(0.7504519561054462d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.021409936943280722d, 3.3306435445317306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9998078778519396d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.002217427235567818d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.3368086899420177E-19d);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextF(1.1377077104187023d, 201.7156361224559d);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var5 = var2.cumulativeProbability(Double.NaN);
//     double var7 = var2.cumulativeProbability(0.038157775941106545d);
//     double var8 = var2.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(850355429512472704L, 58L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric((-17), (-10), (-10));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6421002085301163d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.651788787569491d);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    var3.addSuppressed((java.lang.Throwable)var7);
    boolean var9 = var3.getBoundIsAllowed();
    java.lang.Number var10 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 3.233351086493488d+ "'", var10.equals(3.233351086493488d));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var0.setElement(0, (-0.5063656411097588d));
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var9.setContractionCriteria(1024.0f);
    var9.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var15.setContractionCriteria(1024.0f);
    var15.setElement(0, 3.0000000000000004d);
    float var21 = var15.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var9, var15);
    double[] var23 = var9.getInternalValues();
    var9.setElement(100, 27.12061425361551d);
    boolean var27 = var0.equals((java.lang.Object)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var2 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var1);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     double[] var7 = var5.sample(99);
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var9 = var8.getElements();
//     int var10 = var8.getExpansionMode();
//     double[] var11 = var8.getInternalValues();
//     double var12 = var2.mannWhitneyUTest(var7, var11);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(4.583731940621995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1409651890262005d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.04175569827445511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(10L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13L);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextWeibull((-0.7568024953079282d), 0.41791873580522526d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.009544456573338406d);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9998245123878073d, 5.744920421363131E-278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9998245123878073d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 291729791);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextUniform(0.7781512503836435d, 0.7247032922278211d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)13.801711757320268d);
//     java.lang.Throwable[] var3 = var2.getSuppressed();
//     java.lang.String var4 = var2.toString();
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     var0.reSeed(7L);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var0.nextSample(var13, (-5));
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1270);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-1.00734152150007d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8457259950799338d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements((-5));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(127, (-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.3376070089627754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(98.38824842905983d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.282094375738045d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(383341803785389312L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    java.lang.Class var5 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "e5567ab24438df853764a369c63dc5418bc2b932ca3251cfa77741e48e99c27eea62c91daf1a3b74792419ca510e10d5db61700b2afc0a1aef214730e86f1009eaa49359d95b178f162efeb341c6610844db73ef21dda09ed2f46db63af3c99e9e4c93112a72331c42efb5ac880b122750599c4c2cd6ce7240c16fe5f002d0a158b067a0fff97ad916887823bc3e91655441270360700e635ec1d6b0f4c093d0e3271e78cc80738ae2089d45cb4634ffcfd50d51a0d4db66325a92d9380b9c3a8b2706141f52481762888bead1d2f1f498b1383908b54077dfcfd35747ba094015b0f5b38a43baa2a402299d872c06f4f2962e197e749b7e4d816a9971c6c62fc839800f7b805a5bc70367d231dcd323037aa071bd8e774bef015f80f0c67622fadde6b102acff39c1fa08a98b68bf0abac07a37acc02c83248b6c6ce4031b6e0d57054ff66972219c1178d0f0af44a2a70ac31dff124eac07c4ec7efcdad0622e19f8badc1631b9c58f84c68d3eb942700ac1133944d007189c721c9766d2d898208821d365c4618a3898077956ffd3c66e2181b43059a87bf9eb3b2b4ea8823ce4015ffb2e6dedc2dbb7d2986fa1233aea68921d47b8e703e453e080f72ad0d39c63cd8c68f36c481d38c8f6330234775a8e31dba859e4dfeaac66f3b33a8911662bd0051613aab49a27b3c0e060069f6790aceb2931e9d66b4ed4d4d07ee4b636bbd4258d162c7a56fe00d8b4516e01f685c007c0b4cb86af6924a23ce26d23ab26b254b2ab6d3798cf66a41a98c0eb736a3fd3a0249c77c47a9a35f1283a83f8e1eaade6559420da8b5afc36631600581cc56e573fde5acd68bf1f817b9ad871672b19add3d49688f6fdadf61432275774881af7af0f236317");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextHypergeometric((-17), 9, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.210350605934786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01565840429718989d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.20966646014632304d);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9160084765308957d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
//     org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var5.setContractionCriteria(1024.0f);
//     var5.setElement(0, 3.0000000000000004d);
//     float var11 = var5.getContractionCriteria();
//     boolean var13 = var5.equals((java.lang.Object)0.21400263603676362d);
//     org.apache.commons.math3.util.ResizableDoubleArray var14 = var5.copy();
//     double[] var15 = var5.getElements();
//     org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     double[] var17 = var5.getInternalValues();
//     double[] var18 = var2.rank(var17);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var9.setContractionCriteria(1024.0f);
    var9.setElement(0, 3.0000000000000004d);
    float var15 = var9.getContractionCriteria();
    boolean var17 = var9.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var9.copy();
    double[] var19 = var9.getElements();
    double[] var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var8.mannWhitneyU(var19, var20);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(2L, 56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56L);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1024.0001f, 0.01768834252748158d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(5.282094375738045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6643226811401675d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.6643226811401675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6643226811401677d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    java.lang.Enum var8 = java.lang.Enum.<java.lang.Enum>valueOf(var6, "MAXIMAL");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var10 = java.lang.Enum.<java.lang.Enum>valueOf(var6, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    var0.discardFrontElements(0);
    double var8 = var0.addElementRolling(2040.3837802863068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(3.31160576334217d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4905488366463986d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.01453836480175214d, 3.0927921673007823d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.075116688098195E-6d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-727379968), (-727379968));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-10), 291729791);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.2879738713425515d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9972169089396286d);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var8 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.003941584617449815d);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.2541246823682386d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0d, (-150.28615268479777d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999999999998d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(36L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var4.substituteMostRecentElement((-1.5574077246549023d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 93L);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(3.1444428812273078d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.711278612018845E-6d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.8390715290764524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3142172955075926d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.027690443908148718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03123733597590902d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6931471805599453d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(3.272211577652278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.022147517156860363d), 0.9998078778519396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial((-5), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01437173585630316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.135052028975922d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "0f26ac5f3756ce2c26073d654dd8ccf77a413014901973b4fdc3b107d658123bb4d24fd9bcc35ee781160fb010a3a93cf475cc3b352df47e408e417cbf113762ad8dafee4007dfc8bd8c813f16d040e347f21dc2a27f74dca2e4ea96813768c4aa2e5a3d0ef6f1d226b47f89386667f1e1ad65f8ae7dff108b45be69c4b92311b6cb950c4b0a614174f2ff4c42b0f1ae84b9381c19d1a3e374213253642354bf1a915d652c561ca0b94c34b4000a9e4a14c3f2630fb4a6e17c00b5197c4027d5cda9f0c3cadeb7552020523e8413d6bc378e7c3d198c4c3367fa253ff7e4f755e442c850af6e24f3905d33d2b608f3d96b7262927e0a55e0601272b362ba01eee00d3e936e46978be3d1649e403e98a4c6fa608bb8eb1cee7476e0e5e314a7b8ffd80afc7e0d6b11d2656e5a6e87355a07d8cacb18c71419d62b70404fd430a908b91bd6ae695b9a66378c82dc564353b9ad742fbd8ae0e69a0f217c308bc9d653c69bdb5965bb5a043613d90669a70c0e3635f837d5fa03deb18559e4a06aed8dd1e91f458462d57706b3ec8f7c2288c9714dd2ab2ff194fd68b45fc625dfe99f89cb7e8c5129efbf5ce53e29c637bf11cee201eb6f9a0c6e3629770031e2962d80a110d2d52559a14d3f8e442899895c02d81b12ecdf1970a92157f7c669988fb2996c9c98bf5c99d2f976ad23cbbfe1a31befd676bb14188be11cc6aebd94582dd97b21582f831f985879c73eb2b11d93bf75a76baba8d36ac55c2e6df18e8d25642829d817409402044b5ccdd4b1bd55f1aae810a85e4105aaaa146bd5024fbe5edca92ca94dbd1764186ef034b2f3031f223a0a33544b9ede744367d249aa77163f8044e0dd645ddfb2bfb731dfd8a11d4324089539a8a002"+ "'", var13.equals("0f26ac5f3756ce2c26073d654dd8ccf77a413014901973b4fdc3b107d658123bb4d24fd9bcc35ee781160fb010a3a93cf475cc3b352df47e408e417cbf113762ad8dafee4007dfc8bd8c813f16d040e347f21dc2a27f74dca2e4ea96813768c4aa2e5a3d0ef6f1d226b47f89386667f1e1ad65f8ae7dff108b45be69c4b92311b6cb950c4b0a614174f2ff4c42b0f1ae84b9381c19d1a3e374213253642354bf1a915d652c561ca0b94c34b4000a9e4a14c3f2630fb4a6e17c00b5197c4027d5cda9f0c3cadeb7552020523e8413d6bc378e7c3d198c4c3367fa253ff7e4f755e442c850af6e24f3905d33d2b608f3d96b7262927e0a55e0601272b362ba01eee00d3e936e46978be3d1649e403e98a4c6fa608bb8eb1cee7476e0e5e314a7b8ffd80afc7e0d6b11d2656e5a6e87355a07d8cacb18c71419d62b70404fd430a908b91bd6ae695b9a66378c82dc564353b9ad742fbd8ae0e69a0f217c308bc9d653c69bdb5965bb5a043613d90669a70c0e3635f837d5fa03deb18559e4a06aed8dd1e91f458462d57706b3ec8f7c2288c9714dd2ab2ff194fd68b45fc625dfe99f89cb7e8c5129efbf5ce53e29c637bf11cee201eb6f9a0c6e3629770031e2962d80a110d2d52559a14d3f8e442899895c02d81b12ecdf1970a92157f7c669988fb2996c9c98bf5c99d2f976ad23cbbfe1a31befd676bb14188be11cc6aebd94582dd97b21582f831f985879c73eb2b11d93bf75a76baba8d36ac55c2e6df18e8d25642829d817409402044b5ccdd4b1bd55f1aae810a85e4105aaaa146bd5024fbe5edca92ca94dbd1764186ef034b2f3031f223a0a33544b9ede744367d249aa77163f8044e0dd645ddfb2bfb731dfd8a11d4324089539a8a002"));
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3522260890046898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.4433558681593072d);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(127, (-0.02172004731721395d));
    var0.setElement(0, 2.075116688098195E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.random.RandomGenerator var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var4 = var3.getElements();
//     double[] var5 = var2.rank(var4);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.3900553644082354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8412102988002852d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.098418460323332d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.485437011111235d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(9.094947E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0842022E-19f);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(5.183028998081309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(9900, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextF(0.6104227919456581d, 0.9780959384763808d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation((-100), 2);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.226139957689864d);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(Double.NEGATIVE_INFINITY, 0.02240694992560174d, 100.7011985441339d, 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0078125f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.0f);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(127, (-0.02172004731721395d));
    int var18 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(9.536744E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(9L, 56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-47L));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(8.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.06313470951770385d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06321879551527536d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.02172004731721395d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2121.4185729849014d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    float var6 = var4.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.discardFrontElements((-127));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4036656746966349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.412848953997996d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.NoDataException var6 = new org.apache.commons.math3.exception.NoDataException();
//     java.lang.Throwable[] var7 = var6.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)9.332621544395286E157d, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var7);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode((-100));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 1.8189894E-12f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(2.4014826029593057d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04191377835100361d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1025, 9.536744E-7f, 7.629395E-6f, 130048);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Throwable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, (java.lang.Number)3.233351086493488d, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var3, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var2, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(9900, 1124);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(127, 1124);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2083303935));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.004625354262543145d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8));

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(27.50058504859484d, 1.489663623435252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.489663623435252d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.49999997f), 0.9968961379767788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.49999994f));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.230325591810731d, 2.010275321846272d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.004464771942251129d));

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(3.227226180092589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 184.9064396534319d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.8709381773848226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     double var5 = var2.cumulativeProbability(Double.NaN);
//     double var7 = var2.cumulativeProbability(0.038157775941106545d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var2.inverseCumulativeProbability(3.158982217932436d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1024.0f+ "'", var5.equals(1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100+ "'", var6.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1024.0f+ "'", var7.equals(1024.0f));

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.027472359321754035d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-36.93313360551038d));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(8.18871602462383E42d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    double var6 = var2.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.cumulativeProbability(99.45901239974921d, (-6.856437577172423d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-127), 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeed();
//     double var18 = var0.nextF(0.014644560842127431d, 3.1444428812273078d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextUniform(3.1444428812273078d, 0.005307422838786435d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1878924842732506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.00602494852537586d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.936126814373246d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.223824559954817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.4311175526597343E-9d);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.011993192308645845d, 0.02240694992560174d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.011993192308645846d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    double var6 = var2.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var8 = var2.sample((-5));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 0.0078125f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(127, (-0.02172004731721395d));
    int var18 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-1), 2.4014826029593057d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(3.227226180092589d, 5.64539685894143d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.0191180244969094E-6d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2L, 56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56L);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.006935830340986719d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(99, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 101);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.49999994f));

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-2.001220210450374d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13517024642000433d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 4064528);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4064528);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(291729791, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.221784168705742d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2359321581335148d);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
//     double var4 = var3.getMean();
//     double var7 = var3.cumulativeProbability(0.31456926834144955d, 3.230325591810731d);
//     double var9 = var3.density(4.346069909771813E28d);
//     double var10 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.038157775941106545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.06857547421121805d);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getMean();
    double var5 = var2.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.inverseCumulativeProbability((-2.1680794060836064d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0574806988857035E105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.21400263603676362d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(5832L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5832L);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getElement(2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.0f), 0.9972169089396286d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 45L);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(291729791, 7.629395E-6f, 1.2207031E-4f, 8);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(5, (-727379968));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var1);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-1), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 27.12061425361551d};
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var4, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)1.0d, var6);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    int var11 = var10.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setExpansionFactor(4.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1025);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.000001f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3f6b9f710f83a360846717a9679342d48e0464472f40bc663fbb00f7bac1b087aa091993ad5e3ae8aca1f397e6a107d72a98edc5911610cb88c372bf0d87eabcb26b46e8e020ac9ae44d2814c19fd848af4f841fe53a9a3ad27d22438ab19dc69faf76ad5708ea671e16850e9dca5667a7e7fe7999904ea65eafc4221b1fe62606633a602a6b1ee14da5d9c769d4c9b2daef14fa9e410ec173af5111f7694f2074a6ec738f50cd726e881b2a66c459fddd882a9f08010b83638a19aace8e9ae7144949410f56cc026528c1fb5b0ea73c592263866b4585fea29a3706eb7ee43eae795a7fda49134358b3b9b14f1764154010fba31fab598695479086b93b51c5db2ff95b003860ea3b0af08eb738222974b7f8c247eb2b711926f89f7083ae4fa97b0b552fb7a73fc05ba7de80016183b96343612ec15cc5f1027e9fc5f6a5e170422022c185271329f9777789dc6855928a373519dce815e173ab0849138692c58c87f63e065e635346b9822d987999bc8ce1bf0d9b376b16d4ca41fb0036b2577e1833bb2818edb8c6b65f57d4224961c6f87237262a2cd9646d39671caaf73be57a36ebfc3835cba701dd1adee1aaf8dd3bf152ae53b03e7e0e99d9cb1f4c161bd36017ccb2d051ed783f259b4f407f8bed1ed7026162685730e7e06c4256e87f2f82848a4951fc016526683758950bc4665efe2aecce789457d92db2520598aaccafa1d90c2b67ae5eac7357af718161fd11a85bdd89abc64985c70717542aa7ca31416f930c2c164a9ebad5008d9a2659c7c0425131a7de5cccfeabd7f08c0eac8e56c1522276802599f075c971b7849bfca5f08fff319d6cbca11df9fa8426e5bed0da595fd5fb94d5a44598708543e5a8190fb05355f3d0", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004309838962765995d);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(1025);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(383341803785389312L, 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)3.305530002646725d, false);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.String var6 = var3.toString();
    java.lang.Number var7 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.305530002646725d+ "'", var4.equals(3.305530002646725d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than, or equal to, the minimum (3.306)"+ "'", var6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than, or equal to, the minimum (3.306)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 3.305530002646725d+ "'", var7.equals(3.305530002646725d));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.nextExponential((-2.1680794060836064d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)99L);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(4, 9900);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(2.1409651890262005d, 27.12061425361551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1409651890262005d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.31160576334217d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 27.429134827355153d);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var6 = var2.cumulativeProbability(6.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var2.cumulativeProbability(3.2722646632737273d, (-638.3703397929479d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.39835734056715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(383341803785389312L, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-2L), (-2L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(4064528);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.7788687978395656E7d);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     long var15 = var0.nextLong((-1L), 9223372036854775807L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than, or equal to, the minimum (3.306)", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2065654505007535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.02716259252242828d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.7109668676690046d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3312807986087874560L);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.1635534192908262d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.061647155000831025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.938893903907228E-18d);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.353223934874788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1024.0f, (-0.49999997f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var0.nextInversionDeviate(var15);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.021137266976184718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.689149036074892E-4d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.3900553644082354d, 0.0d, 3.5480122537930616d, (-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.03097415474563565d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0309692022248409d);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var5 = var0.nextT(0.8390715290764524d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform(184.9064396534319d, 1.8408623877672396d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.18125390045683257d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportConnected();
    boolean var4 = var2.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var6 = var2.sample((-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.digamma(Double.NEGATIVE_INFINITY);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var1.nextSecureLong(535514000795646464L, (-2L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(17.356026299362938d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0d));

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(100.7011985441339d, 0.6104227919456581d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(4.0f, 7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.6293945E-6f);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextGamma(1.8360738684267854d, 3.5743392688675386d);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(6.232928512989213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.0d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1), 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.7247032922278211d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(9.536743E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-535514000795646456L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1024, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(3.233351086493488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0916297253956488d));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    int var7 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1124, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1124L);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(5832L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextBinomial(9, 100.18831295682915d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(16L, (-535514000795646456L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8568224012730343296L));

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1024, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(8L, 45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 360L);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1024, 9.536743E-7f, 4.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.9314281945454969d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.1377077104187023d, (java.lang.Number)0L, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0L+ "'", var5.equals(0L));

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(18L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18L);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.7316474682224906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7316474682224907d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.8189894E-12f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8189894E-12f);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)4.898248617516793d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.227226180092589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4415460285734238d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    var3.addSuppressed((java.lang.Throwable)var7);
    boolean var9 = var3.getBoundIsAllowed();
    boolean var10 = var3.getBoundIsAllowed();
    java.lang.Number var11 = var3.getArgument();
    java.lang.Number var12 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1)+ "'", var11.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1)+ "'", var12.equals((-1)));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(101);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    int var6 = var5.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.02240694992560174d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.02240694992560174d);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(3.1367639833139664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.8189894E-12f, (-8));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.1054274E-15f);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextHypergeometric((-1), 1024, (-100));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4468270197719417d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.644570925330973E-4d));
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextZipf((-127), 5.541569075991355d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.551825017531005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03829215616739374d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1374117218631768576L);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var12 = var0.nextUniform(3.3900553644082354d, 4.723647519700551d, false);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var0.nextSample(var13, 0);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.446743189812706d, 1.3856829362664274d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.446743189812706d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(1.2207031E-4f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var0.setElement(100, 1.2245129522199552d);
    double[] var9 = var0.getInternalValues();
    float var10 = var0.getContractionCriteria();
    float var11 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1024.0f);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.027690443908148718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.3845071169264922d, 0.9233044426883612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0001683942492827d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(4.86927073907222d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.22788969386187025d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.230325591810731d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9968773290157855d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)3.305530002646725d, false);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10+ "'", var4.equals(10));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.03428444643176393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.983764724579021E-4d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    int var6 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(3.275083049119101d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999963726652458d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.9380858908743853E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.938085888996297E-9d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var0.getElement(9900);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(10, 1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12700);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var12 = var0.nextUniform(0.8390715290764524d, 3.215653939400476d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var0.nextSecureHexString((-5));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1880375486133836d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.00995981767601306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.4466233219759514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.212394396538079d);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     long var8 = var0.nextPoisson(0.06857547421121805d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(1124, 3.8626412474598433d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3899890365335983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01675412882837923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(127.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.026525695313479d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 1124L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextF(0.6104227919456581d, 0.9780959384763808d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.226139957689864d);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(41.752984630466926d, 1.2541246823682386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.07612931540406859d));

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     long var8 = var0.nextPoisson(0.06857547421121805d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("687dd3253fb04958c9875563c0da7fe7f05a53ea7d6f7bdb9f0dfe8e66c5d818f6b5b60f0c6a1ef08cf05ad25373bec1aaf00861622db65fd227833ab9f1b08b32026bfb6ea58a2a9e4607bb64d1f3b610949daeb53b5dedf2ca827a0515656ce2231b47725c2aeb6449a900274a31ba0002bd5528971eabbf588954e27e6e932b045fb3e0457e8732a2c02d9200b5053b8dff8669ddd1e32d408c8326a2bf2f47975bc41c8c97cb00bb645281e2819792c1c1c0a6d50385fc51f63e9fe76830d96f1d781c3f4e844099d35b8434ab9b600a72c010af45d4a86be79253a886e6041e53dc66bb4577aadbdcbb4a11c022618857b1a1481361813b95479675f984796447be8eb7eaab423657c64ef70099919be619e1389dda04b8dc2310253421ee8d6bab67cae015e93142a060e8b64d4d4a781eff069122943225c1ef66b9208219f7ae81e3187458b1b053844e5cd9d2631f8bdafbe4c6de339094d9886893a2c84f946dbc422dc62b654d4e7541bae016e3b7344c56f48adea8dfe0729cbb5a81c0d849f2e5a10accee3ac0d3e7727ee9cfd454b3a1001bde46fd9440ae2cfaaafc24d72f1728c05cdbaae1972dc621443cf71a1b20e719b29d8237c70a6317a2cd464479e70372b1da054a6a990b951758aecf2060a4d73b0cc86b33807727b6e1ded1c70f9438b62742ec0670945fe4a8c2148513d554e04e8fa2b474c823e91dfc777e6e508ef3ce6b4f3ae49f374ec7960abe2d1e07f480a6835f772d4ae9367fe7146930b8cd646607abbf526264ceceee555b07800d978388554fb552e931b72ae43a5d788574a277b52eb845d176b50cf8ea46e29701d8570fd37d13c2a9d861b3a603a1437efec9d3f735e31f07242069abfdca2266", "3f6b9f710f83a360846717a9679342d48e0464472f40bc663fbb00f7bac1b087aa091993ad5e3ae8aca1f397e6a107d72a98edc5911610cb88c372bf0d87eabcb26b46e8e020ac9ae44d2814c19fd848af4f841fe53a9a3ad27d22438ab19dc69faf76ad5708ea671e16850e9dca5667a7e7fe7999904ea65eafc4221b1fe62606633a602a6b1ee14da5d9c769d4c9b2daef14fa9e410ec173af5111f7694f2074a6ec738f50cd726e881b2a66c459fddd882a9f08010b83638a19aace8e9ae7144949410f56cc026528c1fb5b0ea73c592263866b4585fea29a3706eb7ee43eae795a7fda49134358b3b9b14f1764154010fba31fab598695479086b93b51c5db2ff95b003860ea3b0af08eb738222974b7f8c247eb2b711926f89f7083ae4fa97b0b552fb7a73fc05ba7de80016183b96343612ec15cc5f1027e9fc5f6a5e170422022c185271329f9777789dc6855928a373519dce815e173ab0849138692c58c87f63e065e635346b9822d987999bc8ce1bf0d9b376b16d4ca41fb0036b2577e1833bb2818edb8c6b65f57d4224961c6f87237262a2cd9646d39671caaf73be57a36ebfc3835cba701dd1adee1aaf8dd3bf152ae53b03e7e0e99d9cb1f4c161bd36017ccb2d051ed783f259b4f407f8bed1ed7026162685730e7e06c4256e87f2f82848a4951fc016526683758950bc4665efe2aecce789457d92db2520598aaccafa1d90c2b67ae5eac7357af718161fd11a85bdd89abc64985c70717542aa7ca31416f930c2c164a9ebad5008d9a2659c7c0425131a7de5cccfeabd7f08c0eac8e56c1522276802599f075c971b7849bfca5f08fff319d6cbca11df9fa8426e5bed0da595fd5fb94d5a44598708543e5a8190fb05355f3d0");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.341827938233171d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03506090028107785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(10.000001f, (-17));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.629395E-5f);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 127);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.4255844847533664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20.5381175232356d);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.1309659398685306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, (-727379968));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-1), 127);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-2083303935));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2083303935);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.02172004731721395d), 32.94631867978169d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6.592555721226109E-4d));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-10), (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5));

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "687dd3253fb04958c9875563c0da7fe7f05a53ea7d6f7bdb9f0dfe8e66c5d818f6b5b60f0c6a1ef08cf05ad25373bec1aaf00861622db65fd227833ab9f1b08b32026bfb6ea58a2a9e4607bb64d1f3b610949daeb53b5dedf2ca827a0515656ce2231b47725c2aeb6449a900274a31ba0002bd5528971eabbf588954e27e6e932b045fb3e0457e8732a2c02d9200b5053b8dff8669ddd1e32d408c8326a2bf2f47975bc41c8c97cb00bb645281e2819792c1c1c0a6d50385fc51f63e9fe76830d96f1d781c3f4e844099d35b8434ab9b600a72c010af45d4a86be79253a886e6041e53dc66bb4577aadbdcbb4a11c022618857b1a1481361813b95479675f984796447be8eb7eaab423657c64ef70099919be619e1389dda04b8dc2310253421ee8d6bab67cae015e93142a060e8b64d4d4a781eff069122943225c1ef66b9208219f7ae81e3187458b1b053844e5cd9d2631f8bdafbe4c6de339094d9886893a2c84f946dbc422dc62b654d4e7541bae016e3b7344c56f48adea8dfe0729cbb5a81c0d849f2e5a10accee3ac0d3e7727ee9cfd454b3a1001bde46fd9440ae2cfaaafc24d72f1728c05cdbaae1972dc621443cf71a1b20e719b29d8237c70a6317a2cd464479e70372b1da054a6a990b951758aecf2060a4d73b0cc86b33807727b6e1ded1c70f9438b62742ec0670945fe4a8c2148513d554e04e8fa2b474c823e91dfc777e6e508ef3ce6b4f3ae49f374ec7960abe2d1e07f480a6835f772d4ae9367fe7146930b8cd646607abbf526264ceceee555b07800d978388554fb552e931b72ae43a5d788574a277b52eb845d176b50cf8ea46e29701d8570fd37d13c2a9d861b3a603a1437efec9d3f735e31f07242069abfdca2266");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.227310932136778d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-2.97893201780539d));
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     double var14 = var0.nextWeibull(0.9999999999999919d, 4.5359460963350345E52d);
//     long var17 = var0.nextLong(0L, 3L);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var0.nextSample(var18, 0);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.0d, 1.0406823393269602d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-127), 1124);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2083303935));

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(13.801711757320268d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)13.801711757320268d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-0.49999997f), 9.094948E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.094948E-13f);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.4255844847533664d, 4.86927073907222d, 3.32964908430422d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var5 = var3.sample((-17));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1024, (-5));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(3.1861776233842214d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4714877841868557d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(31.501720002936757d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03225347902783931d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.28680180181229414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2830087616199811d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var0.getElement(4064528);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.06857547421121805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.99764962345751d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-16L));

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.427603063030133d, 0.8390715290764524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.5288105345286316d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(100, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(162.89837633952882d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     double var6 = var2.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.22056007056258d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(130048);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1401359.6943629924d);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed();
//     double var12 = var0.nextWeibull(1.2245129522199552d, 1.0963506818711306d);
//     double var14 = var0.nextChiSquare(6.232928512989213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01901555094517132d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.1112516376339919d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.703633656885639d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000001f);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.1726441408056698d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.09724295972011165d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03123733597590902d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(39L, 45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 39L);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(9.536744E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(101, 1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 128270);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(2147483647, 2083303935);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2083303935);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextLong(20518787866943904L, 36L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2032475803798962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.9827410916834551d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "eebcd4c3911fb02047ddecebd39ad54085edf12f944f190f684d1dbc8989c4724e7c0b6d92d99f95f4defbecc9507f60f146291abb2cf327409660b92b8aaef5e7a7dead5f4f8887fc3071686e0166bc6d165bc2be9750b0f95bdee20bf02c48ca2e57e7a06cbfaa9cfa8ce63d8601a623a0a75e050e2540e082bfe4abbc4ee4d5807d02decd63396359323c62e2eb6c76ec9e2949f9607e4b1226d84a081150054d8f3b20f90d91a9558a0a09fb6de5c550b03043069160c30dd71d4e56a4da6a58dcd3c5b550fa09ace2aabcbe59f2d06b8671ac22be3bfc13fe8811abc2b2f68a3590331cb01d7873b286f8ad4c1f97fd8c625db19ba7a3d56407f8d3694c4fabe9090561347b0f10d69ff72827d9ac60066a5e83ab9b0b681249aa11e46219513f2d8fe81fa10ef323fd99c8b896879c0edddb91dbd823d1a0e4db49acf610568d5b5c07c50e9f218cee8b7e8158a9cc030a58a8eb5612047cfd3a9a2aba1a1bc19ec12e123ce29415779707e97eed8f822ac4c1258db8ce5e5dd7863beff61baf68edba912a88320cc3c807ef7fedac7f0e0a2a61ea28d633ab111f9df3cb028577f16d27fbd8ebf9bb90a10526be6248665c86593f19023ec5a894776087c05717caedc56533204b6c718cda95eaa931cccf2f5e5ac13a38703a56628fba466163f5a9f389c95664719feafb287f6f47ce42148d5778327eaf7d493ebdda40dc4ca1d8453660b8697f839a17a50ae6d11189ef293ca5ac55b43dc1dec9a81575e36adfb5ba74eca9cd1b24cc928204280dfa25de9f820cf29c8041cd9d8f467e6200e9ad2f25e10a3ae91c2a94b11c010aed9bcd5b4324a97e524af9db6c6d119f43346dd5e632b2be5f0211ebce0c1826efb57ecb07a6be"+ "'", var13.equals("eebcd4c3911fb02047ddecebd39ad54085edf12f944f190f684d1dbc8989c4724e7c0b6d92d99f95f4defbecc9507f60f146291abb2cf327409660b92b8aaef5e7a7dead5f4f8887fc3071686e0166bc6d165bc2be9750b0f95bdee20bf02c48ca2e57e7a06cbfaa9cfa8ce63d8601a623a0a75e050e2540e082bfe4abbc4ee4d5807d02decd63396359323c62e2eb6c76ec9e2949f9607e4b1226d84a081150054d8f3b20f90d91a9558a0a09fb6de5c550b03043069160c30dd71d4e56a4da6a58dcd3c5b550fa09ace2aabcbe59f2d06b8671ac22be3bfc13fe8811abc2b2f68a3590331cb01d7873b286f8ad4c1f97fd8c625db19ba7a3d56407f8d3694c4fabe9090561347b0f10d69ff72827d9ac60066a5e83ab9b0b681249aa11e46219513f2d8fe81fa10ef323fd99c8b896879c0edddb91dbd823d1a0e4db49acf610568d5b5c07c50e9f218cee8b7e8158a9cc030a58a8eb5612047cfd3a9a2aba1a1bc19ec12e123ce29415779707e97eed8f822ac4c1258db8ce5e5dd7863beff61baf68edba912a88320cc3c807ef7fedac7f0e0a2a61ea28d633ab111f9df3cb028577f16d27fbd8ebf9bb90a10526be6248665c86593f19023ec5a894776087c05717caedc56533204b6c718cda95eaa931cccf2f5e5ac13a38703a56628fba466163f5a9f389c95664719feafb287f6f47ce42148d5778327eaf7d493ebdda40dc4ca1d8453660b8697f839a17a50ae6d11189ef293ca5ac55b43dc1dec9a81575e36adfb5ba74eca9cd1b24cc928204280dfa25de9f820cf29c8041cd9d8f467e6200e9ad2f25e10a3ae91c2a94b11c010aed9bcd5b4324a97e524af9db6c6d119f43346dd5e632b2be5f0211ebce0c1826efb57ecb07a6be"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.842047292493884d);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(35L, (-27326631));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 535514000795646464L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.99999994f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.007748145938530172d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8));

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(4.346069909771813E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(8L, (-56L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 64L);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.0917147927829527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.6068334162420739d, 0.6931471805599453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.25598053042381363d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.394517941340612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9499029663101612d));

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(3.247201896442588d, 7.516125731000207d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.247201896442588d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(20.5381175232356d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20.538117523235602d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.4905488366463986d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 85.4021574979734d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1L), (-56L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56L);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.2722646632737273d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(535514000795646464L, 35L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.06857547421121805d, 5.541569075991355d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6389524216021881d));

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(130048, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 130048);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.0f), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(4.9E-324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    double var15 = var0.getElement(0);
    var0.setExpansionFactor(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 3.0000000000000004d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(29.605465286259054d, 0.027472359321754035d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 29.60546528625905d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.07612931540406859d));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(8.014685878351596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7705079069914262d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(130048, 4064528);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextUniform(0.0d, 0.7316474682224906d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextZipf((-1), 0.09274653975152695d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.5058498297722527d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-37.47050046599331d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 231.79351285098048d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.1336955438798254d);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.23799934003749132d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(9900, 1.2207031E-4f, 8.0f, 291729791);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-100), 0.99999994f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1025, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than, or equal to, the minimum (3.306)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NoDataException var2 = new org.apache.commons.math3.exception.NoDataException();
//     java.lang.Throwable[] var3 = var2.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)9.332621544395286E157d, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var7 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var7);
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.004625354262543145d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextF(1.1377077104187023d, 201.7156361224559d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(3.427603063030133d, (-0.02172004731721395d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.25350497259446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-140.9879569549544d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9056402939564797d);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-0.7568024953079281d), 3.2296410968908655d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7155019267144769d);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var12 = var0.nextUniform(3.3900553644082354d, 4.723647519700551d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(2L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.009472092170526377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.704459979913892d);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)Double.NaN, (java.lang.Number)Double.NaN);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.2359321581335148d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8442914302025525d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var0, var2, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionMode(1270);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(3.6178058981865213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.641288354543516d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(29.60546528625905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 29.60546528625905d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-8), 8.0f, 7.6293945E-6f, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(2.281783181607902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.171384080773366d, 85.4021574979734d, 0.6104227919456581d, 2083303935);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0078125f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0078125f);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(8.590595999805713E106d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.590595999805713E106d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.023807852794796608d, 4.346069909771813E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.023807852794796608d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(9.536744E-7f, (-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.523165E-37f);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getElement((-10));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    int var14 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var15.setContractionCriteria(1024.0f);
    var15.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var24 = var23.isSupportConnected();
    double[] var26 = var23.sample(127);
    var15.addElements(var26);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    var0.addElements(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode((-5));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setElement((-17), 0.17936156675857706d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    boolean var6 = var0.equals((java.lang.Object)(-0.99999994f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(9.536743E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1124, (-27326631));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1124);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.24608028700641002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2412861326857803d);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.4036656746966349d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3836624416669226d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)6L, (java.lang.Number)(-948.6589633412129d), true);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3.0857950556867113d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.146128035678238d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.146128035678238d);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     long var11 = var0.nextLong(3L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation(0, 1024);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4346224465632589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 81L);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(98.78234435786233d, 0.8022140792099908d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 39.8253719986887d);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(3.3166247903554003d, 1.412848953997996d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextZipf((-100), 0.027468903747454535d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.7114447498771425d);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)0.038157775941106545d, false);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-27326631), 9900);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.2722646632737273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9971282080575165d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.005325222439319957d, 27.429134827355153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.005325222439319957d);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     int var15 = var0.nextInt(2, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextSecureInt(0, (-8));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3717990535017126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.120546939962123d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-279.4804900974584d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 9);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(5.761569390740933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.0d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 850355429512472704L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 850355429512472704L);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9971282080575165d, (-330.58873706391927d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.587644237017741d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.4714877841868557d, 2.0329713608269496E53d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4714877841868559d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.8412102988002852d, 5.183028998081309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.027505346892645402d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    var0.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var15);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)41.752984630466926d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.4714877841868557d, 4.283760323497615d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4714877841868557d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-2L), 99L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.7568024953079282d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.7549570184429867d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8555885738117186d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(191.8435074745319d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0364460231518503E83d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-10), 2083303935);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     java.lang.String var11 = var0.nextHexString(127);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var0.nextSample(var12, 2);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextGamma(1.8360738684267854d, 3.5743392688675386d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(4, 3.5480122537930616d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.183028998081309d);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)3.2722646632737273d, (java.lang.Number)81188.39044958311d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.0001683942492827d, 3.3176882611728495d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.29280070382754847d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.setContractionCriteria(1024.0f);
    var3.setElement(0, 3.0000000000000004d);
    float var9 = var3.getContractionCriteria();
    boolean var11 = var3.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    double[] var15 = new double[] { 100.0d, 0.0d};
    var3.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    double[] var18 = var1.rank(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.discardFrontElements((-5));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.5487448944692996d, 9.999999999999998d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.611012690880258d);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1124);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6776.136847418304d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)3.305530002646725d, false);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    java.lang.Number var7 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.305530002646725d+ "'", var4.equals(3.305530002646725d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 3.305530002646725d+ "'", var7.equals(3.305530002646725d));

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var6 = var2.cumulativeProbability(6.0d);
//     double var7 = var2.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.32415977361578d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("3f6b9f710f83a360846717a9679342d48e0464472f40bc663fbb00f7bac1b087aa091993ad5e3ae8aca1f397e6a107d72a98edc5911610cb88c372bf0d87eabcb26b46e8e020ac9ae44d2814c19fd848af4f841fe53a9a3ad27d22438ab19dc69faf76ad5708ea671e16850e9dca5667a7e7fe7999904ea65eafc4221b1fe62606633a602a6b1ee14da5d9c769d4c9b2daef14fa9e410ec173af5111f7694f2074a6ec738f50cd726e881b2a66c459fddd882a9f08010b83638a19aace8e9ae7144949410f56cc026528c1fb5b0ea73c592263866b4585fea29a3706eb7ee43eae795a7fda49134358b3b9b14f1764154010fba31fab598695479086b93b51c5db2ff95b003860ea3b0af08eb738222974b7f8c247eb2b711926f89f7083ae4fa97b0b552fb7a73fc05ba7de80016183b96343612ec15cc5f1027e9fc5f6a5e170422022c185271329f9777789dc6855928a373519dce815e173ab0849138692c58c87f63e065e635346b9822d987999bc8ce1bf0d9b376b16d4ca41fb0036b2577e1833bb2818edb8c6b65f57d4224961c6f87237262a2cd9646d39671caaf73be57a36ebfc3835cba701dd1adee1aaf8dd3bf152ae53b03e7e0e99d9cb1f4c161bd36017ccb2d051ed783f259b4f407f8bed1ed7026162685730e7e06c4256e87f2f82848a4951fc016526683758950bc4665efe2aecce789457d92db2520598aaccafa1d90c2b67ae5eac7357af718161fd11a85bdd89abc64985c70717542aa7ca31416f930c2c164a9ebad5008d9a2659c7c0425131a7de5cccfeabd7f08c0eac8e56c1522276802599f075c971b7849bfca5f08fff319d6cbca11df9fa8426e5bed0da595fd5fb94d5a44598708543e5a8190fb05355f3d0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    double[] var4 = var2.sample(99);
    double var5 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var0.copy();
    int var4 = var0.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.011993192308645845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999280825311608d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2, 2083303935);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(8.711278612018845E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000000000379432d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var0.getElement((-8));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var6 = var5.getElements();
    int var7 = var5.getExpansionMode();
    double[] var8 = var5.getInternalValues();
    var4.addElements(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     long var8 = var0.nextPoisson(0.06857547421121805d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2100037926629676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0064611056898412535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(2083303935, 100.0f, 10.0f, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(24.013235187792638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.3376070089627754d, 3.1132389726050125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3376070089627754d);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-127353.53036079442d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1124, 5.9604645E-8f, 7.1054274E-15f, 130048);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(9900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9900);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.2296410968908655d, 3.0185015619418953d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4730946691978376d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.8390715290764524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9431910296713536d);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     java.lang.Object[] var9 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)3.233351086493488d, var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var9);
//     java.lang.Object[] var12 = new java.lang.Object[] { var5};
//     org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var4, var12);
//     org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)1.1749304202020776d, var12);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var12);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var12);
//     java.lang.String var17 = var16.toString();
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double[] var3 = var0.sample(12700);
    double var4 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.03123733597590902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9647639020111903d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    boolean var6 = var2.isSupportConnected();
    double var7 = var2.getSupportUpperBound();
    double var9 = var2.density(0.9999963726652458d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-2L), 884124501032112256L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2L));

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)4.0d, var2, (java.lang.Number)(-7.262980904399892d));
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(99);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.substituteMostRecentElement(3.689149036074892E-4d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.03225347902783931d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var20 = var0.nextBeta(5.282094375738045d, 3.5480122537930616d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var0.nextHypergeometric(9, 1025, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2994277424440557d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.00477509126543047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.8726614433760898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.262994789044818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 44L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.5300949285604557d);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(3.4496806839002896d, 0.5529915507320138d, 3.3166247903554003d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    int var3 = var0.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.substituteMostRecentElement(0.03225347902783931d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(850355429512472704L, 46L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.7081386520500382d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.6032975776636309d), 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6032975776636308d));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(130048, 1179);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(80674.34799462138d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 80674L);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2083303935, 2083303935);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-2.654150622549162d), 0.9973002184105607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.2113672537263271d));

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeedSecure();
//     long var18 = var0.nextLong(3L, 18L);
//     org.apache.commons.math3.distribution.IntegerDistribution var19 = null;
//     int var20 = var0.nextInversionDeviate(var19);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.5743392688675386d, 1.489663623435252d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)2.9999999999999996d);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, 0.07902415835395639d, 3.6178058981865213d, 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-8));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(27.429134827355153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.5024195390363198d, 1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(5.761569390740933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7512099012666158d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2, 291729791);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 291729791);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(127);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 491.5534482232981d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7L);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.0035555880210079d), (-7.262980904399892d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0035555880210079d));

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(81188.39044958311d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0078125f, 1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-16L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode((-5));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-535514000795646456L), 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-535514000795646456L));

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     int var7 = var1.nextHypergeometric(4064528, 1024, 0);
//     long var10 = var1.nextLong(3L, 535514000795646464L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var1.nextPermutation(128270, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 386825675298621312L);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.2830087616199811d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16.215207606048914d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.023202279252666963d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9997308391941973d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(9.094948E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0842022E-19f);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.3055624425443724d, 3.461767687323154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6057997097623945d);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeed();
//     int var20 = var0.nextPascal(130048, 0.03097415474563565d);
//     double var22 = var0.nextT(4.08146646114519d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.012950351706914819d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.0460227205454609d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "ec9928beff9cf6705a87acfaf1f4922bb3bfedadbb2347ca1781a1e85f12780566c51861ff1226d92400afd719f1cfbf6be66c94182dcb6c2f4087fbe2b42627b0b3037336c70f1c4177a7e29c5fee7d99e1a4eb9a3dc79423112ca3210fa9d4e3eecd7bf72de46a73c7ea8cb19734ec01ad66c50cb9b728ff17977f0ae615e9144048baa05b63c7de363ad19749a6c71f914d0314b3e59b562e1414d46d8bc84575c643d60d0b2f17ac05e11691eac1657ea472cd2d37521315228575f014ae95b8367d718d62d3d5c2b5544c52fb231f0db95ac1be80773d49e645dd6aef74719254622947f21535c4e032d00b5a7d723a204348c80897fbfcb06cf3e024ad5e3f2f6ce305e26bf54f53e49a697700bd3a4cc90a030285b27bb5f892099c8912eff7e97add7e0b3ebd8951135edd7f5f0cbee183e9fe4553cfe60431aee4d4021339d8079e0ece207cf22b79a58c3b2a5a999fa81f364e279227ddadd74f7cc70b41acccf77b90f0ceae353bcf34849d8d760fd20bf268bb412f9879e11f0aad7e1ab359f0e4af4495780fe38a4229c52605d73669bceb2d070a01d1ce0318777ecfb7e7bb870c5fd255b410ea8fd9f9c65c673cdf96b236c38e6b9c7fb3c7a3ed47656812ed166ff379a555b1357f2852c107ac4f4e5ba9fc825131320c66ffe890fd8f544cd9cd17676bf1ea3dbd2e2d440f7e60d2f64e057be77d32ee38ed7b612a012b1bba936735bb022ecda53d6838b8d5ca6064f858a1e0fb9f46780aa461ac867cc4a557c92071eec714dd4bde87de200b04f83b83c5f83c36138af35016b81ac82ac8f4657117a20a0c9b492fb4104c83eeeabf7fdad337a924136c65a3da540d59c8d95c8a66fda98172fd88f1a9ea296158bbbcfc"+ "'", var13.equals("ec9928beff9cf6705a87acfaf1f4922bb3bfedadbb2347ca1781a1e85f12780566c51861ff1226d92400afd719f1cfbf6be66c94182dcb6c2f4087fbe2b42627b0b3037336c70f1c4177a7e29c5fee7d99e1a4eb9a3dc79423112ca3210fa9d4e3eecd7bf72de46a73c7ea8cb19734ec01ad66c50cb9b728ff17977f0ae615e9144048baa05b63c7de363ad19749a6c71f914d0314b3e59b562e1414d46d8bc84575c643d60d0b2f17ac05e11691eac1657ea472cd2d37521315228575f014ae95b8367d718d62d3d5c2b5544c52fb231f0db95ac1be80773d49e645dd6aef74719254622947f21535c4e032d00b5a7d723a204348c80897fbfcb06cf3e024ad5e3f2f6ce305e26bf54f53e49a697700bd3a4cc90a030285b27bb5f892099c8912eff7e97add7e0b3ebd8951135edd7f5f0cbee183e9fe4553cfe60431aee4d4021339d8079e0ece207cf22b79a58c3b2a5a999fa81f364e279227ddadd74f7cc70b41acccf77b90f0ceae353bcf34849d8d760fd20bf268bb412f9879e11f0aad7e1ab359f0e4af4495780fe38a4229c52605d73669bceb2d070a01d1ce0318777ecfb7e7bb870c5fd255b410ea8fd9f9c65c673cdf96b236c38e6b9c7fb3c7a3ed47656812ed166ff379a555b1357f2852c107ac4f4e5ba9fc825131320c66ffe890fd8f544cd9cd17676bf1ea3dbd2e2d440f7e60d2f64e057be77d32ee38ed7b612a012b1bba936735bb022ecda53d6838b8d5ca6064f858a1e0fb9f46780aa461ac867cc4a557c92071eec714dd4bde87de200b04f83b83c5f83c36138af35016b81ac82ac8f4657117a20a0c9b492fb4104c83eeeabf7fdad337a924136c65a3da540d59c8d95c8a66fda98172fd88f1a9ea296158bbbcfc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12.289789136661126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 4066573);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-4.293613635393813d));
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.7871088143391114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7343516762351687d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    boolean var6 = var0.equals((java.lang.Object)(-0.99999994f));
    var0.discardMostRecentElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.substituteMostRecentElement(2.0917147927829527d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.1409651890262005d, (java.lang.Number)98.60049196142404d, false);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 58L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, (-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3L, 16L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19L);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.String var17 = var14.name();
    java.lang.String var18 = var14.toString();
    java.lang.String var19 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(30.48232336227865d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4840480658487383d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(8.193092887159683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextWeibull(0.0d, 9.332621544395286E157d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.013501597096808652d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.8118705260095422d);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var5 = var0.nextT(0.8390715290764524d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextZipf(0, 0.023202279252666963d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.4244265640742135d);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-1L), 437317876998765120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-437317876998765120L));

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-127), (-0.49999997f), 1.2207031E-4f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(6L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException(var0, var1);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.984925048774637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6776111866603864d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(3.305530002646725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.16320402005311493d));

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(99L, (-56L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 155L);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(80674L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("MAXIMAL");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(3.2695135139523783d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05706377575691857d);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.3376070089627754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9160084765308957d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(Float.POSITIVE_INFINITY, (-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(7.523165E-37f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, (-2083303935));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.10170633440773788d));

  }

}
