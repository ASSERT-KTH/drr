
import junit.framework.*;

public class RandoopTest6 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test1"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(127.0d, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.464389127721526E-37d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.9737836962784687d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.973783696278469d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test3"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, (-31.863965778894688d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-31.863965778894688d));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(40767, 0.49999994f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test5"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    var0.clear();
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test6"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(100, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25.949484949043022d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-4), 4066573);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test8"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1010, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1010);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     int var10 = var0.nextZipf(1, 0.38805925492513493d);
//     var0.reSeedSecure(45L);
//     int var15 = var0.nextZipf(3, 97.97198016599408d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextSecureLong(0L, (-8568224012730343296L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test10"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(99990000, 1253);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(98.46394980830692d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 98.0d);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test12"); }
// 
// 
//     java.lang.Throwable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var7 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)3.233351086493488d, var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var7);
//     org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var2, var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var7);
//     org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var11);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test13"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(14.344651159851056d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.750282948470202d));

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test14"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(321, 9900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-520980735));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test15"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    int var10 = var2.ordinal();
    int var11 = var2.ordinal();
    int var12 = var2.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test16"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(10521.341352945761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test17"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.9227843322079321d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test18"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0f, (java.lang.Number)var4, false);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 58L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 2);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 850355429512472704L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 8);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var19);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 4064528);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test19"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.2230357805130138d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test20"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    double var6 = var2.getNumericalMean();
    double var8 = var2.inverseCumulativeProbability(0.0d);
    double var9 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     java.lang.String var13 = var0.nextHexString(1025);
//     double var15 = var0.nextT(1.1336742313097214d);
//     int var18 = var0.nextZipf(670, 2855572.904500886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0071859307175064615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.12620658621490477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7678825771538214d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "d90181b991257ac423ea94824dcb1f450fa7f1bd6d150c78634d8683595fca10622a494cdab21347944d630042163a2131c9641cb2f6627bae8695fa495d70738d1e904d948025370674a2722ac8d58c8178ac1b674d42ad256b23b993467925d77dbcd4b9a07450103fe08e7900fe217c43878746ae18c9c123f22b9c39a6fe7ca60b76aff1e1c986502ac2afbbaecac925fc05ae2994b4f66399ac9b1edf130d54208025058f39cfc1827beb8a620e98cc3875e00acd8dfdbc1ae5097a97b5a74c0f66bd052451f00064c9cdd270438b5d725c2e6c64eff3b99e903e9d4a4c6d9582d700f5057df571bc9d4824959dad7ad400c8b86c17478085ad7a70b05741a86b45433eef29cb52d600615780ecadb07e08b1d5f25db528b698d25e6e05084759740629afcec1047c5c9d2fac21f5b03d50b4dbe9c92472bc7ed556deec30de0de4ecb0acd275ac155ea9ebb48e00b460e782b504cdff8c1f7ed25fb39db96b69dc6b04fbf07ade3696691c5fb67962473ea97942ed62c0c14fdb0c6e3d9061999a3c3e84d8ecc9c2a22c8875e02321c049059f865706b29101c9d4bc197d1a83d500fe4dfac7914d06ad3a1d948f2dd0c4e17ece721260a428e1cb6a07a42a3f3b209cdbcd7e9d8e63cdd5e235dc7d3985154952d6da5a6ca7a02c4bd9214a94c9d0eb35983b2b7c5e918376e2a9da53e9b81049b9132e8e06236ee623c"+ "'", var13.equals("d90181b991257ac423ea94824dcb1f450fa7f1bd6d150c78634d8683595fca10622a494cdab21347944d630042163a2131c9641cb2f6627bae8695fa495d70738d1e904d948025370674a2722ac8d58c8178ac1b674d42ad256b23b993467925d77dbcd4b9a07450103fe08e7900fe217c43878746ae18c9c123f22b9c39a6fe7ca60b76aff1e1c986502ac2afbbaecac925fc05ae2994b4f66399ac9b1edf130d54208025058f39cfc1827beb8a620e98cc3875e00acd8dfdbc1ae5097a97b5a74c0f66bd052451f00064c9cdd270438b5d725c2e6c64eff3b99e903e9d4a4c6d9582d700f5057df571bc9d4824959dad7ad400c8b86c17478085ad7a70b05741a86b45433eef29cb52d600615780ecadb07e08b1d5f25db528b698d25e6e05084759740629afcec1047c5c9d2fac21f5b03d50b4dbe9c92472bc7ed556deec30de0de4ecb0acd275ac155ea9ebb48e00b460e782b504cdff8c1f7ed25fb39db96b69dc6b04fbf07ade3696691c5fb67962473ea97942ed62c0c14fdb0c6e3d9061999a3c3e84d8ecc9c2a22c8875e02321c049059f865706b29101c9d4bc197d1a83d500fe4dfac7914d06ad3a1d948f2dd0c4e17ece721260a428e1cb6a07a42a3f3b209cdbcd7e9d8e63cdd5e235dc7d3985154952d6da5a6ca7a02c4bd9214a94c9d0eb35983b2b7c5e918376e2a9da53e9b81049b9132e8e06236ee623c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.5772769577312322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(4.040832693848323d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6175712854698436d);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextCauchy(0.0d, 2040.3837802863068d);
//     double var13 = var0.nextExponential(3.1132389726050125d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 623);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test24"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(17.991600914693997d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.233046508298208E-143d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test25"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var11.setContractionCriteria(1024.0f);
    var11.setElement(0, 3.0000000000000004d);
    float var17 = var11.getContractionCriteria();
    boolean var19 = var11.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = var11.copy();
    double[] var23 = new double[] { 100.0d, 0.0d};
    var11.addElements(var23);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    boolean var26 = var0.equals((java.lang.Object)var23);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var0.copy();
    var27.addElement((-0.9314281945454969d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test26"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextCauchy(0.0d, 2040.3837802863068d);
//     double var13 = var0.nextExponential(3.1132389726050125d);
//     double var15 = var0.nextExponential(100.7122747073287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3347298275149213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15.386899982606833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-8463.233736153323d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 11.713432871215137d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 181.0083260947179d);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test27"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.setContractionCriteria(1024.0f);
    var3.setElement(0, 3.0000000000000004d);
    float var9 = var3.getContractionCriteria();
    boolean var11 = var3.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    double[] var15 = new double[] { 100.0d, 0.0d};
    var3.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    double[] var18 = var1.rank(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setElement(5, 0.3845071169264922d);
    float var23 = var19.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test28"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1099, 1179);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     double var13 = var0.nextGamma(0.027468903747454535d, 0.4036656746966349d);
//     double var15 = var0.nextChiSquare(1.6224247951349726d);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextBeta((-0.0015415340722212366d), 1.1726441408056698d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3032583477662256d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.1732845725752465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1844123836172259E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6102681742310754d);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test30"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-8992), 1024.0001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test31"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     double var12 = var0.nextGaussian(1.0001683942492827d, 4.81548573505896d);
//     long var15 = var0.nextLong((-8568224012730343296L), 0L);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var0.nextSample(var16, 618);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test33"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportConnected();
    double[] var5 = var2.sample(127);
    double var6 = var2.getStandardDeviation();
    boolean var7 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test34"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(101.32486090663886d, 1.6713364782464966E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000000077187865d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test35"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(941, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.999675834289484d);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var19 = var0.nextChiSquare(3.4496806839002896d);
//     double var21 = var0.nextExponential(3.14595944790464d);
//     int var24 = var0.nextZipf(680227, 80596.80471926239d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.8437256982613834d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.008322158875702625d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.074575632158176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.625140335916251d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 35L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.736271164199577d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.3093797694681212d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test37"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.7236461218218848d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test38"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NoDataException var6 = new org.apache.commons.math3.exception.NoDataException();
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)9.332621544395286E157d, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)5.262179821628377d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     int var10 = var0.nextZipf(1, 0.38805925492513493d);
//     var0.reSeedSecure(45L);
//     int var15 = var0.nextZipf(3, 97.97198016599408d);
//     long var17 = var0.nextPoisson(2.706533175782903E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextHypergeometric(19430, 2, (-785605899));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0L);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test40"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.2381864063067494d, 6419.031468911137d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test41"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.9999039343116616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.46350505080872756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4635050508087276d);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy(3.0d, 0.8390715290764524d);
//     double var11 = var0.nextGamma(0.22788969386187025d, 0.06857547421121805d);
//     double var13 = var0.nextT(1.0102809869206864E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.199087453820337d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 23.58416956547804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.7745946627379667d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0013049399254999056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3407807929942597E154d);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test44"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double[] var3 = var0.sample(12700);
    double var4 = var0.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test45"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test46"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("69edf03da95d455d35c06f9275120ff5ad761ccf1206604457deddc19e60dd8276e5c5d72e427a469c2b04f26c04360c7aa1d09dab49dee690b9fb919293bec");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test47"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.2622146137297445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test48"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)7.629395E-5f);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test49"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.950581586494586d), 219.8181462454294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test50"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(3.459756744893044d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test51"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    int var6 = var4.getExpansionMode();
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var4.substituteMostRecentElement(3.0927921673007823d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test52"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(73737L, 5594589197447221635L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5594589197447295372L);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.005325222439319957d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.005325247608412166d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test54"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(99990000, 129);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1874.9895418649403d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test55"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 27.12061425361551d};
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var4, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var6);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var1, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(100.57860120573436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.304111416201575d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test57"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-127), 1253);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test58"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.15945342209332286d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.136008114865476d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test59"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(9, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test60"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.015704685053792435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4056.223021511559d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test61"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test62"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.30903939704698563d, (java.lang.Number)0.274381943317341d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextF(0.6104227919456581d, 0.9780959384763808d);
//     double var11 = var0.nextF(3.301994448166912d, 1.7746100167139231E52d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.226139957689864d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.6056945377530676d);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test64"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(7.7668954541513795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test65"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)0.29074983096826307d, false);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test66"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.2759086387217901d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.24111773995252417d));

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test67"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { 27.12061425361551d};
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var4, var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var3, var6);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var6);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var1, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test68"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.1950114037185906d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.161590657062124d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test69"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    int var11 = var10.getNumElements();
    int var12 = var10.getExpansionMode();
    int var13 = var10.getNumElements();
    int var14 = var10.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test70"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var9);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)3.1936453631680304d, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test71"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var12 = var0.getInternalValues();
    float var13 = var0.getExpansionFactor();
    var0.clear();
    double[] var15 = var0.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var0.getElement((-10238021));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-3.6948294002049735d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-211.69813065259837d));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test73"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    boolean var20 = var12.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var12.copy();
    double[] var24 = new double[] { 100.0d, 0.0d};
    var12.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var37 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var39 = var26.equals((java.lang.Object)var38);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var38);
    double[] var41 = var11.getInternalValues();
    var11.addElement(0.0d);
    double var45 = var11.substituteMostRecentElement(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test74"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8772679019046061d), 78021.47903283725d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test75"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1794L, 73737L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 75531L);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test76"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)3.305530002646725d, false);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.NotPositiveException var8 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)130048);
    var5.addSuppressed((java.lang.Throwable)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.305530002646725d+ "'", var4.equals(3.305530002646725d));

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("aeaefe04ebc57f8638bede69f2eafb67f039716fa8361ec5c22749dbdde2c94cb9449f9a2c5edd3bff24102881101b16add2cfacdf902609825bfa61a22b3e7035b35f3ab76151391177ea6ba73279c1f7871a5371de68a773c28940a4c9fc80ee63667a198dad24a29b6b92598fda9b216b753a63d6377909dd09103ae33cfc363202c17aae1081711717298b0d27d405a9233c43549b6a5f04fe5788780c23a7dc8c999e8f254efd2ee7dcb97316ab4d3227d54100799360999b5bb6708ad85d3973c632b693edbd57c50d5a89e459ed35edc6161ba385f4656bd6fdbaa0fc67d6545f7003738c72f44ae2bbfda84e56fb8cbdfc8706991387e954dadaa5124269ddce96aa5f316df02d01dabe4ed29dd9058cef8bb4b4e4b72b8c0761157e4d3d225b78551e2efe1bdb0279f3127057d04830d2b1c3424a71298a46cb80602252f5614a967c8be7593502d1fbc4ad6d431684b4ee9930472d9f915407515d8e38520e4dc802b154d74ea7b77f58f4dc27a640537882e7a01b75b54b1dc8877b785893413662bc0245ff65e3db8c28877772ae0d3719315e9f02e8cdd01e67c582cb815c1125e5832e60db47f02e1e5f75069c780d1e01a07e1de34d278add2afa3c8302134f84114f9480e4857e2c9c5b29ff99b567cbb6f50d2a892abcbacdb92b7d45982a1e187d36a5640d445828a2a49a94f00c4bf73670dbd5ab52726221ec5b86fc31755db8e77cb3505c80d0d9822ec16de64db898a385614132e9772257311a81aaf836e8e84495825f2439b06ccefd9a340343aefa08828ce0d5ce37a74bfba8e327c580a8bfe1acea1ef1a9f85052c5b22958b68e4618ff688b20f03f17228ac30bdcca9b8e056da69163c4bf76f500f5edcea31b");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-6.632574559050144d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.34232402341118245d));

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test79"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(535514000795646456L, 535514000795646456L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test80"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    boolean var8 = var2.equals((java.lang.Object)4.1495472005154115d);
    int var9 = var2.ordinal();
    java.lang.Class var10 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var12 = java.lang.Enum.<java.lang.Enum>valueOf(var10, "9132d9694c5b90851ae2c3e4143b3a884365f28c7613d71c4098c24630cfd21e598826875f2fcb9a79c3d078ac5241d183988f39d8b2fc8f30441e87796f328e6f0630488dc56866391426b29486b59a2fe7d60f0342616a2b24f721d39cc072bf0d4ccbda748d1e219b5ae04ce9180853561bb0986137d9693f247d9bad54e36bf559158756e96da1ea0456c5544d3b78a515ac9f5e5fbcd3ba6da7a1a00dda740bde85cfcbd5fb499d2d6f812536e641408fee8310c7ff279ff8a8722d4b88b3a1ecdcb824331c3742a632af4faa1467dac491d2f6e64272eb10e9af259c88db63ae885a7852028f3298977aa53599ec6e1984377e105f47121899686ec62e900b16fe662f8b69ebb2c116d181de076d7616197b2718ffa0534ff3e8ba6b744e638b34e64d685ec817b9ef3833be24bceaacdabe2a1490070e83399be51d773d70c2b8a3a2c32b5d20f35ca56492afbee0e98a0a440c4434d2de0b052c976f9ec03ac0954e2341e5c8ecf204ccb1aacc01ad264ceb80bfca2218649142aefb9e4ee8c66e99d0fb3a0280eeb889e52776c6d4ddc09a92a1f6af559042ca7504c6eada5750d22724ca319538a5cd603016f6583736dc7a3751506444576b744c1d5f7e442ecb29601065b66ea24558bc3f0de7cfc8246ad9a220f2a627371222069957eae220e907c59c7ad9c75c7483cb6fd3ff94cd28318f7b4cc938db3ad49cdca64fbad0de3f915c8b7afa4c25a2486bae1734730ceb1fd7bd89f235bf9b9e6f0416818b883df715b6f80ea899635d71eb8ce4c6fe339570c279166b05d01b081b144d7560f03f399a7e4aeaa409297f289076bc94f1ad14c50d1f4b017e05fa81c92c1b02544abc2b2f9cf50a7ad16064a92dbbb819ff5285");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test81"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var4 = var2.getNumericalMean();
    boolean var5 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test82"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooLargeException: 99 is larger than, or equal to, the maximum (1,024)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextF(0.6104227919456581d, 0.9780959384763808d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.226139957689864d);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test84"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.1970105693253613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.581875192516645d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test85"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(6.938893903907228E-18d, 3.2116680910860644d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.928828434834408E-20d);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test86"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.870162609038243d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextGaussian(3.2132396021992005d, 0.17936156675857706d);
//     double var12 = var0.nextCauchy(3.7252681214586643d, 3.1936828330503824d);
//     int var15 = var0.nextPascal(41, 0.33216015558007217d);
//     var0.reSeedSecure((-2L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.187634407318972d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01747363490634848d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.074028110998192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.4467605169581064d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 86);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test88"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 58L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 58L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 2);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 850355429512472704L);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 8);
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 58L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 2);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, var26);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 155L);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, 2083303935);
    org.apache.commons.math3.exception.util.Localizable var36 = null;
    java.math.BigInteger var37 = null;
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, 0L);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var39, 58L);
    java.lang.Number var42 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var44 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var36, (java.lang.Number)var41, var42, false);
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var33, var41);
    java.math.BigInteger var46 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test89"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(623, 8184);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8184);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test90"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.7205001824963826d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.7081386520500381d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6593212625817835d));

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test92"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(1.5707963267941214d, 0.005307422838786435d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test93"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.008772664288256161d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000384800661406d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test94"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.074575632158176d, 28.328185538980232d, 1.0031992654415178d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test95"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(3.0841429669768945d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.455609341102267d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test96"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.cumulativeProbability(80674.34799462138d, 0.09272622225462313d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(5.863439728021239d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4214540524282593d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test98"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(129, 751);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 751);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test99"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.094948E-13f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test100"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var9 = var8.isSupportConnected();
    double[] var11 = var8.sample(127);
    var0.addElements(var11);
    double[] var13 = var0.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test101"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "1ba5fbde505b375f2f4da3f7b7a76a616d352dc6d5e5201754d9cf7062cd0d853abac052dbf16f31ac4cad4e9a31509259f74ff0074b5e2956e80f626fee6838272814a725121f5eb3448f88ac6f6488c586425c33629dd4734113b9cdc4d571db23fef2daa8ca9b900d00365dcf65c5d975d12887ccd261e486184a8ee4462979df8ba25f93cff994c9ede6c9ce3b1364bb679afdfe0c35276e0fc77d6706ba12a253fa7c739c18b26f9857a04276d23d122523c28719f6d30bf6569807007ce8f61fd0fb8ee71341d4d0693d21b3953bfaff8b3ffedb943e312557767787af05d10f11aea063fc4e5bc98e9ed971510930209846e89ebf306036cb3985a647b6b962acd130f60da3e8f008a4b2d49774a1ce68f61c5a73e9efe3ac5109e89d17aea20160feaa67e1697bd3d0c80fc07550bb38d2220978c964fa89bddebe945a8929bac40929c9dd7bef71b29fe8b1ca10d20efd9a97c1db60d1d550dc9517e45418eb5f716b4eed0322cfdb96abc64f7282988dd0f499095c2e75c5eb2e345a7efef9aac20e7508bdf45f158368a8d0a5e16dcdcb35c105f4635ff72dd212ebe6f21e0dac4e9b7f41c1c4094485b97f3ee29e2718b56e0793e44fd1ba655530175f019b844149e6382286f878944b820ab094a95c8605321657dd37afd687ca24dce39590549284cc74713a965c34ba6b32cad57201b12217bd14a9f4d9945bfd90093def8aadea161a99842d8473ed888b294fc039851025b73843f794bb0d28eaa0db977916f3e4576d72e00b5d01ee4a6d57466f5fc18410ace00cd0353b9348141868f8b7458cd07e32e48707fffb536524b5742a2f283ff05952506828e194552106757fe443decf700fb40f87754de06d5f4db1e4b7c0");
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test102"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.7628193343349245d, 2.1734929141759232E16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1734929141759232E16d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test103"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.425947759839367E159d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test104"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(9051734712261706624L, 43L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 43L);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test105"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.641606458128386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8742055143083846d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test106"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 58L);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 2);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 10L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 5L);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var21 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var13, (java.lang.Number)1.0f, (java.lang.Number)var17, false);
    java.math.BigInteger var22 = null;
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 58L);
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 2);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 850355429512472704L);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 8);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, var32);
    java.math.BigInteger var34 = null;
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var34, 0L);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, 58L);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, var36);
    org.apache.commons.math3.exception.OutOfRangeException var40 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.287776849500193d, (java.lang.Number)var10, (java.lang.Number)var36);
    java.lang.Number var41 = var40.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + 3.287776849500193d+ "'", var41.equals(3.287776849500193d));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test107"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.6056945377530676d, 7.370405536544812d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.6056945377530676d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test108"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var1 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test109"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.536744E-7f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy(3.0d, 0.8390715290764524d);
//     double var11 = var0.nextGamma(0.22788969386187025d, 0.06857547421121805d);
//     double var14 = var0.nextWeibull(0.8044731591362173d, 0.022508601831614856d);
//     int[] var17 = var0.nextPermutation(321, 4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("AVERAGE", "80003bfa100420754a5c172b3d15d4baa86b452cbf24fe4ea70809cdcaff4223075c602f395e8523b824c6a9b35a2b114b88463623a999562736cec8407e3544398e0328c23d564599fdd005ef94b35b7673062aacf36e883c40760a3bc02da1c5b7da8fc21690e22c53ea74f8473e69a3e13b1b8b1f3117b08c6e8e818bab0c88585c7e66330363f68acb3725dc48203e3e38ae607394cf541fb3362dd7c2cddf776b1b03e194036da412600c94dec1202257fd85922c815f61cabdf030c33fc00cf29b662f080565904a16aedc3c5b23375370928ccb9e094e942a9bb02e6166866be02c38b8fcb54b6335e65ff3cbb0c229f5541010b57a6a19287f3d3d92a3be90e17f9d8ce051e13610c50713eb90212fbc77401f3fde79d48fef4f6082451fe39dfa58f2b5ce4624c39af1558807e0c71c349d12f4ed1d034fdea98edc2c1e41b513a90c8c73ea784a5048eacef99d36520b0e38931cdfeecc7d569789c697edbd8d95c5cd0cd5a2a760e3aa59187e7cbd293b996a55a09caebf8aea18f04dfa4f456de821d07fc282d8ff7ee030459bd794727d005be0ac5e3e2e7f1304a73e4ad926b5cfe40685814ef9f216111490fa7cd7aab05788dccb1c19d135304af9c2c32412902c7bf0f78f54c0f1a37d1485cc80ec2cc1f34b3e830397e6b6dea60714baac658ae09839ff443e834b25690a62e8624205a36d5adc7652364");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4795827490049573d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-53.00412141983184d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.502037552935409d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.0665001775334164E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.005795040306954023d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test111"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(3.2061932951262935d, (-1.7503775036344438d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0705143096325034d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test112"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3841858E-7f);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test113"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)15.324021276261647d, (java.lang.Number)(-0.011043391284980018d), (java.lang.Number)2121.4185729849014d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test114"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.35673251118415d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test115"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.004997851075629565d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test116"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9998078778519396d, 0.020382238871254087d, 5.672005667328684d, 1019);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.019987574442318388d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test117"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-2083303935), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2083303935));

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1531225969699204352L, (java.lang.Number)(-1623574463), (java.lang.Number)14.014111025031722d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test119"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    double var4 = var2.cumulativeProbability((-3.4657978658285428E-6d));
    boolean var5 = var2.isSupportUpperBoundInclusive();
    double var6 = var2.getNumericalMean();
    double var7 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test120"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    boolean var6 = var0.equals((java.lang.Object)(-0.99999994f));
    var0.discardMostRecentElements(0);
    var0.contract();
    java.lang.Object var10 = null;
    boolean var11 = var0.equals(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(79224.29970660231d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.280050967532116d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.1132389726050125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1132389726050125d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test123"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    boolean var20 = var12.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var12.copy();
    double[] var24 = new double[] { 100.0d, 0.0d};
    var12.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var37 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var39 = var26.equals((java.lang.Object)var38);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var38);
    double[] var41 = var11.getElements();
    float var42 = var11.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.discardMostRecentElements(4064528);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1024.0f);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test124"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-8.715340095278876d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test125"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.29861131299342814d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test126"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)(-0.004625354262543145d), (java.lang.Number)3.5321218005364248d, false);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.5321218005364248d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test128"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.9999999999999996d, 1.1749304202020776d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1975145446980184d);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeed();
//     double var19 = var0.nextUniform((-0.6836289098502112d), 3.0d, false);
//     double var21 = var0.nextChiSquare(1.0963506818711306d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextF((-0.2745173498669733d), 2.285466362193911d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.560342392662298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.009742947746461793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5459905882079249d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.057765392576053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.8752746459166936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.17220880064143482d);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test130"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double var16 = var14.addElementRolling(3.5321218005364248d);
    int var17 = var14.getNumElements();
    var14.setElement(130048, 6.152568171329303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test131"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(4064528, 75157);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test132"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(751);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    boolean var6 = var4.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var9.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double[] var14 = var9.getInternalValues();
    double[] var15 = var8.rank(var14);
    var1.addElements(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test133"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test134"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooSmallException: 3 is smaller than the minimum (0)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test135"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var4.clear();
    int var6 = var4.getNumElements();
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test136"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(2, Float.POSITIVE_INFINITY);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(4.1495472005154115d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5335917623466878d));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test138"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    double var4 = var3.getMean();
    double var6 = var3.density(363.7393755555636d);
    boolean var7 = var3.isSupportUpperBoundInclusive();
    boolean var8 = var3.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test139"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var5.setContractionCriteria(1024.0f);
    var5.setElement(0, 3.0000000000000004d);
    float var11 = var5.getContractionCriteria();
    boolean var13 = var5.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var5.copy();
    double[] var15 = var5.getElements();
    double[] var16 = var5.getElements();
    double[] var17 = var5.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    double[] var19 = var4.rank(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.4802139752840215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test141"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test142"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.3900553644082354d, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3471.416693154033d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.8655703585904524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.865570358590453d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test144"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    boolean var11 = var9.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var12);
    java.lang.String var14 = var9.name();
    org.apache.commons.math3.random.RandomGenerator var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var15);
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var19.setContractionCriteria(1024.0f);
    var19.setElement(0, 3.0000000000000004d);
    float var25 = var19.getContractionCriteria();
    boolean var27 = var19.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = var19.copy();
    double[] var29 = var19.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    double[] var31 = var19.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var32.setContractionCriteria(1024.0f);
    var32.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var38.setContractionCriteria(1024.0f);
    var38.setElement(0, 3.0000000000000004d);
    float var44 = var38.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var32, var38);
    double[] var46 = var32.getInternalValues();
    var19.addElements(var46);
    double[] var48 = var18.rank(var46);
    org.apache.commons.math3.stat.ranking.TiesStrategy var49 = var18.getTiesStrategy();
    java.lang.String var50 = var49.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var51 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + "RANDOM"+ "'", var50.equals("RANDOM"));

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     var0.reSeedSecure(545642504737558400L);
//     org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var19 = var18.isSupportLowerBoundInclusive();
//     double var21 = var18.probability(0.007907055323073179d);
//     double var22 = var18.getSupportUpperBound();
//     double var24 = var18.probability(0.0d);
//     double var25 = var18.getMean();
//     double var26 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var18);
//     var0.reSeedSecure();
//     int var30 = var0.nextSecureInt(0, 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.457113569144271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.385054978375372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 98.7043276147834d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 17);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(3.967710105131278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0849444048267725d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test147"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 850355429512472704L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 8);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 58L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 2);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var13);
    java.math.BigInteger var19 = null;
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 0L);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 58L);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 2);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 850355429512472704L);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 8);
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 58L);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 2);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, var32);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 155L);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test148"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    int var4 = var0.getExpansionMode();
    var0.addElement(0.13136687189114007d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test149"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(545642504737558400L, 64L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 545642504737558400L);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test150"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(8, 10.0f);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test151"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    var0.discardFrontElements(0);
    var0.contract();
    double var9 = var0.addElementRolling(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test152"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(73737L, 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test153"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    var0.clear();
    var0.contract();
    double var5 = var0.addElementRolling(0.010447699603780409d);
    int var6 = var0.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test154"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(130048, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextF(1.1377077104187023d, 201.7156361224559d);
//     double var11 = var0.nextGaussian(0.3774867637513935d, 30.48232336227865d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.599579928739761d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-13072.961344791953d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.15718499323508087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12.090619874203123d);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test156"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    int var9 = var6.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    boolean var16 = var14.equals((java.lang.Object)(short)10);
    java.lang.Class var17 = var14.getDeclaringClass();
    java.lang.Class var18 = var14.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var26);
    java.lang.String var29 = var26.name();
    java.lang.String var30 = var26.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var26);
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
    org.apache.commons.math3.stat.ranking.NaNStrategy var36 = var35.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var37 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36, var37);
    org.apache.commons.math3.random.RandomGenerator var39 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36, var39);
    org.apache.commons.math3.stat.ranking.TiesStrategy var41 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
    org.apache.commons.math3.stat.ranking.NaNStrategy var43 = var42.getNanStrategy();
    boolean var45 = var43.equals((java.lang.Object)(short)10);
    java.lang.Class var46 = var43.getDeclaringClass();
    java.lang.Class var47 = var43.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var48 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var49 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var49);
    org.apache.commons.math3.stat.ranking.NaNStrategy var51 = var50.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var52 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51, var52);
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51);
    org.apache.commons.math3.stat.ranking.TiesStrategy var55 = var54.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var56 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var48, var55);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var57 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var43, var55);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var58 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var36, var55);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var59 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test157"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    boolean var8 = var2.equals((java.lang.Object)4.1495472005154115d);
    org.apache.commons.math3.stat.ranking.TiesStrategy var9 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var10 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test158"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(7.629395E-5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test159"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(155L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 155L);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.01887862911434995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.55191657610179d);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy(3.0d, 0.8390715290764524d);
//     double var11 = var0.nextGamma(0.22788969386187025d, 0.06857547421121805d);
//     double var14 = var0.nextGamma(19.406218909794774d, (-8.01436751738282d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.291780208464862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.885800687344457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.8004879291027758d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0876417261851614d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-144.08723922824436d));
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test162"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(94, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test163"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)99, (java.lang.Number)1024.0f, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.String var5 = var3.toString();
    java.lang.Throwable[] var6 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1024.0f+ "'", var4.equals(1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 99 is larger than, or equal to, the maximum (1,024)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 99 is larger than, or equal to, the maximum (1,024)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test164"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(919965907, 9.999999f, 4.7683716E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.7262772900781184d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8988781454256316d);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeed((-144705876426790031L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.7176134712297335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.009650292058015906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.1939716958502276d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.19149003944067d);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy(3.0d, 0.8390715290764524d);
//     var0.reSeedSecure(9L);
//     var0.reSeed(19L);
//     java.lang.String var14 = var0.nextSecureHexString(751);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.201947510262934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0361526727850816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.318463961703946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "88bf0c581967a0b74d630368f33ac58bce56d187c0df16e47d76d0a67ad244d2479fec41d2cfd77734e587990775e6e525e2a27ce2544835420e8223a23d442796658b8223239672967ee012208f4b107ded235ac8c9035796e15be7167b03a2ad260511d8c42450a014fd7f55ace4b573d778b19113edd3dbde2e06d4390d806265b3c95f3b81a48811c87e5af67c097cbeb75f6f42113d34a8ac06c05e102407920fa787e9955f9b05a9db6a820ef2a9f426211bcb301da77775b9d0e53bf679c99a1ec381c889551e2cfbc6b085aa9136aabedb39462f2ec129c6d6acc1941f4de87058b9631ed71a99bcdae9b155dad3877f3a344966e7270e6339cca2f93a10633a92ebd503d85c054ee573b864f6497dc64ecac62f15543255137ccef49ef98de828088657e72cc4fed91e930a43748e7e4bf2f9e0b6cb07607231c73a0959c350f56beb026b07984a6bbbba5fa06c31174bd9d39edad8441ecf3a0bec381999cd73548475b0eccb2a88f9a2f6b8ceb8d3465de00"+ "'", var14.equals("88bf0c581967a0b74d630368f33ac58bce56d187c0df16e47d76d0a67ad244d2479fec41d2cfd77734e587990775e6e525e2a27ce2544835420e8223a23d442796658b8223239672967ee012208f4b107ded235ac8c9035796e15be7167b03a2ad260511d8c42450a014fd7f55ace4b573d778b19113edd3dbde2e06d4390d806265b3c95f3b81a48811c87e5af67c097cbeb75f6f42113d34a8ac06c05e102407920fa787e9955f9b05a9db6a820ef2a9f426211bcb301da77775b9d0e53bf679c99a1ec381c889551e2cfbc6b085aa9136aabedb39462f2ec129c6d6acc1941f4de87058b9631ed71a99bcdae9b155dad3877f3a344966e7270e6339cca2f93a10633a92ebd503d85c054ee573b864f6497dc64ecac62f15543255137ccef49ef98de828088657e72cc4fed91e930a43748e7e4bf2f9e0b6cb07607231c73a0959c350f56beb026b07984a6bbbba5fa06c31174bd9d39edad8441ecf3a0bec381999cd73548475b0eccb2a88f9a2f6b8ceb8d3465de00"));
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test168"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-23.95915697465193d), (-8.764508098242358d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25.511914964192083d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(8L);
//     double var13 = var0.nextF(1.2553086822669244d, 1.7155019267144769d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.353339477013049d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.31812639685238464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.18846267793830368d);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var8 = var0.nextT(0.28680180181229414d);
//     org.apache.commons.math3.distribution.NormalDistribution var11 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var12 = var11.isSupportConnected();
//     double var14 = var11.cumulativeProbability(Double.NaN);
//     double var16 = var11.cumulativeProbability(0.038157775941106545d);
//     double var18 = var11.cumulativeProbability((-0.7568024953079281d));
//     boolean var19 = var11.isSupportUpperBoundInclusive();
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.235510139236915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.341419878230298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1733.2915024557853d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 99.7219761181234d);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test171"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    java.lang.String var8 = var2.toString();
    java.lang.Class var9 = var2.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test172"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(9051734712261706624L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test173"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getMean();
    double var5 = var2.getNumericalMean();
    double var7 = var2.cumulativeProbability((-6.856437577172423d));
    double var8 = var2.getMean();
    var2.reseedRandomGenerator(3687843355676870602L);
    boolean var11 = var2.isSupportUpperBoundInclusive();
    double var12 = var2.getStandardDeviation();
    boolean var13 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0574806988857035E105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4.535946096335034E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextWeibull(6.0d, 5.183028998081309d);
//     int var18 = var0.nextInt((-727379968), (-10));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("8e750f55d9b61373f2dc9cccb808740798b8b1f6fc3781c30108692ea59464573c369119b11a1998bf1e99b417b502566e7c044eca39d0cc7de6ce2ba0ee6932f237d76fb65e58b1a4e6d61f2bb992dc8f8bc966eb7afc69be70e63093697052081a6628dbac2e0215894807297fa2b4700d57113554b88876e5abd7b1febd3d2023d91ccefb245fc56cdede843fda9f95b3c5b5b1117ce02ff3d51c3e26baa64627737042785691b596ee64026780c1bd52ecc2887886c69819cc8b3643d5d7a32930d206b4640acf2cc19db35c2d6c49f086e25fd4827a6f7473b74f9260793037057c43dd7e86af1052b601c0ca9e9088570e95e750c9ed406f47403c0d30c05fb05131f7e910d556b936f14bf83f448b59d2621b9033b9ab0b6cbf8d5c1d1c7dd77dcd3191eee00516c849d2ee2c34749d8c700fd60ae859ec883e20c5ae3c9f9c7ac99782bc3b01c356330bc6fe2da4ce6060704b34c89adfa3acc4797a7b2c004e597279ccdeae3fe54af3ef7a21fd962e65791cd81040fb770a7c54babff15e3c26c6a912e154e377c78946850044408543212597afc389f98ee64386b55fa28497cdd79065e9d91141e10a756f727b4213b28f296ef59531cfcbeed09b4c95dfc0bf920e7e33a2d243c73e0afbd97ec0f50f3d887636037736ecf3461e002788079de2d983402eb3ac68ba63e5a355ef5474545b4ace46720da94ec2bb1a0ca20b8477667f05f9e51b9e589813913f74d059820b7e49c55e39a6218a4b19f499a41740f1dcd6fdd2fdc0794de9f213d0833ff9015df2a8c5e7368c48ef1e0151260e1cbbfd8b70ec3b4abbe431fe3e2efc4a762e54d7a0847975c9a4963ba145958d98d066215de7d0acebd9f8022340f78c29d5bf55d9", "69edf03da95d455d35c06f9275120ff5ad761ccf1206604457deddc19e60dd8276e5c5d72e427a469c2b04f26c04360c7aa1d09dab49dee690b9fb919293bec");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.080457844376925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 16.226531220581535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 44.962540144623844d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.432516965333335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-62118312));
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test175"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    int var4 = var0.getExpansionMode();
    int var5 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var8 = new double[] { 1.0d};
    var6.addElements(var8);
    int var10 = var6.getExpansionMode();
    int var11 = var6.start();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    boolean var14 = var0.equals((java.lang.Object)1531225969699204964L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test176"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 1.0726310930754699d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test177"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.7081386520500381d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2613844925447641d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test178"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var12 = var10.addElementRolling(3.689149036074892E-4d);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var13.setContractionCriteria(1024.0f);
    var13.setElement(0, 3.0000000000000004d);
    float var19 = var13.getContractionCriteria();
    boolean var21 = var13.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = var13.copy();
    double[] var23 = var13.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var25.setContractionCriteria(1024.0f);
    var25.setElement(0, 3.0000000000000004d);
    float var31 = var25.getContractionCriteria();
    boolean var33 = var25.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var34 = var25.copy();
    double[] var37 = new double[] { 100.0d, 0.0d};
    var25.addElements(var37);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var40.setContractionCriteria(1024.0f);
    var40.setElement(0, 3.0000000000000004d);
    float var46 = var40.getContractionCriteria();
    boolean var48 = var40.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var49 = var40.copy();
    double[] var50 = var40.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
    boolean var52 = var39.equals((java.lang.Object)var51);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var24, var51);
    double[] var54 = var24.getInternalValues();
    var10.addElements(var54);
    double[] var56 = var9.rank(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test179"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 1.4399227978608449d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test180"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var18);
//     org.apache.commons.math3.random.RandomGenerator var20 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.05835004463692486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test181"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-16L), (-47L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test182"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var9 = var8.getElements();
    int var10 = var8.getExpansionMode();
    float var11 = var8.getExpansionFactor();
    var8.setElement(127, 3.1936453631680304d);
    var8.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var8.copy();
    int var19 = var18.getNumElements();
    int var20 = var18.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var7, var18);
    var18.setContractionCriteria(2.0000002f);
    int var24 = var18.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test183"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(7.105428E-15f, 1.2207033E-4f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.105428E-15f);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test184"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Number var3 = var1.getMax();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NoDataException var7 = new org.apache.commons.math3.exception.NoDataException();
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var4, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test185"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.density(0.0d);
//     boolean var6 = var2.isSupportConnected();
//     double var7 = var2.getSupportUpperBound();
//     double[] var9 = var2.sample(99);
//     org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
//     double var12 = var10.getElement(10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 101.18895540883145d);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test186"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test187"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.1015674805733365E-13d, (java.lang.Number)(-785605799), true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test188"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(2320.659353464481d, 247.92495163615533d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test189"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)20.861422072720746d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.1154275644726788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0561380423375908d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(9.92484747815762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1503725935447098d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test192"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var11.setContractionCriteria(1024.0f);
    var11.setElement(0, 3.0000000000000004d);
    float var17 = var11.getContractionCriteria();
    boolean var19 = var11.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = var11.copy();
    double[] var23 = new double[] { 100.0d, 0.0d};
    var11.addElements(var23);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    boolean var26 = var0.equals((java.lang.Object)var23);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNumElements((-520980735));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test193"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var3, (java.lang.Number)(-0.004625354262543145d), (java.lang.Number)3.5321218005364248d, false);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test194"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    int var6 = var4.getExpansionMode();
    var4.clear();
    double var9 = var4.addElementRolling(4.723647519700551d);
    int var10 = var4.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     int var17 = var0.nextSecureInt(0, 1010);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextUniform(3.431877347714405d, 2.954874930442047d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1104360474058446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.014786444977830425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7.34943648555478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.472498868037513d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 83);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     int[] var9 = var0.nextPermutation(1124, 10);
//     long var11 = var0.nextPoisson(3.469446951953614E-18d);
//     int[] var14 = var0.nextPermutation(9900, 1099);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var16 = var0.nextHexString((-785605899));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4035486585344232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.005061816795777342d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test197"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    boolean var20 = var12.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var12.copy();
    double[] var24 = new double[] { 100.0d, 0.0d};
    var12.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var37 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var39 = var26.equals((java.lang.Object)var38);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var38);
    double[] var41 = var11.getElements();
    float var42 = var11.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setContractionCriteria(7.629395E-5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1024.0f);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextWeibull(100.22056007056258d, 81188.39044958311d);
//     int var14 = var0.nextZipf(1, 10.140709416791422d);
//     int var17 = var0.nextPascal(1180, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3688853917864585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.21919452766066352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 80835.5833692509d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2147483647);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test199"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(3, 40767);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test200"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var10.setExpansionFactor(100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var9, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var9.copy();
    java.math.BigInteger var18 = null;
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 58L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 2);
    boolean var25 = var9.equals((java.lang.Object)2);
    double[] var26 = var9.getElements();
    org.apache.commons.math3.distribution.NormalDistribution var30 = new org.apache.commons.math3.distribution.NormalDistribution(882.393803686349d, 3.270534600767394d, 3.529069951149791d);
    double var32 = var30.probability(0.7871088143391114d);
    double var33 = var30.getStandardDeviation();
    boolean var34 = var9.equals((java.lang.Object)var30);
    float var35 = var9.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 3.270534600767394d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1024.0f);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test201"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(8L, 36L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-28L));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.195935841756499d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.195935841756499d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test203"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    double var2 = var0.getNumericalVariance();
    double var3 = var0.getStandardDeviation();
    var0.reseedRandomGenerator(46L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeedSecure();
//     double var20 = var0.nextGamma(2.0574806988857035E105d, 41.752984630466926d);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution(5.64539685894143d, 98.81133101777444d);
//     double var24 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     double var27 = var0.nextGaussian(0.33716748409417585d, 3.198435777009929d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2282830205086807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.2335968573322872d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "7fd992f7ebb05bf07d3bf493e84f8e62c01959e4a1ed29ff38273989b9caaacb340a6917b9b0d343069f4b0aebab39616903398cff5477f2cc18f69476dd22f70109f06edf0075d5d623e8e0b47d9f425c3500b9e600f620f3ef14cde46d16e86d628e278a1f15da6abd48c4746b671fa8b27b0d479f894afc01dbecc9c17129dcc3e33eedb39915a93da828cc101e0c7b34dd8052906991eeb2f405d93a87c685680addf0222eca0de25d79a66883fad70dd70eed30323de5463aa217168f5f897f5e846ea207e4f46b69158d821103ba18d8a3404b526e935dcb420e945261a0b5c9fcbd9874be49fb796fa367a7a3375efab82817c6bdd8acce9c189d67fd516b7071fbab87c2a607adcb6ca9b216b297c636e5f99aa3cece98ae8d54d538f483f3c13a7e251f1c1cf23f1c21eb5c606d0ed10114f587c6548b6e3ae10fee8008d0556b5a6fe04132a161a79cd5594c2c1c939181479ef65e00e20cdbfc0621e90f3e8fb3a518ac050684aef8d91caf4fe817667437b65be4492ced3d1895f762b2fa3675c4a0045a923b06b4d56a06247495c34b88e64db768a2f354591a9b2a1d031774a0f69000d77049acb3a12da0dc8bfea317d0806ad60f8aef450689766d0bae74d649abec1c1bb7281766ca084887345831dc3475a62bc022456aa9ee52039f45ea238bee993961423226c48def61ac25b26318f597dc9bb7afd3147dd257833941da4520c0d30c67041f26e2c28bcebdba41a31f653e208bb3aeac1acd6be8b36c57804d02029b4accd8ddfc3012bf1ab26a6a221b8834d1b28fbc30bbca5018285ce4d927999f7e499a980b0464c79fd220847a01cd691f3ef424e2977cd0e40297197775914ac27bfe253149d0f39bd76713a38d"+ "'", var13.equals("7fd992f7ebb05bf07d3bf493e84f8e62c01959e4a1ed29ff38273989b9caaacb340a6917b9b0d343069f4b0aebab39616903398cff5477f2cc18f69476dd22f70109f06edf0075d5d623e8e0b47d9f425c3500b9e600f620f3ef14cde46d16e86d628e278a1f15da6abd48c4746b671fa8b27b0d479f894afc01dbecc9c17129dcc3e33eedb39915a93da828cc101e0c7b34dd8052906991eeb2f405d93a87c685680addf0222eca0de25d79a66883fad70dd70eed30323de5463aa217168f5f897f5e846ea207e4f46b69158d821103ba18d8a3404b526e935dcb420e945261a0b5c9fcbd9874be49fb796fa367a7a3375efab82817c6bdd8acce9c189d67fd516b7071fbab87c2a607adcb6ca9b216b297c636e5f99aa3cece98ae8d54d538f483f3c13a7e251f1c1cf23f1c21eb5c606d0ed10114f587c6548b6e3ae10fee8008d0556b5a6fe04132a161a79cd5594c2c1c939181479ef65e00e20cdbfc0621e90f3e8fb3a518ac050684aef8d91caf4fe817667437b65be4492ced3d1895f762b2fa3675c4a0045a923b06b4d56a06247495c34b88e64db768a2f354591a9b2a1d031774a0f69000d77049acb3a12da0dc8bfea317d0806ad60f8aef450689766d0bae74d649abec1c1bb7281766ca084887345831dc3475a62bc022456aa9ee52039f45ea238bee993961423226c48def61ac25b26318f597dc9bb7afd3147dd257833941da4520c0d30c67041f26e2c28bcebdba41a31f653e208bb3aeac1acd6be8b36c57804d02029b4accd8ddfc3012bf1ab26a6a221b8834d1b28fbc30bbca5018285ce4d927999f7e499a980b0464c79fd220847a01cd691f3ef424e2977cd0e40297197775914ac27bfe253149d0f39bd76713a38d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 7.7169328076652794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 8.590595999805713E106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 184.2032759981684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-2.0397690230790304d));
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.791508962278884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9757416833662803d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test206"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.8390715290764524d, 0.011993192308645846d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8391572364988865d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test207"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    java.lang.String var8 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var14.setContractionCriteria(1024.0f);
    var14.setExpansionFactor(10.0f);
    var14.discardFrontElements(0);
    var14.contract();
    boolean var22 = var11.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test208"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(3.000738937384491d, 3.488745585512574d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.488745585512574d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test209"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1542623280274737152L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1542623280274737152L);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test210"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var6 = var5.getMean();
    double[] var8 = var5.sample(12700);
    var0.addElements(var8);
    var0.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var0.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test211"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)3.233351086493488d, var4);
//     org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var4);
//     org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
//     java.lang.String var8 = var6.toString();
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test212"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.0012498386252579215d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999992189518071d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test213"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    boolean var6 = var2.isSupportConnected();
    double var7 = var2.getSupportUpperBound();
    double[] var9 = var2.sample(99);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    int var11 = var10.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test214"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var11);
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test215"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException(var1);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test216"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)19L);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.String var3 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (19) exceeded"+ "'", var3.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (19) exceeded"));

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test217"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)3.305530002646725d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 27.12061425361551d};
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var9, var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var8, var11);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var7, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var6, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test218"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.06857547421121805d, 3.095103430125948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.016095893653443E-4d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test219"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    boolean var6 = var4.equals((java.lang.Object)(short)10);
    java.lang.Class var7 = var4.getDeclaringClass();
    java.lang.Class var8 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var16);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var16);
    java.lang.String var19 = var16.name();
    java.lang.String var20 = var16.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test220"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.8390715290764524d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.566370614359173d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test221"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(4.898248617516793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3694091670949862d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test222"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test223"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    boolean var7 = var5.equals((java.lang.Object)(short)10);
    java.lang.Class var8 = var5.getDeclaringClass();
    java.lang.Class var9 = var5.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var17);
    java.lang.String var20 = var17.name();
    java.lang.String var21 = var17.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var17);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var24.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.distribution.NormalDistribution var29 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var30 = var29.getMean();
    double[] var32 = var29.sample(12700);
    var24.addElements(var32);
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var35 = var34.getElements();
    int var36 = var34.getExpansionMode();
    int var37 = var34.start();
    int var38 = var34.getNumElements();
    int var39 = var34.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
    org.apache.commons.math3.distribution.NormalDistribution var43 = new org.apache.commons.math3.distribution.NormalDistribution(3.2132396021992005d, 0.8390715290764524d);
    double var44 = var43.getNumericalMean();
    double[] var46 = var43.sample(4064528);
    boolean var47 = var34.equals((java.lang.Object)var46);
    double var48 = var23.mannWhitneyUTest(var32, var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 3.2132396021992005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test224"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(5.64539685894143d, 98.81133101777444d);
    double var4 = var2.cumulativeProbability(101.79837155550794d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.834747364317562d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test225"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(16.215207606048914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16L);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test226"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1024.0f, 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5f);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test227"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var4 = var2.inverseCumulativeProbability(0.0d);
    double var5 = var2.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.21400263603676362d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test228"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    boolean var20 = var12.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var12.copy();
    double[] var24 = new double[] { 100.0d, 0.0d};
    var12.addElements(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var37 = var27.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    boolean var39 = var26.equals((java.lang.Object)var38);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var11, var38);
    double[] var41 = var11.getInternalValues();
    var11.addElement(0.0d);
    double var45 = var11.substituteMostRecentElement(0.024817848901220855d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test229"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)4.000000000000001d, var2, true);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var5, (java.lang.Number)1.1377077104187023d, (java.lang.Number)0L, true);
    org.apache.commons.math3.exception.NotPositiveException var11 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)100);
    boolean var12 = var11.getBoundIsAllowed();
    java.lang.Number var13 = var11.getArgument();
    var9.addSuppressed((java.lang.Throwable)var11);
    boolean var15 = var9.getBoundIsAllowed();
    var4.addSuppressed((java.lang.Throwable)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (short)100+ "'", var13.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test230"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var0.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.getElement(127);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test231"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8.512293546547506d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test232"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test233"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(8.04846741624539E306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 706.6765201464082d);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test234"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeedSecure();
//     double var20 = var0.nextGamma(2.0574806988857035E105d, 41.752984630466926d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "db685685e43aaeed0333467cf16d742df5bcddc5724604679e940ebeb4b4699d540497b2cbd8794de669db37249452eae199a264ad911d54c9391c0eba37a918fb85c1d7569b57f19433df99e7e62ff3b903d4e0c71663b053be3871148d68574d942d57a552d6e20d75b2b2dac4e32cc97c449f80735f02e10924de6006a9e59091e8ce26e450e477ac615edb741828d28ed1cd952a45d7822dc51ffc372f04ff31d668b1865b12036111e3686ec6932b80de92689ca87a64cae112aadfe36e4d032d80500825b58c00f9b69e8e794629bee01666fd31e5f703a5b3f974bdf1385a8eca02473bee3b95267701eb7f8efd1da7e9a8bf9bea64ba192148cd59a8b85a36ef7c0b60478012dafce5b739ac6db9f6bc00a0d4e1f9cf9a4b6078877625d54ac8fd48060a3bffbb64c10d2cca7f081188f221aa02cedea10567fc5cd06cf3b0a9c15d6a88ebc13f2634332f349beb002cfe4916f9970a710be4664a923ee10932a5ca0eaed0588ffb35b733b58fcad613ed59197e5143f741d98468b3db3e6e9fff7c0d519fc6a86d135aedd0d0a25a51803c6645d549e2d0b5ab1011a4fb472a951bdfff65609fb0ddec4d458171751115e040c6b951d274a3e35df2858c7e7bd35887ebdeafe668d938fb5963d7cd1037722e54541434a13f3ff49ac55371a0dc0248d77da726d069798bf917c41ea52644b2b48755939fc118ed0d38b13a16038ce7c3207cad23d4cb0fd129890cb1ebbb7c900569a3c4210aac10df275557c613d7c7a0e06ca1b451ff51975d11c2fbb4056babbf894b4f17872f855a7f0a3add36af870492ec189a7ac2bb31b02861f2f2c5c22b5d8a76c36ba67f42293ffd5a747be8ee1a379ba8525691dc0a753c2f0a178af4c5");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.24549419161630756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6506969235500333d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "7398d7745998e522134fe16e12caeca0a4ff90e6d8da09ac1cc575e8e377c82d172e93efc613922337f16d0935b95692c62e38efa5c4c8bdbcbbf4fcee296c7c993fdd28d4ca1af81a33fa4682a2f2b3485c1e8ea6f12d5cf0eab4fe72bfe10062cdcfe979f01d9fd5ce711104a83cf27bd15dff259f78be5ed059ecfb085c25293291c1af47ce2003aaa6e96a37fbcd72fef60c1e1e8af0a5ac4c1f57cb58e4b0e269efca72ed519596db0c24d35efa729b428a501e39c50b2a4194e9b62b7ff013d9f8de93c5a0ca1f2c90efa81277d6cf4871556e66b3b963450da4a56e293ee7ccef1a39d04336261e7588f4e3f4051a9cb99772bf2396d423c0e502374228068bb877848460f1aebbf709a0334801bee7f1df1e24a36d508de0b5586b23729f6ce643d3bf6eaac2d52a4269bbf68932a5283da2d0edce6faed259e3afbff9455ca6160948fb3f6d37b3281bd0faa5c1989b1e12fdd324ee09ad4c39d5726f72a6f17bc2db35f2bf86c6cd749dc12146b7d02cd50507370f2ad65402b90af9a4e8c4336ffd6f757494da851506043072322169e3c0fc047cc9ebec3aad594df75ca3d1680d0092e0ac823206056837fba301051fa51baf3b937ee3ea611d8063f7d507071d2ac364ea35673dc317bcb8a093c58e90151b63ff0cde1803801b0a22d3975919830ae05f592ccd214066be6c2805c1b5af5bdeddc30f390bc89175c2da21c412aada9947860db13026eda4571727433b436e5c00978e60ec5291245164b65a39bf8a514833f3f42dd4a744a0ec735565301779f0c182d2fee5bc3877a1caa77cd0c8de16676eed1164933472c83ebfb82c96846d644739c17a120fafb85e0624d93db65959efd773ad1dfe8dbaacb61474df1c0d"+ "'", var13.equals("7398d7745998e522134fe16e12caeca0a4ff90e6d8da09ac1cc575e8e377c82d172e93efc613922337f16d0935b95692c62e38efa5c4c8bdbcbbf4fcee296c7c993fdd28d4ca1af81a33fa4682a2f2b3485c1e8ea6f12d5cf0eab4fe72bfe10062cdcfe979f01d9fd5ce711104a83cf27bd15dff259f78be5ed059ecfb085c25293291c1af47ce2003aaa6e96a37fbcd72fef60c1e1e8af0a5ac4c1f57cb58e4b0e269efca72ed519596db0c24d35efa729b428a501e39c50b2a4194e9b62b7ff013d9f8de93c5a0ca1f2c90efa81277d6cf4871556e66b3b963450da4a56e293ee7ccef1a39d04336261e7588f4e3f4051a9cb99772bf2396d423c0e502374228068bb877848460f1aebbf709a0334801bee7f1df1e24a36d508de0b5586b23729f6ce643d3bf6eaac2d52a4269bbf68932a5283da2d0edce6faed259e3afbff9455ca6160948fb3f6d37b3281bd0faa5c1989b1e12fdd324ee09ad4c39d5726f72a6f17bc2db35f2bf86c6cd749dc12146b7d02cd50507370f2ad65402b90af9a4e8c4336ffd6f757494da851506043072322169e3c0fc047cc9ebec3aad594df75ca3d1680d0092e0ac823206056837fba301051fa51baf3b937ee3ea611d8063f7d507071d2ac364ea35673dc317bcb8a093c58e90151b63ff0cde1803801b0a22d3975919830ae05f592ccd214066be6c2805c1b5af5bdeddc30f390bc89175c2da21c412aada9947860db13026eda4571727433b436e5c00978e60ec5291245164b65a39bf8a514833f3f42dd4a744a0ec735565301779f0c182d2fee5bc3877a1caa77cd0c8de16676eed1164933472c83ebfb82c96846d644739c17a120fafb85e0624d93db65959efd773ad1dfe8dbaacb61474df1c0d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6.819295799734101d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 8.590595999805713E106d);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test235"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.11666398836735097d, 2.8499994597941773d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8499994597941773d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test236"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var4.setContractionCriteria(1024.0f);
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var4);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var10 = var9.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var9);
    var4.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test237"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.1978648027698251d);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextGamma(1.8360738684267854d, 3.5743392688675386d);
//     int var11 = var0.nextZipf(9900, 6.242054776499464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.183028998081309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test239"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.String var17 = var14.name();
    java.lang.String var18 = var14.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    java.lang.String var20 = var14.name();
    java.lang.String var21 = var14.toString();
    int var22 = var14.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 3);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test240"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(103696L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 103696L);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test241"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var21 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var24);
//     int var26 = var2.ordinal();
//     org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var27.setContractionCriteria(1024.0f);
//     var27.setExpansionFactor(10.0f);
//     org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
//     org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var33.setContractionCriteria(1024.0f);
//     var33.setElement(0, 3.0000000000000004d);
//     float var39 = var33.getContractionCriteria();
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var27, var33);
//     double[] var41 = var27.getInternalValues();
//     var27.setElement(100, 27.12061425361551d);
//     var27.contract();
//     org.apache.commons.math3.distribution.NormalDistribution var48 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var49 = var48.isSupportConnected();
//     boolean var50 = var48.isSupportConnected();
//     double[] var52 = var48.sample(5);
//     var27.addElements(var52);
//     org.apache.commons.math3.util.ResizableDoubleArray var54 = var27.copy();
//     int var55 = var54.start();
//     org.apache.commons.math3.util.ResizableDoubleArray var56 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var56.setContractionCriteria(1024.0f);
//     var56.setElement(0, 3.0000000000000004d);
//     float var62 = var56.getContractionCriteria();
//     boolean var64 = var56.equals((java.lang.Object)0.21400263603676362d);
//     org.apache.commons.math3.util.ResizableDoubleArray var65 = var56.copy();
//     double[] var68 = new double[] { 100.0d, 0.0d};
//     var56.addElements(var68);
//     double[] var70 = var56.getElements();
//     var54.addElements(var70);
//     boolean var72 = var2.equals((java.lang.Object)var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.09105709288986738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1024.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 1024.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test242"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.0323416025546303d), (java.lang.Number)1.7784046860616962d, true);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test243"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(243, 27326631);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(100, 255);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test245"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     int var7 = var1.nextHypergeometric(4064528, 1024, 0);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var11 = var10.isSupportConnected();
//     double[] var13 = var10.sample(127);
//     boolean var14 = var10.isSupportUpperBoundInclusive();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 97.7123939533347d);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test246"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(3.2201322996148285d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.535690691807389d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test247"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-55.06150692938321d), (java.lang.Number)7.629395E-6f, true);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.5236397786755846d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.655975133694977d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test249"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-2153214848064815104L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     int var10 = var0.nextZipf(1, 0.38805925492513493d);
//     var0.reSeedSecure(45L);
//     org.apache.commons.math3.distribution.NormalDistribution var15 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var16 = var15.isSupportLowerBoundInclusive();
//     double var18 = var15.probability(0.007907055323073179d);
//     double var19 = var15.getSupportUpperBound();
//     double var21 = var15.probability(0.0d);
//     boolean var22 = var15.isSupportLowerBoundInclusive();
//     double var23 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var15);
//     double var24 = var15.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 99.06278234431649d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.0d);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test251"); }


    long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test252"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    var0.setElement(93, 0.020382238871254087d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test253"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(9.536744E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536745E-7f);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test254"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.10908724711328653d, 0.012149533084566505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9906346082414381d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test255"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.022405075367622047d, 4.283760323497615d);
    double var3 = var2.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.022405075367622047d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test256"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.909032998552898d), (java.lang.Number)(-7.113883993924793d), true);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test257"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(5594589197447221635L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test258"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-4.476254319231334d), (java.lang.Number)0.9984374437168237d, false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test259"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1049, 1180);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-941303519));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test260"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    boolean var8 = var6.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var9);
    java.lang.String var11 = var6.name();
    org.apache.commons.math3.random.RandomGenerator var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var12);
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var25);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var28);
    org.apache.commons.math3.random.RandomGenerator var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var32);
    boolean var35 = var6.equals((java.lang.Object)1.6776111866603864d);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    org.apache.commons.math3.stat.ranking.NaNStrategy var38 = var37.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var39 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var38, var39);
    java.lang.Class var41 = var38.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var42 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38, var42);
    org.apache.commons.math3.stat.ranking.TiesStrategy var44 = var43.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44);
    java.lang.Class var46 = var44.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var47 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var44);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "MAXIMAL"+ "'", var11.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test261"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.01901325932480203d, (java.lang.Number)0.005841951193309029d, true);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test262"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)3.280479249978234d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test263"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.0623483795315067d, 1.3142172955075926d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.24414372263359033d);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextF(3.158982217932436d, (-0.10153108032969048d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.499398592401149d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03458142905155033d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.023114620693718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test265"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-520980735), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 520980735);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test266"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.setContractionCriteria(1024.0f);
    var18.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var24.setContractionCriteria(1024.0f);
    var24.setElement(0, 3.0000000000000004d);
    float var30 = var24.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var18, var24);
    double[] var32 = var18.getInternalValues();
    var0.addElements(var32);
    var0.setExpansionFactor(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var20 = var0.nextBeta(5.282094375738045d, 3.5480122537930616d);
//     java.lang.String var22 = var0.nextSecureHexString(10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.460555595423459d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0063135642079871195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8036746892388591d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.977008088876142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 38L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.3652666587655267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "ecb6b9fe18"+ "'", var22.equals("ecb6b9fe18"));
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test268"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test269"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(3.192807891725479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8782305521868524d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test270"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(451);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test271"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    java.lang.String var8 = var2.name();
    java.lang.String var9 = var2.toString();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var13);
    java.lang.Class var15 = var12.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    boolean var21 = var18.equals((java.lang.Object)6.6401884929809825d);
    java.lang.String var22 = var18.name();
    boolean var24 = var18.equals((java.lang.Object)3.31160576334217d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "RANDOM"+ "'", var22.equals("RANDOM"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextGaussian(3.2132396021992005d, 0.17936156675857706d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2665875479334145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.006260235862867707d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.266877597156394d);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test273"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.019944222488261613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.019942900305644877d);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test274"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     double var14 = var0.nextWeibull(0.9999999999999919d, 4.5359460963350345E52d);
//     long var16 = var0.nextPoisson(4.986994462827701d);
//     double var19 = var0.nextWeibull(3.3854536287719275d, 3.2670245904542883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.006721290915257329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.6781245114998264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.8050539465012158d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.3168298945771623E53d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.025157853478424d);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test275"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var12.setContractionCriteria(1024.0f);
    var12.setElement(0, 3.0000000000000004d);
    float var18 = var12.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var6, var12);
    double[] var20 = var6.getInternalValues();
    var6.setElement(100, 27.12061425361551d);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var24.setContractionCriteria(1024.0f);
    var24.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var30.setContractionCriteria(1024.0f);
    var30.setElement(0, 3.0000000000000004d);
    float var36 = var30.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var24, var30);
    double[] var38 = var24.getInternalValues();
    var6.addElements(var38);
    double[] var40 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var5, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var43 = var5.getElement((-20202817));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test276"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)99);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 99+ "'", var3.equals(99));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(23.58416956547804d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 23.58416956547804d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test278"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(10L, 9187355818195226112L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test279"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var3 = var2.getNumericalMean();
    double var5 = var2.inverseCumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.21400263603676362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test280"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(8750037941196460992L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test281"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(4.1510015688468584d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test282"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var13 = var12.isSupportLowerBoundInclusive();
//     double var15 = var12.density(0.0d);
//     double var16 = var12.getNumericalMean();
//     double var18 = var12.inverseCumulativeProbability(0.0d);
//     double var19 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var12.reseedRandomGenerator(56L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.28408112724089d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-5.007965763151202E-4d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.1427516427643458d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 100.04100755997635d);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test283"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    int var4 = var2.ordinal();
    int var5 = var2.ordinal();
    java.lang.Class var6 = var2.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test284"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.6224247951349728d, 1.042988945741194E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963261520386d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test285"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.442920668402201E-5d, (-0.004464771942251129d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4429206684022008E-5d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test286"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.1409651890262005d, 0.15729146283385384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1409651890262005d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test287"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var18.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var19);
    int var21 = var19.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var19);
    java.lang.String var23 = var19.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test288"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-1.298252896874428d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.26918185503308273d);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test289"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.629216385636781d), 0.25677494449075766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test290"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.2582967123516604d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.005205053526307d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0523598775598299d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test292"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.7182818285621857d, 0.4345638372360526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.017799643891161218d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test293"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.7269109241219371d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.930821162545541d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test294"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(7.17351271127659d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7L);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test295"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0f);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test296"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0f, (java.lang.Number)var4, false);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 58L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 2);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 850355429512472704L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 8);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var19);
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.math.BigInteger var23 = null;
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var29 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var21, (java.lang.Number)1.0f, (java.lang.Number)var25, false);
    java.math.BigInteger var30 = null;
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var30, 0L);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 58L);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 2);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, 850355429512472704L);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 8);
    java.math.BigInteger var41 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, var40);
    java.math.BigInteger var43 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, 0);
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, 1L);
    java.math.BigInteger var46 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test297"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double var16 = var14.addElementRolling(3.5321218005364248d);
    var14.contract();
    double var19 = var14.substituteMostRecentElement((-0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.5321218005364248d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test298"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1270);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test299"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    boolean var6 = var4.equals((java.lang.Object)(short)10);
    java.lang.Class var7 = var4.getDeclaringClass();
    java.lang.Class var8 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var16);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var16);
    java.lang.String var19 = var16.name();
    java.lang.String var20 = var16.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var22.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.distribution.NormalDistribution var27 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var28 = var27.getMean();
    double[] var30 = var27.sample(12700);
    var22.addElements(var30);
    var22.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var35 = var34.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var39 = new double[] { 1.0d};
    var37.addElements(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    var34.addElements(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    var22.addElements(var39);
    org.apache.commons.math3.distribution.NormalDistribution var47 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var48 = var47.isSupportLowerBoundInclusive();
    double var50 = var47.density(0.0d);
    boolean var51 = var47.isSupportConnected();
    double var52 = var47.getSupportUpperBound();
    double[] var54 = var47.sample(99);
    var22.addElements(var54);
    org.apache.commons.math3.util.ResizableDoubleArray var56 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var57 = var56.getElements();
    int var58 = var56.getExpansionMode();
    float var59 = var56.getExpansionFactor();
    var56.setElement(127, 3.1936453631680304d);
    var56.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var66 = var56.copy();
    int var67 = var66.getNumElements();
    var66.addElement(99.76434593142625d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var70 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.util.ResizableDoubleArray var71 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var71.setContractionCriteria(1024.0f);
    var71.setElement(0, 3.0000000000000004d);
    float var77 = var71.getContractionCriteria();
    boolean var79 = var71.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var80 = var71.copy();
    double[] var81 = var71.getElements();
    double[] var82 = var71.getElements();
    double[] var83 = var71.getInternalValues();
    double[] var84 = var70.rank(var83);
    org.apache.commons.math3.util.ResizableDoubleArray var85 = new org.apache.commons.math3.util.ResizableDoubleArray(var84);
    var66.addElements(var84);
    double var87 = var21.mannWhitneyUTest(var54, var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 1.5493895055840312E-10d);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy(3.0d, 0.8390715290764524d);
//     var0.reSeedSecure(9L);
//     var0.reSeed(19L);
//     var0.reSeedSecure();
//     long var16 = var0.nextSecureLong(0L, 612L);
//     long var18 = var0.nextPoisson(473.47413152097477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.9462875107474797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.4740190556128544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.8524869264336807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 458L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 496L);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test301"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    boolean var6 = var4.equals((java.lang.Object)(short)10);
    java.lang.Class var7 = var4.getDeclaringClass();
    java.lang.Class var8 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var16);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var16);
    java.lang.String var19 = var16.name();
    java.lang.String var20 = var16.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    java.lang.Class var22 = var16.getDeclaringClass();
    int var23 = var16.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 3);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test302"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 103696L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 103696L);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test303"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test304"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(99990000, 10239145);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 110229145);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test305"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.010150131838024495d, 3.8721855928581603d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.010150131838024497d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test306"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2147483647, 86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2147483561);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test307"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.8394622403005243d, 0.2989556716881633d, 8.590595999805713E106d);
    double var4 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test308"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.1377077104187023d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.9043645290323704d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9670475746038808d));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test310"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)291729791, (java.lang.Number)3.1975339658050914d, (java.lang.Number)5.780270116065924d);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextCauchy(0.0d, 2040.3837802863068d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextLong(5594589197447295372L, 6L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.330576932541491d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3440310703801448d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-9911.757163125736d));
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test312"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-1294.3830542039552d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test313"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.4740190556128544d, (java.lang.Number)16.545662219537288d, false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test314"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var20 = var0.nextBeta(5.282094375738045d, 3.5480122537930616d);
//     var0.reSeed(39L);
//     double var25 = var0.nextUniform(0.0022174236012274633d, 20.538117523235602d);
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     double var30 = var28.cumulativeProbability((-3.4657978658285428E-6d));
//     boolean var31 = var28.isSupportUpperBoundInclusive();
//     double var32 = var28.getNumericalMean();
//     double var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.423462868527436d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03132356267468335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.06138052297357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.733841336614133d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 31L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.7760813294364762d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2.8916709706052672d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 99.93027732956757d);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test316"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var1, (java.lang.Number)(-0.004625354262543145d), (java.lang.Number)3.5321218005364248d, false);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test317"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.getNumericalMean();
//     double var9 = var2.probability(12.063722427580958d);
//     double var10 = var2.getStandardDeviation();
//     double var11 = var2.sample();
//     double var12 = var2.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.08672145463547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 101.3530150049379d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 100.0d);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test318"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.getStandardDeviation();
//     double var9 = var2.density(120.0d);
//     double[] var11 = var2.sample(1195);
//     double var13 = var2.inverseCumulativeProbability(0.47712125471966244d);
//     double var15 = var2.cumulativeProbability((-0.49983239787941475d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.90965804713039d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.520948362159764E-88d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 99.94262001883607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test319"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(99);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.getElement(4066573);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test320"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportConnected();
//     boolean var4 = var2.isSupportConnected();
//     boolean var5 = var2.isSupportLowerBoundInclusive();
//     double[] var7 = var2.sample(1270);
//     double var8 = var2.sample();
//     double var9 = var2.getStandardDeviation();
//     double var10 = var2.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 99.42767063907537d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test321"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2040.3837802863068d, 1.6901710844898903d, 0.005307422838786435d);
    double var5 = var3.density(0.6345871160370109d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     int var15 = var0.nextInt(0, 130048);
//     var0.reSeed(59L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3538769221572826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.01238880209613184d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.67666759490413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 100177);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test323"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(9.094948E-13f, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3283067E-10f);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test324"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2, (-785605899));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 785605901);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test325"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    int var4 = var0.getExpansionMode();
    double[] var5 = var0.getElements();
    var0.addElement(0.07902415835395639d);
    boolean var9 = var0.equals((java.lang.Object)2.7705079069914262d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(4.2E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test326"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.32200012842236153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test327"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3L);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test328"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 850355429512472704L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 8);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 58L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 2);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, var13);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 155L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 2083303935);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 4064528);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test329"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.07813596190804502d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test330"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    int var15 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test331"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var5.setContractionCriteria(1024.0f);
    var5.setElement(0, 3.0000000000000004d);
    float var11 = var5.getContractionCriteria();
    boolean var13 = var5.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var5.copy();
    double[] var15 = var5.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = var5.copy();
    double var18 = var16.substituteMostRecentElement(0.0d);
    int var19 = var16.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = var16.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.0000000000000004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test332"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test333"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test334"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(99, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.486940148245216d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(99.13100687439591d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 99.0d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test336"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var12 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var14 = var13.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var18 = new double[] { 1.0d};
    var16.addElements(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var13.addElements(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var11.addElements(var18);
    int var24 = var11.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setExpansionFactor(5.9604645E-8f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test337"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9315603992489111d, 3.5024195390363198d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.5024195390363198d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(2.357887982222818d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test339"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-3847095399992368128L));
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-3847095399992368128L)+ "'", var2.equals((-3847095399992368128L)));

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(5613.380974050871d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 17.77221285613304d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test341"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)3.233351086493488d, var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var7);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var1, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test342"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(2.8437256982613834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.913001356044336d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test343"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 58L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 24L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, (-9223372036854695133L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     var0.reSeedSecure(545642504737558400L);
//     org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var19 = var18.isSupportLowerBoundInclusive();
//     double var21 = var18.probability(0.007907055323073179d);
//     double var22 = var18.getSupportUpperBound();
//     double var24 = var18.probability(0.0d);
//     double var25 = var18.getMean();
//     double var26 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var18);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var30 = var0.nextLong(6L, (-6495504173895948927L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.406043683693164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9101824975849045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 98.7043276147834d);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     var0.reSeed(7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var0.nextPermutation(17, (-17));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.238185692884073d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.002656706619954487d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1185179510675769344L);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(24.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.000000000000004d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test347"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.0f), 1.5703805657617391d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(3.3142072789405845d);
//     int var7 = var1.nextHypergeometric(4064528, 1024, 0);
//     long var10 = var1.nextLong(3L, 535514000795646464L);
//     var1.reSeedSecure(9187355818195226112L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextBeta(0.0d, 3.7339183133724134d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 322080464166463296L);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test349"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1623574473), 2083303935);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1209445767);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test350"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-56L), 38L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-56L));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test351"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    boolean var11 = var9.equals((java.lang.Object)(short)10);
    java.lang.Class var12 = var9.getDeclaringClass();
    java.lang.Class var13 = var9.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test352"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.String var17 = var14.name();
    java.lang.String var18 = var14.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test353"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-1.855421056660866d), 0.1112516376339919d, 3.5449405039502326d);
    boolean var4 = var3.isSupportConnected();
    double var5 = var3.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.012376926876245043d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test354"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    var4.setNumElements(40767);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var4.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test355"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    int var4 = var0.getNumElements();
    boolean var6 = var0.equals((java.lang.Object)768662.31447054d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextGamma(0.006935830340986719d, 0.0d);
//     double var13 = var0.nextT(0.5211415343642575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3518084491089892d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.5128383208785516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.5644894697097675d));
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test357"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.005771153194535552d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.005771217267134356d));

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeed();
//     int var18 = var0.nextPascal(1195, 2.5453090700369303E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.28105500853017d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.002761896204475915d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.39923652531585274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.882954188802566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test359"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    var6.setElement(1049, 0.9647639020111903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test360"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, (-0.37265870739300694d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test361"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     var0.reSeed(58L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextBinomial((-20202817), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.100280635238879d);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test362"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    var4.setNumElements(40767);
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     org.apache.commons.math3.distribution.NormalDistribution var15 = new org.apache.commons.math3.distribution.NormalDistribution(4.226139957689864d, 1.4632615084784795d, 4.394517941340612d);
//     double var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var15);
//     double var19 = var0.nextGaussian(3.4559854457990564d, 1.4399227978608449d);
//     double var21 = var0.nextChiSquare(0.9976525399559268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.34964649284318894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.0246392568551936d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 7.080407811221509d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.6076893820575404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 4.9139120187692535d);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test364"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(11.625722118811352d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0880820034010856d);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test365"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     double var20 = var7.nextCauchy(0.0d, 168.73250215626115d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4267836990530027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 281.0979446667781d);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test366"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
    var3.addSuppressed((java.lang.Throwable)var7);
    boolean var9 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var3.getContext();
    java.lang.Throwable[] var12 = var3.getSuppressed();
    boolean var13 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test367"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.8988781454256316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.015688383211897677d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test368"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1010, 1024.0f, 2.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test369"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     java.lang.String var7 = var2.name();
//     org.apache.commons.math3.random.RandomGenerator var8 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
//     double[] var13 = null;
//     double[] var14 = var11.rank(var13);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeed(1531225969699204352L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.483045445191057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.015764220843575337d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.199885965489538d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.095773169503299d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 25L);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test371"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(93, 1209445767);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1209445767);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test372"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.08164921326879017d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextGaussian(3.2132396021992005d, 0.17936156675857706d);
//     double var12 = var0.nextCauchy(3.7252681214586643d, 3.1936828330503824d);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var14 = var13.getMean();
//     double[] var16 = var13.sample(12700);
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var13);
//     org.apache.commons.math3.distribution.IntegerDistribution var18 = null;
//     int var19 = var0.nextInversionDeviate(var18);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test374"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var11);
    int var13 = var11.ordinal();
    java.lang.String var14 = var11.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test375"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.022147517156860363d), 0.0037606833841678563d, 3.853702795813156d);
    double var5 = var3.probability((-0.29861131299342814d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     double var11 = var0.nextCauchy(0.5211415343642575d, 1.098418460323332d);
//     int var14 = var0.nextInt(127, 1270);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var18 = var17.isSupportConnected();
//     double[] var20 = var17.sample(127);
//     double var21 = var17.getSupportLowerBound();
//     var17.reseedRandomGenerator(9223372036854775807L);
//     double var24 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     double var25 = var17.getNumericalMean();
//     double var26 = var17.getStandardDeviation();
//     boolean var27 = var17.isSupportConnected();
//     double var28 = var17.getSupportUpperBound();
//     double var29 = var17.getNumericalMean();
//     double var30 = var17.getNumericalVariance();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var32 = var17.inverseCumulativeProbability(8.033816814586373d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2045737864218937d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.6051633296331407d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-92.77409186830337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 71.38484292634783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 390);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 100.40876115394269d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.0d);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test377"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    boolean var6 = var0.equals((java.lang.Object)(-0.99999994f));
    var0.setNumElements(1124);
    float var9 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test378"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.08164921326879017d, (-0.7081386520500381d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test379"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     java.lang.String var7 = var2.name();
//     java.lang.String var8 = var2.name();
//     org.apache.commons.math3.random.RandomGenerator var9 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var9);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var14 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var14);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var19 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18, var19);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var22);
//     int var24 = var22.ordinal();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var22);
//     org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     int var27 = var26.getExpansionMode();
//     org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
//     org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var31 = new double[] { 1.0d};
//     var29.addElements(var31);
//     org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
//     var26.addElements(var31);
//     org.apache.commons.math3.distribution.NormalDistribution var37 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     double[] var39 = var37.sample(99);
//     double var40 = var25.mannWhitneyUTest(var31, var39);
//     org.apache.commons.math3.distribution.NormalDistribution var43 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var44 = var43.isSupportConnected();
//     boolean var45 = var43.isSupportConnected();
//     double[] var47 = var43.sample(5);
//     org.apache.commons.math3.distribution.NormalDistribution var50 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var51 = var50.isSupportConnected();
//     boolean var52 = var50.isSupportConnected();
//     double[] var54 = var50.sample(5);
//     double var55 = var25.mannWhitneyU(var47, var54);
//     org.apache.commons.math3.util.ResizableDoubleArray var56 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.08637895933480677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 15.0d);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test380"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 42L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test381"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2083303935), 751);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 751);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextCauchy((-1.855421056660866d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.306053702376434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.071942832310655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test383"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(42.60631487685974d, 3.1589822179324365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test384"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(7.629395E-6f, 9.094948E-13f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.629395E-6f);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test385"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportConnected();
    double[] var5 = var2.sample(127);
    double var6 = var2.getSupportLowerBound();
    var2.reseedRandomGenerator(9223372036854775807L);
    double var9 = var2.getStandardDeviation();
    double var12 = var2.cumulativeProbability(0.28680180181229414d, 882.393803686349d);
    double var13 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var10 = var0.nextChiSquare(3.227226180092589d);
//     int var13 = var0.nextInt(99, 1034);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2769454227505013d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03246237386009703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6602783082944866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.988888050111759d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 719);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test387"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.022147517156860363d), 0.0037606833841678563d, 3.853702795813156d);
    double var5 = var3.density(3.4444618688311177d);
    double var6 = var3.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0037606833841678563d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test388"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(4.535946096335034E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 52.656667884905275d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test389"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.09105709288986738d, 0.7269109241219371d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.09105709288986738d);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextWeibull(5.369230505538924d, (-0.005653700782947468d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.005314074991382535d);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test391"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.7099776159634059d, 1.1343677288932124d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2066881553532225d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test392"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.2541246823682386d);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getMin();
    boolean var4 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test393"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1024.0f, 8184);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test394"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.5692125921887341d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test395"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    boolean var2 = var0.equals((java.lang.Object)5);
    var0.setNumElements(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test396"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    float var9 = var0.getExpansionFactor();
    float var10 = var0.getContractionCriteria();
    var0.setContractionCriteria(4.0f);
    int var13 = var0.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test397"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
    java.lang.Number var10 = var9.getLo();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var9.getHi();
    java.lang.Number var13 = var9.getArgument();
    java.lang.Number var14 = var9.getLo();
    java.lang.Number var15 = var9.getLo();
    java.lang.Number var16 = var9.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1024.0f+ "'", var10.equals(1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100+ "'", var12.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0L+ "'", var13.equals(0L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 1024.0f+ "'", var14.equals(1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 1024.0f+ "'", var15.equals(1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 100+ "'", var16.equals(100));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test398"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)0);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test399"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(4.6220390880797995d, 1.0000000077187865d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000000077187865d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test400"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var2.getContext();
    java.lang.Throwable[] var6 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test401"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)9.136008114865476d, (java.lang.Number)(-2.7830471997385823E34d), true);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test402"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var4 = var2.inverseCumulativeProbability(0.0d);
    boolean var5 = var2.isSupportConnected();
    boolean var6 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test403"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.0000000000379432d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test404"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.706533175782903E-6d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test405"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.8575054451473088d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test406"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(27326631, 99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27326532);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     var0.reSeed(64L);
//     var0.reSeed();
//     double var11 = var0.nextCauchy(0.9870620532286489d, 1.3349505155866186d);
//     java.lang.String var13 = var0.nextHexString(762);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.9937263875082925d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "1adf9a635bf095a7b92d38fbd2fde324d35a6a0d8224dadbff5ccbdf80168cc237e7eb85fb0131ac210d7deb9a75f51832ce8145bd5fba01d03e57a1278ee8b5e4bcc784f97674cea905e1c251c9fadf21ac79ff9929cecd7e79ea6d02bfa4ac0d37cf4d170f679c7d872b852885b841f8fbfdcd3f37d89ad1b405dc7841c8d235fd81699b2d35a7aa711bf694e2358205d92c894210fba8173d1a175c5a9c1226ae66e183494870b1cdcef54e7638a0e00dd0392fe379df630e425dce6ef8bdba8202b6214fa53b5e95acdebc0b6a65694abc6f490d7d0982814116b97fc55ee5bb42579364eddd8519c8d6250505a3ffdc2276fbbb2838bc6b86097ddbc883cd84d4dbe7386bf3c5939ba661c2c7dfe1c1d151e35d294d33b38f6a0bafe4fedb4df0892f598981edec22705682ea8e33ada8da4eac9f9fb240002d095828c1775c7d9ab17cdb5e80c8fe7fc0ffb6c1e1b334a7271bad6c70539000e4771b42377bdb8ee608970142c86b572ef6181a8f235efbdf01af871cd613d247"+ "'", var13.equals("1adf9a635bf095a7b92d38fbd2fde324d35a6a0d8224dadbff5ccbdf80168cc237e7eb85fb0131ac210d7deb9a75f51832ce8145bd5fba01d03e57a1278ee8b5e4bcc784f97674cea905e1c251c9fadf21ac79ff9929cecd7e79ea6d02bfa4ac0d37cf4d170f679c7d872b852885b841f8fbfdcd3f37d89ad1b405dc7841c8d235fd81699b2d35a7aa711bf694e2358205d92c894210fba8173d1a175c5a9c1226ae66e183494870b1cdcef54e7638a0e00dd0392fe379df630e425dce6ef8bdba8202b6214fa53b5e95acdebc0b6a65694abc6f490d7d0982814116b97fc55ee5bb42579364eddd8519c8d6250505a3ffdc2276fbbb2838bc6b86097ddbc883cd84d4dbe7386bf3c5939ba661c2c7dfe1c1d151e35d294d33b38f6a0bafe4fedb4df0892f598981edec22705682ea8e33ada8da4eac9f9fb240002d095828c1775c7d9ab17cdb5e80c8fe7fc0ffb6c1e1b334a7271bad6c70539000e4771b42377bdb8ee608970142c86b572ef6181a8f235efbdf01af871cd613d247"));
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test408"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test409"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1794L, (-27326631));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test410"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.007645651245452489d, 0.06313470951770385d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00764565124545249d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test411"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.99999994f), 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test412"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(100.07621862802338d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test413"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var3 = var2.getNumericalVariance();
    double var5 = var2.inverseCumulativeProbability(2.706533175782903E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0574806988857035E105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2.0629967313662414E53d));

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test414"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var4.clear();
    int var7 = var4.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test415"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(9);
    float var2 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test416"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.Class var17 = var2.getDeclaringClass();
    java.lang.String var18 = var2.toString();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    boolean var23 = var21.equals((java.lang.Object)(short)10);
    java.lang.Class var24 = var21.getDeclaringClass();
    java.lang.Class var25 = var21.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var33);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var33);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
    org.apache.commons.math3.stat.ranking.NaNStrategy var39 = var38.getNanStrategy();
    boolean var41 = var39.equals((java.lang.Object)(short)10);
    java.lang.Class var42 = var39.getDeclaringClass();
    java.lang.Class var43 = var39.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var44 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45);
    org.apache.commons.math3.stat.ranking.NaNStrategy var47 = var46.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var48 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47, var48);
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47);
    org.apache.commons.math3.stat.ranking.TiesStrategy var51 = var50.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var52 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var44, var51);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var53 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var39, var51);
    java.lang.String var54 = var51.name();
    java.lang.String var55 = var51.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var56 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var51);
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var51);
    org.apache.commons.math3.stat.ranking.TiesStrategy var58 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var58);
    org.apache.commons.math3.stat.ranking.NaNStrategy var60 = var59.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var61 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var62 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var60, var61);
    java.lang.Class var63 = var60.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var64 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var65 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var60, var64);
    org.apache.commons.math3.stat.ranking.TiesStrategy var66 = var65.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var67 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var66);
    java.lang.Class var68 = var66.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var69 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "MAXIMAL"+ "'", var18.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "AVERAGE"+ "'", var54.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "AVERAGE"+ "'", var55.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(3.1975339658050914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.256484760814486d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test418"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    int var4 = var0.getNumElements();
    int var5 = var0.getExpansionMode();
    double var7 = var0.addElementRolling(0.9233044426883612d);
    double[] var8 = var0.getElements();
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test419"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-285.0810761538832d));

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test420"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
//     java.lang.Number var10 = var9.getLo();
//     var4.addSuppressed((java.lang.Throwable)var9);
//     java.lang.Number var12 = var9.getHi();
//     java.lang.Number var13 = var9.getHi();
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.exception.NoDataException var18 = new org.apache.commons.math3.exception.NoDataException();
//     java.lang.Throwable[] var19 = var18.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var16, (java.lang.Number)9.332621544395286E157d, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var15, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var14, (java.lang.Object[])var19);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test421"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(751);
    double[] var2 = var1.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test422"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(3748598005569525248L, 19656L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3748598005569505592L);

  }

}
