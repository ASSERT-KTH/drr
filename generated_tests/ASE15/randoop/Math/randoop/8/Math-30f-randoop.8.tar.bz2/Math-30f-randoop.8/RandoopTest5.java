
import junit.framework.*;

public class RandoopTest5 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var5 = var0.nextT(0.8390715290764524d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextCauchy(2.4759461198032047d, (-3.30279209400559d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.580454345537099d));
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(5.520948362159764E-88d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test3"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    double var6 = var2.getNumericalMean();
    double var7 = var2.getSupportLowerBound();
    double var8 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1010, 924);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test5"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextGaussian(3.2132396021992005d, 0.17936156675857706d);
//     double var12 = var0.nextCauchy(3.7252681214586643d, 3.1936828330503824d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than, or equal to, the minimum (3.306)", "69edf03da95d455d35c06f9275120ff5ad761ccf1206604457deddc19e60dd8276e5c5d72e427a469c2b04f26c04360c7aa1d09dab49dee690b9fb919293bec");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.380067832861142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.013021142342855162d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.3714817688773326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.1129687668857176d);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test6"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    java.lang.Class var8 = var2.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(1195, 4064528);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(2.1734929141759232E16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test9"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    int var5 = var2.ordinal();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test10"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.03097415474563565d, 4975.561694056367d, 2.0102753218462723d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test11"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double var16 = var14.addElementRolling(3.5321218005364248d);
    int var17 = var14.getNumElements();
    int var18 = var14.getNumElements();
    float var19 = var14.getExpansionFactor();
    var14.setNumElements(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed(0L);
//     int var13 = var0.nextInt(0, 1010);
//     double var15 = var0.nextT(0.33270341242676643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.10432960274684124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 751);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.42806631226941894d);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test13"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.7534324315490821d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(9.569347564413189E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(5.262179821628377d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.0d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test16"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setExpansionFactor(4.0000005f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test17"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    int var15 = var14.getExpansionMode();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var17.setContractionCriteria(1024.0f);
    var17.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var23.setContractionCriteria(1024.0f);
    var23.setElement(0, 3.0000000000000004d);
    float var29 = var23.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var17, var23);
    double[] var31 = var17.getInternalValues();
    var17.setElement(100, 27.12061425361551d);
    var17.contract();
    org.apache.commons.math3.distribution.NormalDistribution var38 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var39 = var38.isSupportConnected();
    boolean var40 = var38.isSupportConnected();
    double[] var42 = var38.sample(5);
    var17.addElements(var42);
    org.apache.commons.math3.util.ResizableDoubleArray var44 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var44.setContractionCriteria(1024.0f);
    var44.setElement(0, 3.0000000000000004d);
    float var50 = var44.getContractionCriteria();
    boolean var52 = var44.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var53 = var44.copy();
    double[] var54 = var44.getElements();
    double[] var55 = var44.getElements();
    double[] var56 = var44.getInternalValues();
    double var57 = var16.mannWhitneyUTest(var42, var56);
    var14.addElements(var42);
    org.apache.commons.math3.util.ResizableDoubleArray var59 = var14.copy();
    int var60 = var14.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 9.569347564413189E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-785605799), (-5));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test19"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(128270, (-1623574463));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test20"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    float var2 = var1.getExpansionFactor();
    var1.addElement((-1.5574077246549023d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test21"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.2676855983885d);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test22"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-11172.476296932173d), 0.9999999999999919d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test23"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 0.01768834252748158d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test24"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(680227, 1.7763568E-15f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     double var18 = var0.nextExponential(3.431877347714405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.212002420493204d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.025549558489554536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.2859716551644924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.347663621247331d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 33L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.025690509057663815d);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test26"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    java.lang.String var5 = var2.toString();
    java.lang.String var6 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "MAXIMAL"+ "'", var6.equals("MAXIMAL"));

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test27"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.37265870739300694d));

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test28"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextWeibull(6.0d, 5.183028998081309d);
//     int var18 = var0.nextPascal(100, 5.520948362159764E-88d);
//     var0.reSeedSecure();
//     double var22 = var0.nextGamma(0.3223349576087434d, 3.4433010476697197d);
//     double var24 = var0.nextChiSquare(1.329242941412034d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var27 = var0.nextUniform(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.042611685223234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0808214227436916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8.392064683891844d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.0404054854018465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.6668369570651463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0012606170948484944d);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     int var10 = var0.nextZipf(1, 0.38805925492513493d);
//     java.lang.String var12 = var0.nextSecureHexString(98822);
//     java.lang.String var14 = var0.nextHexString(2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "24"+ "'", var14.equals("24"));
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test30"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    boolean var15 = var13.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var16);
    java.lang.String var18 = var13.name();
    org.apache.commons.math3.random.RandomGenerator var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var19);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "MAXIMAL"+ "'", var18.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test31"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1107, (-8));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test32"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.362006553099749d, 8.14132845107721E-6d);
    double var3 = var2.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.inverseCumulativeProbability(101.3970117354133d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test33"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    java.lang.String var8 = var2.name();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test34"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(5594589197447221635L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5594589197447221635L);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test35"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(9187355818195226112L, 437317876998765120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8750037941196460992L);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test36"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(61L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 61L);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test37"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-19.406218909794774d), 1.8793939982176235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19.406218909794774d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test38"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.49999994f), 3.255364039133607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.4999999f));

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test39"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.6345871160370109d, (java.lang.Number)6.868542863871458d, false);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test40"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(4.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0000005f);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test42"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     long var15 = var0.nextPoisson(97.97198016599408d);
//     int var18 = var0.nextZipf(9, 3.4814111562406533d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextZipf((-20332865), 5.780270116065924d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3484068883493103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3439500128493742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 108L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test44"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.99999994f, 0.0078125f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0078125f);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test45"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var15.setContractionCriteria(1024.0f);
    var15.setElement(0, 3.0000000000000004d);
    float var21 = var15.getContractionCriteria();
    boolean var23 = var15.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var15.copy();
    double[] var25 = var15.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var27.setContractionCriteria(1024.0f);
    var27.setElement(0, 3.0000000000000004d);
    float var33 = var27.getContractionCriteria();
    boolean var35 = var27.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var27.copy();
    double[] var39 = new double[] { 100.0d, 0.0d};
    var27.addElements(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var42.setContractionCriteria(1024.0f);
    var42.setElement(0, 3.0000000000000004d);
    float var48 = var42.getContractionCriteria();
    boolean var50 = var42.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var51 = var42.copy();
    double[] var52 = var42.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
    boolean var54 = var41.equals((java.lang.Object)var53);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var26, var53);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var53);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var53.setExpansionMode(1195);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test46"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(97.8210147035919d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 97.8210147035919d);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test47"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.412848953997996d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var3, (java.lang.Number)1.412848953997996d);
//     var2.addSuppressed((java.lang.Throwable)var5);
//     java.lang.Number var7 = var2.getArgument();
//     boolean var8 = var2.getBoundIsAllowed();
//     java.lang.String var9 = var2.toString();
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test48"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(751);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4225.905396797109d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test49"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var4.setContractionCriteria(1024.0f);
    var4.clear();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var4);
    float var9 = var0.getContractionCriteria();
    float var10 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test50"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var6 = var5.getElements();
    int var7 = var5.getExpansionMode();
    float var8 = var5.getExpansionFactor();
    var5.setElement(127, 3.1936453631680304d);
    var5.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var5.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var0.copy();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test51"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)0, (java.lang.Number)98.78234435786233d, false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getArgument();
    boolean var7 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 98.78234435786233d+ "'", var5.equals(98.78234435786233d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)0+ "'", var6.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test52"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.99999994f));

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(3.2475886883319047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5115610200459808d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test54"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     var0.reSeedSecure(545642504737558400L);
//     org.apache.commons.math3.distribution.NormalDistribution var18 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var19 = var18.isSupportLowerBoundInclusive();
//     double var21 = var18.probability(0.007907055323073179d);
//     double var22 = var18.getSupportUpperBound();
//     double var24 = var18.probability(0.0d);
//     double var25 = var18.getMean();
//     double var26 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var18);
//     double[] var28 = var18.sample(99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4014509804104147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2184031760848177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 98.7043276147834d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test56"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     double var12 = var0.nextGaussian(1.0001683942492827d, 4.81548573505896d);
//     long var15 = var0.nextLong((-8568224012730343296L), 0L);
//     org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var19 = var16.nextSecureLong(1L, 10L);
//     double var22 = var16.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var24 = var16.nextExponential(2.33467759294052d);
//     org.apache.commons.math3.distribution.NormalDistribution var27 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var28 = var27.isSupportConnected();
//     boolean var29 = var27.isSupportConnected();
//     double[] var31 = var27.sample(5);
//     double var32 = var27.getNumericalMean();
//     double var33 = var16.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var27);
//     double var34 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var27);
//     boolean var35 = var27.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.095072584615446d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.009964866687684672d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.4321612630332558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-6.632574559050144d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-2488790701777353728L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.006610720737924218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 4.731718289134921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 100.07621862802338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 101.80658653349299d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test57"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(155L, (-144705876426790031L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-144705876426790031L));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test58"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-2.2937895310710235d), 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5193208606971118d);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test59"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextWeibull(6.0d, 5.183028998081309d);
//     int var18 = var0.nextPascal(100, 5.520948362159764E-88d);
//     var0.reSeedSecure();
//     int var22 = var0.nextSecureInt(1023, 1270);
//     double var24 = var0.nextExponential(1.221784168705742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3000325111746074d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6495807080327797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 83.42787209141669d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.697015692829264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1049);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.540809521494791d);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test60"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2.4014826029593057d, (-0.950581586494586d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.582774485877303d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.2291166414558345d, 0.21644885760862753d, 0.0d, (-676495215));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test62"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getSupportUpperBound();
    boolean var2 = var0.isSupportConnected();
    double var3 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test63"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("8e750f55d9b61373f2dc9cccb808740798b8b1f6fc3781c30108692ea59464573c369119b11a1998bf1e99b417b502566e7c044eca39d0cc7de6ce2ba0ee6932f237d76fb65e58b1a4e6d61f2bb992dc8f8bc966eb7afc69be70e63093697052081a6628dbac2e0215894807297fa2b4700d57113554b88876e5abd7b1febd3d2023d91ccefb245fc56cdede843fda9f95b3c5b5b1117ce02ff3d51c3e26baa64627737042785691b596ee64026780c1bd52ecc2887886c69819cc8b3643d5d7a32930d206b4640acf2cc19db35c2d6c49f086e25fd4827a6f7473b74f9260793037057c43dd7e86af1052b601c0ca9e9088570e95e750c9ed406f47403c0d30c05fb05131f7e910d556b936f14bf83f448b59d2621b9033b9ab0b6cbf8d5c1d1c7dd77dcd3191eee00516c849d2ee2c34749d8c700fd60ae859ec883e20c5ae3c9f9c7ac99782bc3b01c356330bc6fe2da4ce6060704b34c89adfa3acc4797a7b2c004e597279ccdeae3fe54af3ef7a21fd962e65791cd81040fb770a7c54babff15e3c26c6a912e154e377c78946850044408543212597afc389f98ee64386b55fa28497cdd79065e9d91141e10a756f727b4213b28f296ef59531cfcbeed09b4c95dfc0bf920e7e33a2d243c73e0afbd97ec0f50f3d887636037736ecf3461e002788079de2d983402eb3ac68ba63e5a355ef5474545b4ace46720da94ec2bb1a0ca20b8477667f05f9e51b9e589813913f74d059820b7e49c55e39a6218a4b19f499a41740f1dcd6fdd2fdc0794de9f213d0833ff9015df2a8c5e7368c48ef1e0151260e1cbbfd8b70ec3b4abbe431fe3e2efc4a762e54d7a0847975c9a4963ba145958d98d066215de7d0acebd9f8022340f78c29d5bf55d9");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test64"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    int var5 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    boolean var12 = var10.equals((java.lang.Object)(short)10);
    java.lang.Class var13 = var10.getDeclaringClass();
    java.lang.Class var14 = var10.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18, var19);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var22);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var22);
    java.lang.String var25 = var22.name();
    java.lang.String var26 = var22.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var22);
    java.lang.Class var28 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var30 = java.lang.Enum.<java.lang.Enum>valueOf(var28, "80003bfa100420754a5c172b3d15d4baa86b452cbf24fe4ea70809cdcaff4223075c602f395e8523b824c6a9b35a2b114b88463623a999562736cec8407e3544398e0328c23d564599fdd005ef94b35b7673062aacf36e883c40760a3bc02da1c5b7da8fc21690e22c53ea74f8473e69a3e13b1b8b1f3117b08c6e8e818bab0c88585c7e66330363f68acb3725dc48203e3e38ae607394cf541fb3362dd7c2cddf776b1b03e194036da412600c94dec1202257fd85922c815f61cabdf030c33fc00cf29b662f080565904a16aedc3c5b23375370928ccb9e094e942a9bb02e6166866be02c38b8fcb54b6335e65ff3cbb0c229f5541010b57a6a19287f3d3d92a3be90e17f9d8ce051e13610c50713eb90212fbc77401f3fde79d48fef4f6082451fe39dfa58f2b5ce4624c39af1558807e0c71c349d12f4ed1d034fdea98edc2c1e41b513a90c8c73ea784a5048eacef99d36520b0e38931cdfeecc7d569789c697edbd8d95c5cd0cd5a2a760e3aa59187e7cbd293b996a55a09caebf8aea18f04dfa4f456de821d07fc282d8ff7ee030459bd794727d005be0ac5e3e2e7f1304a73e4ad926b5cfe40685814ef9f216111490fa7cd7aab05788dccb1c19d135304af9c2c32412902c7bf0f78f54c0f1a37d1485cc80ec2cc1f34b3e830397e6b6dea60714baac658ae09839ff443e834b25690a62e8624205a36d5adc7652364");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test65"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.41791873580522526d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test66"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var10.setExpansionFactor(100.0f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var9, var10);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var9.copy();
    var9.clear();
    var9.setNumElements(255);
    var9.setExpansionMode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test67"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    java.lang.String var8 = var2.name();
    java.lang.String var9 = var2.toString();
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    int var15 = var12.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    boolean var22 = var20.equals((java.lang.Object)(short)10);
    java.lang.Class var23 = var20.getDeclaringClass();
    java.lang.Class var24 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var27.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var29);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var25, var32);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var32);
    java.lang.String var35 = var32.name();
    java.lang.String var36 = var32.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var32);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextGaussian(3.2132396021992005d, 0.17936156675857706d);
//     double var12 = var0.nextCauchy(3.7252681214586643d, 3.1936828330503824d);
//     double var15 = var0.nextF(3.2879738713425515d, 4.581418190307575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.240533652404984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.019944222488261613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.2061932951262935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.4591146067290817d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6146744499674263d);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test69"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, (java.lang.Number)3.233351086493488d, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var8);
    java.lang.Object[] var11 = new java.lang.Object[] { var4};
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var3, var11);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test70"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(6.578793360216593E219d, 0.5769681036283701d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test71"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(7.6293945E-4f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-4f);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test72"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 34L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-34L));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test73"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.412848953997996d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, (java.lang.Number)3.233351086493488d, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, var11);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var6, var11);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var11);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var11);
    org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var2, var11);
    var1.addSuppressed((java.lang.Throwable)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test74"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(7.400159832691739E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.40015983275928E-6d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test76"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(23.91344788708774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.0d);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeed();
//     double var18 = var0.nextF(0.018539642106444626d, 1.4840480658487383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.153573524043094d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.013350572911927542d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.242054776499464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6.293506485021325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0075446860491244E-9d);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test78"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var6 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)3.233351086493488d, var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var6);
//     org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, var6);
//     org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var6);
//     org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
//     org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException();
//     java.lang.Throwable[] var16 = var15.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var14, (java.lang.Object[])var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var13, (java.lang.Object[])var16);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test79"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 58L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 2);
//     java.math.BigInteger var8 = null;
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0L);
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 58L);
//     java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var12);
//     java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var13);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test80"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.825814487325096d, 93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.798551117961941E28d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test81"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-100), 9.094947E-13f, 2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test82"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.2207033E-4f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4551915E-11f);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.009166277471225287d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5998172202426106E-4d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test84"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var22 = var21.isSupportConnected();
    boolean var23 = var21.isSupportConnected();
    double[] var25 = var21.sample(5);
    var0.addElements(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var0.copy();
    var0.setNumElements(670);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test85"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double var2 = var0.addElementRolling(0.8390715290764524d);
    var0.setElement(670, 27.50058504859484d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements(9900);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test86"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1049, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6294);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     int var10 = var0.nextZipf(1, 0.38805925492513493d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextSecureLong(40320L, (-9223372036854695133L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test88"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.5002669897290136d, (-0.9775970065495919d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9681553458564858d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test89"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(919965907, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 919965907);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test90"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.03410560019633457d, (-0.31982339482235594d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.03410560019633457d);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test91"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(127.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(4.08146646114519d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test93"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var5 = var0.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.substituteMostRecentElement(4.865840722195883d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test94"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("d5c329bd9a60cc2fc4c845b0d1fb7c8dea6d19f45dd1a0ba56784cd1d861783f1de2a271ff7dd17a0c6d29eb94a6a81134f7f00a0ec08be5cbc79a323fd7d13641c4c4380152ea099c82099eed866cd93c5edbc30289ffaecf21ac5e33d91d98352be3eb484f91112a68af16b0b1d443243018397fdedcfb0213bf609de13a32355e76e5b420cad89aaeda804aa3afd64d4a4405383371e49efa420725433f9c0e0dab019424c37f764c757c7602bff33ead750538c25973cc210a368e06ea37aecfcfb11062a58d958675dd43ce1c20129a1183f7c77ae9f2c1feabd841c3871ccc2f89fa5b47dd9108585e77efd7ecdb11664967b3d51479410a6a906bcf0fb0fb123d76f7fff3977c614a9d731d584cf5b717abb0271209d74f6d5a8d07a15d2e6717e73fa05c575c61fc13969971bdec4c9a6394c6793a5f06f3600e26b1e228912c10dd32322769e5b4976ebd2061b4d1f306f8c07e05d3aa0d0609590a3c8abc40e060a86f54bf50fdb0e1ca822bdc3dd8cce3903ee89b6825fb6e7ee0d943c3744de6f91fe5dc36cf18bf04ae160fa80ac991e1bcfc9cbd72babd455b7bd99dc797455663283eda593d2847eaee6e30a737cf1ce4bd6b601eb23cd6da9df829d245ea0c73965a3929b9adcf2a9eb6b049301f7ebf83d5ef904391c92405e42b2495770715a67ef82a5af515f90da79ea9c7a7508cc7dc3a78a917af870");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test95"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.020294450361988292d), (java.lang.Number)7.105428E-15f, true);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test96"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.364770999664135d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(6.259401627677235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.259401627677236d);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test98"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeed();
//     double var19 = var0.nextUniform((-0.6836289098502112d), 3.0d, false);
//     double var21 = var0.nextChiSquare(1.0963506818711306d);
//     var0.reSeed(437317876998765120L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.280479249978234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.007879899322461921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.063414192868746d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4.416611942354338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.808451963690805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2.550267224746501d);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test99"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var12 = var11.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var14 = var13.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var18 = new double[] { 1.0d};
    var16.addElements(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var13.addElements(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var11.addElements(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setExpansionFactor(1.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test100"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.642566250494787d);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test101"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     long var11 = var0.nextPoisson(1.7297716605398856d);
//     double var14 = var0.nextWeibull(2.281783181607902d, 32.92012974757845d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextPascal(1180, 7.8139067709017285d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.450983640697789d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.159171083877699d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.8998550590914426E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.604404176538741d);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test102"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)99990000);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test103"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.6321205588285577d), 3.3900553644082354d, 3.2132396021992005d);
//     double var4 = var3.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-5.253744533174332d));
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.9968961379767788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8791771211955594d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test105"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    boolean var6 = var4.equals((java.lang.Object)(short)10);
    java.lang.Class var7 = var4.getDeclaringClass();
    java.lang.Class var8 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var16);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var16);
    java.lang.String var19 = var16.name();
    java.lang.String var20 = var16.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var22.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    double[] var27 = var22.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var30 = new double[] { 1.0d};
    var28.addElements(var30);
    int var32 = var28.getExpansionMode();
    double[] var33 = var28.getElements();
    double var34 = var21.mannWhitneyU(var27, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 16.0d);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextSecureHexString((-27326631));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004387942845773901d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.00778786051905d);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test107"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextWeibull(6.0d, 5.183028998081309d);
//     int var18 = var0.nextPascal(100, 5.520948362159764E-88d);
//     var0.reSeedSecure();
//     double var22 = var0.nextF(882.393803686349d, 3.8626412474598433d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextWeibull(0.0d, 2.5453090700369303E-9d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2673392444829967d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9206374191768428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 18.815807554991533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.812252088365086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.3481867864387673d);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test108"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(8.72051698654943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextCauchy(0.0d, 2040.3837802863068d);
//     double var14 = var0.nextWeibull(1.7784046860616962d, 3.6559346743185963d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2955646848225677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.7224608303460727d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-7610.8929782719615d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.3107662774599236d);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test110"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.3032372470426154d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.29861131299342814d));

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test111"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.probability(0.007907055323073179d);
    double var6 = var2.getStandardDeviation();
    double var7 = var2.getMean();
    double var9 = var2.inverseCumulativeProbability(0.006756178246282831d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 97.53002783273233d);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     double var12 = var0.nextBeta(3.5480122537930616d, 3.5480122537930616d);
//     int var15 = var0.nextZipf(9, 0.38805925492513493d);
//     double var18 = var0.nextF(3.0841429669768945d, 100.7122747073287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4460196666868095d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.370129921737534d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9.5408187373668E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6616912299356315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.9456270046239199d);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test113"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(78021.47903283725d, 355.70596950611366d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test114"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = var0.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test115"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.1132389726050125d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test116"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test117"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.sample();
//     var0.reseedRandomGenerator(8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-0.036808220661213344d));
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test118"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(13, 7.629395E-5f, 7.6293945E-6f, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test119"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var13.setContractionCriteria(1024.0f);
    var13.setElement(0, 3.0000000000000004d);
    float var19 = var13.getContractionCriteria();
    boolean var21 = var13.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = var13.copy();
    double[] var23 = var13.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    double[] var25 = var13.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var26.setContractionCriteria(1024.0f);
    var26.setElement(0, 3.0000000000000004d);
    float var32 = var26.getContractionCriteria();
    boolean var34 = var26.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var35 = var26.copy();
    double[] var36 = var26.getElements();
    var26.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var39 = var38.getElements();
    int var40 = var38.getExpansionMode();
    double[] var41 = var38.getInternalValues();
    var26.addElements(var41);
    double var43 = var12.mannWhitneyU(var25, var41);
    org.apache.commons.math3.stat.ranking.TiesStrategy var44 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var45 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44);
    org.apache.commons.math3.stat.ranking.NaNStrategy var46 = var45.getNanStrategy();
    boolean var48 = var46.equals((java.lang.Object)(short)10);
    java.lang.Class var49 = var46.getDeclaringClass();
    java.lang.Class var50 = var46.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var51 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var52 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var52);
    org.apache.commons.math3.stat.ranking.NaNStrategy var54 = var53.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var55 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54, var55);
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var54);
    org.apache.commons.math3.stat.ranking.TiesStrategy var58 = var57.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var59 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var51, var58);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var60 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var46, var58);
    org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var61.setContractionCriteria(1024.0f);
    var61.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var66 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
    var61.setElement(100, 1.2245129522199552d);
    double[] var70 = var61.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var71 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var73 = new double[] { 1.0d};
    var71.addElements(var73);
    int var75 = var71.getExpansionMode();
    double[] var76 = var71.getElements();
    double var77 = var60.mannWhitneyUTest(var70, var76);
    double[] var78 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var79 = var12.mannWhitneyU(var70, var78);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 136.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.09272622225462313d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test120"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.1862795170312377d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.836860525818306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test122"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.2407356563918071d), (-0.010785851297718047d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test123"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-61.95351437679464d), 0.11666398836735097d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-61.95351437679463d));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test124"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(130048, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test125"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(3.1780538303479458d, 3.4665531328750507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4665531328750507d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test126"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    int var5 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    boolean var12 = var10.equals((java.lang.Object)(short)10);
    java.lang.Class var13 = var10.getDeclaringClass();
    java.lang.Class var14 = var10.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18, var19);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var22);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var22);
    java.lang.String var25 = var22.name();
    java.lang.String var26 = var22.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var22);
    java.lang.Class var28 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var30 = java.lang.Enum.<java.lang.Enum>valueOf(var28, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.2879738713425515d);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 3.2879738713425515d+ "'", var3.equals(3.2879738713425515d));

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test128"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(56L, (-351L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19656L);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.02806276080706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.333010472204809d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test130"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var1 = var0.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var5 = new double[] { 1.0d};
    var3.addElements(var5);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    var0.addElements(var5);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    int var10 = var9.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test131"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(4.588999058751262d, 1034);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test132"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.8643992372211438d, (java.lang.Number)(-0.9044181407467577d), false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.9044181407467577d)+ "'", var4.equals((-0.9044181407467577d)));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(7.553298229414772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.146316966389537d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test135"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var0.setElement(100, 1.2245129522199552d);
    double[] var9 = var0.getInternalValues();
    float var10 = var0.getContractionCriteria();
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1024.0f);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test136"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.09724295972011165d, 2.1141481465164924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.04596388818802734d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test137"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    boolean var8 = var2.equals((java.lang.Object)1.4551915E-11f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test138"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
    java.lang.Number var10 = var9.getLo();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var9.getHi();
    java.lang.Number var13 = var9.getArgument();
    java.lang.Number var14 = var9.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1024.0f+ "'", var10.equals(1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100+ "'", var12.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0L+ "'", var13.equals(0L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 100+ "'", var14.equals(100));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test139"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.03005264204018276d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.030043599478791753d);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test140"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     double var10 = var0.nextF(1.8793939982176235d, 16.545662219537288d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3854536287719275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.015527998750193388d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.017923657181589937d);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test141"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(83.42787209141669d, 1.3027476538919007d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 318.4077388962058d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test142"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(924, 10.0f, 7.523165E-37f, 751);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test143"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(6294, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 24.449820056101398d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test144"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.03123733597590902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test146"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
    boolean var4 = var3.isSupportUpperBoundInclusive();
    double var5 = var3.getNumericalMean();
    var3.reseedRandomGenerator(884124501032112256L);
    boolean var8 = var3.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test147"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    double[] var6 = var5.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test148"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var12 = var0.getInternalValues();
    float var13 = var0.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.discardFrontElements((-676495215));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test149"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(4.2E-45f, 9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test150"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-144705876426790031L), (-2153214848064815104L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test151"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(882.393803686349d, 3.270534600767394d, 3.529069951149791d);
    double var5 = var3.probability(0.7871088143391114d);
    double var7 = var3.probability(0.025549558489554536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test152"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     var0.reSeed();
//     double var14 = var0.nextCauchy((-7.262980904399892d), 0.018734606752382445d);
//     double var17 = var0.nextF(0.038157775941106545d, 447.9102432789676d);
//     double var20 = var0.nextGamma(1.6224247951349726d, 1.7155019267144769d);
//     int var23 = var0.nextSecureInt(1073, 4066573);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.350841795625807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.003615401042158694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 23535998657016956L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-7.238068932951465d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.035992739525839E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3.7628193343349245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 3309915);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test153"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportConnected();
    double[] var5 = var2.sample(127);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    var6.setElement(128270, 6.686727934632684d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setExpansionFactor(9.094947E-13f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test154"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.445088612893593d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6266422245194085d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     double var11 = var0.nextCauchy(0.5211415343642575d, 1.098418460323332d);
//     int var14 = var0.nextInt(127, 1270);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var18 = var17.isSupportConnected();
//     double[] var20 = var17.sample(127);
//     double var21 = var17.getSupportLowerBound();
//     var17.reseedRandomGenerator(9223372036854775807L);
//     double var24 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     double var25 = var17.getNumericalMean();
//     double var26 = var17.getStandardDeviation();
//     boolean var27 = var17.isSupportConnected();
//     double var28 = var17.getSupportUpperBound();
//     double var29 = var17.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.281614896002267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.7219875967544513d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 72.32679532377001d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.023895748780263d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1253);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 102.20650666855305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test156"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var4 = var2.getNumericalMean();
    double var5 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextWeibull(6.0d, 5.183028998081309d);
//     double var18 = var0.nextF(16.545662219537288d, 1.4905488366463986d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var21 = var0.nextPermutation(243, 22489184);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3259166430920737d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.5293539156055057d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-55.63616884677721d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6.099999991499837d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.0305080028853286d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test158"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test159"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0f, (java.lang.Number)var4, false);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 58L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 2);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 850355429512472704L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 8);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var19);
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 58L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, var23);
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 56L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, (-4));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test160"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    int var15 = var14.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setExpansionMode(10100);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test161"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(2.0321705903560816d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.7497903081131745d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test162"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)4.0518358810872055d, (java.lang.Number)0.006332486605038009d, (java.lang.Number)(-0.9484644058632247d));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test163"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-785605799), 291729791);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test164"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(4.2E-45f, 0.49999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.2E-45f);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test165"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3, 662);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3574297);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test166"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-140));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test167"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(451, (-1623574463));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test168"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var7, (java.lang.Number)3.233351086493488d, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var10);
    java.lang.Object[] var13 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var5, var13);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var13);
    org.apache.commons.math3.exception.MaxCountExceededException var17 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, var2, var13);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     var0.reSeed();
//     double var19 = var0.nextUniform((-0.6836289098502112d), 3.0d, false);
//     var0.reSeedSecure((-1531225969699204352L));
//     long var24 = var0.nextSecureLong(4L, 1531225969699204352L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.266099613706622d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.015587542821244563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.212663814067419d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.995467717232029d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0422004845716133d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 934249390553163520L);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test170"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(98822);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test171"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    float var9 = var0.getExpansionFactor();
    float var10 = var0.getContractionCriteria();
    var0.setContractionCriteria(4.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardFrontElements((-10));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1024.0f);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test172"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.7534619774493243d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5236397786755846d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.412848953997996d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test174"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-285L), (-6481L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test175"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test176"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.8332364716232395d, (java.lang.Number)16.707111717247518d, (java.lang.Number)10.140709416791422d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.140709416791422d+ "'", var5.equals(10.140709416791422d));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test177"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("090e33be2466e57a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test178"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.getNumericalMean();
//     double var9 = var2.probability(12.063722427580958d);
//     var2.reseedRandomGenerator((-437317876998765120L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.89543988572233d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test179"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.06520344674258512d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.06520344674258512d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test180"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    java.lang.String var7 = var2.name();
    java.lang.String var8 = var2.name();
    java.lang.String var9 = var2.toString();
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    boolean var16 = var14.equals((java.lang.Object)(short)10);
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var17);
    java.lang.String var19 = var14.name();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "MAXIMAL"+ "'", var8.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "MAXIMAL"+ "'", var19.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     var0.reSeed(7L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.356551937039457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01844447987781785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1167881445488174592L);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test182"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     double var12 = var0.nextF(3.7339183133724134d, 8.590595999805713E106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.063995908765617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.801278716403626d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2594215751606516E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.535630356613149d);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test183"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.1198345179668387d, 201.7156361224559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.119834517966839d);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     long var15 = var0.nextPoisson(97.97198016599408d);
//     double var18 = var0.nextCauchy(0.0d, 0.14569630083882143d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2598713615599824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.881670691011993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 108L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.9274045416702621d));
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test185"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test186"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(924, (-17));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 941);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(4308.687015814714d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 65.64058969734134d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(100.0747172280404d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.448329826469603E43d);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     double var12 = var0.nextF(0.012950351706914819d, 0.023743591158329934d);
//     int var15 = var0.nextSecureInt(1, 27326631);
//     org.apache.commons.math3.distribution.IntegerDistribution var16 = null;
//     int var17 = var0.nextInversionDeviate(var16);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test190"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    boolean var6 = var0.equals((java.lang.Object)(-0.99999994f));
    var0.discardMostRecentElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(1.7014117E38f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test191"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)183.63204833513834d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test193"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.400312697951845d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9667182381347795d));

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.1999137787130581d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.2230357805130138d));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test195"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test196"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    boolean var11 = var9.equals((java.lang.Object)(short)10);
    java.lang.Class var12 = var9.getDeclaringClass();
    java.lang.Class var13 = var9.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var21);
    org.apache.commons.math3.random.RandomGenerator var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test197"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-3.8741345662445585d), (-127353.53036079442d), 0.5002669897290136d, 941);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test198"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(934249390553163520L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test199"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(4L, 437317876998765120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test200"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(40767);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 40767);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextGaussian(3.2132396021992005d, 0.17936156675857706d);
//     double var12 = var0.nextCauchy(3.7252681214586643d, 3.1936828330503824d);
//     double var14 = var0.nextT(97.8210147035919d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4866032706750767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.025552408583287556d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.08957755334065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.701411911973816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.3399642441284807d));
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.632831231253379d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8817492752640248d));

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test203"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.009939019418199392d);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     var0.reSeed();
//     double var14 = var0.nextCauchy((-7.262980904399892d), 0.018734606752382445d);
//     double var17 = var0.nextF(0.038157775941106545d, 447.9102432789676d);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var0.nextSample(var18, (-47));
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextInt(130048, 75157);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.09293831904196957d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.1600436721087803d));
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     double var15 = var0.nextWeibull(6.0d, 5.183028998081309d);
//     double var18 = var0.nextGamma(4.000000000000001d, 9.911077798205748E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1975339658050914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 11.625722118811352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-289.56440690231886d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.303612564348167d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 7.953302346369373E-5d);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test207"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 662);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test208"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3L);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var10);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var3, var10);
    var1.addSuppressed((java.lang.Throwable)var14);
    boolean var16 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test209"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.475071648092547E55d, (java.lang.Number)0.10432960274684124d, (java.lang.Number)0.7484183916512467d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test210"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    boolean var11 = var9.equals((java.lang.Object)(short)10);
    java.lang.Class var12 = var9.getDeclaringClass();
    java.lang.Class var13 = var9.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var21);
    java.lang.String var24 = var21.name();
    java.lang.String var25 = var21.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
    boolean var31 = var29.equals((java.lang.Object)(short)10);
    java.lang.Class var32 = var29.getDeclaringClass();
    java.lang.Class var33 = var29.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.NaNStrategy var37 = var36.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
    org.apache.commons.math3.stat.ranking.TiesStrategy var41 = var40.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var42 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var34, var41);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var43 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var41);
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45);
    org.apache.commons.math3.stat.ranking.NaNStrategy var47 = var46.getNanStrategy();
    boolean var49 = var47.equals((java.lang.Object)(short)10);
    java.lang.Class var50 = var47.getDeclaringClass();
    java.lang.Class var51 = var47.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var52 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var53 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53);
    org.apache.commons.math3.stat.ranking.NaNStrategy var55 = var54.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var56 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55, var56);
    org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    org.apache.commons.math3.stat.ranking.TiesStrategy var59 = var58.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var60 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var52, var59);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var61 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var47, var59);
    java.lang.String var62 = var59.name();
    java.lang.String var63 = var59.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var64 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var59);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var65 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var59);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var66 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var59);
    int var67 = var2.ordinal();
    org.apache.commons.math3.random.RandomGenerator var68 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var69 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "AVERAGE"+ "'", var24.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "AVERAGE"+ "'", var62.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + "AVERAGE"+ "'", var63.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test211"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
    java.lang.Number var10 = var9.getLo();
    var4.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var12 = var9.getHi();
    java.lang.Number var13 = var9.getArgument();
    java.lang.Number var14 = var9.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1024.0f+ "'", var10.equals(1024.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100+ "'", var12.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0L+ "'", var13.equals(0L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 0L+ "'", var14.equals(0L));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test212"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(80674L, 6937L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 73737L);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test213"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(short)100);
    java.lang.Number var2 = var1.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (short)100+ "'", var2.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.022147517156860363d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.592945654957258d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test215"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.3836624416669226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.41258142037406365d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test216"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var18.setContractionCriteria(1024.0f);
    var18.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var24.setContractionCriteria(1024.0f);
    var24.setElement(0, 3.0000000000000004d);
    float var30 = var24.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var18, var24);
    double[] var32 = var18.getInternalValues();
    var0.addElements(var32);
    double var35 = var0.substituteMostRecentElement((-0.4903739027740648d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test217"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.442523153288516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.26574700072199d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test218"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var10.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test219"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     double var12 = var0.nextF(0.012950351706914819d, 0.023743591158329934d);
//     int var15 = var0.nextSecureInt(1, 27326631);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var0.nextSample(var16, 1019);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test220"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(3853530431829475328L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3853530431829475328L);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test221"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(83.42787209141669d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test222"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(3.3166247903554003d, 1.412848953997996d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextBinomial((-47), 447.9102432789676d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5333239283098576d);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     double var13 = var0.nextGamma(0.027468903747454535d, 0.4036656746966349d);
//     double var15 = var0.nextChiSquare(1.6224247951349726d);
//     double var18 = var0.nextF(32.94631867978169d, 6.6401884929809825d);
//     java.lang.String var20 = var0.nextHexString(5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var22 = var0.nextHexString((-676495215));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.415347716749917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.965541846500923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.1844123836172259E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6102681742310754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.1343677288932124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "e4772"+ "'", var20.equals("e4772"));
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test224"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getMean();
    double var3 = var0.density(1.6713364782464966E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.3989422804014327d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test225"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.10170633440773788d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.10153108032969048d));

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test226"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(3.2999483368158655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test227"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(8, 1551199137);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var8 = var0.nextExponential(2.33467759294052d);
//     double var11 = var0.nextBeta(27.50058504859484d, 9.06969503466339d);
//     java.lang.String var13 = var0.nextHexString(1025);
//     java.lang.String var15 = var0.nextSecureHexString(8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextLong(17L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.004569737596798841d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.3206506333877575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.8087352063464021d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "bae7f919199a946487c61298219bda6c303b28dc287192d306ba4ab64b277fd1e2c484a531e3fac2d90359d092cf34ac09c4117dc9debcbd5c081036eb393d466d1ae8c88b7951e884a5049e023a26d871ad057dc5f89fda4fb2e4e8917146e2fe7a8c1488710031490ac67139645a19e1b14c99d1047a517947c62b21318d5e606dd81542ec1560568708833a83b52ce1bc7ba0737e39f9cc61c68bf60746ed59a80f08daa128c1d4baf8b3e31d7d6d65876d4e9720dcfa890e6af2dc348ca1ecbe34f87c7b5b0da531cbf83654080b98d1eda745dbd1ecbb1e3c30f1b33bb8347dd04f3eaa7321be91360ce5ebf721db97190cb6fdcc407936df5912168b047b196285ebbf3249db342a6a4bcecf87c7c4c256abdb04d2dfb81e2bb427f38febca4feb55177918abf7f6ab739efa2e63d17beb9b0c8bd4cef002571ff1b7b205ca84113947be1b9a4f23e59b2cd6e0af70ae99b5cc3a9001e970b1be3945b8f8b0bfd6438af03db8017f58c91ceff1edd4ad7d66cef128b3c3fa084b459d4a92bbcfcb93a97aa3335bf46254e00dde869e89cff2f25cda29daef0d853b216fb65e0e5306e2f23634fe75b82ae33b6978c3ddd615d50fa0855516b87d1686e3224c6a98b2e147f104118ab81d3ab1d9a493a3992237f178b736e647b84b9ea31f9a3fd72d4949d788cbfa8fdc90fbf5dd579e881373d2cf68f4577dc4deb10cb"+ "'", var13.equals("bae7f919199a946487c61298219bda6c303b28dc287192d306ba4ab64b277fd1e2c484a531e3fac2d90359d092cf34ac09c4117dc9debcbd5c081036eb393d466d1ae8c88b7951e884a5049e023a26d871ad057dc5f89fda4fb2e4e8917146e2fe7a8c1488710031490ac67139645a19e1b14c99d1047a517947c62b21318d5e606dd81542ec1560568708833a83b52ce1bc7ba0737e39f9cc61c68bf60746ed59a80f08daa128c1d4baf8b3e31d7d6d65876d4e9720dcfa890e6af2dc348ca1ecbe34f87c7b5b0da531cbf83654080b98d1eda745dbd1ecbb1e3c30f1b33bb8347dd04f3eaa7321be91360ce5ebf721db97190cb6fdcc407936df5912168b047b196285ebbf3249db342a6a4bcecf87c7c4c256abdb04d2dfb81e2bb427f38febca4feb55177918abf7f6ab739efa2e63d17beb9b0c8bd4cef002571ff1b7b205ca84113947be1b9a4f23e59b2cd6e0af70ae99b5cc3a9001e970b1be3945b8f8b0bfd6438af03db8017f58c91ceff1edd4ad7d66cef128b3c3fa084b459d4a92bbcfcb93a97aa3335bf46254e00dde869e89cff2f25cda29daef0d853b216fb65e0e5306e2f23634fe75b82ae33b6978c3ddd615d50fa0855516b87d1686e3224c6a98b2e147f104118ab81d3ab1d9a493a3992237f178b736e647b84b9ea31f9a3fd72d4949d788cbfa8fdc90fbf5dd579e881373d2cf68f4577dc4deb10cb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "72f0f61d"+ "'", var15.equals("72f0f61d"));
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test229"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, (-6495504173895948927L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test230"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0000002f, 129);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test231"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.456845392997481d, 0.4257901731989268d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.674075763105709d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test232"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    float var9 = var0.getExpansionFactor();
    float var10 = var0.getContractionCriteria();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.discardMostRecentElements((-47));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1024.0f);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10, (java.lang.Number)0.15729146283385384d, (java.lang.Number)(-1));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getHi();
    java.lang.Number var8 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.15729146283385384d+ "'", var8.equals(0.15729146283385384d));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test234"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(618, 7.629395E-5f, (-0.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test235"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (-1.351004290131115d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.9E-324d));

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test236"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(4.703633656885639d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.23678885062837743d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test237"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var4.setElement(1073, (-0.11238141480796804d));
    var4.contract();
    var4.addElement(0.01887862911434995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test238"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    double var6 = var2.getNumericalMean();
    double var7 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test239"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.clear();
    int var4 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test240"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1049, 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test241"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(3.192807891725479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.369230505538924d);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     java.lang.String var14 = var0.nextSecureHexString(101);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextSecureLong(8L, (-144705876426790031L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.405255012243949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.010607668656097354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 10.23031183516249d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "0fcf6b846aea980cc0f582c8ea54d1daa56a807555c72ee5d49ded6565848a538623b7040d6f008e83de1dca982512b69862e"+ "'", var14.equals("0fcf6b846aea980cc0f582c8ea54d1daa56a807555c72ee5d49ded6565848a538623b7040d6f008e83de1dca982512b69862e"));
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test243"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var7);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-100));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test245"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextCauchy(0.0d, 2040.3837802863068d);
//     double var13 = var0.nextChiSquare(4975.561694056367d);
//     double var16 = var0.nextF(0.3199299628391793d, 3.529069951149791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4788037233570703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3123183117661228d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1294.3830542039552d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4879.122955347341d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.6727512249078162d);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     var0.reSeed(64L);
//     var0.reSeed();
//     long var10 = var0.nextPoisson(3.1780538303479458d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(3.78983811332289d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6037887138661188d));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test248"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    int var4 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var13 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test249"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    boolean var6 = var4.equals((java.lang.Object)(short)10);
    java.lang.Class var7 = var4.getDeclaringClass();
    java.lang.Class var8 = var4.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var16);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var16);
    java.lang.String var19 = var16.name();
    java.lang.String var20 = var16.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var21 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    boolean var26 = var24.equals((java.lang.Object)(short)10);
    java.lang.Class var27 = var24.getDeclaringClass();
    java.lang.Class var28 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = var31.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var33 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32, var33);
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var36);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var24, var36);
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var40 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var40);
    org.apache.commons.math3.stat.ranking.NaNStrategy var42 = var41.getNanStrategy();
    boolean var44 = var42.equals((java.lang.Object)(short)10);
    java.lang.Class var45 = var42.getDeclaringClass();
    java.lang.Class var46 = var42.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var47 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var48 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
    org.apache.commons.math3.stat.ranking.NaNStrategy var50 = var49.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var51 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var50, var51);
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var50);
    org.apache.commons.math3.stat.ranking.TiesStrategy var54 = var53.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var55 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var47, var54);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var56 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var42, var54);
    java.lang.String var57 = var54.name();
    java.lang.String var58 = var54.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var59 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var24, var54);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var60 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var54);
    java.lang.Class var61 = var54.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "AVERAGE"+ "'", var20.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "AVERAGE"+ "'", var57.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + "AVERAGE"+ "'", var58.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test250"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.6945826528851498d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6740421177352662d);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test251"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var7.nextSample(var18, 4);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test252"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1551199137, 1.7014117E38f, 1024.0f, 27326631);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test253"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.7219875967544513d, (-1.178937054361303d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.178937054361303d));

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test254"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(4.0000005f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.7683716E-7f);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(3.0000000000000004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0523598775598299d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test256"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 3574297);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test257"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(4890.948027809601d, 1.2594215751606516E-9d, 0.7129093806593251d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test258"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var12 = new double[] { 100.0d, 0.0d};
    var0.addElements(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    double var16 = var14.addElementRolling(3.5321218005364248d);
    int var17 = var14.getNumElements();
    double[] var18 = var14.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var19.setContractionCriteria(1024.0f);
    var19.setElement(0, 3.0000000000000004d);
    float var25 = var19.getContractionCriteria();
    boolean var27 = var19.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = var19.copy();
    double[] var31 = new double[] { 100.0d, 0.0d};
    var19.addElements(var31);
    double var34 = var19.getElement(0);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 3.0000000000000004d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test259"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double[] var5 = var0.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionFactor(7.105428E-15f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test260"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    boolean var11 = var9.equals((java.lang.Object)(short)10);
    java.lang.Class var12 = var9.getDeclaringClass();
    java.lang.Class var13 = var9.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var21);
    java.lang.String var24 = var21.name();
    java.lang.String var25 = var21.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
    boolean var31 = var29.equals((java.lang.Object)(short)10);
    java.lang.Class var32 = var29.getDeclaringClass();
    java.lang.Class var33 = var29.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.NaNStrategy var37 = var36.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
    org.apache.commons.math3.stat.ranking.TiesStrategy var41 = var40.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var42 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var34, var41);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var43 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var41);
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45);
    org.apache.commons.math3.stat.ranking.NaNStrategy var47 = var46.getNanStrategy();
    boolean var49 = var47.equals((java.lang.Object)(short)10);
    java.lang.Class var50 = var47.getDeclaringClass();
    java.lang.Class var51 = var47.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var52 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var53 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53);
    org.apache.commons.math3.stat.ranking.NaNStrategy var55 = var54.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var56 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55, var56);
    org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    org.apache.commons.math3.stat.ranking.TiesStrategy var59 = var58.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var60 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var52, var59);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var61 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var47, var59);
    java.lang.String var62 = var59.name();
    java.lang.String var63 = var59.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var64 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var59);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var65 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var59);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var66 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var59);
    boolean var68 = var59.equals((java.lang.Object)0.1978648027698251d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "AVERAGE"+ "'", var24.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "AVERAGE"+ "'", var62.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + "AVERAGE"+ "'", var63.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test261"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.094947E-13f, 3.2999483368158655d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.094948E-13f);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test262"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var0);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test263"); }


    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 58L);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 2);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 1124L);
    org.apache.commons.math3.exception.OutOfRangeException var11 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-6481L), (java.lang.Number)0.027468903747454535d, (java.lang.Number)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     double var12 = var0.nextF(0.012950351706914819d, 0.023743591158329934d);
//     int var15 = var0.nextSecureInt(1, 27326631);
//     double var17 = var0.nextChiSquare(0.06323500510736024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.300503764689949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.021679763238360912d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1.9017462386649702d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.1734929141759656E16d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6869966);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.042988945741194E-9d);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.158982217932436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9963992720365391d);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     long var11 = var0.nextSecureLong((-144705876426790031L), 402440103350858240L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.16671848276216544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 55023570782910752L);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test267"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.8897644350211715d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 1.8897644350211715d+ "'", var2.equals(1.8897644350211715d));

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test268"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.533863737028583d, (java.lang.Number)0.004997851075629565d, false);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.8332364716232395d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 47.740933160383804d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test270"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(7.40015983275928E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-135132.79362714913d));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test271"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var11);
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var17, var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var17, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test272"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.902022817325913d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.27921572257999505d);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     double var12 = var0.nextF(0.012950351706914819d, 0.023743591158329934d);
//     double var15 = var0.nextGamma(Double.NaN, 0.5211415343642575d);
//     java.lang.String var17 = var0.nextHexString(1025);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4713610322249617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0060450492899458835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3.6948294002049735d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "a6239cff43a79f37ead5e266e43f20492a3cc29eaa0d67db77a2331b8fe49efaa714e2835feb142710e4ab36869b73a364a862175ba5674b4c8a5dad47c769b2b023bd2747dec6d02954d191700b6fd8887ed1c0851773c9cfddad1f84d0f76c65e888244c7944966cb30e065923688cd8b7f0e485b9a6334c50aac9f4fa1d5278798f09323887df22b674bad6d74c56cf23f2670e028254db4ed69ce819ff43bde6589c956785be5c3b708cd968e3b994ec0e03dcc0bdda7416c02bfb992ee7b96219f681bdf59cad1e6a7c4c2a8ae6227270f9f8ae591d9c2bf3998827ddfa1321f9d17914edd5d83487aeb20300aa1371fb5e2926a5084dcc52922a64adc3b5e0e88d68759856a2f32e877c65d66908657c945dba601c2bac696eccd7769111cde6469b53f83d0c14b16ab4973cf77d164cc427e9cea8a1d165850323c16c645691a4ea3f2434218dd976e8d1c319f0e639e727d766c81530f8af794b5a14987d4ec9f0171eb7a0539869b33f92f50bcbdbf0c7f2928f2fbaa715040a2e64a90d9706ec3c91f463637a81bce32d541bc90211dfeac6d9d1f6c7adf34008a6aaebf8d83af94395bbf9f6bf66c5a46a2ac74ad10259e98792b1acfe1807fb05fb3d95ada8419d077f9982819c6bdedafa8bc4c3e3c238ac2e20aaa9d88c65045eca92bea61d545e1ed918fdbc9260271f51bbf6802055c06d864e9811aeef65c"+ "'", var17.equals("a6239cff43a79f37ead5e266e43f20492a3cc29eaa0d67db77a2331b8fe49efaa714e2835feb142710e4ab36869b73a364a862175ba5674b4c8a5dad47c769b2b023bd2747dec6d02954d191700b6fd8887ed1c0851773c9cfddad1f84d0f76c65e888244c7944966cb30e065923688cd8b7f0e485b9a6334c50aac9f4fa1d5278798f09323887df22b674bad6d74c56cf23f2670e028254db4ed69ce819ff43bde6589c956785be5c3b708cd968e3b994ec0e03dcc0bdda7416c02bfb992ee7b96219f681bdf59cad1e6a7c4c2a8ae6227270f9f8ae591d9c2bf3998827ddfa1321f9d17914edd5d83487aeb20300aa1371fb5e2926a5084dcc52922a64adc3b5e0e88d68759856a2f32e877c65d66908657c945dba601c2bac696eccd7769111cde6469b53f83d0c14b16ab4973cf77d164cc427e9cea8a1d165850323c16c645691a4ea3f2434218dd976e8d1c319f0e639e727d766c81530f8af794b5a14987d4ec9f0171eb7a0539869b33f92f50bcbdbf0c7f2928f2fbaa715040a2e64a90d9706ec3c91f463637a81bce32d541bc90211dfeac6d9d1f6c7adf34008a6aaebf8d83af94395bbf9f6bf66c5a46a2ac74ad10259e98792b1acfe1807fb05fb3d95ada8419d077f9982819c6bdedafa8bc4c3e3c238ac2e20aaa9d88c65045eca92bea61d545e1ed918fdbc9260271f51bbf6802055c06d864e9811aeef65c"));
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test274"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.1377077104187023d, (java.lang.Number)0L, true);
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)100);
    boolean var7 = var6.getBoundIsAllowed();
    java.lang.Number var8 = var6.getArgument();
    var4.addSuppressed((java.lang.Throwable)var6);
    java.lang.String var10 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"+ "'", var10.equals("org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"));

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     long var15 = var0.nextLong((-1L), 9223372036854775807L);
//     int var18 = var0.nextSecureInt(1, 2147483647);
//     double var21 = var0.nextGaussian((-11.810664123296036d), 2.993222846126381d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.040003151136584d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.027555921855171417d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3349505155866186d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3929527865906204672L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1216583493);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-8.715340095278876d));
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test276"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-56L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 56L);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test277"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.getStandardDeviation();
//     double var9 = var2.density(120.0d);
//     double var11 = var2.density(1.7534324315490821d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.4154247036949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.520948362159764E-88d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test278"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(7.629395E-5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test279"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)99.13100687439591d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test280"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    var0.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    double var12 = var10.substituteMostRecentElement(0.005325222439319957d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setExpansionFactor(1.7763568E-15f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.215874911574371d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test281"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.352274166842308d, 3.272211577652278d, 3.3213905690642505d, 680227);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.7876493503419921d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test282"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("d5c329bd9a60cc2fc4c845b0d1fb7c8dea6d19f45dd1a0ba56784cd1d861783f1de2a271ff7dd17a0c6d29eb94a6a81134f7f00a0ec08be5cbc79a323fd7d13641c4c4380152ea099c82099eed866cd93c5edbc30289ffaecf21ac5e33d91d98352be3eb484f91112a68af16b0b1d443243018397fdedcfb0213bf609de13a32355e76e5b420cad89aaeda804aa3afd64d4a4405383371e49efa420725433f9c0e0dab019424c37f764c757c7602bff33ead750538c25973cc210a368e06ea37aecfcfb11062a58d958675dd43ce1c20129a1183f7c77ae9f2c1feabd841c3871ccc2f89fa5b47dd9108585e77efd7ecdb11664967b3d51479410a6a906bcf0fb0fb123d76f7fff3977c614a9d731d584cf5b717abb0271209d74f6d5a8d07a15d2e6717e73fa05c575c61fc13969971bdec4c9a6394c6793a5f06f3600e26b1e228912c10dd32322769e5b4976ebd2061b4d1f306f8c07e05d3aa0d0609590a3c8abc40e060a86f54bf50fdb0e1ca822bdc3dd8cce3903ee89b6825fb6e7ee0d943c3744de6f91fe5dc36cf18bf04ae160fa80ac991e1bcfc9cbd72babd455b7bd99dc797455663283eda593d2847eaee6e30a737cf1ce4bd6b601eb23cd6da9df829d245ea0c73965a3929b9adcf2a9eb6b049301f7ebf83d5ef904391c92405e42b2495770715a67ef82a5af515f90da79ea9c7a7508cc7dc3a78a917af870");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.9963992720365391d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0015665984284150634d));

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric(1270, 99990000, (-8992));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.256714654044899d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.1305575702614488d));
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test285"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(99, (-2106148007));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test286"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(16);
    int var2 = var1.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test287"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 2.141841126451995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed();
//     long var12 = var0.nextLong((-2153214848064815104L), 535514000795646456L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("24", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1477348351515381d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-544126308422713216L));
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test289"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.025552408583287556d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02554962803717905d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test290"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(437317876998765120L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeedSecure();
//     double var20 = var0.nextF(0.8442914302025525d, 31.501720002936757d);
//     long var22 = var0.nextPoisson(31.13221310339627d);
//     org.apache.commons.math3.distribution.RealDistribution var23 = null;
//     double var24 = var0.nextInversionDeviate(var23);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test292"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.0401488806678563d, (java.lang.Number)3.08957755334065d, var3);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test293"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    boolean var6 = var0.equals((java.lang.Object)(-0.99999994f));
    var0.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test294"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 10.0d};
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test295"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(101.79837155550794d, 0.8022140792099908d, 0.007324358818749868d, 1551199137);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test296"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(437317876998765120L, (-3847095399992368128L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 437317876998765120L);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test297"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(2.9592217263584035d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19.282958495719168d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(4.678155320865237d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.08164921326879017d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test299"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-437317876998765120L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test300"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test301"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.49999994f), 8.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.49999994f));

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     double var11 = var0.nextCauchy(0.5211415343642575d, 1.098418460323332d);
//     double var14 = var0.nextCauchy((-0.16320402005311493d), 2.010275321846272d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextSecureInt(623, (-17));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3494446051958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-8.645016112529477d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-469.95291631771255d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-5.839948202635948d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1.6200270709216482d));
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var0.reSeed();
//     long var12 = var0.nextLong((-1L), 2L);
//     int var15 = var0.nextInt(2, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextT((-118.79542840366751d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.4724642749315286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.2400716508269891d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8.15172475104442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test304"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-285.0810761538832d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.07147419154409183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2673465757104284d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test306"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(1261121381978859776L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test307"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test308"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(7, (-0.0f), 4.2E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test309"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.8794632640771181d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test310"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.3841858E-7f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841858E-7f);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test311"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test312"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1024.0f, 2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test313"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.2132396021992005d, 0.8390715290764524d);
    double var3 = var2.getMean();
    double var4 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3.2132396021992005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8390715290764524d);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     double var11 = var0.nextCauchy(0.5211415343642575d, 1.098418460323332d);
//     int var14 = var0.nextInt(127, 1270);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var18 = var17.isSupportConnected();
//     double[] var20 = var17.sample(127);
//     double var21 = var17.getSupportLowerBound();
//     var17.reseedRandomGenerator(9223372036854775807L);
//     double var24 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     double var25 = var17.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.324290419959253d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.9568847409715004d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 16.87982562468983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.3737555507923713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 492);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 101.31373550235824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 100.88860117801379d);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test315"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.7014117E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7014117E38f);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-0.6032975776636308d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5470048677180578d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test317"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)5.347663621247331d, (java.lang.Number)(-96.50604730818554d), false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test318"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    int var3 = var0.getExpansionMode();
    double[] var4 = var0.getElements();
    int var5 = var0.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test319"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-118.79542840366751d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test320"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var2 = new double[] { 1.0d};
    var0.addElements(var2);
    int var4 = var0.getExpansionMode();
    int var5 = var0.start();
    double var7 = var0.substituteMostRecentElement(4.678155320865237d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test321"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-47), 130048);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var9 = var0.nextCauchy(0.17936156675857706d, 0.8709381773848226d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var0.nextSample(var10, 670);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     double var11 = var0.nextWeibull(100.22056007056258d, 81188.39044958311d);
//     int var14 = var0.nextZipf(1, 10.140709416791422d);
//     var0.reSeedSecure(1124L);
//     org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution(98.471698070287d, 98.46394980830692d);
//     double var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.3578800080014712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4035898903472855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 81991.2846912628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 159.57194538785245d);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test324"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    java.lang.Class var17 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test325"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)4.9E-324d);
    float var9 = var0.getContractionCriteria();
    var0.setNumElements(10100);
    var0.contract();
    int var13 = var0.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test326"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.6100421169092672d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6117139755211727d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test327"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.7534324315490821d, (-8.01436751738282d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8.01436751738282d));

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test328"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-0.29861131299342814d), 0.00929392015692091d, 5.152730218441169d, 1034);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test329"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.addElement(3.3176882611728495d);
    float var5 = var0.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var0.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test330"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.285466362193911d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test331"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.9314281945454969d), var2, false);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test332"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     long var7 = var0.nextPoisson(13.14778027539684d);
//     int var10 = var0.nextZipf(1, 0.38805925492513493d);
//     var0.reSeedSecure(45L);
//     int var15 = var0.nextZipf(3, 97.97198016599408d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextHypergeometric(99, 6294, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test333"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.012812083397006109d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test334"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-8568224012730343296L), 612L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test335"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    var0.clear();
    float var12 = var0.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     long var15 = var0.nextPoisson(97.97198016599408d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextBinomial((-5), 4.530436597647827d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.461356010067051d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.06809936100000072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 108L);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test337"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1531225969699204352L, 612L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1531225969699204964L);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test338"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)130.35560904666173d, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test339"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var6 = var5.getElements();
    int var7 = var5.getExpansionMode();
    float var8 = var5.getExpansionFactor();
    var5.setElement(127, 3.1936453631680304d);
    var5.setElement(1024, 3.215874911574371d);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var5.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var15);
    double[] var17 = var0.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test340"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    double[] var10 = var0.getElements();
    double[] var11 = var0.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    float var13 = var12.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.5f);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test341"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    int var3 = var2.ordinal();
    int var4 = var2.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var13 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var11);
    double[] var14 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray();
    int var16 = var15.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var20 = new double[] { 1.0d};
    var18.addElements(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    var15.addElements(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var25 = var13.mannWhitneyUTest(var14, var20);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     int[] var9 = var0.nextPermutation(1124, 10);
//     var0.reSeed((-535514000795646456L));
//     int var14 = var0.nextSecureInt(0, 29);
//     var0.reSeedSecure();
//     double var19 = var0.nextUniform(3.469446951953614E-18d, 45.24030222698074d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1509021021915005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.016226386083736593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 10.549104754967635d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test343"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 4.723647519700551d);
    double var4 = var2.cumulativeProbability(0.9998245123878073d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.cumulativeProbability(2.7182818285621857d, 1.1368683772161603E-13d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5838152787471453d);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     var0.reSeed();
//     double var13 = var0.nextChiSquare(3.127567616786903d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2721364814418528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.00441549729735375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 837496894691474176L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.7293467973612975d);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test345"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var9);
    boolean var12 = var6.equals((java.lang.Object)4.1495472005154115d);
    int var13 = var6.ordinal();
    java.lang.Class var14 = var6.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var17 = var16.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var18);
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var17, var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    boolean var26 = var24.equals((java.lang.Object)(short)10);
    java.lang.Class var27 = var24.getDeclaringClass();
    java.lang.Class var28 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = var31.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var33 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32, var33);
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var36);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var24, var36);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var17, var36);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var36);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var41 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var36);
    java.lang.String var42 = var36.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "AVERAGE"+ "'", var42.equals("AVERAGE"));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test346"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var9.setContractionCriteria(1024.0f);
    var9.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var18 = var17.isSupportConnected();
    double[] var20 = var17.sample(127);
    var9.addElements(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    double[] var23 = var8.rank(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var8.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.7628193343349245d, (-0.8390715290764524d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.855236746783707d);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     double var15 = var0.nextCauchy(6.0d, 0.6104227919456581d);
//     int var18 = var0.nextZipf(618, 5.000407837286738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.170589324782999d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03518701071515243d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0832355731689138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.672005667328684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)0.47712125471966244d, false);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var12 = var0.nextUniform(0.8390715290764524d, 3.215653939400476d, false);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var14 = var13.getSupportUpperBound();
//     boolean var15 = var13.isSupportConnected();
//     double var16 = var13.getStandardDeviation();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var13);
//     double var20 = var0.nextCauchy(3.468956023199054d, 0.05209977259005042d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.6503907634561417d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.05645161530227144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8641168894793373d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.8575054451473088d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.5463872214374164d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3.4358829787890994d);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test351"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(98.471698070287d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 99.0d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test352"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-785605799), (-100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-785605899));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test353"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    int var3 = var0.start();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var0.copy();
    boolean var6 = var0.equals((java.lang.Object)(-0.99999994f));
    var0.setNumElements(1124);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var0.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test354"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.0857950556867113d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test355"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.287776849500193d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.287776849500193d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test356"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(4.0f, 7.629395E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.629395E-6f);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test357"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.022405075367622047d, 4.283760323497615d);
//     double var3 = var2.sample();
//     double var5 = var2.density(3.461767687323154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-5.9823122531534985d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.06746940157497469d);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.1377077104187023d, (java.lang.Number)0L, true);
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)100);
    boolean var7 = var6.getBoundIsAllowed();
    java.lang.Number var8 = var6.getArgument();
    var4.addSuppressed((java.lang.Throwable)var6);
    java.lang.Number var10 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0L+ "'", var10.equals(0L));

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test359"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.density(0.0d);
    double var6 = var2.getNumericalMean();
    double var8 = var2.inverseCumulativeProbability(0.0d);
    double var9 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test360"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    java.lang.Class var6 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var14);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var16 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
    int var24 = var21.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var25);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
    boolean var31 = var29.equals((java.lang.Object)(short)10);
    java.lang.Class var32 = var29.getDeclaringClass();
    java.lang.Class var33 = var29.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.NaNStrategy var37 = var36.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var37);
    org.apache.commons.math3.stat.ranking.TiesStrategy var41 = var40.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var42 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var34, var41);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var43 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var29, var41);
    java.lang.String var44 = var41.name();
    java.lang.String var45 = var41.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var41);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var47 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var18, var41);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var48 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var41);
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "AVERAGE"+ "'", var44.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "AVERAGE"+ "'", var45.equals("AVERAGE"));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test361"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)97.97198016599408d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.014819381657606202d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test363"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(127);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test364"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
    java.lang.Number var6 = var5.getMax();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.4781445519135112d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 3.233351086493488d+ "'", var6.equals(3.233351086493488d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test365"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(1034, 0.0f, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test366"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.306414241335056d, 4.632543379969219d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2820067079642592d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test367"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.7297716605398856d, (java.lang.Number)99.76434593142625d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     double var11 = var0.nextCauchy((-1.0d), 0.03428444643176393d);
//     java.lang.String var13 = var0.nextHexString(1270);
//     double var16 = var0.nextGamma(3.1622776601683795d, 3.3166247903554003d);
//     var0.reSeedSecure();
//     double var20 = var0.nextGamma(2.0574806988857035E105d, 41.752984630466926d);
//     java.lang.String var22 = var0.nextHexString(19430);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.20780652443890868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8347169744384769d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "c47727564e7bca876af5c30627df08e3b891fc5f6caf6220653e1878992507689c5f131ff0e65933fb9c0342c9354d1ba0c2a1dacc07b70903feb410c3f567d386e2636e0da01a58c700abcc817ff4400fd92664e10605b97de47ed3ca6c8c23ad39ee82ce4e75d3ce2708aefb6dab84f12ab2f0839f85a9a28edcd00a4cf3fa9fc7f86b49c66b1f40e405aa4d4c2de01726207570035da2db6610b1873c814e69c442846d0927e2684fea183ed6abe37d2c6c693ed0f47f43f3d96fd2c6257effe0df63e711a6023bfd489567f24b4745597fa28c1b2642a052089c0c56f30abcb60b18343664e2166b80de64fcfcb191c72d3b38d8b61be11bb492b60cc30dc735916fadfde71fb49f8d427a17145fc296ec305b367e72b64d561a51b6a3f55f51c18c715220876f29215b5a1dd25b9661d10a74a030d141623f041f72d2906f3d74c5d8d358db9ee835a9c248c6ba8555891d76dcb97b788eb45eda64a6355664b3aa90f0fc7a9cbd1278e6450654cc9993cc1373b3778ea65b48b77136994cb57d054bc78b0ba6b075a35e9795b6d1a103abe7353cb8a846144be5ded9ffd9ca02bd5653afedf115383ff9e0c5a54c7b96bc16f952045f0667e7377aef13facec3f635b7220237ac8bcb46e204608371553ca4b07e9175a47e9de94fc6968a33542c31758d2211a95cfebe436c59261107950b5bb425baceb2bcce7be014f7e36a0062dae566d2db1aa898210783f5b3800d64ff93d57c90a615fc7f4e78dfe326a53525ece07a9b070b4c67954a35d3392b3e54aac12d6b2d4a7d4cd81bcee6378a4215d5cf5ac795335327bd8305858cafff222caffc3567ecef88a4805fb31ed6bf0f85083b3dd6bfdc29d59fe4701034931af7095e5bf1"+ "'", var13.equals("c47727564e7bca876af5c30627df08e3b891fc5f6caf6220653e1878992507689c5f131ff0e65933fb9c0342c9354d1ba0c2a1dacc07b70903feb410c3f567d386e2636e0da01a58c700abcc817ff4400fd92664e10605b97de47ed3ca6c8c23ad39ee82ce4e75d3ce2708aefb6dab84f12ab2f0839f85a9a28edcd00a4cf3fa9fc7f86b49c66b1f40e405aa4d4c2de01726207570035da2db6610b1873c814e69c442846d0927e2684fea183ed6abe37d2c6c693ed0f47f43f3d96fd2c6257effe0df63e711a6023bfd489567f24b4745597fa28c1b2642a052089c0c56f30abcb60b18343664e2166b80de64fcfcb191c72d3b38d8b61be11bb492b60cc30dc735916fadfde71fb49f8d427a17145fc296ec305b367e72b64d561a51b6a3f55f51c18c715220876f29215b5a1dd25b9661d10a74a030d141623f041f72d2906f3d74c5d8d358db9ee835a9c248c6ba8555891d76dcb97b788eb45eda64a6355664b3aa90f0fc7a9cbd1278e6450654cc9993cc1373b3778ea65b48b77136994cb57d054bc78b0ba6b075a35e9795b6d1a103abe7353cb8a846144be5ded9ffd9ca02bd5653afedf115383ff9e0c5a54c7b96bc16f952045f0667e7377aef13facec3f635b7220237ac8bcb46e204608371553ca4b07e9175a47e9de94fc6968a33542c31758d2211a95cfebe436c59261107950b5bb425baceb2bcce7be014f7e36a0062dae566d2db1aa898210783f5b3800d64ff93d57c90a615fc7f4e78dfe326a53525ece07a9b070b4c67954a35d3392b3e54aac12d6b2d4a7d4cd81bcee6378a4215d5cf5ac795335327bd8305858cafff222caffc3567ecef88a4805fb31ed6bf0f85083b3dd6bfdc29d59fe4701034931af7095e5bf1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6.652912208394895d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 8.590595999805713E106d);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.8040919077431283d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.33607730520703d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test370"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NoDataException var5 = new org.apache.commons.math3.exception.NoDataException();
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)9.332621544395286E157d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.34386069837598404d, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test371"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)4.9E-324d);
    float var9 = var0.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.getElement(93);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1024.0f);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test372"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test373"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(12700, 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test374"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-676495215));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test375"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    double var4 = var2.cumulativeProbability((-3.4657978658285428E-6d));
    double var5 = var2.getNumericalVariance();
    double var7 = var2.probability(27.567148453340938d);
    var2.reseedRandomGenerator(383341803785389312L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test376"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("ebed90d7f61005d7e2fe37ef3beacd28827ae8d1e63d63572f25ac21107028cc3ef9a2f500b394c6b7e580dd6705d72a5f245096663a7ef99da4dac5d67068c");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.8916709706052672d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7236461218218848d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test378"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.641606458128386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test379"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)3.233351086493488d, var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var7);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var1, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test380"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(3.7497903081131745d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3101800128676757d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test381"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(3.3176882611728495d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.200525380682005d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test382"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExpansionMode(75157);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test383"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.09272622225462313d);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test384"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.233351086493488d, var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException(var5, (java.lang.Number)0L, (java.lang.Number)1024.0f, (java.lang.Number)100);
//     java.lang.Number var10 = var9.getLo();
//     var4.addSuppressed((java.lang.Throwable)var9);
//     java.lang.Number var12 = var9.getLo();
//     org.apache.commons.math3.exception.NumberIsTooLargeException var16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
//     org.apache.commons.math3.exception.NumberIsTooSmallException var20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
//     var16.addSuppressed((java.lang.Throwable)var20);
//     var9.addSuppressed((java.lang.Throwable)var16);
//     org.apache.commons.math3.exception.MaxCountExceededException var24 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)201.7156361224559d);
//     org.apache.commons.math3.exception.MathInternalError var25 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var24);
//     var9.addSuppressed((java.lang.Throwable)var24);
//     org.apache.commons.math3.exception.util.Localizable var27 = null;
//     org.apache.commons.math3.exception.util.Localizable var28 = null;
//     org.apache.commons.math3.exception.util.Localizable var29 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var33 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var29, (java.lang.Number)3.3489254350599653d, (java.lang.Number)18L, false);
//     java.lang.Throwable[] var34 = var33.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var35 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var28, (java.lang.Object[])var34);
//     org.apache.commons.math3.exception.MathIllegalStateException var36 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var27, (java.lang.Object[])var34);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     double var8 = var0.nextGaussian(3.3142072789405845d, 0.1995641250475069d);
//     java.lang.String var10 = var0.nextSecureHexString(5);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var0.nextSample(var11, (-1));
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test386"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(5981.260539780036d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5981.0d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test387"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 0.3591731072391348d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test388"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     boolean var4 = var2.equals((java.lang.Object)(short)10);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var10 = var7.nextSecureLong(1L, 10L);
//     double var13 = var7.nextBeta(1.0d, 3.1622776601683795d);
//     var7.reSeedSecure(7L);
//     var7.reSeed();
//     boolean var17 = var2.equals((java.lang.Object)var7);
//     var7.reSeedSecure((-56L));
//     double var22 = var7.nextGaussian(3.1132389726050125d, 3.383931628367152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.21736860026352953d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-3.0203137455346987d));
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test389"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.1311185834675412d, (java.lang.Number)1.3885194886694814d, (java.lang.Number)3.287776849500193d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3.287776849500193d+ "'", var5.equals(3.287776849500193d));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test390"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)0.21400263603676362d);
    float var9 = var0.getExpansionFactor();
    float var10 = var0.getContractionCriteria();
    var0.setContractionCriteria(4.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1024.0f);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test391"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)3.233351086493488d, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var9);
    java.lang.Object[] var12 = new java.lang.Object[] { var5};
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var4, var12);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var12);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, var1, var12);
    java.lang.Number var17 = var16.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(8.72051698654943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test393"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.984925048774637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4401509632309146d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test394"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    boolean var4 = var2.equals((java.lang.Object)(short)10);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var7 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "MAXIMAL"+ "'", var7.equals("MAXIMAL"));

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test395"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(27.12061425361551d, 3.6408852451715354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.6408852451715354d);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     var0.reSeed();
//     long var10 = var0.nextSecureLong(0L, 1542623280274737152L);
//     double var13 = var0.nextBeta(2.3047395641448527d, 3.057274851180596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.183739261155591d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.005653700782947468d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 789202005636323456L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5154080236219478d);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test397"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.math.BigInteger var3 = null;
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 58L);
//     org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)1.0f, (java.lang.Number)var5, false);
//     java.math.BigInteger var10 = null;
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
//     java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 58L);
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 2);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 850355429512472704L);
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 8);
//     java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var20);
//     org.apache.commons.math3.exception.util.Localizable var22 = null;
//     org.apache.commons.math3.exception.util.Localizable var23 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var25 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var23, (java.lang.Number)1.412848953997996d);
//     java.lang.Throwable[] var26 = var25.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var27 = new org.apache.commons.math3.exception.NullArgumentException(var22, (java.lang.Object[])var26);
//     org.apache.commons.math3.exception.MaxCountExceededException var28 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var20, (java.lang.Object[])var26);
//     java.math.BigInteger var29 = null;
//     java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var29);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test398"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test399"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.probability(0.007907055323073179d);
    double var6 = var2.getSupportUpperBound();
    double var8 = var2.cumulativeProbability(4.583731940621995d);
    double var10 = var2.probability(4.9E-324d);
    double var11 = var2.getNumericalMean();
    double var12 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var12 = var0.nextUniform(0.8390715290764524d, 3.215653939400476d, false);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var14 = var13.getSupportUpperBound();
//     boolean var15 = var13.isSupportConnected();
//     double var16 = var13.getStandardDeviation();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var13);
//     double var18 = var13.getMean();
//     double var19 = var13.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.5213427749444888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.008772664288256161d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.842167901118271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.7412243123732107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.3636064196243784d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test401"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.362006553099749d, 8.14132845107721E-6d);
    double var3 = var2.getSupportUpperBound();
    var2.reseedRandomGenerator(40320L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test402"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(3.0623483795315067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7514427545997335d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test403"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-785605899), 100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test404"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     int[] var9 = var0.nextPermutation(1124, 10);
//     var0.reSeed((-535514000795646456L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(3, 72.32679532377001d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.504263421489547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.010478889350533357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test405"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(535514000795646464L, 36L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 535514000795646464L);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     long var11 = var0.nextLong(3L, 100L);
//     java.lang.String var13 = var0.nextHexString(10100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.38141643677263926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 61L);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test407"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.022405075367622047d, 4.283760323497615d);
    double var3 = var2.getMean();
    double var5 = var2.density(0.874052976737114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.022405075367622047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.09130660553240219d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test408"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1099);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test409"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.5869075889250874d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.024817848901220855d);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextCauchy(0.021137266976184718d, 0.6291190492340889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.20995672459709808d));
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test411"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(10.549104754967635d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.247938539284208d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test412"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setElement(0, 3.0000000000000004d);
    float var6 = var0.getContractionCriteria();
    boolean var8 = var0.equals((java.lang.Object)4.9E-324d);
    int var9 = var0.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.setContractionCriteria(1024.0f);
    var10.setElement(0, 3.0000000000000004d);
    float var16 = var10.getContractionCriteria();
    boolean var18 = var10.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var10.copy();
    double[] var20 = var10.getElements();
    double[] var21 = var10.getElements();
    double[] var22 = var10.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    var0.addElements(var22);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test413"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(762, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test414"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("a3ad55ba789c44653d5d5116871df2de220c78d5e8f730161754b4d39f9982a6f0f325ec2c81687c3553487e035c641342f0a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test415"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var2.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var4 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3, var4);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var7);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var13 = var12.isSupportLowerBoundInclusive();
//     double var14 = var12.sample();
//     double var15 = var12.getNumericalVariance();
//     boolean var16 = var12.isSupportLowerBoundInclusive();
//     double var17 = var12.getStandardDeviation();
//     double var19 = var12.density(120.0d);
//     double[] var21 = var12.sample(1195);
//     double[] var22 = var9.rank(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 100.65281071925759d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.520948362159764E-88d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test416"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    double[] var4 = var2.sample(99);
    double var6 = var2.cumulativeProbability(0.6104227919456581d);
    double var7 = var2.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.POSITIVE_INFINITY);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test417"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.412848953997996d);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var3, (java.lang.Number)1.412848953997996d);
    var2.addSuppressed((java.lang.Throwable)var5);
    boolean var7 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test418"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(16.545662219537288d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6691745171494606d));

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test419"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
    boolean var8 = var2.equals((java.lang.Object)4.1495472005154115d);
    int var9 = var2.ordinal();
    java.lang.Class var10 = var2.getDeclaringClass();
    java.lang.Class var11 = var2.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(5.4736351625495825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6898241876487198d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test421"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(670);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test422"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(4064528);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     double var9 = var0.nextF(0.021246670571198962d, 3.1936453631680304d);
//     long var11 = var0.nextPoisson(1.7297716605398856d);
//     double var14 = var0.nextWeibull(2.281783181607902d, 32.92012974757845d);
//     double var17 = var0.nextGaussian(3.1309638589241073d, 3.246534960233099d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var19 = var0.nextSecureHexString((-100));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.1830724624209497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.59399033058565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 40.04001019328077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4.081965186510913d);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test424"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(5.863439728021239d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.86343972802124d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test425"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(9.536744E-7f, 1179);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test426"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1), (java.lang.Number)3.233351086493488d, false);
//     org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)0L, true);
//     var4.addSuppressed((java.lang.Throwable)var8);
//     boolean var10 = var4.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
//     org.apache.commons.math3.exception.util.ExceptionContext var12 = var4.getContext();
//     java.lang.Number var13 = var4.getArgument();
//     java.lang.Throwable[] var14 = var4.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var14);
//     java.lang.String var16 = var15.toString();
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test427"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(75157);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test428"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NoDataException var4 = new org.apache.commons.math3.exception.NoDataException();
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)9.332621544395286E157d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test429"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)(-3.4657978658285428E-6d), (java.lang.Number)3.859177131877446d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.0894669675887705E52d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 120.51326057232106d);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test431"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.213239602199201d, (java.lang.Number)3.3166247903554003d, var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Object[] var6 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var6);
//     var4.addSuppressed((java.lang.Throwable)var7);
//     java.lang.Number var9 = var4.getHi();
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     java.lang.Object[] var19 = new java.lang.Object[] { 10L};
//     org.apache.commons.math3.exception.MaxCountExceededException var20 = new org.apache.commons.math3.exception.MaxCountExceededException(var16, (java.lang.Number)3.233351086493488d, var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, var19);
//     java.lang.Object[] var22 = new java.lang.Object[] { var15};
//     org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError(var14, var22);
//     org.apache.commons.math3.exception.MathArithmeticException var24 = new org.apache.commons.math3.exception.MathArithmeticException(var13, var22);
//     org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException(var12, var22);
//     org.apache.commons.math3.exception.NullArgumentException var26 = new org.apache.commons.math3.exception.NullArgumentException(var11, var22);
//     org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var10, var22);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     double var14 = var0.nextUniform(3.1936453631680304d, 8.033816814586373d);
//     long var16 = var0.nextPoisson(37.994147737115796d);
//     var0.reSeedSecure();
//     double var21 = var0.nextUniform(9.569347564413189E-4d, 3.3791583060607677d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var0.nextBeta(1.3101800128676757d, (-0.2407356563918071d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.6224066371974524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.036671791194109266d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9788890006342706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6.5274649640485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 26L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.4198636945737497d);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test433"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     double var3 = var2.sample();
//     double var4 = var2.getStandardDeviation();
//     boolean var5 = var2.isSupportConnected();
//     boolean var6 = var2.isSupportConnected();
//     boolean var7 = var2.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 101.07318644067483d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var11 = var0.nextGamma(0.0d, 3.2132396021992005d);
//     var0.reSeed();
//     double var15 = var0.nextCauchy(6.0d, 0.6104227919456581d);
//     double var17 = var0.nextT(3.5436855677394425d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextPascal(93, 13.14778027539684d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.0156550139823617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0282581962148252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.626640481992545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.859568431625929d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.5366093861305536d));
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextBeta(1.0d, 3.1622776601683795d);
//     var0.reSeedSecure(7L);
//     var0.reSeed();
//     double var12 = var0.nextWeibull(1.2245129522199552d, 1.0963506818711306d);
//     double var15 = var0.nextBeta(1.333010472204809d, 1.5707963267941214d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3089839426991366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.245246739178808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5692125921887341d);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test436"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(6937L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6937L);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test437"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.842167901118271d, (java.lang.Number)(-0.020294450361988292d), true);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test438"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var4.setContractionCriteria(1024.0f);
    var4.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var10.setContractionCriteria(1024.0f);
    var10.setElement(0, 3.0000000000000004d);
    float var16 = var10.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var10);
    double[] var18 = var4.getInternalValues();
    var4.setElement(100, 27.12061425361551d);
    var4.contract();
    org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var26 = var25.isSupportConnected();
    boolean var27 = var25.isSupportConnected();
    double[] var29 = var25.sample(5);
    var4.addElements(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var33 = new double[] { 1.0d};
    var31.addElements(var33);
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
    var4.addElements(var33);
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var37.setContractionCriteria(1024.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    double[] var42 = var37.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var37);
    var37.addElement(27.50058504859484d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(5832L);
//     double var8 = var0.nextGamma(45.24030222698074d, 100.77847174078188d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(3.4788037233570703d, (-589.6871983837793d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4975.561694056367d);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test440"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)1.5998172202426106E-4d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test441"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.21400263603676362d, 4.535946096335034E52d);
    double var4 = var2.inverseCumulativeProbability(0.0d);
    boolean var5 = var2.isSupportConnected();
    boolean var6 = var2.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var8 = var2.sample(1551199137);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextWeibull(0.7781512503836435d, 3.213239602199201d);
//     var0.reSeedSecure(56L);
//     var0.reSeed(0L);
//     int[] var13 = var0.nextPermutation(128270, 99);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 0.17747447229466043d, 13.14778027539684d);
//     double var18 = var17.getMean();
//     double var21 = var17.cumulativeProbability(0.31456926834144955d, 3.230325591810731d);
//     double var23 = var17.probability(3.577868738045182d);
//     double var24 = var17.getNumericalMean();
//     boolean var25 = var17.isSupportConnected();
//     double var26 = var17.getNumericalMean();
//     double var27 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var30 = var0.nextPermutation(29, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.355432905224732d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4756266502177484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.038157775941106545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-0.2407356563918071d));
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test443"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.29074983096826307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.974797868173702d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test444"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    boolean var4 = var2.isSupportConnected();
    double var6 = var2.density(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

//  public void test445() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest5.test445"); }
//
//
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(291729791);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//
//  }
//
  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test446"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var3.setContractionCriteria(1024.0f);
    var3.setElement(0, 3.0000000000000004d);
    float var9 = var3.getContractionCriteria();
    boolean var11 = var3.equals((java.lang.Object)0.21400263603676362d);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = var3.copy();
    double[] var15 = new double[] { 100.0d, 0.0d};
    var3.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    double[] var18 = var1.rank(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var19.setElement(5, 0.3845071169264922d);
    int var23 = var19.getExpansionMode();
    double[] var24 = var19.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setExpansionMode((-2083303935));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test447"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.7014117E38f, 1.7236461218218848d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7014116E38f);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test448"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(7.629395E-5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.2759576E-12f);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test449"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.003920326239751834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.77539005348868d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test450"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var3 = var2.isSupportConnected();
    boolean var4 = var2.isSupportConnected();
    boolean var5 = var2.isSupportLowerBoundInclusive();
    double var6 = var2.getMean();
    double var9 = var2.cumulativeProbability(0.0d, 2.1734929141759232E16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test451"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 58L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 2);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 850355429512472704L);
    java.math.BigInteger var9 = null;
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0L);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 58L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 2);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 10L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 5L);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var17);
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 58L);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 2);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 19656L);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test452"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy(3.0d, 0.8390715290764524d);
//     long var10 = var0.nextPoisson(3.5480122537930616d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextPoisson((-0.0323416025546303d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.5309065003762004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-10.391807722471109d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.246023039495206d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3L);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test453"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test454"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var6 = var0.nextGaussian(0.014644560842127431d, 0.014644560842127431d);
//     double var8 = var0.nextChiSquare(3.215653939400476d);
//     double var12 = var0.nextUniform(0.8390715290764524d, 3.215653939400476d, false);
//     org.apache.commons.math3.distribution.NormalDistribution var13 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var14 = var13.getSupportUpperBound();
//     boolean var15 = var13.isSupportConnected();
//     double var16 = var13.getStandardDeviation();
//     double var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var13);
//     double var18 = var13.getMean();
//     double[] var20 = var13.sample(5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.5585852085064507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.015247258047634327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7.087669156882293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.315210193049401d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.1113924139788876d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test455"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-10), (-1623574463));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1623574473));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test456"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.04175569827445511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5));

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test457"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.098418460323332d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test458"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var3, (java.lang.Number)3.3489254350599653d, (java.lang.Number)18L, false);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test459"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(19L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19L);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test460"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-21.78306364600953d), (-0.601575175951977d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test461"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.0f), (java.lang.Number)(-0.0f), false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test462"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.967710105131278d, 3.5616731857903305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.331813890294625d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test463"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.01844447987781785d, var1, false);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test464"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var3 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var3);
//     org.apache.commons.math3.random.RandomGenerator var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var5);
//     boolean var8 = var2.equals((java.lang.Object)4.1495472005154115d);
//     java.lang.String var9 = var2.toString();
//     org.apache.commons.math3.random.RandomGenerator var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var10);
//     org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var12.setContractionCriteria(1024.0f);
//     var12.setExpansionFactor(10.0f);
//     org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var21 = var20.isSupportConnected();
//     double[] var23 = var20.sample(127);
//     var12.addElements(var23);
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
//     org.apache.commons.math3.random.RandomDataImpl var26 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var29 = var26.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var31 = var26.nextT(0.47712125471966244d);
//     double var34 = var26.nextCauchy((-3.4657978658424197E-6d), 100.0d);
//     var26.reSeed();
//     java.lang.String var37 = var26.nextHexString(127);
//     double var40 = var26.nextGamma((-0.022147517156860363d), 5.0191180244969094E-6d);
//     boolean var41 = var25.equals((java.lang.Object)5.0191180244969094E-6d);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     double[] var43 = var42.getElements();
//     int var44 = var42.getExpansionMode();
//     float var45 = var42.getExpansionFactor();
//     var42.setElement(127, 3.1936453631680304d);
//     var42.setElement(1024, 3.215874911574371d);
//     org.apache.commons.math3.util.ResizableDoubleArray var52 = var42.copy();
//     org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray();
//     var53.setContractionCriteria(1024.0f);
//     var53.setElement(0, 3.0000000000000004d);
//     float var59 = var53.getContractionCriteria();
//     boolean var61 = var53.equals((java.lang.Object)0.21400263603676362d);
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = var53.copy();
//     double[] var65 = new double[] { 100.0d, 0.0d};
//     var53.addElements(var65);
//     org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray(var65);
//     boolean var68 = var42.equals((java.lang.Object)var65);
//     var25.addElements(var65);
//     double[] var70 = var11.rank(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "MAXIMAL"+ "'", var9.equals("MAXIMAL"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 3.420765892937262d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-0.06796390024844273d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-108.30459304090697d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "c27cb6591f76765d07bff805e78d7be30d44e1fb954b5470784540bc7a73596873ada016c00ae2dca6e071c253cd6aef9d4ba250decbad9757d6bf5cfeb5207"+ "'", var37.equals("c27cb6591f76765d07bff805e78d7be30d44e1fb954b5470784540bc7a73596873ada016c00ae2dca6e071c253cd6aef9d4ba250decbad9757d6bf5cfeb5207"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 9.17674955759094E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1024.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test465"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 10L};
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var6, (java.lang.Number)3.233351086493488d, var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var9);
    java.lang.Object[] var12 = new java.lang.Object[] { var5};
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var4, var12);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)0.006925146002330119d, var12);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var0, var1, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test466"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(3.632831231253379d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test467"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var3 = var2.isSupportLowerBoundInclusive();
//     double var4 = var2.sample();
//     double var5 = var2.getNumericalVariance();
//     boolean var6 = var2.isSupportLowerBoundInclusive();
//     double var7 = var2.getNumericalMean();
//     double var9 = var2.probability(12.063722427580958d);
//     double var10 = var2.getStandardDeviation();
//     double var11 = var2.sample();
//     double var13 = var2.density((-1.0035555880210079d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.41452522815295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 101.10059979863337d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test468"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(3.2676855983885d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.483930022151201d);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test469"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.022405075367622047d, 4.283760323497615d);
//     double var3 = var2.sample();
//     double var4 = var2.getStandardDeviation();
//     double var5 = var2.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.152568171329303d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.283760323497615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test470"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(4.1510015688468584d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.75665713955777d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test471"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(127, (-0.02172004731721395d));
    float var18 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10.0f);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test472"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(321, (-10238021));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test473"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.02238554306116827d, 1025);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.04846741624539E306d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test474"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2.357887982222818d, 3.4412438291909626d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.171545855993395d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-61.95351437679463d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3549.674899793401d));

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test476"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.5524949386970578E15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.552494938697057E15d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test477"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)318.4077388962058d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test478"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(7.2759576E-12f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test479"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.7014116E38f, 3.3176882611728495d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7014115E38f);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test480"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-143683.08381690684d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 17);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test481"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.909032998552898d), (java.lang.Number)0.7999302109750811d, (java.lang.Number)(-0.31982339482235594d));
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.31982339482235594d)+ "'", var5.equals((-0.31982339482235594d)));

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test482"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 58L);
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 2);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 850355429512472704L);
//     java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 8);
//     java.math.BigInteger var12 = null;
//     java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
//     java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 58L);
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 2);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var14);
//     java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 155L);
//     java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 56L);
//     java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var21);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test483"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    org.apache.commons.math3.distribution.NormalDistribution var21 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
    boolean var22 = var21.isSupportConnected();
    boolean var23 = var21.isSupportConnected();
    double[] var25 = var21.sample(5);
    var0.addElements(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var0.copy();
    float var28 = var27.getContractionCriteria();
    float var29 = var27.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1024.0f);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test484"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 58L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var3, (java.lang.Number)1.0f, (java.lang.Number)var7, false);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 58L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 2);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 850355429512472704L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 8);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var22);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0);
    org.apache.commons.math3.exception.NumberIsTooLargeException var27 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)32.92012974757845d, (java.lang.Number)var25, false);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 884124501032112256L);
    org.apache.commons.math3.exception.NumberIsTooSmallException var32 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)884124501032112256L, (java.lang.Number)6.868542863871458d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test485"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    double[] var1 = var0.getElements();
    int var2 = var0.getExpansionMode();
    float var3 = var0.getExpansionFactor();
    var0.setElement(127, 3.1936453631680304d);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var0.copy();
    var0.addElement(0.9122609917060266d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1401359.6943629922d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.43941783199387435d));

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test487"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    boolean var2 = var0.equals((java.lang.Object)5);
    var0.setContractionCriteria(100.0f);
    float var5 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test488"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(100.0d, 1.0d);
//     boolean var4 = var3.isSupportLowerBoundInclusive();
//     double var5 = var3.sample();
//     double var6 = var3.getNumericalVariance();
//     boolean var7 = var3.isSupportLowerBoundInclusive();
//     double var8 = var3.getStandardDeviation();
//     double var10 = var3.density(120.0d);
//     double[] var12 = var3.sample(1195);
//     double[] var13 = var0.rank(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 99.76977862029834d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.520948362159764E-88d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test489"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1542623280274737152L, 837496894691474176L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test490"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0842022E-19f, 1.7763568E-15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7763568E-15f);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     double var6 = var0.nextGamma((-1.00734152150007d), 0.002217427235567818d);
//     double var9 = var0.nextGaussian(0.9968961379767788d, 4.422926254591315d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextWeibull((-10.306684647491558d), 2.504224114108881d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.005807633391793179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9637478301978478d);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.012812083397006109d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.012811382410752756d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test493"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var0.setContractionCriteria(1024.0f);
    var0.setExpansionFactor(10.0f);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray();
    var6.setContractionCriteria(1024.0f);
    var6.setElement(0, 3.0000000000000004d);
    float var12 = var6.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var6);
    double[] var14 = var0.getInternalValues();
    var0.setElement(100, 27.12061425361551d);
    var0.contract();
    int var19 = var0.getNumElements();
    int var20 = var0.start();
    float var21 = var0.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 10.0f);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(183.63204833513834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10521.341352945761d);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test495"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong(1L, 10L);
//     var0.reSeed(0L);
//     var0.reSeed(64L);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextInt(1, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5L);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(3.3166247903554003d, 0.15729146283385384d);
//     double var5 = var0.nextT(0.47712125471966244d);
//     double var8 = var0.nextCauchy(3.0d, 0.8390715290764524d);
//     var0.reSeedSecure(9L);
//     var0.reSeed(19L);
//     var0.reSeedSecure();
//     var0.reSeed(80674L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextBinomial((-1623574463), (-948.6589633412129d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.7366609006134848d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.1283134292660044d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.015395056994395d);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test497"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(3.5354941951466117d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test498"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-17), 3574297);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-17));

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test499"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(535514000795646464L, (-2488790701777353728L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test500"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var2.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var2.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var2.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

}
