
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
//     double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var12 = new double[] { };
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var7, var14);
//     double[] var16 = null;
//     double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var21 = new double[] { };
//     boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
//     boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var16, var20);
//     double[][] var24 = new double[][] { var20};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var24);
//     double[] var29 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var30 = new double[] { };
//     boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var30);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
//     double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var37 = new double[] { };
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
//     double[][] var39 = new double[][] { var36};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var32, var39);
//     double[] var44 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var45 = new double[] { };
//     boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var45);
//     double var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var45);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var5, var30);
//     double var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var48);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    int[] var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 1236725234);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     int var13 = var0.nextBinomial(445938823, 0.5127948165466234d);
//     double var16 = var0.nextGamma(8.402273643127563d, 73.45997103732067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.399992204512466d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6749990788145617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 94.37406976352618d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 228667646);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 327.92227914992736d);
// 
//   }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(0.015854286399873473d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextInt(0, (-2102199606));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.03168344933511455d);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     long var10 = var0.nextLong(862908985188605553L, 3081282935693573632L);
//     long var13 = var0.nextLong(88L, 1697424459525688832L);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 100);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }
// 
// 
//     org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(63455071, (-1978339594));
//     int var3 = var2.getDimension();
//     int var4 = var2.getDimension();
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     int var7 = var6.nextInt();
//     long[] var8 = null;
//     long[][] var9 = new long[][] { var8};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)var9);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var5, (java.lang.Object[])var9);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
//     var15.addSuppressed((java.lang.Throwable)var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1978339594));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1978339594));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1051296493));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = null;
    long[][] var2 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var2, (java.lang.Object)(-86705920));
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     var0.reSeed();
//     double var10 = var0.nextUniform(0.8683854052034767d, 8.012870143369822d, true);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8.986565956563156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 86L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4.202152073411737d);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    int var18 = var4.nextZipf(59, 0.05190356240941041d);
    long var20 = var4.nextPoisson(141.746624376947d);
    double var22 = var4.nextChiSquare(23.95389662180223d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var25 = var4.nextF(2.407139629739897d, (-55731.07512021974d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 166L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 20.594153217877338d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextCauchy(1.0d, 100.96201588326613d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var17 = var4.nextHexString((-1219036332));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-86.03939096591209d));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var3.nextUniform(0.0d, 100.0d, false);
    double var10 = var3.nextUniform(0.0d, 10.0d);
    double var13 = var3.nextGamma(1.4808388048950236d, 5.279378583866268d);
    java.lang.Object[] var14 = new java.lang.Object[] { 5.279378583866268d};
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.9346068085718677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 11.13208948913201d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }
// 
// 
//     long[][] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
//     java.lang.String var2 = var1.toString();
//     java.lang.Number var3 = var1.getMin();
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     int var7 = var6.nextInt();
//     long[] var8 = null;
//     long[][] var9 = new long[][] { var8};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)var9);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var4, (java.lang.Object[])var9);
//     boolean var14 = var1.getBoundIsAllowed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1047461944));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var11 = var0.nextBeta(3.9346068085718677d, 4.359252164571766d);
//     double var14 = var0.nextBeta(5.271764897745934d, 99.3294376204589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.9416200447237086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-4.435837838930404d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 64.8425752781876d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.3999726405475486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.054028333260298586d);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    var4.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    double var12 = var2.nextGamma(1.4808388048950236d, 5.279378583866268d);
    double var15 = var2.nextWeibull(0.9614486620846391d, 0.9967298592597413d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var2.nextInt(0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 11.13208948913201d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.30986974897550007d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    int var6 = var2.nextInt(225475469);
    var2.setSeed(1165421618);
    var2.setSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 63455071);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)722500763);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)72L, (java.lang.Number)(-1.9841284616200225d), false);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    int var4 = var3.getIndex();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1232268348);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-430674889)+ "'", var5.equals((-430674889)));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var4.nextSecureInt(55901590, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     java.util.List var1 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var2 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0, var1);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    double var14 = var2.nextCauchy(1.3995975989718865d, 2456.934613457899d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var17 = var2.nextLong(1568649952495051008L, 579504999478877568L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-853.0935538935793d));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextHypergeometric(228667646, 1180133107, 368375954);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    int var3 = var1.nextInt();
    float var4 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 200911654);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.43617046f);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)14229.64140379441d, (java.lang.Number)0.2550536339465285d, (-401038879), var3, false);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    var1.clear();
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(100L);
    int var6 = var4.nextInt(1);
    int[] var7 = new int[] { };
    var4.setSeed(var7);
    int[] var9 = null;
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var9);
    byte[] var15 = new byte[] { (byte)0, (byte)10, (byte)(-1)};
    var11.nextBytes(var15);
    var1.nextBytes(var15);
    double var18 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.41632153096343955d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)15, (java.lang.Number)(-1219036332), false);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var19);
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    double[] var32 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var33 = new double[] { };
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var33);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var28, var35);
    double[] var40 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var41 = new double[] { };
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var41);
    double[] var47 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var48 = new double[] { };
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var48);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    double[] var54 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var55 = new double[] { };
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var55);
    double[][] var57 = new double[][] { var54};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var48, var50, var57);
    double[] var62 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var63 = new double[] { };
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var63);
    org.apache.commons.math3.util.MathArrays.OrderDirection var65 = null;
    double[] var69 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var70 = new double[] { };
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var69, var70);
    double[][] var72 = new double[][] { var69};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var63, var65, var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var63);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var26, var74);
    double var76 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var26);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var84 = var83.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var86 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var84, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var88 = org.apache.commons.math3.util.MathArrays.isMonotonic(var4, var84, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c();
//     int var3 = var2.nextInt();
//     long[] var4 = null;
//     long[][] var5 = new long[][] { var4};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-705659893));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var15, var19);
    double[][] var23 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var23);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var29 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var30 = new double[] { };
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var30);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    double[][] var39 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var32, var39);
    double[] var44 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var45 = new double[] { };
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var45);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    double[][] var54 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var45, var47, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var45);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var59 = org.apache.commons.math3.util.MathArrays.normalizeArray(var45, (-0.08244612118583806d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeed(12L);
    double var10 = var4.nextT(0.2149917709512965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-13.537512201729418d));

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextGaussian(10.327401159520946d, 26.19989450026949d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var4.nextUniform(1.0d, (-396.0582404126832d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.8075322823616666d);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var4 = new double[] { };
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var11 = new double[] { };
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
//     double[][] var13 = new double[][] { var10};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
//     double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var19 = new double[] { };
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var19);
//     double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var26 = new double[] { };
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
//     double[] var32 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var33 = new double[] { };
//     boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var33);
//     double[][] var35 = new double[][] { var32};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var28, var35);
//     double[] var40 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var41 = new double[] { };
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var41);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
//     double[] var47 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var48 = new double[] { };
//     boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var48);
//     double[][] var50 = new double[][] { var47};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var41, var43, var50);
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var41);
//     double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var4, var52);
//     double[] var54 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var55 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var53, var54);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
    int var19 = var4.nextHypergeometric(722500763, 91, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var22 = var4.nextPermutation(1755678109, 2146598351);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5127948165466234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     double var8 = var0.nextBeta(17.308134617107928d, 0.1176853562419486d);
//     double var11 = var0.nextBeta(101.73535858077676d, 102.09948570917526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextBeta(0.0d, 13.694776949656356d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12.143982053032621d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 63L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9999995363713023d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5223395795220434d);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     double var7 = var0.nextUniform(0.0d, 73.45997103732067d, false);
//     var0.reSeedSecure(7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var0.nextPermutation((-1816989844), (-1213169957));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 17.15515673997784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 62.44656672635262d);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.30986974897550007d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1, (java.lang.Number)10.24834333371038d, true);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getMax();
    boolean var7 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 4418713979230659041L+ "'", var6.equals(4418713979230659041L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2130077989, (java.lang.Number)(-33.183357284990514d), true);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.5127948165466234d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    long var13 = var4.nextLong(166L, 2110551683838641920L);
    double var16 = var4.nextWeibull(12.950477475625878d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var4.nextChiSquare((-0.8968620151317581d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1568649952495051008L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 9.915595306501313d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    var4.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var4.nextInt(63455071, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.26436923679510055d);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    double[] var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = var10.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var11, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-86.03939096591209d), var2, (-955090935), var11, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = var15.getDirection();
    double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var21 = new double[] { };
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var28 = new double[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    double[][] var30 = new double[][] { var27};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var23, var30);
    double[] var32 = null;
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var32, var36);
    double[][] var40 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var16, var40);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var3 = null;
    long[][] var4 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var35);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var46);
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    org.apache.commons.math3.util.MathArrays.OrderDirection var54 = null;
    double[] var58 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var59 = new double[] { };
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var59);
    double[][] var61 = new double[][] { var58};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var52, var54, var61);
    double var63 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var14, var52);
    double[] var68 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var69 = new double[] { };
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    double[] var75 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var76 = new double[] { };
    boolean var77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var75, var76);
    double[][] var78 = new double[][] { var75};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var69, var71, var78);
    double var80 = org.apache.commons.math3.util.MathArrays.safeNorm(var69);
    double[] var84 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var85 = new double[] { };
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var84, var85);
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = null;
    double[] var91 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var92 = new double[] { };
    boolean var93 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var91, var92);
    double[][] var94 = new double[][] { var91};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var85, var87, var94);
    double[] var96 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var85);
    double[] var97 = org.apache.commons.math3.util.MathArrays.ebeAdd(var52, var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var69);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var14 = var0.nextUniform(11.656091933465596d, 102.09948570917526d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(2.7429747933972144d, 0.7724109753531756d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.140061946947155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-6.784595164446156d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 103.35807222963325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5510811476769366d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 98.83578460040006d);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var4 = var0.nextF(1.7965218799149243d, 5.271764897745934d);
//     int var7 = var0.nextSecureInt(91, 100);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.07972951618563204d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 99);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    double[][] var22 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var15, var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var4, 0.011847334872158638d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-571311543), 825523605);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 1L};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
//     org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     double var12 = var4.nextCauchy(10.327401159520946d, 0.953266988202223d);
//     org.apache.commons.math3.distribution.RealDistribution var13 = null;
//     double var14 = var4.nextInversionDeviate(var13);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    boolean var4 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    int var18 = var4.nextZipf(59, 0.05190356240941041d);
    long var20 = var4.nextPoisson(141.746624376947d);
    double var22 = var4.nextChiSquare(23.95389662180223d);
    var4.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var25 = var4.nextPoisson((-3273.652368371841d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 166L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 20.594153217877338d);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeedSecure();
//     var2.reSeedSecure(10L);
//     long var12 = var2.nextSecureLong(0L, 18L);
//     var2.reSeedSecure(166L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    var1.setSeed(1L);
    var1.setSeed(1L);
    var1.setSeed(10L);
    var1.clear();
    var1.setSeed((-1634309337));

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(20.594153217877338d, 8.986565956563156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.9966135312502d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    var4.reSeedSecure(10L);
    double var16 = var4.nextUniform(11.13208948913201d, 2456.934613457899d, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var4.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1828.9544353782949d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    boolean var3 = var1.nextBoolean();
    int var4 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1873337969);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    float[] var2 = new float[] { 100.0f, 100.0f};
    float[] var4 = new float[] { 100.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, 100.0f};
    float[] var10 = new float[] { 100.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
    float[] var14 = new float[] { 0.0f};
    float[] var17 = new float[] { 100.0f, 100.0f};
    float[] var19 = new float[] { 100.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var19);
    float[] var24 = new float[] { 100.0f, 100.0f};
    float[] var26 = new float[] { 100.0f};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var24, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var14, var24);
    float[] var31 = new float[] { 100.0f, 100.0f};
    float[] var33 = new float[] { 100.0f};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var31, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var8, var31);
    float[] var38 = new float[] { 0.0f};
    float[] var41 = new float[] { 100.0f, 100.0f};
    float[] var43 = new float[] { 100.0f};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var41, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var43);
    float[] var48 = new float[] { 100.0f, 100.0f};
    float[] var50 = new float[] { 100.0f};
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var48, var50);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var38, var48);
    float[] var55 = new float[] { 100.0f, 100.0f};
    float[] var57 = new float[] { 100.0f};
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var55, var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var48, var55);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var31, var55);
    float[] var61 = null;
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var55, var61);
    float[] var64 = new float[] { 0.0f};
    float[] var67 = new float[] { 100.0f, 100.0f};
    float[] var69 = new float[] { 100.0f};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var67, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var69);
    float[] var74 = new float[] { 100.0f, 100.0f};
    float[] var76 = new float[] { 100.0f};
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var74, var76);
    boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var64, var74);
    float[] var81 = new float[] { 100.0f, 100.0f};
    float[] var83 = new float[] { 100.0f};
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var81, var83);
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var74, var81);
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var55, var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    var4.reSeedSecure(10L);
    double var16 = var4.nextUniform(11.13208948913201d, 2456.934613457899d, true);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var20 = var4.nextLong(2483254080546082816L, 579504999478877568L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1828.9544353782949d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    boolean var3 = var1.nextBoolean();
    long var4 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 8045925313331692144L);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextGaussian((-853.0935538935793d), 1.7965218799149243d);
//     double var9 = var2.nextWeibull(0.08928819504170851d, 7.251598159864589d);
//     double var11 = var2.nextChiSquare(0.30986974897550007d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-854.1973165815996d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.349742710098841d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.449872988733151E-5d);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var12 = var4.nextHexString((-1699419680));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var21 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = var21.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var22, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = var24.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var27 = org.apache.commons.math3.util.MathArrays.isMonotonic(var11, var25, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var10 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    var1.setSeed(var10);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(100L);
    int var17 = var15.nextInt(1);
    int[] var18 = new int[] { };
    var15.setSeed(var18);
    int[] var20 = null;
    int var21 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var20);
    byte[] var26 = new byte[] { (byte)0, (byte)10, (byte)(-1)};
    var22.nextBytes(var26);
    var1.nextBytes(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed((-1307283657));
    var1.clear();
    double var10 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSecureAlgorithm("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception", "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [0.19, 1] range");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.3890340168320314d);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
//     int var4 = var3.nextInt();
//     long[] var5 = null;
//     long[][] var6 = new long[][] { var5};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1), (java.lang.Object[])var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1916042885);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed(12L);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var4.nextSample(var9, (-380348068));
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    float[] var2 = new float[] { 100.0f, 100.0f};
    float[] var4 = new float[] { 100.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, 100.0f};
    float[] var10 = new float[] { 100.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
    float[] var14 = new float[] { 0.0f};
    float[] var17 = new float[] { 100.0f, 100.0f};
    float[] var19 = new float[] { 100.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var19);
    float[] var24 = new float[] { 100.0f, 100.0f};
    float[] var26 = new float[] { 100.0f};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var24, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var14, var24);
    float[] var31 = new float[] { 100.0f, 100.0f};
    float[] var33 = new float[] { 100.0f};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var31, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)0.9999999917315139d, var2);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.9999999917315139d+ "'", var4.equals(0.9999999917315139d));

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var4 = new double[] { };
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var4);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var4);
//     double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var13 = new double[] { };
//     boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var20 = new double[] { };
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
//     double[][] var22 = new double[][] { var19};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var15, var22);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
//     double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var24);
//     double[] var30 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var31 = new double[] { };
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var31);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
//     double[] var37 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var38 = new double[] { };
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var38);
//     double[][] var40 = new double[][] { var37};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var33, var40);
//     double[] var42 = null;
//     double[] var46 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var47 = new double[] { };
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var47);
//     boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var42, var46);
//     double[][] var50 = new double[][] { var46};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var50);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var50);
//     double[] var53 = null;
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var53);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     int var9 = var4.nextSecureInt((-1477247604), 749227529);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var4.nextCauchy(1.0385453521058168d, (-19.02928815170223d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-676080042));
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var14 = var0.nextUniform(11.656091933465596d, 102.09948570917526d, true);
//     var0.reSeed(13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.4906844717417544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-7.1339526419227175d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 100.80584684333247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.9981328885080152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 13.696648558418104d);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.8371016669875919d), (-179.4397511845404d), 1828.9544353782949d, 0.953266988202223d, 0.0d, 0.054028333260298586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1893.691201012582d);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var4);
//     double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 6.619854946565481d);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     int var9 = var4.nextSecureInt((-1477247604), 749227529);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var4.nextUniform(4.7352702461876515d, 0.7724109753531756d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 674621112);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)20L, (java.lang.Number)0.049864014567367256d, true);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-179.4397511845404d));

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var4, 3.866719511476555d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    java.lang.Number var4 = var3.getPrevious();
    boolean var5 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 862908985188605553L+ "'", var4.equals(862908985188605553L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    int[] var1 = new int[] { 0};
    int[] var5 = new int[] { 0, 100, 1};
    double var6 = org.apache.commons.math3.util.MathArrays.distance(var1, var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(100L);
    int var12 = var10.nextInt(1);
    int[] var13 = new int[] { };
    var10.setSeed(var13);
    int[] var17 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
    int var19 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(100L);
    int var23 = var21.nextInt(1);
    int[] var24 = new int[] { };
    var21.setSeed(var24);
    int[] var29 = new int[] { 0, 100, 1};
    int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var29);
    int var31 = org.apache.commons.math3.util.MathArrays.distance1(var17, var29);
    org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(100L);
    int var35 = var33.nextInt(1);
    int[] var36 = new int[] { };
    var33.setSeed(var36);
    int[] var41 = new int[] { 0, 100, 1};
    int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var36, var41);
    int var43 = org.apache.commons.math3.util.MathArrays.distance1(var29, var41);
    org.apache.commons.math3.random.Well19937c var45 = new org.apache.commons.math3.random.Well19937c(100L);
    int var47 = var45.nextInt(1);
    int[] var48 = new int[] { };
    var45.setSeed(var48);
    int[] var52 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var53 = new org.apache.commons.math3.random.Well19937c(var52);
    int var54 = org.apache.commons.math3.util.MathArrays.distance1(var48, var52);
    int[] var58 = new int[] { (-1), 100, 100};
    double var59 = org.apache.commons.math3.util.MathArrays.distance(var48, var58);
    int var60 = org.apache.commons.math3.util.MathArrays.distance1(var29, var58);
    var8.setSeed(var29);
    int var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var29);
    int[] var63 = new int[] { };
    org.apache.commons.math3.random.Well19937c var65 = new org.apache.commons.math3.random.Well19937c(100L);
    int var67 = var65.nextInt(1);
    int[] var68 = new int[] { };
    var65.setSeed(var68);
    int[] var73 = new int[] { 0, 100, 1};
    int var74 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var73);
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var63, var73);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var76 = org.apache.commons.math3.util.MathArrays.distance(var29, var63);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     var1.setSeed(1L);
//     var1.setSeed(1L);
//     var1.setSeed(10L);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var8);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var10, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var12.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1165421618, (java.lang.Number)65.09175302980526d, (-1072502360), var13, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var9, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     double var6 = var0.nextWeibull(0.6052934619394505d, 0.9861807351340854d);
//     double var9 = var0.nextWeibull(3.8642377162259853d, 0.9614486620846391d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9666929925700074d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.053025120244028924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.1203679680126208d);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     java.lang.Object var10 = var5.getValue();
//     boolean var12 = var5.equals((java.lang.Object)825523605);
//     double[] var16 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var17 = new double[] { };
//     boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var17);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
//     double[] var23 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var24 = new double[] { };
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var24);
//     double[][] var26 = new double[][] { var23};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var19, var26);
//     double[] var31 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var32 = new double[] { };
//     boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var32);
//     double var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var32);
//     double[] var38 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var39 = new double[] { };
//     boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var39);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
//     double[] var45 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var46 = new double[] { };
//     boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var45, var46);
//     double[][] var48 = new double[][] { var45};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var39, var41, var48);
//     double[] var50 = null;
//     double[] var54 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var55 = new double[] { };
//     boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var55);
//     boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var50, var54);
//     double[][] var58 = new double[][] { var54};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var39, var58);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var58);
//     boolean var61 = var5.equals((java.lang.Object)var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1305282296));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-1305282296)+ "'", var6.equals((-1305282296)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     var4.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var4.nextHypergeometric(63455071, (-1978339594), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.29117117961308575d);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(0L, 4418713979230659041L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 225,475,468 and 225,475,469 are not strictly increasing (0 >= 100)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1653842645889036800L);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var35);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var4, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var35, 6.03709264688173d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var35);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var46);
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var52);
    double var55 = org.apache.commons.math3.util.MathArrays.distance(var46, var54);
    double[] var59 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var60 = new double[] { };
    boolean var61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var59, var60);
    double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var60);
    double[] var66 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var67 = new double[] { };
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var67);
    double[] var69 = org.apache.commons.math3.util.MathArrays.copyOf(var67);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeAdd(var60, var67);
    double[] var74 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var75 = new double[] { };
    boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var74, var75);
    org.apache.commons.math3.util.MathArrays.OrderDirection var77 = null;
    double[] var81 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var82 = new double[] { };
    boolean var83 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var81, var82);
    double[][] var84 = new double[][] { var81};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var75, var77, var84);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var75);
    double var87 = org.apache.commons.math3.util.MathArrays.distance(var70, var75);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var88 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var46, var70);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var35);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var46);
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    org.apache.commons.math3.util.MathArrays.OrderDirection var54 = null;
    double[] var58 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var59 = new double[] { };
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var59);
    double[][] var61 = new double[][] { var58};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var52, var54, var61);
    double var63 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var14, var52);
    double[] var68 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var69 = new double[] { };
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    double[] var75 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var76 = new double[] { };
    boolean var77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var75, var76);
    double[][] var78 = new double[][] { var75};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var69, var71, var78);
    double var80 = org.apache.commons.math3.util.MathArrays.safeNorm(var69);
    double[] var84 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var85 = new double[] { };
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var84, var85);
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = null;
    double[] var91 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var92 = new double[] { };
    boolean var93 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var91, var92);
    double[][] var94 = new double[][] { var91};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var85, var87, var94);
    double[] var96 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var85);
    double[] var97 = org.apache.commons.math3.util.MathArrays.ebeAdd(var52, var69);
    double[] var98 = null;
    double var99 = org.apache.commons.math3.util.MathArrays.distance(var52, var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.0d);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     var0.setSeed(4418713979230659041L);
//     int var5 = var0.nextInt(16);
//     double var6 = var0.nextGaussian();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     var0.setSeed(1773701085);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-768316509));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.542290759080808d);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
    boolean var6 = var5.getBoundIsAllowed();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.12561605610783408d, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)24.34812647271368d, (java.lang.Number)1.6797400806850826d, (java.lang.Number)7.251598159864589d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.9967298592597413d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)83.49391301487294d);
    java.lang.Object var3 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)(-1219036332), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)5.346651980456539d, (java.lang.Number)(-4.435837838930404d), (java.lang.Number)0.07277703f);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var5 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var6 = new double[] { };
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var5);
//     double var9 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var1);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    long var5 = var2.nextLong();
    long var6 = var2.nextLong();
    double var7 = var2.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4418713979230659041L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 7258068567783673378L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.1505364353345049d);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     int var6 = var0.nextPascal(100, 0.0d);
//     var0.reSeedSecure(4812634305967451571L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(5.346651980456539d, 0.2550536339465285d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.927811391572309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.6973523005858913d, (java.lang.Number)(byte)1, false);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     var0.reSeedSecure();
//     double var14 = var0.nextUniform(6.850654457304433d, 100.80584684333247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7.344503370255124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 97.22699097325065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 96.73119664500416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.906421008931025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 30.043691138926352d);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     int var18 = var4.nextZipf(59, 0.05190356240941041d);
//     long var20 = var4.nextPoisson(141.746624376947d);
//     double var22 = var4.nextChiSquare(23.95389662180223d);
//     var4.reSeedSecure(100L);
//     java.util.Collection var25 = null;
//     java.lang.Object[] var27 = var4.nextSample(var25, 264518552);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(0.015854286399873473d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextHypergeometric((-1219036332), (-1307283657), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0310602425290512d);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)4.917623451873656d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     int var13 = var4.nextInt(100, 2146598351);
//     double var16 = var4.nextBeta(83.86480134623451d, 1.036975522396707d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9.624037350643665d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 228846559);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9875595607028754d);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)86L, 104097891);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    var1.setSeed(1L);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(100L);
    int var7 = var5.nextInt(1);
    int[] var8 = new int[] { };
    var5.setSeed(var8);
    int[] var12 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    int var14 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    var1.setSeed(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var15, var19);
    double[][] var23 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var23);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var29 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var30 = new double[] { };
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var30);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    double[][] var39 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var32, var39);
    double[] var44 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var45 = new double[] { };
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var45);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    double[][] var54 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var45, var47, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var45);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var45);
    double var58 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var10);
//     java.lang.Object var12 = var11.getSecond();
//     java.lang.Object var13 = var11.getFirst();
//     java.lang.Object var14 = var11.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-623744341));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-623744341)+ "'", var6.equals((-623744341)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + (-623744341)+ "'", var13.equals((-623744341)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    int var4 = var3.getIndex();
    int var5 = var3.getIndex();
    java.lang.Number var6 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1232268348);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1232268348);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0L+ "'", var6.equals(0L));

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)166L, (java.lang.Number)11.947415003583655d, true);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(byte)(-1));
    boolean var2 = var1.getBoundIsAllowed();
    boolean var3 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGamma(3.8744448346390348d, 10.0d);
//     double var5 = var0.nextExponential(141.746624376947d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)", "746dd4329f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 17.90753422508394d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 66.57367479150017d);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var5 = new double[] { };
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var12 = new double[] { };
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    double[][] var14 = new double[][] { var11};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var7, var14);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var35 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var36 = new double[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    double[] var42 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var43 = new double[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    double[][] var45 = new double[][] { var42};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var36, var38, var45);
    org.apache.commons.math3.util.MathArrays.checkPositive(var36);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var36);
    double[][] var49 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var49);
    org.apache.commons.math3.exception.MathIllegalStateException var51 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextBeta(7.33117135760314d, 0.3890340168320314d);
//     double var13 = var4.nextBeta(0.9191929024728597d, 3.9346068085718677d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var4.nextPascal(1815146088, 10.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9999953550028252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.18937297763155747d);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
    int var4 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 225475469);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    java.lang.Comparable[] var4 = new java.lang.Comparable[] { 11.656091933465596d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var8 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var8.getDirection();
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var9, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.15562109371395244d, (java.lang.Number)0.9967298592597413d, 1790344579, var9, true);
    int var14 = var13.getIndex();
    int var15 = var13.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1790344579);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1790344579);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    int[] var1 = new int[] { 0};
    int[] var5 = new int[] { 0, 100, 1};
    double var6 = org.apache.commons.math3.util.MathArrays.distance(var1, var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(100L);
    int var12 = var10.nextInt(1);
    int[] var13 = new int[] { };
    var10.setSeed(var13);
    int[] var17 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
    int var19 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(100L);
    int var23 = var21.nextInt(1);
    int[] var24 = new int[] { };
    var21.setSeed(var24);
    int[] var29 = new int[] { 0, 100, 1};
    int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var29);
    int var31 = org.apache.commons.math3.util.MathArrays.distance1(var17, var29);
    org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(100L);
    int var35 = var33.nextInt(1);
    int[] var36 = new int[] { };
    var33.setSeed(var36);
    int[] var41 = new int[] { 0, 100, 1};
    int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var36, var41);
    int var43 = org.apache.commons.math3.util.MathArrays.distance1(var29, var41);
    org.apache.commons.math3.random.Well19937c var45 = new org.apache.commons.math3.random.Well19937c(100L);
    int var47 = var45.nextInt(1);
    int[] var48 = new int[] { };
    var45.setSeed(var48);
    int[] var52 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var53 = new org.apache.commons.math3.random.Well19937c(var52);
    int var54 = org.apache.commons.math3.util.MathArrays.distance1(var48, var52);
    int[] var58 = new int[] { (-1), 100, 100};
    double var59 = org.apache.commons.math3.util.MathArrays.distance(var48, var58);
    int var60 = org.apache.commons.math3.util.MathArrays.distance1(var29, var58);
    var8.setSeed(var29);
    int var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var5, (-401038879));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(0L, 4418713979230659041L);
//     int var6 = var0.nextSecureInt(941025974, 2146598351);
//     int var9 = var0.nextSecureInt((-1775042804), (-825071061));
//     int var12 = var0.nextInt((-1141446620), 368375954);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextHypergeometric((-955573574), 111145379, (-1521029328));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3271994418247361024L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1147279756);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1567123835));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1113604582));
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    var1.setSeed(1L);
    var1.setSeed(1L);
    double var6 = var1.nextDouble();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.07277703352123166d);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(0L, 4418713979230659041L);
//     int var6 = var0.nextSecureInt(941025974, 2146598351);
//     int var9 = var0.nextSecureInt((-1775042804), (-825071061));
//     int var12 = var0.nextInt((-1141446620), 368375954);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextPascal(1045626652, 31.067130348919022d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3675491379019718144L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1656089993);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1184595970));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-12935068));
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2146598351, (java.lang.Number)96.73119664500416d, true);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    int var18 = var4.nextZipf(59, 0.05190356240941041d);
    long var20 = var4.nextPoisson(141.746624376947d);
    double var22 = var4.nextChiSquare(1.6797400806850826d);
    double var24 = var4.nextT(1.036975522396707d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var27 = var4.nextPascal(264518552, (-55651.14224347731d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 166L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.6052934619394505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-10.5184672894674d));

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    double var4 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.04677838737026563d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    boolean var4 = var3.getStrict();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-430674889)+ "'", var5.equals((-430674889)));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(100L);
    int var9 = var7.nextInt(1);
    int[] var10 = new int[] { };
    var7.setSeed(var10);
    int[] var12 = null;
    int var13 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
    var1.setSeed(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextPascal(2074555787, 100.96201588326613d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGamma(3.8744448346390348d, 10.0d);
//     double var5 = var0.nextExponential(141.746624376947d);
//     long var8 = var0.nextSecureLong(3L, 872029271940837376L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation((-1854505007), 312574995);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 73.13276664716815d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.92295231374713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 146876292405111936L);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var5);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)90.43193939599433d, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
//     double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var12 = new double[] { };
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.ebeAdd(var5, var12);
//     double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var20 = new double[] { };
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
//     double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var27 = new double[] { };
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
//     double[][] var29 = new double[][] { var26};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
//     double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
//     double var32 = org.apache.commons.math3.util.MathArrays.distance(var15, var20);
//     double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var37 = new double[] { };
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
//     double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var37);
//     double[] var43 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var44 = new double[] { };
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var44);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var44);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var37, var44);
//     double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var52 = new double[] { };
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var54 = null;
//     double[] var58 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var59 = new double[] { };
//     boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var59);
//     double[][] var61 = new double[][] { var58};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var52, var54, var61);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var52);
//     double[] var67 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var68 = new double[] { };
//     boolean var69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var67, var68);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var70 = null;
//     double[] var74 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var75 = new double[] { };
//     boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var74, var75);
//     double[][] var77 = new double[][] { var74};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var68, var70, var77);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var68);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var52, var68);
//     double var81 = org.apache.commons.math3.util.MathArrays.distance(var37, var68);
//     boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var15, var37);
//     double var83 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var37);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var4 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     int var18 = var4.nextZipf(59, 0.05190356240941041d);
//     long var20 = var4.nextPoisson(141.746624376947d);
//     double var22 = var4.nextChiSquare(1.6797400806850826d);
//     double var24 = var4.nextT(1.036975522396707d);
//     int var27 = var4.nextSecureInt(5, 1180133107);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3098593374527597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.08244612118583806d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 166L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.6052934619394505d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-10.5184672894674d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 867547393);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)476057892828369472L, (java.lang.Number)0.5147835921413739d, (java.lang.Number)(-3273.652368371841d));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var35);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var4, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var50 = org.apache.commons.math3.util.MathArrays.normalizeArray(var35, (-1.9841284616200225d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     long var9 = var4.nextLong(1L, 70L);
//     int var12 = var4.nextZipf(59, 4.269328604906451d);
//     org.apache.commons.math3.distribution.RealDistribution var13 = null;
//     double var14 = var4.nextInversionDeviate(var13);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     double[] var0 = null;
//     java.lang.Comparable[] var5 = new java.lang.Comparable[] { 11.656091933465596d};
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
//     boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var10, true);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)872029271940837376L, (java.lang.Number)(-1307283657), (-955090935), var10, false);
//     boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var10, false);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 862908985188605553L);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     var0.reSeed(0L);
//     java.lang.String var11 = var0.nextSecureHexString(1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "4bfdf0b893"+ "'", var3.equals("4bfdf0b893"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "6"+ "'", var11.equals("6"));
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var11 = new int[] { 0, 100, 1};
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var11);
    var1.setSeed(var6);
    double var14 = var1.nextGaussian();
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(100L);
    int var18 = var16.nextInt(1);
    int[] var19 = new int[] { };
    var16.setSeed(var19);
    int[] var23 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
    int var25 = org.apache.commons.math3.util.MathArrays.distance1(var19, var23);
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(100L);
    int var29 = var27.nextInt(1);
    int[] var30 = new int[] { };
    var27.setSeed(var30);
    int[] var35 = new int[] { 0, 100, 1};
    int var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var35);
    int var37 = org.apache.commons.math3.util.MathArrays.distance1(var23, var35);
    org.apache.commons.math3.random.Well19937c var39 = new org.apache.commons.math3.random.Well19937c(100L);
    int var41 = var39.nextInt(1);
    int[] var42 = new int[] { };
    var39.setSeed(var42);
    int[] var47 = new int[] { 0, 100, 1};
    int var48 = org.apache.commons.math3.util.MathArrays.distanceInf(var42, var47);
    int var49 = org.apache.commons.math3.util.MathArrays.distance1(var35, var47);
    var1.setSeed(var35);
    int[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    org.apache.commons.math3.random.Well19937c var53 = new org.apache.commons.math3.random.Well19937c(100L);
    float var54 = var53.nextFloat();
    boolean var55 = var53.nextBoolean();
    org.apache.commons.math3.random.Well19937c var57 = new org.apache.commons.math3.random.Well19937c(100L);
    int var59 = var57.nextInt(1);
    int[] var60 = new int[] { };
    var57.setSeed(var60);
    int[] var64 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var65 = new org.apache.commons.math3.random.Well19937c(var64);
    int var66 = org.apache.commons.math3.util.MathArrays.distance1(var60, var64);
    org.apache.commons.math3.random.Well19937c var68 = new org.apache.commons.math3.random.Well19937c(100L);
    int var70 = var68.nextInt(1);
    int[] var71 = new int[] { };
    var68.setSeed(var71);
    int[] var76 = new int[] { 0, 100, 1};
    int var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var71, var76);
    int var78 = org.apache.commons.math3.util.MathArrays.distance1(var64, var76);
    var53.setSeed(var76);
    org.apache.commons.math3.random.Well19937c var80 = new org.apache.commons.math3.random.Well19937c(var76);
    int var81 = org.apache.commons.math3.util.MathArrays.distance1(var35, var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.8371016669875919d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }
// 
// 
//     float[] var2 = new float[] { 100.0f, 100.0f};
//     float[] var4 = new float[] { 100.0f};
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
//     float[] var8 = new float[] { 100.0f, 100.0f};
//     float[] var10 = new float[] { 100.0f};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
//     float[] var14 = new float[] { 0.0f};
//     float[] var17 = new float[] { 100.0f, 100.0f};
//     float[] var19 = new float[] { 100.0f};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var19);
//     float[] var24 = new float[] { 100.0f, 100.0f};
//     float[] var26 = new float[] { 100.0f};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var24, var26);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var14, var24);
//     float[] var31 = new float[] { 100.0f, 100.0f};
//     float[] var33 = new float[] { 100.0f};
//     boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var31, var33);
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var8, var31);
//     org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c();
//     int var38 = var37.nextInt();
//     long[] var39 = null;
//     long[][] var40 = new long[][] { var39};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var40);
//     org.apache.commons.math3.util.Pair var42 = new org.apache.commons.math3.util.Pair((java.lang.Object)var38, (java.lang.Object)var40);
//     java.lang.Object var43 = var42.getKey();
//     org.apache.commons.math3.random.Well19937c var45 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var46 = var42.equals((java.lang.Object)var45);
//     org.apache.commons.math3.util.Pair var47 = new org.apache.commons.math3.util.Pair(var42);
//     org.apache.commons.math3.util.Pair var48 = new org.apache.commons.math3.util.Pair(var47);
//     java.lang.Object var49 = var48.getSecond();
//     float[] var53 = new float[] { 10.0f, 0.0f, 100.0f};
//     float[] var57 = new float[] { 1.0f, 100.0f, 100.0f};
//     boolean var58 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var57);
//     boolean var59 = var48.equals((java.lang.Object)var57);
//     boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var8, var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == (-1395623025));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + (-1395623025)+ "'", var43.equals((-1395623025)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var4 = var0.nextF(1.7965218799149243d, 5.271764897745934d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.15853214439116886d);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var6.nextPascal(0, 0.7724109753531756d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }
// 
// 
//     float[] var2 = new float[] { 100.0f, 100.0f};
//     float[] var4 = new float[] { 100.0f};
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
//     float[] var8 = new float[] { 100.0f, 100.0f};
//     float[] var10 = new float[] { 100.0f};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
//     float[] var14 = new float[] { 0.0f};
//     float[] var17 = new float[] { 100.0f, 100.0f};
//     float[] var19 = new float[] { 100.0f};
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var19);
//     float[] var24 = new float[] { 100.0f, 100.0f};
//     float[] var26 = new float[] { 100.0f};
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var24, var26);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var14, var24);
//     float[] var31 = new float[] { 100.0f, 100.0f};
//     float[] var33 = new float[] { 100.0f};
//     boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var31, var33);
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var8, var31);
//     float[] var38 = new float[] { 0.0f};
//     float[] var41 = new float[] { 100.0f, 100.0f};
//     float[] var43 = new float[] { 100.0f};
//     boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var41, var43);
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var43);
//     float[] var48 = new float[] { 100.0f, 100.0f};
//     float[] var50 = new float[] { 100.0f};
//     boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var48, var50);
//     boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var38, var48);
//     float[] var55 = new float[] { 100.0f, 100.0f};
//     float[] var57 = new float[] { 100.0f};
//     boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var55, var57);
//     boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var48, var55);
//     boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var31, var55);
//     org.apache.commons.math3.random.Well19937c var61 = new org.apache.commons.math3.random.Well19937c();
//     int var62 = var61.nextInt();
//     long[] var63 = null;
//     long[][] var64 = new long[][] { var63};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var64);
//     org.apache.commons.math3.util.Pair var66 = new org.apache.commons.math3.util.Pair((java.lang.Object)var62, (java.lang.Object)var64);
//     java.lang.Object var67 = var66.getKey();
//     org.apache.commons.math3.random.Well19937c var69 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var70 = var66.equals((java.lang.Object)var69);
//     org.apache.commons.math3.util.Pair var71 = new org.apache.commons.math3.util.Pair(var66);
//     org.apache.commons.math3.util.Pair var72 = new org.apache.commons.math3.util.Pair(var71);
//     java.lang.Object var73 = var72.getSecond();
//     float[] var77 = new float[] { 10.0f, 0.0f, 100.0f};
//     float[] var81 = new float[] { 1.0f, 100.0f, 100.0f};
//     boolean var82 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var77, var81);
//     boolean var83 = var72.equals((java.lang.Object)var81);
//     float[] var84 = null;
//     boolean var85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var81, var84);
//     boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var55, var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == (-457904412));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var67 + "' != '" + (-457904412)+ "'", var67.equals((-457904412)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == false);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1854640921));
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(11.13208948913201d, 0.0d, 0.15853214439116886d, (-7.1339526419227175d), 151.8831637432365d, 0.0d, 4.917623451873656d, 0.016151381368146953d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0515343985128982d));

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception", "5e7cb2ff82");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "47fbd607fd"+ "'", var3.equals("47fbd607fd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     java.lang.Object var10 = var5.getFirst();
//     java.lang.Object var11 = var5.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 2003889464);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 2003889464+ "'", var6.equals(2003889464));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + 2003889464+ "'", var10.equals(2003889464));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + 2003889464+ "'", var11.equals(2003889464));
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)63455071);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    long var4 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.08971084836383868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2776907188931195853L);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(1L);
    var3.clear();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(100L);
    int var8 = var6.nextInt(1);
    int[] var9 = new int[] { };
    var6.setSeed(var9);
    int[] var11 = null;
    int var12 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var11);
    byte[] var17 = new byte[] { (byte)0, (byte)10, (byte)(-1)};
    var13.nextBytes(var17);
    var3.nextBytes(var17);
    var1.nextBytes(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-852432388));

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     java.lang.Object var11 = var10.getFirst();
//     java.lang.Object var12 = var10.getValue();
//     org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 466644217);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 466644217+ "'", var6.equals(466644217));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + 466644217+ "'", var11.equals(466644217));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextInt(5, (-457904412));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9831053539772528d);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.distribution.IntegerDistribution var6 = null;
//     int var7 = var5.nextInversionDeviate(var6);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (-3273.652368371841d), 141.746624376947d, 1.3161168395169025d, 0.0d, 1.327000036267693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 186.55511928717704d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    double var9 = var4.nextF(3.8744448346390348d, 6.03709264688173d);
    var4.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.1504224218416993d);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(3.8744448346390348d, 11.656091933465596d);
//     var2.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextHypergeometric(1755678109, (-260641056), 19);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 11.282131447667517d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    var4.reSeedSecure(10L);
    var4.reSeedSecure(88L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var4.nextUniform(0.054028333260298586d, 11.38364603395183d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5840095788202652d);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c();
//     int var11 = var10.nextInt();
//     long[] var12 = null;
//     long[][] var13 = new long[][] { var12};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
//     org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair((java.lang.Object)var11, (java.lang.Object)var13);
//     java.lang.Object var16 = var15.getKey();
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var19 = var15.equals((java.lang.Object)var18);
//     org.apache.commons.math3.util.Pair var20 = new org.apache.commons.math3.util.Pair(var15);
//     org.apache.commons.math3.util.Pair var21 = new org.apache.commons.math3.util.Pair(var20);
//     java.lang.Object var22 = var20.getSecond();
//     boolean var23 = var5.equals(var22);
//     java.lang.Object var24 = var5.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1588168313));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-1588168313)+ "'", var6.equals((-1588168313)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 186022101);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + 186022101+ "'", var16.equals(186022101));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.9507047658344296d, 32.766919113449504d, 3.742940940679912d, 1.542290759080808d, (-1.1012004570294223d), (-853.0935538935793d), 0.30986974897550007d, 90.33170045287306d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1004.3424421677889d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)11.292796076075014d, 104097891);
    boolean var4 = var3.getStrict();
    boolean var5 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.8444156216806316d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var21 = new double[] { };
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var28 = new double[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    double[][] var30 = new double[][] { var27};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var23, var30);
    double[] var32 = null;
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var32, var36);
    double[][] var40 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var40);
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var46 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var47 = new double[] { };
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var47);
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
    double[] var53 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var54 = new double[] { };
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var54);
    double[][] var56 = new double[][] { var53};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var47, var49, var56);
    double[] var61 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var62 = new double[] { };
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var62);
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = null;
    double[] var68 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var69 = new double[] { };
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var69);
    double[][] var71 = new double[][] { var68};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var62, var64, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeDivide(var47, var62);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeAdd(var21, var62);
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var6, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var14 = var0.nextUniform(11.656091933465596d, 102.09948570917526d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextZipf(186022101, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.691034825142872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9728217616947197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 102.45328978634285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.0575295307170793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 74.48911767534219d);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeedSecure(100L);
//     var4.reSeed(0L);
//     int var13 = var4.nextInt((-260641056), 445938823);
//     long var16 = var4.nextSecureLong(26L, 7258068567783673378L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var4.nextZipf(1741975207, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 264518552);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2915000747433413120L);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     var0.setSeed(4418713979230659041L);
//     int var5 = var0.nextInt(16);
//     var0.setSeed(100);
//     boolean var8 = var0.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 114749410);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1815146088);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1219036332));
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed((-1307283657));
    var1.clear();
    double var10 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var14 = var11.nextF(0.1504224218416993d, 100.7941743858271d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var17 = var11.nextPermutation(200911654, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.3890340168320314d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.3156585688760107d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(3.5865133480106643d, 0.8444156216806316d, 10.9966135312502d, 0.0d, 1.7965218799149243d, 94.001960871218d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 171.90508735847604d);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     int var9 = var4.nextSecureInt((-1477247604), 749227529);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var4.nextHypergeometric(0, 1423375680, (-1775042804));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1041558398));
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var10 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(100L);
    int var16 = var14.nextInt(1);
    int[] var17 = new int[] { };
    var14.setSeed(var17);
    int[] var22 = new int[] { 0, 100, 1};
    int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distance1(var10, var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(100L);
    int var28 = var26.nextInt(1);
    int[] var29 = new int[] { };
    var26.setSeed(var29);
    int[] var34 = new int[] { 0, 100, 1};
    int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var34);
    int var36 = org.apache.commons.math3.util.MathArrays.distance1(var22, var34);
    org.apache.commons.math3.random.Well19937c var38 = new org.apache.commons.math3.random.Well19937c(100L);
    int var40 = var38.nextInt(1);
    int[] var41 = new int[] { };
    var38.setSeed(var41);
    int[] var45 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var46 = new org.apache.commons.math3.random.Well19937c(var45);
    int var47 = org.apache.commons.math3.util.MathArrays.distance1(var41, var45);
    int[] var51 = new int[] { (-1), 100, 100};
    double var52 = org.apache.commons.math3.util.MathArrays.distance(var41, var51);
    int var53 = org.apache.commons.math3.util.MathArrays.distance1(var22, var51);
    var1.setSeed(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 100);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)3L, (java.lang.Number)2.913539924093275d, true);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)1.7965218799149243d, (java.lang.Object)(short)0);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1.7965218799149243d+ "'", var3.equals(1.7965218799149243d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.7965218799149243d+ "'", var4.equals(1.7965218799149243d));

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(445938823, 1741975207);
//     long var5 = var0.nextPoisson(1.4808388048950236d);
//     double var8 = var0.nextF(0.953266988202223d, 19.07978762652375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 937419978);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.919301834718983d);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeed();
    var2.reSeedSecure(7258068567783673378L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }
// 
// 
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)11.38364603395183d, (java.lang.Number)1741975207, 1741975207);
//     var3.addSuppressed((java.lang.Throwable)var7);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c();
//     int var13 = var12.nextInt();
//     long[] var14 = null;
//     long[][] var15 = new long[][] { var14};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var15);
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var15);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var9, (java.lang.Object[])var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1991088005));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(byte)(-1));
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)32.36871072544811d, (java.lang.Number)1697424459525688832L, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)11);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     var0.reSeedSecure(872029271940837376L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.776824947060764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-371.89595262305977d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 105.28176645801895d);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-63.070338506413165d), (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    long var9 = var2.nextPoisson(11.292796076075014d);
    long var11 = var2.nextPoisson(83.86480134623451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 65L);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextGaussian((-853.0935538935793d), 1.7965218799149243d);
//     double var9 = var2.nextWeibull(0.08928819504170851d, 7.251598159864589d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var2.nextPermutation(749227529, 1068662605);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-854.3899290060092d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.5095864645430213E-6d);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1004.3424421677889d, (java.lang.Number)11.292796076075014d, false);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var4.nextSample(var5, (-852432388));
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c();
//     int var3 = var2.nextInt();
//     long[] var4 = null;
//     long[][] var5 = new long[][] { var4};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1688967133));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var5);
//     java.lang.Object var7 = var5.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1744202849);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var5 = new double[] { };
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var12 = new double[] { };
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    double[][] var14 = new double[][] { var11};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var7, var14);
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var21 = new double[] { };
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var28 = new double[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    double[][] var30 = new double[][] { var27};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var23, var30);
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var5, var21);
    java.lang.Comparable[] var38 = new java.lang.Comparable[] { 11.656091933465596d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = var42.getDirection();
    boolean var45 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var38, var43, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.15562109371395244d, (java.lang.Number)0.9967298592597413d, 1790344579, var43, true);
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    org.apache.commons.math3.util.MathArrays.OrderDirection var54 = null;
    double[] var58 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var59 = new double[] { };
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var59);
    double[][] var61 = new double[][] { var58};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var52, var54, var61);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var43, var61);
    org.apache.commons.math3.exception.MathArithmeticException var64 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var7 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c();
//     int var12 = var11.nextInt();
//     long[] var13 = null;
//     long[][] var14 = new long[][] { var13};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
//     org.apache.commons.math3.util.Pair var16 = new org.apache.commons.math3.util.Pair((java.lang.Object)var12, (java.lang.Object)var14);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
//     org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var10, (java.lang.Object[])var14);
//     java.lang.Throwable[] var19 = var18.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-537630031));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var12.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var13, false);
    boolean var17 = org.apache.commons.math3.util.MathArrays.isMonotonic(var3, var13, false);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10.099504938362077d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var4);
    boolean var12 = var11.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)1, (java.lang.Number)716369212, false);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 716369212+ "'", var4.equals(716369212));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 716369212+ "'", var6.equals(716369212));

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     long var18 = var4.nextSecureLong((-4523942956662907304L), 696171521889898368L);
//     double var21 = var4.nextCauchy(1.1250108292257317d, 8.773005865746882d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var24 = var4.nextLong(696171521889898368L, 12L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3098593374527597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.08244612118583806d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-3052532970072876032L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-12.142480884604916d));
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var14, var19);
    double[] var35 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var36 = new double[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var36);
    double[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    double[] var42 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var43 = new double[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var43);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeAdd(var36, var43);
    double[] var50 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var51 = new double[] { };
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var51);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    double[] var57 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var58 = new double[] { };
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var57, var58);
    double[][] var60 = new double[][] { var57};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var51, var53, var60);
    org.apache.commons.math3.util.MathArrays.checkPositive(var51);
    double[] var66 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var67 = new double[] { };
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var67);
    org.apache.commons.math3.util.MathArrays.OrderDirection var69 = null;
    double[] var73 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var74 = new double[] { };
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var73, var74);
    double[][] var76 = new double[][] { var73};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var67, var69, var76);
    org.apache.commons.math3.util.MathArrays.checkPositive(var67);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var67);
    double var80 = org.apache.commons.math3.util.MathArrays.distance(var36, var67);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var14, var36);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var85 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    java.lang.String var86 = var85.toString();
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = var85.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var88 = var85.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var91 = org.apache.commons.math3.util.MathArrays.checkOrder(var14, var88, true, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var86 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)"+ "'", var86.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
//     org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
//     int var6 = var2.nextInt(225475469);
//     var2.setSeed(1165421618);
//     long var9 = var2.nextLong();
//     java.util.List var10 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var11 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var10);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, (-1816989844));
    java.lang.String var3 = var2.toString();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 1 != -1,816,989,844"+ "'", var3.equals("org.apache.commons.math3.exception.DimensionMismatchException: 1 != -1,816,989,844"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1072502360), 1773701085);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var9 = var6.nextBeta(4.917623451873656d, 100.49939010820418d);
    var6.reSeedSecure(4812634305967451571L);
    var6.reSeed(404374688027301760L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05190356240941041d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)5.816193535071593d);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var10);
//     java.lang.Object var12 = var11.getValue();
//     java.lang.Object var13 = var11.getKey();
//     java.lang.Object var14 = var11.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1913623175));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-1913623175)+ "'", var6.equals((-1913623175)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + (-1913623175)+ "'", var13.equals((-1913623175)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    var4.reSeed(166L);
    var4.reSeed(14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    long var13 = var4.nextLong(166L, 2110551683838641920L);
    double var16 = var4.nextWeibull(12.950477475625878d, 10.0d);
    double var18 = var4.nextChiSquare(5.271764897745934d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1568649952495051008L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 9.915595306501313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.6139475188008925d);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     int var10 = var4.nextInt((-1223526183), 941025974);
//     double var13 = var4.nextGamma(12.950477475625878d, 0.5127948165466234d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var4.nextBinomial((-1854505007), (-2495.812825115084d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 129861255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7.633617799272932d);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.685214883999529d, (java.lang.Number)100.14688685347892d, false);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    java.lang.Object var5 = var4.getKey();
    java.lang.Object var6 = var4.getSecond();
    java.lang.Object var7 = var4.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 'a'+ "'", var5.equals('a'));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    double[] var1 = new double[] { 10.0d};
    double[] var5 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var6 = new double[] { };
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    double[][] var15 = new double[][] { var12};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var8, var15);
    double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var21 = new double[] { };
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var21);
    double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var28 = new double[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    double[][] var37 = new double[][] { var34};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var28, var30, var37);
    double[] var42 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var43 = new double[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = null;
    double[] var49 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var50 = new double[] { };
    boolean var51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var50);
    double[][] var52 = new double[][] { var49};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var45, var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var28, var43);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var54);
    double[] var59 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var60 = new double[] { };
    boolean var61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var59, var60);
    org.apache.commons.math3.util.MathArrays.OrderDirection var62 = null;
    double[] var66 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var67 = new double[] { };
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var67);
    double[][] var69 = new double[][] { var66};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var60, var62, var69);
    org.apache.commons.math3.util.MathArrays.checkPositive(var60);
    double[] var75 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var76 = new double[] { };
    boolean var77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var75, var76);
    org.apache.commons.math3.util.MathArrays.OrderDirection var78 = null;
    double[] var82 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var83 = new double[] { };
    boolean var84 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var83);
    double[][] var85 = new double[][] { var82};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var76, var78, var85);
    org.apache.commons.math3.util.MathArrays.checkPositive(var76);
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeDivide(var60, var76);
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var6, var60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var90 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var1, var6);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(19.42595685892877d, 0.9875595607028754d, 100.76486974265387d, (-11.001814281555863d), 11.292796076075014d, 100.20256715030962d, 273.2471843471883d, 83.49391301487294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 22856.631704978743d);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(3.8744448346390348d, 11.656091933465596d);
//     long var12 = var2.nextPoisson(0.1504224218416993d);
//     double var15 = var2.nextF(0.05190356240941041d, 105.28176645801895d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 14.08436327714356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16.90438850801693d);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(0L, 4418713979230659041L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextUniform(11.292796076075014d, 3.8439213970347454d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3565690805785299456L);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
    java.lang.Number var4 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var19);
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    double[] var32 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var33 = new double[] { };
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var33);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var28, var35);
    double[] var40 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var41 = new double[] { };
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var41);
    double[] var47 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var48 = new double[] { };
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var48);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    double[] var54 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var55 = new double[] { };
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var55);
    double[][] var57 = new double[][] { var54};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var48, var50, var57);
    double[] var62 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var63 = new double[] { };
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var63);
    org.apache.commons.math3.util.MathArrays.OrderDirection var65 = null;
    double[] var69 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var70 = new double[] { };
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var69, var70);
    double[][] var72 = new double[][] { var69};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var63, var65, var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var63);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var26, var74);
    double var76 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var26);
    double[] var80 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var81 = new double[] { };
    boolean var82 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var80, var81);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var81);
    double[] var87 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var88 = new double[] { };
    boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var87, var88);
    double[] var90 = org.apache.commons.math3.util.MathArrays.copyOf(var88);
    double[] var91 = org.apache.commons.math3.util.MathArrays.ebeAdd(var81, var88);
    double var92 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 403.86667959045457d, 886.7023399316736d, 186.55511928717704d, 10.774705318241162d, 0.016151381368146953d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 165419.0348245471d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var20);
    java.lang.Comparable[] var33 = new java.lang.Comparable[] { 11.656091933465596d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = var37.getDirection();
    boolean var40 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var33, var38, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var44 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = var44.getDirection();
    boolean var47 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var33, var45, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var4, var45, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
    java.lang.String var2 = var1.toString();
    java.lang.Number var3 = var1.getMin();
    boolean var4 = var1.getBoundIsAllowed();
    java.lang.Number var5 = var1.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1978339594)+ "'", var5.equals((-1978339594)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var32 = new int[] { 0, 100, 1};
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
    int[] var38 = new int[] { 10, 100, 10};
    int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var38);
    int[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    org.apache.commons.math3.random.Well19937c var41 = new org.apache.commons.math3.random.Well19937c(var32);
    double var42 = var41.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.4698048838655384d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    long var9 = var4.nextLong(1L, 70L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var4.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35L);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     long var10 = var2.nextLong(0L, 3081282935693573632L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1734114146526189568L);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextBeta(3.9346068085718677d, 23.95389662180223d);
    long var9 = var4.nextPoisson(6.03709264688173d);
    double var11 = var4.nextExponential(0.10511601352671937d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.049864014567367256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.12790376618944505d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    double var14 = var2.nextCauchy(1.3995975989718865d, 2456.934613457899d);
    double var17 = var2.nextF(0.9861807351340854d, 1.3161168395169025d);
    var2.reSeed(70L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-853.0935538935793d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.050339377390359874d);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
//     int var4 = var3.nextInt();
//     long[] var5 = null;
//     long[][] var6 = new long[][] { var5};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1873337969, (java.lang.Object[])var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-848135671));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    int var13 = var4.nextInt((-260641056), 445938823);
    var4.reSeedSecure();
    var4.reSeedSecure(872029271940837376L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 264518552);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var14 = var0.nextUniform(11.656091933465596d, 102.09948570917526d, true);
//     double var16 = var0.nextT(99.97081874303055d);
//     int var19 = var0.nextBinomial(0, 0.08971084836383868d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.213558304720719d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-39.0427551601906d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 99.08335651542299d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.7757308952758872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 93.80443882825725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1.2096963608191038d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     double var12 = var4.nextCauchy(10.327401159520946d, 0.953266988202223d);
//     double var15 = var4.nextGaussian(100.20256715030962d, 4.917623451873656d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var4.nextSecureLong(82L, 18L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4.12114886610423d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 104.69072203383386d);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var11 = new int[] { 0, 100, 1};
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var11);
    var1.setSeed(var6);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(100L);
    int var17 = var15.nextInt(1);
    int[] var18 = new int[] { };
    var15.setSeed(var18);
    int[] var22 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(100L);
    int var28 = var26.nextInt(1);
    int[] var29 = new int[] { };
    var26.setSeed(var29);
    int[] var34 = new int[] { 0, 100, 1};
    int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var34);
    int var36 = org.apache.commons.math3.util.MathArrays.distance1(var22, var34);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var6, var34);
    org.apache.commons.math3.random.Well19937c var40 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(100L);
    int var44 = var42.nextInt(1);
    int[] var45 = new int[] { };
    var42.setSeed(var45);
    int[] var50 = new int[] { 0, 100, 1};
    int var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var50);
    var40.setSeed(var45);
    org.apache.commons.math3.random.Well19937c var54 = new org.apache.commons.math3.random.Well19937c(100L);
    int var56 = var54.nextInt(1);
    int[] var57 = new int[] { };
    var54.setSeed(var57);
    int[] var61 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var62 = new org.apache.commons.math3.random.Well19937c(var61);
    int var63 = org.apache.commons.math3.util.MathArrays.distance1(var57, var61);
    org.apache.commons.math3.random.Well19937c var65 = new org.apache.commons.math3.random.Well19937c(100L);
    int var67 = var65.nextInt(1);
    int[] var68 = new int[] { };
    var65.setSeed(var68);
    int[] var73 = new int[] { 0, 100, 1};
    int var74 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var73);
    int var75 = org.apache.commons.math3.util.MathArrays.distance1(var61, var73);
    org.apache.commons.math3.random.Well19937c var77 = new org.apache.commons.math3.random.Well19937c(100L);
    int var79 = var77.nextInt(1);
    int[] var80 = new int[] { };
    var77.setSeed(var80);
    int[] var85 = new int[] { 0, 100, 1};
    int var86 = org.apache.commons.math3.util.MathArrays.distanceInf(var80, var85);
    int var87 = org.apache.commons.math3.util.MathArrays.distance1(var73, var85);
    double var88 = org.apache.commons.math3.util.MathArrays.distance(var45, var73);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var89 = org.apache.commons.math3.util.MathArrays.distance1(var34, var45);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextF(0.0d, 1.6973523005858913d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "626d56dd3c"+ "'", var3.equals("626d56dd3c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    java.lang.String var5 = var4.toString();
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var4.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var4.getDirection();
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure(20L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 225,475,468 and 225,475,469 are not strictly increasing (0 >= 100)", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 225,475,468 and 225,475,469 are not strictly increasing (0 >= 100)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)11.656091933465596d, (java.lang.Number)(-0.08244612118583806d), false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(63455071, (-1978339594));
    int var3 = var2.getDimension();
    int var4 = var2.getDimension();
    java.lang.Throwable[] var5 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1978339594));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1978339594));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    var1.setSeed(1232268348);
    float var8 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.12277675f);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var3 = null;
    long[][] var4 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-1.1012004570294223d), (java.lang.Object[])var4);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     double var12 = var0.nextExponential(14229.64140379441d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextSecureInt(1773701085, (-1298863262));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7.502622879255236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.967113351731211d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 101.70435857189631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21211.24799995728d);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextGamma(10.24834333371038d, 4.7352702461876515d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 32.40741877671882d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var11 = new int[] { 0, 100, 1};
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var11);
    var1.setSeed(var6);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(100L);
    int var17 = var15.nextInt(1);
    int[] var18 = new int[] { };
    var15.setSeed(var18);
    int[] var22 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(100L);
    int var28 = var26.nextInt(1);
    int[] var29 = new int[] { };
    var26.setSeed(var29);
    int[] var34 = new int[] { 0, 100, 1};
    int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var34);
    int var36 = org.apache.commons.math3.util.MathArrays.distance1(var22, var34);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var6, var34);
    org.apache.commons.math3.random.Well19937c var39 = new org.apache.commons.math3.random.Well19937c(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     int[] var4 = new int[] { };
//     var1.setSeed(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.setSeed((-1307283657));
//     var1.clear();
//     double var10 = var1.nextDouble();
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var14 = var11.nextSecureLong(72L, 88L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3890340168320314d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 88L);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    int[] var1 = new int[] { 0};
    int[] var5 = new int[] { 0, 100, 1};
    double var6 = org.apache.commons.math3.util.MathArrays.distance(var1, var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
    int var10 = var8.nextInt(1);
    int[] var11 = new int[] { };
    var8.setSeed(var11);
    int[] var15 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
    int var17 = org.apache.commons.math3.util.MathArrays.distance1(var11, var15);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(100L);
    int var21 = var19.nextInt(1);
    int[] var22 = new int[] { };
    var19.setSeed(var22);
    int[] var26 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var26);
    int var28 = org.apache.commons.math3.util.MathArrays.distance1(var22, var26);
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(100L);
    int var33 = var31.nextInt(1);
    int[] var34 = new int[] { };
    var31.setSeed(var34);
    int[] var38 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var39 = new org.apache.commons.math3.random.Well19937c(var38);
    int var40 = org.apache.commons.math3.util.MathArrays.distance1(var34, var38);
    int[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var34);
    double var42 = org.apache.commons.math3.util.MathArrays.distance(var22, var41);
    int var43 = org.apache.commons.math3.util.MathArrays.distance1(var11, var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var44 = org.apache.commons.math3.util.MathArrays.distance(var5, var22);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var4.nextSecureInt(1236725234, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-1991088005), (-571311543));

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var19);
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    double[] var32 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var33 = new double[] { };
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var33);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var28, var35);
    double[] var40 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var41 = new double[] { };
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var41);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    double[] var47 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var48 = new double[] { };
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var48);
    double[][] var50 = new double[][] { var47};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var41, var43, var50);
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var41);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var4, var52);
    double[] var57 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var58 = new double[] { };
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var57, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
    double[] var64 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var65 = new double[] { };
    boolean var66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var65);
    double[][] var67 = new double[][] { var64};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var58, var60, var67);
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double[] var73 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var74 = new double[] { };
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var73, var74);
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = null;
    double[] var80 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var81 = new double[] { };
    boolean var82 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var80, var81);
    double[][] var83 = new double[][] { var80};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var74, var76, var83);
    org.apache.commons.math3.util.MathArrays.checkPositive(var74);
    double[] var86 = org.apache.commons.math3.util.MathArrays.ebeDivide(var58, var74);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var4, var58);
    double var88 = org.apache.commons.math3.util.MathArrays.safeNorm(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var4.nextChiSquare((-0.8371016669875919d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
    double var17 = var4.nextExponential(1.4636684439841448d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = var4.nextInt((-1265566754), (-1395623025));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5127948165466234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.7429747933972144d);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
//     org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
//     long var5 = var2.nextLong();
//     int var7 = var2.nextInt(55901590);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var8);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextF(97.80131830602635d, 73.45997103732067d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var2.nextPascal(1045626652, 3.5865133480106643d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.1465958732435784d);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c();
//     int var2 = var1.nextInt();
//     long[] var3 = null;
//     long[][] var4 = new long[][] { var3};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var2, (java.lang.Object)var4);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
//     java.lang.Throwable[] var9 = var8.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     java.lang.Object[] var13 = new java.lang.Object[] { (byte)10};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, var13);
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var20 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var16, (java.lang.Number)11.656091933465596d, (java.lang.Number)(-0.08244612118583806d), false);
//     var15.addSuppressed((java.lang.Throwable)var20);
//     var8.addSuppressed((java.lang.Throwable)var15);
//     org.apache.commons.math3.exception.util.ExceptionContext var23 = var8.getContext();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1259404826);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextBeta(7.33117135760314d, 0.3890340168320314d);
//     long var13 = var4.nextSecureLong(0L, 10L);
//     double var16 = var4.nextCauchy(25.606519169958414d, 2.407139629739897d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var4.nextHypergeometric(1232268348, (-623744341), 1905686917);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9302824796499628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 47.02236245828856d);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     double var12 = var4.nextCauchy(911.976359897697d, 0.08928819504170851d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var4.nextPascal(487874150, 186.55511928717704d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.010002141729723612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 915.2930250084987d);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var15, var19);
    double[][] var23 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var23);
    double[] var28 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var29 = new double[] { };
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var29);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    double[] var35 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var36 = new double[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var36);
    double[][] var38 = new double[][] { var35};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var29, var31, var38);
    double[] var40 = null;
    double[] var44 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var45 = new double[] { };
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var40, var44);
    double[][] var48 = new double[][] { var44};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var29, var48);
    double[] var53 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var54 = new double[] { };
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var54);
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    double[] var60 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var61 = new double[] { };
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var60, var61);
    double[][] var63 = new double[][] { var60};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var54, var56, var63);
    double[] var68 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var69 = new double[] { };
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var69);
    double var71 = org.apache.commons.math3.util.MathArrays.distanceInf(var54, var69);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var54);
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var4, var29);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var78 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    java.lang.String var79 = var78.toString();
    org.apache.commons.math3.util.MathArrays.OrderDirection var80 = var78.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var81 = var78.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var84 = org.apache.commons.math3.util.MathArrays.checkOrder(var29, var81, false, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var79 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)"+ "'", var79.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c();
//     int var5 = var4.nextInt();
//     long[] var6 = null;
//     long[][] var7 = new long[][] { var6};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)var7);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var7);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1), (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1073118273);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.1672233456208478d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    int var6 = var2.nextInt(225475469);
    int var7 = var2.nextInt();
    org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 63455071);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-401038879));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8.379633310485001d);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 8.379633310485001d+ "'", var3.equals(8.379633310485001d));

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     java.lang.Object var11 = var10.getFirst();
//     org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair(var10);
//     java.lang.Object var13 = null;
//     boolean var14 = var10.equals(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1257695588);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 1257695588+ "'", var6.equals(1257695588));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + 1257695588+ "'", var11.equals(1257695588));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextGaussian((-853.0935538935793d), 1.7965218799149243d);
//     long var9 = var2.nextLong(12L, 696171521889898368L);
//     int var12 = var2.nextInt((-1462141839), 1685252840);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextBinomial((-1162417290), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-854.4300898985481d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 207875016479817792L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 875027689);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    double var11 = var4.nextGaussian(2.4996568400077432d, 1.0429625641369598d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var4.nextHypergeometric((-1946542504), 0, 452229905);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3.685214883999529d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var4.nextSecureInt((-1462141839), (-1477247604));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var20);
    var23.clear();
    org.apache.commons.math3.random.RandomDataGenerator var25 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var28 = var25.nextGaussian(101.73535858077676d, (-6.823093198153258d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    long var4 = var1.nextLong();
    byte[] var7 = new byte[] { (byte)1, (byte)1};
    var1.nextBytes(var7);
    float var9 = var1.nextFloat();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.75475645f);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextGaussian(10.327401159520946d, 26.19989450026949d);
//     var4.reSeed();
//     long var14 = var4.nextSecureLong((-3672105181913330688L), 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9.337083404058355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1498907027521517312L));
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     int var13 = var0.nextBinomial(445938823, 0.5127948165466234d);
//     double var16 = var0.nextBeta(1.327000036267693d, 0.011847334872158638d);
//     java.lang.String var18 = var0.nextHexString(11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.698248796015525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-22.05839579842444d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 101.04521449400569d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 228667646);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9999999988643679d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "e00e09a64d7"+ "'", var18.equals("e00e09a64d7"));
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var2 = null;
    long[][] var3 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 20.594153217877338d);
    double[] var28 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var29 = new double[] { };
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var29);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    double[] var35 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var36 = new double[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var36);
    double[][] var38 = new double[][] { var35};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var29, var31, var38);
    double[] var43 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var44 = new double[] { };
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var44);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    double[] var50 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var51 = new double[] { };
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var51);
    double[][] var53 = new double[][] { var50};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var44, var46, var53);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var56 = org.apache.commons.math3.util.MathArrays.ebeAdd(var24, var29);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    double[] var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    java.lang.String var5 = var4.toString();
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var4.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var4.getDirection();
    double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var12 = new double[] { };
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    double[] var22 = org.apache.commons.math3.util.MathArrays.ebeAdd(var12, var19);
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    double[] var33 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var34 = new double[] { };
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var34);
    double[][] var36 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var29, var36);
    double[] var38 = null;
    double[] var42 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var43 = new double[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var38, var42);
    double[][] var46 = new double[][] { var42};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var46);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var22, var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var7, var46);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var32 = new int[] { 0, 100, 1};
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
    int[] var38 = new int[] { 10, 100, 10};
    int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var38);
    org.apache.commons.math3.random.Well19937c var40 = new org.apache.commons.math3.random.Well19937c(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 10);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    var4.reSeedSecure(10L);
    double var14 = var4.nextExponential(30.043691138926352d);
    double var16 = var4.nextExponential(32.40741877671882d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 14.61575505112098d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 5.951069795407048d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 111145379, 2074555787);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c();
//     int var5 = var4.nextInt();
//     long[] var6 = null;
//     long[][] var7 = new long[][] { var6};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)var7);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var7);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1), (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.036975522396707d, (java.lang.Object[])var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1288764890);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var4 = var0.nextF(1.7965218799149243d, 5.271764897745934d);
//     int var7 = var0.nextSecureInt(91, 100);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4500140660199234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 96);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    boolean var6 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     java.util.Collection var2 = null;
//     java.lang.Object[] var4 = var1.nextSample(var2, (-458435062));
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)11.38364603395183d, (java.lang.Number)1741975207, 1741975207);
    var3.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c();
//     int var3 = var2.nextInt();
//     long[] var4 = null;
//     long[][] var5 = new long[][] { var4};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var5);
//     java.lang.Object var8 = var7.getKey();
//     org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair(var7);
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     java.lang.Comparable[] var14 = new java.lang.Comparable[] { 1L};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     boolean var17 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var14, var15, true);
//     org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var11, (java.lang.Object[])var14);
//     java.lang.Throwable[] var20 = var19.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var20);
//     boolean var22 = var7.equals((java.lang.Object)var20);
//     org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var20);
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 731048424);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + 731048424+ "'", var8.equals(731048424));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var35);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)0.9999999917315139d, var2);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var20);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = var40.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var41, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var45 = org.apache.commons.math3.util.MathArrays.isMonotonic(var20, var41, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    float var4 = var2.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)1.7965218799149243d, (java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.23953891f);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextHypergeometric((-1521029328), 1045626652, 749227529);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var35);
    double[][] var48 = new double[][] { var35};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var48);
    double[] var53 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var54 = new double[] { };
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var54);
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    double[] var60 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var61 = new double[] { };
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var60, var61);
    double[][] var63 = new double[][] { var60};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var54, var56, var63);
    double[] var68 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var69 = new double[] { };
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var69);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    double[] var75 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var76 = new double[] { };
    boolean var77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var75, var76);
    double[][] var78 = new double[][] { var75};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var69, var71, var78);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var54, var69);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var32 = new int[] { 0, 100, 1};
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var32, (-1162417290));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var11, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var18);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    long var4 = var1.nextLong();
    byte[] var7 = new byte[] { (byte)1, (byte)1};
    var1.nextBytes(var7);
    boolean var9 = var1.nextBoolean();
    boolean var10 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    var4.reSeed(166L);
    long var11 = var4.nextLong(0L, 2110551683838641920L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 903963931762796160L);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(264518552, (-1439532343));

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var5);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)94.37406976352618d, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(3.8744448346390348d, 11.656091933465596d);
//     long var12 = var2.nextPoisson(0.1504224218416993d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextZipf((-1923973809), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4.77754546632368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }
// 
// 
//     org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(63455071, (-1978339594));
//     int var3 = var2.getDimension();
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c();
//     int var7 = var6.nextInt();
//     long[] var8 = null;
//     long[][] var9 = new long[][] { var8};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair((java.lang.Object)var7, (java.lang.Object)var9);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, (java.lang.Object[])var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1978339594));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1789494699));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(100L);
    int var8 = var6.nextInt(1);
    int[] var9 = new int[] { };
    var6.setSeed(var9);
    int[] var14 = new int[] { 0, 100, 1};
    int var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var14);
    var4.setSeed(var9);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(100L);
    int var20 = var18.nextInt(1);
    int[] var21 = new int[] { };
    var18.setSeed(var21);
    int[] var25 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var25);
    int var27 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(100L);
    int var31 = var29.nextInt(1);
    int[] var32 = new int[] { };
    var29.setSeed(var32);
    int[] var37 = new int[] { 0, 100, 1};
    int var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var37);
    int var39 = org.apache.commons.math3.util.MathArrays.distance1(var25, var37);
    org.apache.commons.math3.random.Well19937c var41 = new org.apache.commons.math3.random.Well19937c(100L);
    int var43 = var41.nextInt(1);
    int[] var44 = new int[] { };
    var41.setSeed(var44);
    int[] var49 = new int[] { 0, 100, 1};
    int var50 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var49);
    int var51 = org.apache.commons.math3.util.MathArrays.distance1(var37, var49);
    double var52 = org.apache.commons.math3.util.MathArrays.distance(var9, var37);
    var1.setSeed(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var43 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var44 = new double[] { };
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var44);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    double[] var50 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var51 = new double[] { };
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var51);
    double[][] var53 = new double[][] { var50};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var44, var46, var53);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var44);
    double var56 = org.apache.commons.math3.util.MathArrays.safeNorm(var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var55);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var7 = var1.nextFloat();
    byte[] var10 = new byte[] { (byte)100, (byte)10};
    var1.nextBytes(var10);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.6501708f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    int[] var1 = new int[] { 0};
    int[] var5 = new int[] { 0, 100, 1};
    double var6 = org.apache.commons.math3.util.MathArrays.distance(var1, var5);
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var5, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure(20L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform(8.402273643127563d, (-3273.652368371841d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)21L, var1, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    boolean var5 = var3.getBoundIsAllowed();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)12L);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    int[] var3 = new int[] { 10, 100, 10};
    int[] var5 = new int[] { 0};
    int[] var9 = new int[] { 0, 100, 1};
    double var10 = org.apache.commons.math3.util.MathArrays.distance(var5, var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(7L);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(100L);
    int var17 = var15.nextInt(1);
    int[] var18 = new int[] { };
    var15.setSeed(var18);
    int[] var22 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(100L);
    int var28 = var26.nextInt(1);
    int[] var29 = new int[] { };
    var26.setSeed(var29);
    int[] var34 = new int[] { 0, 100, 1};
    int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var34);
    int var36 = org.apache.commons.math3.util.MathArrays.distance1(var22, var34);
    var13.setSeed(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var3, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 13.45362404707371d);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c();
//     int var3 = var2.nextInt();
//     long[] var4 = null;
//     long[][] var5 = new long[][] { var4};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)2.206754219278758d, (java.lang.Object[])var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     double var12 = var4.nextCauchy(3.8744448346390348d, 0.016151381368146953d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var4.nextSecureHexString((-955090935));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 23L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.892167930990396d);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double var31 = org.apache.commons.math3.util.MathArrays.distance(var14, var19);
    double[] var35 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var36 = new double[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var36);
    double[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    double[] var42 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var43 = new double[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var43);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeAdd(var36, var43);
    double[] var50 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var51 = new double[] { };
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var51);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    double[] var57 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var58 = new double[] { };
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var57, var58);
    double[][] var60 = new double[][] { var57};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var51, var53, var60);
    org.apache.commons.math3.util.MathArrays.checkPositive(var51);
    double[] var66 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var67 = new double[] { };
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var67);
    org.apache.commons.math3.util.MathArrays.OrderDirection var69 = null;
    double[] var73 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var74 = new double[] { };
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var73, var74);
    double[][] var76 = new double[][] { var73};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var67, var69, var76);
    org.apache.commons.math3.util.MathArrays.checkPositive(var67);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var67);
    double var80 = org.apache.commons.math3.util.MathArrays.distance(var36, var67);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var14, var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var36);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(7.349742710098841d, 1.542290759080808d, 2.0097826154152907d, 0.19153321607781723d, 24.87003775369207d, 0.06582638330965575d, 90.43193939599433d, 0.4698048838655384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 55.84285181512543d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var9 = var6.nextBeta(4.917623451873656d, 100.49939010820418d);
    var6.reSeedSecure(4812634305967451571L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var6.nextWeibull((-1.1012004570294223d), (-88.26105062884918d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05190356240941041d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-33.183357284990514d), 6.117202351697582d, 0.0d, 97.22699097325065d, 10.774705318241162d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-213.7640165392062d));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    double var7 = var4.nextChiSquare(17.308134617107928d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var4.nextBinomial((-1219036332), 0.2550536339465285d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.773005865746882d);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(100L);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var6 = var4.nextInt(1);
//     int[] var7 = new int[] { };
//     var4.setSeed(var7);
//     int[] var12 = new int[] { 0, 100, 1};
//     int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var12);
//     var2.setSeed(var7);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var18 = var16.nextInt(1);
//     int[] var19 = new int[] { };
//     var16.setSeed(var19);
//     int[] var23 = new int[] { 1, 10};
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
//     int var25 = org.apache.commons.math3.util.MathArrays.distance1(var19, var23);
//     org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var29 = var27.nextInt(1);
//     int[] var30 = new int[] { };
//     var27.setSeed(var30);
//     int[] var35 = new int[] { 0, 100, 1};
//     int var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var35);
//     int var37 = org.apache.commons.math3.util.MathArrays.distance1(var23, var35);
//     org.apache.commons.math3.random.Well19937c var39 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var41 = var39.nextInt(1);
//     int[] var42 = new int[] { };
//     var39.setSeed(var42);
//     int[] var47 = new int[] { 0, 100, 1};
//     int var48 = org.apache.commons.math3.util.MathArrays.distanceInf(var42, var47);
//     int var49 = org.apache.commons.math3.util.MathArrays.distance1(var35, var47);
//     double var50 = org.apache.commons.math3.util.MathArrays.distance(var7, var35);
//     int var51 = org.apache.commons.math3.util.MathArrays.distance1(var0, var7);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     int var18 = var4.nextZipf(59, 0.05190356240941041d);
//     long var20 = var4.nextPoisson(141.746624376947d);
//     double var22 = var4.nextChiSquare(23.95389662180223d);
//     var4.reSeed();
//     int var26 = var4.nextInt((-463115300), 1479867090);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3098593374527597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.08244612118583806d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 166L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 20.594153217877338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 231969224);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    double[] var2 = new double[] { 100.0d, 100.0d};
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, true);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var5);
    double[] var16 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var17 = new double[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var17);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var25.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var26, false);
    boolean var30 = org.apache.commons.math3.util.MathArrays.isMonotonic(var16, var26, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var32 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)72L, (java.lang.Number)12.098177515297595d, (-1667859135), var26, false);
    boolean var34 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var26, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var2, var26, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-179.4397511845404d), (java.lang.Number)862908985188605553L, false);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     double var12 = var4.nextCauchy(911.976359897697d, 0.08928819504170851d);
//     long var15 = var4.nextSecureLong(35L, 404374688027301760L);
//     org.apache.commons.math3.distribution.IntegerDistribution var16 = null;
//     int var17 = var4.nextInversionDeviate(var16);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double[] var33 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var34 = new double[] { };
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var34);
    double[] var40 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var41 = new double[] { };
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var41);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    double[] var47 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var48 = new double[] { };
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var48);
    double[][] var50 = new double[][] { var47};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var41, var43, var50);
    double[] var55 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var56 = new double[] { };
    boolean var57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var55, var56);
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = null;
    double[] var62 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var63 = new double[] { };
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var63);
    double[][] var65 = new double[][] { var62};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var56, var58, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeDivide(var41, var56);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var67);
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var14, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextGaussian((-853.0935538935793d), 1.7965218799149243d);
//     long var9 = var2.nextLong(12L, 696171521889898368L);
//     int var12 = var2.nextInt((-1462141839), 1685252840);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextPascal((-579798130), 10.259243586441777d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-853.5844245358468d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 65843118889548904L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 962649920);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextF(97.80131830602635d, 73.45997103732067d);
//     double var10 = var2.nextUniform(3.866719511476555d, 96.98599266548317d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8838954615818368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 78.20203935337979d);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextBeta(7.33117135760314d, 0.3890340168320314d);
//     long var13 = var4.nextSecureLong(0L, 10L);
//     double var16 = var4.nextBeta(3.5865133480106643d, 12.082812504764005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9947902875566336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.13942646215987609d);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2456.934613457899d, (java.lang.Number)(-1498907027521517312L), false);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextHypergeometric((-1588168313), (-463115300), (-554403373));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 1827962647, 225475469);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 225475469);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     int[] var4 = new int[] { };
//     var1.setSeed(var4);
//     int[] var6 = null;
//     int var7 = org.apache.commons.math3.util.MathArrays.distance1(var4, var6);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var6);
//     byte[] var12 = new byte[] { (byte)0, (byte)10, (byte)(-1)};
//     var8.nextBytes(var12);
//     double var14 = var8.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1.0964696489186798d));
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     java.lang.Object var11 = var10.getFirst();
//     double[] var15 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var16 = new double[] { };
//     boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     double[] var22 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var23 = new double[] { };
//     boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var23);
//     double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var23);
//     double[] var30 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var31 = new double[] { };
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var31);
//     double var33 = org.apache.commons.math3.util.MathArrays.distance1(var23, var30);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
//     boolean var35 = var10.equals((java.lang.Object)var30);
//     double[] var36 = null;
//     double var37 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var36);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    var2.reSeedSecure(579504999478877568L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    double var12 = var2.nextGamma(1.4808388048950236d, 5.279378583866268d);
    double var15 = var2.nextBeta(12.082812504764005d, 2.3156585688760107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 11.13208948913201d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.7940956297965851d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var10, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-86.03939096591209d), var1, (-955090935), var10, true);
    boolean var15 = var14.getStrict();
    java.lang.String var16 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -955,090,936 and -955,090,935 are not strictly increasing (null >= -86.039)"+ "'", var16.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -955,090,936 and -955,090,935 are not strictly increasing (null >= -86.039)"));

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    var4.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    double[] var6 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var7 = new double[] { };
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var7);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = var15.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var16, false);
    boolean var20 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var16, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)72L, (java.lang.Number)12.098177515297595d, (-1667859135), var16, false);
    org.apache.commons.math3.exception.util.ExceptionContext var23 = var22.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    boolean var4 = var3.getStrict();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeed(1L);
//     var4.reSeedSecure((-1L));
//     var4.reSeed();
//     double var11 = var4.nextT(0.053025120244028924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.23953891f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 47530.321054088694d);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.685214883999529d, 1.3161168395169025d);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var4.nextInversionDeviate(var11);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(2.7429747933972144d, 0.3098593374527597d, 11.292796076075014d, 2.273245767621775d, (-371.89595262305977d), 0.0d, 0.12561605610783408d, 0.9967298592597413d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 26.64644251061012d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8.379633310485001d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var19);
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var46);
    double[] var52 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var53 = new double[] { };
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var55 = null;
    double[] var59 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var60 = new double[] { };
    boolean var61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var59, var60);
    double[][] var62 = new double[][] { var59};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var53, var55, var62);
    double[] var64 = null;
    double[] var68 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var69 = new double[] { };
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var64, var68);
    double[][] var72 = new double[][] { var68};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var53, var72);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var72);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     int var10 = var4.nextInt((-1223526183), 941025974);
//     double var13 = var4.nextGamma(12.950477475625878d, 0.5127948165466234d);
//     double var15 = var4.nextChiSquare(0.017515484636074805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-699747309));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.507370234633702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.6754244041658263E-9d);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     java.lang.Object var11 = var10.getFirst();
//     double[] var15 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var16 = new double[] { };
//     boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     double[] var22 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var23 = new double[] { };
//     boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var23);
//     double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var23);
//     double[] var30 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var31 = new double[] { };
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var31);
//     double var33 = org.apache.commons.math3.util.MathArrays.distance1(var23, var30);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
//     boolean var35 = var10.equals((java.lang.Object)var30);
//     java.lang.Object var36 = var10.getFirst();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 206761918);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 206761918+ "'", var6.equals(206761918));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + 206761918+ "'", var11.equals(206761918));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + 206761918+ "'", var36.equals(206761918));
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    long[] var6 = null;
    long[][] var7 = new long[][] { var6};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)11.38364603395183d, var1, (-1913623175), var3, false);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-623744341), 280165598);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 11.656091933465596d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var7.getDirection();
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var8, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)89.8843325929254d, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1223526183), 11);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)11.656091933465596d, (java.lang.Number)(-0.08244612118583806d), false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.08244612118583806d)+ "'", var5.equals((-0.08244612118583806d)));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1298863262), 59);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8.379633310485001d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1.0f), var1);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0f)+ "'", var3.equals((-1.0f)));

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(63455071, (-1978339594));
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
    int var4 = var2.getDimension();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var6 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var5, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1978339594));

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    var1.setSeed(1232268348);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(100L);
    int var11 = var9.nextInt(1);
    int[] var12 = new int[] { };
    var9.setSeed(var12);
    int[] var16 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    var1.setSeed(var12);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextHypergeometric(0, 1685252840, 1073118273);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d7fbd6b034"+ "'", var3.equals("d7fbd6b034"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1257695588);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var5 = var1.nextFloat();
    long var6 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.04677832f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8045925313331692144L);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     double var12 = var4.nextCauchy(10.327401159520946d, 0.953266988202223d);
//     double var14 = var4.nextT(4.359252164571766d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var4.nextF((-854.472958291455d), 0.505061875757287d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 19L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11.0533366338574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9795151450394398d);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-430674889));
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1276760940);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    double[][] var22 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var15, var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var24, (-1051296493));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextF(97.80131830602635d, 73.45997103732067d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("e00e09a64d7", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7263423308246498d);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var10);
//     java.lang.Object var12 = var10.getKey();
//     java.lang.Object var13 = var10.getFirst();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-284136641));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-284136641)+ "'", var6.equals((-284136641)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (-284136641)+ "'", var12.equals((-284136641)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + (-284136641)+ "'", var13.equals((-284136641)));
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     var4.reSeed();
//     long var13 = var4.nextLong(2L, 3200796353914668032L);
//     double var16 = var4.nextGaussian(31.067130348919022d, 0.6052934619394505d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.09483909789926699d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 799658303633592832L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 30.918522688565865d);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 2030352055);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     int var13 = var0.nextBinomial(445938823, 0.5127948165466234d);
//     double var16 = var0.nextBeta(1.327000036267693d, 0.011847334872158638d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextBinomial(0, 3.8439213970347454d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 12.425091527878925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.558168865926127d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 100.35753765373308d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 228667646);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9999999988643679d);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     int var13 = var0.nextSecureInt((-472844068), 11);
//     var0.reSeedSecure();
//     double var16 = var0.nextExponential(100.76486974265387d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextHypergeometric((-1219036332), (-1854640921), 1685252840);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.589919110254403d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.817659975682445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 99.3070710573635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-343088290));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 150.20397079190536d);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     int var18 = var4.nextZipf(59, 0.05190356240941041d);
//     org.apache.commons.math3.distribution.IntegerDistribution var19 = null;
//     int var20 = var4.nextInversionDeviate(var19);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var14 = var0.nextUniform(11.656091933465596d, 102.09948570917526d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextPascal(1873337969, 141.746624376947d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 10.290474581522691d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.407390539466077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 103.05876158987189d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7.235409585309873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 55.30926935485094d);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.19153321607781723d, (java.lang.Number)1.6797400806850826d, false);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    java.lang.Number var4 = var3.getPrevious();
    int var5 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 862908985188605553L+ "'", var4.equals(862908985188605553L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-852432388));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10L, (java.lang.Number)0.19048333f, (java.lang.Number)1.0f);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10L+ "'", var5.equals(10L));

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     long var18 = var4.nextSecureLong((-4523942956662907304L), 696171521889898368L);
//     double var21 = var4.nextCauchy(1.1250108292257317d, 8.773005865746882d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setSecureAlgorithm("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception", "4bfdf0b893");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3098593374527597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.08244612118583806d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1531561838453291264L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-12.142480884604916d));
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    float[] var3 = new float[] { 10.0f, 0.0f, 100.0f};
    float[] var7 = new float[] { 1.0f, 100.0f, 100.0f};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var7);
    float[] var11 = new float[] { 100.0f, 100.0f};
    float[] var13 = new float[] { 100.0f};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var11, var13);
    float[] var17 = new float[] { 100.0f, 100.0f};
    float[] var19 = new float[] { 100.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var11, var17);
    float[] var23 = new float[] { 0.0f};
    float[] var26 = new float[] { 100.0f, 100.0f};
    float[] var28 = new float[] { 100.0f};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var26, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var28);
    float[] var33 = new float[] { 100.0f, 100.0f};
    float[] var35 = new float[] { 100.0f};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var33, var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var23, var33);
    float[] var40 = new float[] { 100.0f, 100.0f};
    float[] var42 = new float[] { 100.0f};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var40, var42);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var17, var40);
    float[] var47 = new float[] { 0.0f};
    float[] var50 = new float[] { 100.0f, 100.0f};
    float[] var52 = new float[] { 100.0f};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var50, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var52);
    float[] var57 = new float[] { 100.0f, 100.0f};
    float[] var59 = new float[] { 100.0f};
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var57, var59);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var47, var57);
    float[] var64 = new float[] { 100.0f, 100.0f};
    float[] var66 = new float[] { 100.0f};
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var64, var66);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var57, var64);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var40, var64);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var3, var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    int var18 = var4.nextZipf(59, 0.05190356240941041d);
    long var20 = var4.nextPoisson(141.746624376947d);
    var4.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 166L);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)90.43193939599433d, (java.lang.Number)7258068567783673378L, 527625194);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    double[][] var22 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var15, var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var24);
    double[] var30 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var31 = new double[] { };
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var31);
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    double[] var37 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var38 = new double[] { };
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var38);
    double[][] var40 = new double[][] { var37};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var33, var40);
    double[] var42 = null;
    double[] var46 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var47 = new double[] { };
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var42, var46);
    double[][] var50 = new double[][] { var46};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var50);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var50);
    double[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var4, var55, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(12.950477475625878d, 0.1504224218416993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.13862295690761914d);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextGaussian((-853.0935538935793d), 1.7965218799149243d);
//     long var9 = var2.nextLong(12L, 696171521889898368L);
//     int var12 = var2.nextInt((-1462141839), 1685252840);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var2.nextHexString((-826841399));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-854.7837418310767d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 476577133650326144L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-978890919));
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var11 = var0.nextGamma(0.9985657395524848d, 10.327401159520946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8.640852830091575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-13.101092768506213d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 98.9951915602923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.2956708762921725d);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     int var13 = var0.nextBinomial(445938823, 0.5127948165466234d);
//     var0.reSeed(13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.416156676128754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-4.078866628589261d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 99.34087586641043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 228667646);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(59);
    boolean var2 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    var4.reSeedSecure(10L);
    double var16 = var4.nextUniform(11.13208948913201d, 2456.934613457899d, true);
    var4.reSeedSecure();
    double var21 = var4.nextUniform(83.86480134623451d, 403.86667959045457d, true);
    int var24 = var4.nextBinomial(280165598, 0.0d);
    double var27 = var4.nextCauchy(0.0d, 30.043691138926352d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1828.9544353782949d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 273.2471843471883d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.589529399971218d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-853.9703069890292d), (java.lang.Number)10.259243586441777d, false);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var10, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-86.03939096591209d), var1, (-955090935), var10, true);
    boolean var15 = var14.getStrict();
    java.lang.Throwable[] var16 = var14.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-579798130), (-2102199606));
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-2102199606));

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     double var7 = var0.nextUniform(0.0d, 73.45997103732067d, false);
//     var0.reSeedSecure(7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextGaussian(0.5840095788202652d, (-179.4397511845404d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.383636371427204d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 23.815417581959068d);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     int var5 = var0.nextPascal(111145379, 0.05190356240941041d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.65092604991407d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2030509906);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getFirst();
//     java.lang.Object var7 = var5.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1840540321);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 1840540321+ "'", var6.equals(1840540321));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + 1840540321+ "'", var7.equals(1840540321));
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextInt(445938823, 1232268348);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var4.nextHypergeometric(1685252840, (-430674889), (-1500349861));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1158845504);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(0.015854286399873473d);
//     java.lang.Object var3 = null;
//     org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair(var4);
//     java.lang.Object var6 = var5.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8.00832130676024E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var11 = new int[] { 0, 100, 1};
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var11);
    var1.setSeed(var6);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed((-2102199606));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     var4.reSeed();
//     double var19 = var4.nextGaussian(0.9415204784823727d, 0.9666929925700074d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3098593374527597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.08244612118583806d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.36552745519859d);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-554403373));
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeedSecure(100L);
//     var4.reSeed(0L);
//     var4.reSeedSecure(10L);
//     double var14 = var4.nextExponential(30.043691138926352d);
//     var4.reSeed();
//     double var17 = var4.nextT(11.060160009243058d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 14.61575505112098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.5068021275911827d));
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.011847334872158638d, 20.594153217877338d, 32.200484899918834d, 2.2956708762921725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 74.16570121681028d);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }
// 
// 
//     org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(63455071, (-1978339594));
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c();
//     int var8 = var7.nextInt();
//     long[] var9 = null;
//     long[][] var10 = new long[][] { var9};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
//     org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var10);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.util.ExceptionContext var16 = var15.getContext();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-2104039004));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    double[][] var22 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var15, var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var24);
    java.lang.Comparable[] var31 = new java.lang.Comparable[] { 11.656091933465596d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var35 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var36 = var35.getDirection();
    boolean var38 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var31, var36, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.15562109371395244d, (java.lang.Number)0.9967298592597413d, 1790344579, var36, true);
    int var41 = var40.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var42 = var40.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var24, var42, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1790344579);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextBeta(3.9346068085718677d, 23.95389662180223d);
    double var9 = var4.nextChiSquare(6.03709264688173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.049864014567367256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 5.336267947811988d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    long var9 = var4.nextLong(1L, 70L);
    double var12 = var4.nextCauchy(5.816193535071593d, 0.953266988202223d);
    double var15 = var4.nextGaussian(2.2550942871493342d, 2.206754219278758d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 5.957322665165762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.6588561136150881d);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(1.2554478871617567d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.14017682819976d);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var5.nextPascal(1276760940, 1.2554478871617567d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextGaussian((-853.0935538935793d), 1.7965218799149243d);
//     double var8 = var2.nextChiSquare(10.24834333371038d);
//     double var10 = var2.nextExponential(1.4808388048950236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-856.4600337361692d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 19.9238788065283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.28103238781417483d);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeed(1L);
    var4.reSeedSecure((-1L));
    double var10 = var4.nextExponential(0.10511601352671937d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.23586709793735716d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextCauchy(1.0d, 100.96201588326613d);
    var4.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-86.03939096591209d));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.7422697092282008d, (java.lang.Number)78L, true);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = null;
    long[][] var2 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var2);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed((-1265566754));
    var0.setSeed(26L);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(3.7501312412905117d, 10.774705318241162d, 0.13862295690761914d, 0.06582638330965575d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 40.41568407753213d);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     var0.setSeed(4418713979230659041L);
//     int var5 = var0.nextInt(16);
//     double var6 = var0.nextGaussian();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     double var10 = var7.nextBeta(4.631844337134838d, 6.03709264688173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1397943678);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.542290759080808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3102051384423452d);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    int var4 = var3.getIndex();
    int var5 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-852432388));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-852432388));

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = var1.nextPermutation(0, 186022101);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var19);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.7068623656369407d, (java.lang.Number)(byte)10, true);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     var4.reSeed();
//     long var13 = var4.nextLong(2L, 3200796353914668032L);
//     long var15 = var4.nextPoisson(0.015854286399873473d);
//     long var18 = var4.nextLong(696171521889898368L, 3200796353914668032L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.012907254850883454d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1745303111396712704L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1570627865300106752L);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var32 = new int[] { 0, 100, 1};
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(100L);
    int var38 = var36.nextInt(1);
    int[] var39 = new int[] { };
    var36.setSeed(var39);
    int[] var43 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(var43);
    int var45 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
    int[] var49 = new int[] { (-1), 100, 100};
    double var50 = org.apache.commons.math3.util.MathArrays.distance(var39, var49);
    int var51 = org.apache.commons.math3.util.MathArrays.distance1(var20, var49);
    org.apache.commons.math3.random.Well19937c var52 = new org.apache.commons.math3.random.Well19937c(var20);
    org.apache.commons.math3.random.Well19937c var54 = new org.apache.commons.math3.random.Well19937c(7L);
    org.apache.commons.math3.random.Well19937c var56 = new org.apache.commons.math3.random.Well19937c(100L);
    int var58 = var56.nextInt(1);
    int[] var59 = new int[] { };
    var56.setSeed(var59);
    int[] var63 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var64 = new org.apache.commons.math3.random.Well19937c(var63);
    int var65 = org.apache.commons.math3.util.MathArrays.distance1(var59, var63);
    org.apache.commons.math3.random.Well19937c var67 = new org.apache.commons.math3.random.Well19937c(100L);
    int var69 = var67.nextInt(1);
    int[] var70 = new int[] { };
    var67.setSeed(var70);
    int[] var75 = new int[] { 0, 100, 1};
    int var76 = org.apache.commons.math3.util.MathArrays.distanceInf(var70, var75);
    int var77 = org.apache.commons.math3.util.MathArrays.distance1(var63, var75);
    var54.setSeed(var75);
    double var79 = org.apache.commons.math3.util.MathArrays.distance(var20, var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     var4.reSeed();
//     var4.reSeed();
//     double var19 = var4.nextChiSquare(3.8439213970347454d);
//     double var22 = var4.nextF(0.9999977358410781d, 13.694776949656356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3098593374527597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.08244612118583806d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 11.00507952700545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.1418198370061344d);
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var5);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var10 = var8.nextInt(1);
//     int[] var11 = new int[] { };
//     var8.setSeed(var11);
//     int[] var15 = new int[] { 1, 10};
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     int var17 = org.apache.commons.math3.util.MathArrays.distance1(var11, var15);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(100L);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var24 = var22.nextInt(1);
//     int[] var25 = new int[] { };
//     var22.setSeed(var25);
//     int[] var30 = new int[] { 0, 100, 1};
//     int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var30);
//     var20.setSeed(var25);
//     int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
//     int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
//     boolean var35 = var5.equals((java.lang.Object)var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1856963046));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var27 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = var27.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var30 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var28, false);
    boolean var32 = org.apache.commons.math3.util.MathArrays.isMonotonic(var18, var28, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var18);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)11.38364603395183d, (java.lang.Number)1741975207, 1741975207);
    java.lang.Number var4 = var3.getPrevious();
    java.lang.Number var5 = var3.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1741975207+ "'", var4.equals(1741975207));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1741975207+ "'", var5.equals(1741975207));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-565.6035380963093d), (-39.0427551601906d), 0.1505364353345049d, 0.049864014567367256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 22082.727961982746d);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     var4.reSeed();
//     long var13 = var4.nextLong(2L, 3200796353914668032L);
//     long var15 = var4.nextPoisson(0.015854286399873473d);
//     double var19 = var4.nextUniform(11.947415003583655d, 90.43193939599433d, true);
//     double var22 = var4.nextWeibull(0.9985657395524848d, 0.1418198370061344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.08306570678556383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1296461237646943488L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 40.85863191368965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.02713248709803096d);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    double var14 = var2.nextCauchy(1.3995975989718865d, 2456.934613457899d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var2.nextSecureInt((-1072502360), (-1634309337));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-853.0935538935793d));

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var10);
//     java.lang.Object var12 = var11.getValue();
//     java.lang.Object var13 = var11.getValue();
//     java.lang.Object var14 = var11.getFirst();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-696849376));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-696849376)+ "'", var6.equals((-696849376)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (-696849376)+ "'", var14.equals((-696849376)));
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var4.nextZipf(0, 19.42595685892877d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextT(100.96201588326613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.4667426810670496d));

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(8.027560136941847d, 4.917623451873656d);
//     long var12 = var2.nextPoisson(0.8683854052034767d);
//     double var14 = var2.nextT(24.34812647271368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4.333467798172987d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.3349758999915175d));
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)5.951069795407048d, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var4.nextHexString((-284136641));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)73.45997103732067d);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c();
//     int var5 = var4.nextInt();
//     long[] var6 = null;
//     long[][] var7 = new long[][] { var6};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)var7);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var7);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1), (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-288198739));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    java.lang.Throwable[] var6 = var3.getSuppressed();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 225,475,468 and 225,475,469 are not strictly increasing (0 >= 100)"+ "'", var4.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 225,475,468 and 225,475,469 are not strictly increasing (0 >= 100)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    int var18 = var4.nextZipf(59, 0.05190356240941041d);
    double var21 = var4.nextGaussian(886.7023399316736d, 2.913539924093275d);
    double var24 = var4.nextWeibull(11.00507952700545d, 0.9507047658344296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 888.7476162696067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.8887632253277951d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)352.7369979895132d, (java.lang.Number)(-55731.07512021974d), true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-55731.07512021974d)+ "'", var4.equals((-55731.07512021974d)));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)295071075, (java.lang.Number)100.0f, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100.0f+ "'", var6.equals(100.0f));

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.nextWeibull((-1.9841284616200225d), 3.8584457592882444d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = var22.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var23, false);
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    double[] var30 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var31 = new double[] { };
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var31);
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    double[] var37 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var38 = new double[] { };
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var38);
    double[][] var40 = new double[][] { var37};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var33, var40);
    double[] var42 = null;
    double[] var46 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var47 = new double[] { };
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var42, var46);
    double[][] var50 = new double[][] { var46};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var50);
    org.apache.commons.math3.exception.NullArgumentException var52 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var50);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var23, var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    double var12 = var2.nextBeta(0.015854286399873473d, 0.05190356240941041d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var2.nextPascal(731048424, 8.637704071080643d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     double var10 = var8.nextDouble();
//     double var11 = var8.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 619904012);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 619904012+ "'", var6.equals(619904012));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.1904834217843172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.6906229421501671d));
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    double var4 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var5.nextWeibull(1.542290759080808d, 11.38364603395183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.2554478871617567d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.763658226806619d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var9 = var6.nextBeta(4.917623451873656d, 100.49939010820418d);
    var6.reSeedSecure(4812634305967451571L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var6.nextHypergeometric((-1816989844), (-537630031), 2074555787);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05190356240941041d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    boolean var3 = var1.nextBoolean();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(445938823, 1741975207);
//     long var5 = var0.nextPoisson(1.4808388048950236d);
//     double var9 = var0.nextUniform(0.022073983658682416d, 23.95389662180223d, false);
//     double var12 = var0.nextGamma(100.76486974265387d, 0.2149917709512965d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -955,090,936 and -955,090,935 are not strictly increasing (null >= -86.039)", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1451883007);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.1512273937912756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 17.97381907057137d);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     var0.setSeed(4418713979230659041L);
//     int var5 = var0.nextInt(16);
//     double var6 = var0.nextGaussian();
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     boolean var8 = var0.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-302977286));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.542290759080808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)11.38364603395183d, (java.lang.Number)1741975207, 1741975207);
    var3.addSuppressed((java.lang.Throwable)var7);
    int var9 = var7.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1741975207);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.2550536339465285d, (java.lang.Number)(-0.05636459668382493d), 0);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(0.015854286399873473d);
//     java.lang.Object var3 = null;
//     org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextZipf((-302977286), 0.9947902875566336d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.02025067757940567d);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    int var6 = var2.nextInt(225475469);
    int var7 = var2.nextInt();
    var2.clear();
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 63455071);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-401038879));

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     long var4 = var1.nextLong();
//     byte[] var7 = new byte[] { (byte)1, (byte)1};
//     var1.nextBytes(var7);
//     long var9 = var1.nextLong();
//     var1.setSeed(4812634305967451571L);
//     java.util.List var12 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var13 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var12);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(2.913539924093275d, 96.98599266548317d, 1.1203679680126208d, 888.7476162696067d, 7.344503370255124d, 7.838469139671447d, 0.0d, 0.8838954615818368d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1335.8665856387001d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1943075992);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     double var13 = var4.nextGaussian(10.9966135312502d, 24.92858751525751d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var4.nextExponential((-12.142480884604916d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-15.895654922150415d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 11.618576618482656d);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Comparable[] var4 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, true);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)23.95389662180223d, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextInt(1479867090, (-1816989844));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var20);
    var23.clear();
    var23.setSeed((-696849376));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1588168313), 59);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    var4.reSeed(166L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var4.nextUniform(0.0d, 0.0d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    long var9 = var2.nextPoisson(11.292796076075014d);
    int var12 = var2.nextZipf(91, 93.80443882825725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1158845504, (java.lang.Number)1.7965218799149243d, (java.lang.Number)722500763);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Throwable[] var6 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 722500763+ "'", var4.equals(722500763));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.7965218799149243d+ "'", var5.equals(1.7965218799149243d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    int var18 = var4.nextZipf(59, 0.05190356240941041d);
    double var21 = var4.nextGaussian(886.7023399316736d, 2.913539924093275d);
    double var24 = var4.nextBeta(8.012870143369822d, 0.012907254850883454d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 888.7476162696067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.9999999988432865d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var19);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.08244612118583806d), (java.lang.Number)18.78729006034737d, 0, var7, true);
    boolean var10 = var9.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     double var12 = var4.nextCauchy(10.327401159520946d, 0.953266988202223d);
//     double var14 = var4.nextT(4.359252164571766d);
//     double var16 = var4.nextT(1.036975522396707d);
//     var4.reSeedSecure(100L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 26L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10.313703855665612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.5878823303180405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1.4947998163287624d));
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    int var13 = var4.nextInt((-260641056), 445938823);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var4.nextCauchy(89.8843325929254d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 264518552);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    boolean var4 = var3.getStrict();
    int var5 = var3.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1232268348);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var11);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var35);
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var15, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(8.027560136941847d, 4.917623451873656d);
//     java.lang.String var12 = var2.nextSecureHexString(5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.057439617556286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "5d6e8"+ "'", var12.equals("5d6e8"));
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(82L);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = null;
    long[][] var2 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var2, (java.lang.Object)(-86705920));
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var19 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    int var21 = org.apache.commons.math3.util.MathArrays.distance1(var15, var19);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var31 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(var31);
    int var33 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var15, var34);
    int var36 = org.apache.commons.math3.util.MathArrays.distance1(var4, var15);
    org.apache.commons.math3.random.Well19937c var38 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var40 = new org.apache.commons.math3.random.Well19937c(100L);
    int var42 = var40.nextInt(1);
    int[] var43 = new int[] { };
    var40.setSeed(var43);
    int[] var48 = new int[] { 0, 100, 1};
    int var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var43, var48);
    var38.setSeed(var43);
    int var51 = org.apache.commons.math3.util.MathArrays.distance1(var15, var43);
    org.apache.commons.math3.random.Well19937c var53 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var55 = new org.apache.commons.math3.random.Well19937c(100L);
    int var57 = var55.nextInt(1);
    int[] var58 = new int[] { };
    var55.setSeed(var58);
    int[] var63 = new int[] { 0, 100, 1};
    int var64 = org.apache.commons.math3.util.MathArrays.distanceInf(var58, var63);
    var53.setSeed(var58);
    double var66 = org.apache.commons.math3.util.MathArrays.distance(var15, var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10L, (java.lang.Number)0.19048333f, (java.lang.Number)1.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getHi();
    java.lang.Number var7 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.19048333f+ "'", var4.equals(0.19048333f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0f+ "'", var5.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0f+ "'", var6.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.19048333f+ "'", var7.equals(0.19048333f));

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var6 = null;
    int var7 = org.apache.commons.math3.util.MathArrays.distance1(var4, var6);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var6);
    byte[] var12 = new byte[] { (byte)0, (byte)10, (byte)(-1)};
    var8.nextBytes(var12);
    var8.setSeed(1L);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(100L);
    int var19 = var17.nextInt(1);
    int[] var20 = new int[] { };
    var17.setSeed(var20);
    int[] var24 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
    int var26 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(100L);
    int var33 = var31.nextInt(1);
    int[] var34 = new int[] { };
    var31.setSeed(var34);
    int[] var39 = new int[] { 0, 100, 1};
    int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var34, var39);
    var29.setSeed(var34);
    int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var34);
    var8.setSeed(var27);
    var8.setSeed(674019381);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)(-955573574), (java.lang.Number)1045626652);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var11 = new int[] { 0, 100, 1};
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var11);
    var1.setSeed(var6);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(100L);
    int var17 = var15.nextInt(1);
    int[] var18 = new int[] { };
    var15.setSeed(var18);
    int[] var22 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(100L);
    int var28 = var26.nextInt(1);
    int[] var29 = new int[] { };
    var26.setSeed(var29);
    int[] var34 = new int[] { 0, 100, 1};
    int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var34);
    int var36 = org.apache.commons.math3.util.MathArrays.distance1(var22, var34);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.distance(var6, var34);
    org.apache.commons.math3.random.Well19937c var40 = new org.apache.commons.math3.random.Well19937c(100L);
    int var42 = var40.nextInt(1);
    int[] var43 = new int[] { };
    var40.setSeed(var43);
    int[] var48 = new int[] { 0, 100, 1};
    int var49 = org.apache.commons.math3.util.MathArrays.distanceInf(var43, var48);
    int var50 = org.apache.commons.math3.util.MathArrays.distance1(var34, var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var7 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, 2.273245767621775d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var21 = new double[] { };
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var28 = new double[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    double[][] var30 = new double[][] { var27};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var23, var30);
    double[] var35 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var36 = new double[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var36);
    double var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var36);
    double[] var42 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var43 = new double[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = null;
    double[] var49 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var50 = new double[] { };
    boolean var51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var50);
    double[][] var52 = new double[][] { var49};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var45, var52);
    double[] var57 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var58 = new double[] { };
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var57, var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distanceInf(var43, var58);
    double[] var64 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var65 = new double[] { };
    boolean var66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var65);
    org.apache.commons.math3.util.MathArrays.OrderDirection var67 = null;
    double[] var71 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var72 = new double[] { };
    boolean var73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var71, var72);
    double[][] var74 = new double[][] { var71};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var65, var67, var74);
    double[] var79 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var80 = new double[] { };
    boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var79, var80);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = null;
    double[] var86 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var87 = new double[] { };
    boolean var88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var86, var87);
    double[][] var89 = new double[][] { var86};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var80, var82, var89);
    double[] var91 = org.apache.commons.math3.util.MathArrays.ebeDivide(var65, var80);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var43, var91);
    double var93 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var43);
    double var94 = org.apache.commons.math3.util.MathArrays.distance(var6, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(100L);
    int var4 = var2.nextInt(1);
    int[] var5 = new int[] { };
    var2.setSeed(var5);
    int[] var10 = new int[] { 0, 100, 1};
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var10);
    double var12 = org.apache.commons.math3.util.MathArrays.distance(var0, var10);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var4.nextUniform(1.1672233456208478d, 0.6749990788145617d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    double[][] var22 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var15, var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var24);
    double[] var30 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var31 = new double[] { };
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var31);
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    double[] var37 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var38 = new double[] { };
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var38);
    double[][] var40 = new double[][] { var37};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var33, var40);
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeAdd(var24, var31);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     java.lang.Object var10 = var5.getValue();
//     boolean var12 = var5.equals((java.lang.Object)825523605);
//     java.lang.Object var13 = var5.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-816779798));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-816779798)+ "'", var6.equals((-816779798)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1893.691201012582d, var2, (java.lang.Number)2.2956708762921725d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(78L);
    float var2 = var1.nextFloat();
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9165802f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.9415204784823727d, (java.lang.Number)31.067130348919022d, (java.lang.Number)2456.934613457899d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 31.067130348919022d+ "'", var4.equals(31.067130348919022d));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var32 = new int[] { 0, 100, 1};
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
    int[] var38 = new int[] { 10, 100, 10};
    int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var38);
    int[] var41 = new int[] { 0};
    int[] var45 = new int[] { 0, 100, 1};
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var41, var45);
    int var47 = org.apache.commons.math3.util.MathArrays.distance1(var38, var45);
    org.apache.commons.math3.random.Well19937c var48 = new org.apache.commons.math3.random.Well19937c(var45);
    int[] var51 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var52 = new org.apache.commons.math3.random.Well19937c(var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var51);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }


    long[] var0 = null;
    long[][] var1 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var1);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)(-86705920));
    boolean var6 = var4.equals((java.lang.Object)4.202152073411737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    var4.reSeedSecure(10L);
    long var14 = var4.nextPoisson(10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15L);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(3.8744448346390348d, 11.656091933465596d);
//     long var12 = var2.nextPoisson(0.1504224218416993d);
//     var2.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 14.174839805851343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
//     int var4 = var3.nextInt();
//     long[] var5 = null;
//     long[][] var6 = new long[][] { var5};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)2.206754219278758d, (java.lang.Object[])var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1592850574);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (short)1};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var3);
//     double[] var14 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var15 = new double[] { };
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var15);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
//     org.apache.commons.math3.util.MathArrays.OrderDirection var24 = var23.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var26 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var24, false);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.isMonotonic(var14, var24, false);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var30 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)72L, (java.lang.Number)12.098177515297595d, (-1667859135), var24, false);
//     boolean var32 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var24, true);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var24, true);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
    int var19 = var4.nextHypergeometric(722500763, 91, 1);
    double var22 = var4.nextBeta(7.344503370255124d, 100.76486974265387d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5127948165466234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0447322566464164d);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     long[] var1 = null;
//     long[][] var2 = new long[][] { var1};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
//     org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var2);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c();
//     int var9 = var8.nextInt();
//     long[] var10 = null;
//     long[][] var11 = new long[][] { var10};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
//     org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, (java.lang.Object)var11);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var11);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(1.3995975989718865d);
    double var9 = var4.nextGamma(10.259243586441777d, 1.1672233456208478d);
    double var12 = var4.nextCauchy(0.0d, 6.117202351697582d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.022073983658682416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 7.998801860711875d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-9.251097372435593d));

  }

}
