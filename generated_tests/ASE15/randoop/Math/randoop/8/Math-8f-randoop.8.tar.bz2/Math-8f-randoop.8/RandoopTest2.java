
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
    int var19 = var4.nextHypergeometric(722500763, 91, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var4.nextUniform(96.98599266548317d, 2.14017682819976d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5127948165466234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1.5068021275911827d), (java.lang.Number)10.259243586441777d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    float[] var2 = new float[] { 100.0f, 100.0f};
    float[] var4 = new float[] { 100.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, 100.0f};
    float[] var10 = new float[] { 100.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
    float[] var14 = new float[] { 0.0f};
    float[] var17 = new float[] { 100.0f, 100.0f};
    float[] var19 = new float[] { 100.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var19);
    float[] var24 = new float[] { 100.0f, 100.0f};
    float[] var26 = new float[] { 100.0f};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var24, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var14, var24);
    float[] var31 = new float[] { 100.0f, 100.0f};
    float[] var33 = new float[] { 100.0f};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var31, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var8, var31);
    float[] var37 = null;
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     double var7 = var0.nextUniform(0.0d, 73.45997103732067d, false);
//     var0.reSeedSecure(7L);
//     java.lang.Object var10 = null;
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, var10);
//     double var13 = var0.nextT(0.017515484636074805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.62856672522406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 29.275749821059133d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.53996984378587008E18d));
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     var4.reSeed();
//     long var13 = var4.nextLong(2L, 3200796353914668032L);
//     long var15 = var4.nextPoisson(0.015854286399873473d);
//     long var18 = var4.nextLong(13L, 4812634305967451571L);
//     double var20 = var4.nextExponential(193.69455105973202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.018610725364128573d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3115931909942918656L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2466159041063263744L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 424.27955770680217d);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     var4.reSeed();
//     double var19 = var4.nextGaussian(0.0d, 0.6749990788145617d);
//     var4.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3098593374527597d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.08244612118583806d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.2187199149242795d));
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)1, (java.lang.Number)716369212, false);
    java.lang.Number var4 = var3.getMax();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 716369212+ "'", var4.equals(716369212));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var21 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = var21.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var22, false);
    boolean var26 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var22, false);
    boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var22, true);
    double[] var35 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var36 = new double[] { };
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var36);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var44 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = var44.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var45, false);
    boolean var49 = org.apache.commons.math3.util.MathArrays.isMonotonic(var35, var45, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)72L, (java.lang.Number)12.098177515297595d, (-1667859135), var45, false);
    boolean var53 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var45, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);

  }

}
