
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    double[] var0 = new double[] { };
    double[] var3 = new double[] { 1.0d, 1.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var3);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.0d, 0.0d, 0.0d, 0.0d, (-1.0d), 10.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextInt(1, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var3 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var1, true);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     double[] var0 = null;
//     double var1 = org.apache.commons.math3.util.MathArrays.safeNorm(var0);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextF(1.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextCauchy(1.0d, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var4 = new double[] { };
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var3, var6, false, false);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    double[] var1 = new double[] { (-1.0d)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, (-1));
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("", "hi!");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, (-955090935));
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("", "hi!");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextHypergeometric(1, (-1), (-955090935));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var5);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var0, var5);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextInt(0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 225475469);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextWeibull(1.0d, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.nextF(0.0d, 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var2 = new java.lang.Object[] { (byte)10};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var2);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object[] var5 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var5);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextHypergeometric((-955090935), 225475469, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var6 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var7 = new double[] { };
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var7);
    double[][] var9 = new double[][] { var7};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var1, var9);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var4 = new double[] { };
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//     double[] var6 = null;
//     double[] var7 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var6);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var13 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var4, var10);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextBinomial((-955090935), 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    double[] var0 = null;
    double[] var2 = new double[] { 10.0d};
    double var3 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[][] var4 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = org.apache.commons.math3.util.MathArrays.checkOrder(var4, var7, false, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextHypergeometric(1, (-955090935), 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 11.04848005716863d);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(5.271764897745934d, 10.0d, 3.9346068085718677d, 5.271764897745934d, 0.0d, 5.271764897745934d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 73.45997103732067d);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     boolean var7 = var5.equals((java.lang.Object)(short)100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1232268348);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     long[] var0 = null;
//     long[][] var1 = new long[][] { var0};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var1);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var1);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var8 = var2.nextSecureHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10L, (java.lang.Number)0.19048333f, (java.lang.Number)1.0f);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [0.19, 1] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [0.19, 1] range"));

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextZipf((-1), 3.8744448346390348d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var4 = new double[] { };
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     double[] var7 = null;
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var7);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var9 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var10 = new double[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var10);
    double var12 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var13 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var10);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.08971084836383868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.15053642f);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    int[] var2 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var2, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     double var7 = var0.nextUniform(0.0d, 73.45997103732067d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.950074140696172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 57.0134714429631d);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1816989844));
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(91, (-852432388));

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 0.0d};
    double[] var5 = new double[] { 10.0d};
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var7 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var3, var5);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10.0d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    java.lang.String var1 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"+ "'", var1.equals("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"));

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.util.List var0 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var1 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c();
//     int var2 = var1.nextInt();
//     long[] var3 = null;
//     long[][] var4 = new long[][] { var3};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var2, (java.lang.Object)var4);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(13.879672895408403d, 1.3995975989718865d, 0.0d, 0.2149917709512965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 19.42595685892877d);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     float var2 = var1.nextFloat();
//     var1.setSeed(1L);
//     java.util.List var5 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var6 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var5);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    double[] var3 = new double[] { 100.0d, 100.0d, 100.0d};
    double[] var7 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var8 = new double[] { };
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var8);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    double[] var14 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var15 = new double[] { };
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var15);
    double[][] var17 = new double[][] { var14};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var10, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var19 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var8);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     double var7 = var0.nextUniform(0.0d, 73.45997103732067d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var9 = var0.nextHexString((-852432388));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12.37135629208893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 56.52206408073913d);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var4 = new double[] { };
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var4);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
//     double[][] var9 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var8, var9);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-1978339594), (-1816989844));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var8 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 3.742940940679912d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)", "9e7fb29970");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8.771537287532992d);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.6973523005858913d, 8.379633310485001d, 0.4091400389977526d, 13.879672895408403d, (-4.813652559906312d), 1.7965218799149243d, 23.95389662180223d, 102.09948570917526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2456.934613457899d);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.051268594176404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.964325599487369d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 100.51312533134161d);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    var0.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextHypergeometric((-1), (-852432388), (-401038879));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGamma(3.8744448346390348d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextWeibull(0.0d, 4.359252164571766d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 42.226616122351054d);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextBinomial((-1978339594), 3.742940940679912d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.86947971372141d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 46.15925786047628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 98.94095696851218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.954792655554825d);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var12 = new double[] { };
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double[][] var21 = new double[][] { var18};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var14, var21);
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    double[] var33 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var34 = new double[] { };
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var34);
    double[][] var36 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var29, var36);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var39 = org.apache.commons.math3.util.MathArrays.linearCombination(var4, var12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-86705920));
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric(0, (-430674889), 280165598);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.5098586947003048d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-4.452372607994329d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 100.51277668940168d);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var4 = var0.nextF(1.7965218799149243d, 5.271764897745934d);
//     int var7 = var0.nextSecureInt(91, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextBinomial((-401038879), 100.96201588326613d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.497206319612486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 94);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var4, var15, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    double var14 = var2.nextCauchy(1.3995975989718865d, 2456.934613457899d);
    double var17 = var2.nextGaussian(0.0d, 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-853.0935538935793d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 17.308134617107928d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var9 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var10 = new double[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var10);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    double[] var16 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var17 = new double[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var17);
    double[][] var19 = new double[][] { var16};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var10, var12, var19);
    double[] var24 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var25 = new double[] { };
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
    double[] var31 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var32 = new double[] { };
    boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var32);
    double[][] var34 = new double[][] { var31};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var25, var27, var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var10, var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var10);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     double var1 = var0.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1.4797286049067677d));
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-1978339594), 55901590);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var32 = new int[] { 0, 100, 1};
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
    int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var35 = org.apache.commons.math3.util.MathArrays.distance1(var8, var27);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    int var6 = var2.nextInt(225475469);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var7.nextSecureLong(10L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 63455071);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 91, (-1667859135));
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1667859135));
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10L, (java.lang.Number)0.19048333f, (java.lang.Number)1.0f);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

//  public void test76() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
//
//
//    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//    double[] var4 = new double[] { };
//    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
//    double[] var11 = new double[] { };
//    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
//    double[][] var13 = new double[][] { var10};
//    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
//    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
//    double[] var19 = new double[] { };
//    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
//    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
//    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
//    double[] var26 = new double[] { };
//    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
//    double[][] var28 = new double[][] { var25};
//    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
//    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var19);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 225475469);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var3);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var4);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var10);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var11);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var12 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var13);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var18);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var19);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var20 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var25);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var26);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var27 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var28);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var30);
//
//  }
//
  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 4418713979230659041L+ "'", var5.equals(4418713979230659041L));

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-571311543), 99);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var4.nextLong(1L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextInt((-955090935), (-1816989844));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1232268348);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    int[] var24 = new int[] { 0};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var4.nextPoisson((-853.0935538935793d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var4.nextSample(var7, 1741975207);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var4.nextUniform(8.379633310485001d, (-4.813652559906312d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var4.nextHypergeometric(91, 445938823, 225475469);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var4.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     float var3 = var1.nextFloat();
//     java.util.List var4 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var5 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var4);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1, (-401038879));
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure();
    var0.reSeedSecure(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)", "org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     double var7 = var0.nextUniform(0.0d, 73.45997103732067d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 225,475,468 and 225,475,469 are not strictly increasing (0 >= 100)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8.934976382845432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 69.856757914134d);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(73.45997103732067d, 1.0d, 23.95389662180223d, 11.656091933465596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 352.6687922257784d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var4.nextZipf(0, 10.327401159520946d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var4.nextPascal(445938823, 2.3189641425486904d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    double var14 = var2.nextCauchy(1.3995975989718865d, 2456.934613457899d);
    java.lang.String var16 = var2.nextHexString(99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-853.0935538935793d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "e00e09a64d73f8aa3868e7f7077c4d13c22e53b804c5f50c9ed892c7f22b41ea56dec226225195eeb21b5325a63c356b8cc"+ "'", var16.equals("e00e09a64d73f8aa3868e7f7077c4d13c22e53b804c5f50c9ed892c7f22b41ea56dec226225195eeb21b5325a63c356b8cc"));

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var11);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var23 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var15, var22);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(2.913539924093275d, (-853.0935538935793d), 0.4091400389977526d, 0.08971084836383868d, 10.327401159520946d, (-1.0d), 0.0d, 3.866719511476555d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-2495.812825115084d));

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-2102199606), (-1));

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.nextUniform(1.7965218799149243d, 0.9967298592597413d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(10L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var4.nextPascal(280165598, 11.656091933465596d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var8 = var4.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Comparable[] var4 = new java.lang.Comparable[] { (short)1};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
//     boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, true);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)23.95389662180223d, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var9);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1978339594));

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var4 = var0.nextBeta(32.36871072544811d, 2.913539924093275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9295883561064747d);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var4 = var0.nextF(1.7965218799149243d, 5.271764897745934d);
//     int var7 = var0.nextSecureInt(91, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt(1232268348, 104097891);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.810526483946799d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 99);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 862908985188605553L);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextGaussian(0.3098593374527597d, (-0.08244612118583806d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
//     org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
//     int var6 = var2.nextInt(225475469);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
//     double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var12 = new double[] { };
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
//     double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var19 = new double[] { };
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
//     double[][] var21 = new double[][] { var18};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var14, var21);
//     double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var27 = new double[] { };
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
//     double[] var33 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var34 = new double[] { };
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var34);
//     double[][] var36 = new double[][] { var33};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var29, var36);
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 55901590);
//     double[] var41 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var42 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var38, var41);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 59, (-430674889));
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.3189641425486904d, (java.lang.Number)0.0d, (java.lang.Number)0.0d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var3 = var0.nextPermutation(10, 1232268348);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.2149917709512965d, (java.lang.Number)(-1978339594), 100);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextUniform(2456.934613457899d, 1.036975522396707d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 15.82392485077255d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-15.662391606690077d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 102.02892835116627d);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var4 = new double[] { };
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var11 = new double[] { };
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
//     double[][] var13 = new double[][] { var10};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
//     double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var19 = new double[] { };
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
//     double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var26 = new double[] { };
//     boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
//     double[][] var28 = new double[][] { var25};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var19);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 55901590);
//     double[] var33 = null;
//     double[] var37 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var38 = new double[] { };
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var38);
//     boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var33, var37);
//     double var41 = org.apache.commons.math3.util.MathArrays.linearCombination(var30, var33);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.4491217021290816d, (java.lang.Number)0, false);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var10);
//     java.lang.Object var12 = var10.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1223526183));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-1223526183)+ "'", var6.equals((-1223526183)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    java.lang.Number var4 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-430674889)+ "'", var4.equals((-430674889)));

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    int var6 = var2.nextInt(225475469);
    int var7 = var2.nextInt();
    double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var12 = new double[] { };
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double[][] var21 = new double[][] { var18};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var14, var21);
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    double[] var33 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var34 = new double[] { };
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var34);
    double[][] var36 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var29, var36);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 55901590);
    double[] var44 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var45 = new double[] { };
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var45);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    double[][] var54 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var45, var47, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var45);
    double var57 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var58 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var40, var56);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 63455071);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-401038879));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(3.8744448346390348d, 11.656091933465596d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var2.nextSample(var11, 0);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var7.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var8, false);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var8, true);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     int[] var4 = new int[] { };
//     var1.setSeed(var4);
//     int[] var8 = new int[] { 1, 10};
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//     int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var14 = var12.nextInt(1);
//     int[] var15 = new int[] { };
//     var12.setSeed(var15);
//     int[] var20 = new int[] { 0, 100, 1};
//     int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
//     int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var26 = var24.nextInt(1);
//     int[] var27 = new int[] { };
//     var24.setSeed(var27);
//     int[] var32 = new int[] { 0, 100, 1};
//     int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
//     int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
//     int[] var35 = null;
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var32, var35);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)55901590, (java.lang.Number)104097891, true);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var4.nextSecureInt(716369212, 716369212);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    double[] var3 = new double[] { 1.0d, 10.0d, 0.0d};
    double[] var7 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var8 = new double[] { };
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var8);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = org.apache.commons.math3.util.MathArrays.linearCombination(var3, var8);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 4418713979230659041L+ "'", var6.equals(4418713979230659041L));

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     int[] var4 = new int[] { };
//     var1.setSeed(var4);
//     int[] var6 = null;
//     int var7 = org.apache.commons.math3.util.MathArrays.distance1(var4, var6);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var11 = var9.nextInt(1);
//     int[] var12 = new int[] { };
//     var9.setSeed(var12);
//     int[] var16 = new int[] { 1, 10};
//     org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
//     int var18 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
//     int var19 = org.apache.commons.math3.util.MathArrays.distance1(var6, var16);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     org.apache.commons.math3.distribution.RealDistribution var13 = null;
//     double var14 = var4.nextInversionDeviate(var13);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = var0.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.913539924093275d);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(8.027560136941847d, 4.917623451873656d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var2.nextInt(63455071, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.88774723495381d);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var9 = var4.nextSecureHexString((-86705920));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var4.nextSample(var11, 0);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var4.nextBinomial(225475469, 2.913539924093275d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.4091400389977526d, (-11.001814281555863d), 0.0d, (-4.813652559906312d), 0.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-4.501282724201797d));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.19048333f);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setSecureAlgorithm("", "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [0.19, 1] range");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.1399625244915785d);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(11.656091933465596d, 32.36871072544811d, 0.3098593374527597d, (-2495.812825115084d), 13.879672895408403d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-396.0582404126832d));

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextGaussian(10.327401159520946d, 26.19989450026949d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var4.nextBinomial((-2102199606), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-14.785261441778996d));
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = org.apache.commons.math3.util.MathArrays.checkOrder(var4, var6, false, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var4.nextSample(var10, 0);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var4.nextLong(7258068567783673378L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = var22.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var23, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var27 = org.apache.commons.math3.util.MathArrays.isMonotonic(var4, var23, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeedSecure();
//     var2.reSeedSecure(10L);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var2.nextSample(var10, 0);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     int[] var4 = new int[] { };
//     var1.setSeed(var4);
//     int[] var6 = null;
//     int var7 = org.apache.commons.math3.util.MathArrays.distance1(var4, var6);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var6);
//     java.util.List var9 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var10 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var8, var9);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    java.lang.Object var5 = var4.getSecond();
    java.lang.Object var6 = var4.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 'a'+ "'", var6.equals('a'));

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(10.327401159520946d, 10.327401159520946d, 10.327401159520946d, 10.0d, 3.8744448346390348d, 0.0d, 0.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 209.92922630488403d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)0);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var4.nextPascal((-1816989844), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextInt(445938823, 1232268348);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.nextGaussian(5.271764897745934d, (-23.657839919386703d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1158845504);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextWeibull((-23.657839919386703d), (-853.0935538935793d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0031138841114524d);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var4.nextBinomial((-1816989844), (-853.0935538935793d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(3.8744448346390348d, 11.656091933465596d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var2.nextGamma(102.09948570917526d, (-396.0582404126832d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10.948992916572163d);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextSecureInt(1741975207, 716369212);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     java.lang.Object var10 = var5.getValue();
//     java.lang.Object var11 = var5.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1815146088);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 1815146088+ "'", var6.equals(1815146088));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    double[] var1 = new double[] { 10.0d};
    double var2 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var6 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var7 = new double[] { };
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    double[] var13 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var14 = new double[] { };
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var13, var14);
    double[][] var16 = new double[][] { var13};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var7, var9, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = org.apache.commons.math3.util.MathArrays.distance(var1, var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.IntegerDistribution var7 = null;
//     int var8 = var4.nextInversionDeviate(var7);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    var1.clear();
    double[] var6 = new double[] { 100.0d, 10.0d, 100.0d};
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    double[] var17 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var18 = new double[] { };
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var18);
    double[][] var20 = new double[][] { var17};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var11, var13, var20);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var23 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var6, var11);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    long[] var7 = null;
    long[][] var8 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var8);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextLong(12L, (-4523942956662907304L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7723057079587281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.3612724613476421d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 101.55848504757653d);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1854640921));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGaussian(5.271764897745934d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.019062259212925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-37.507196801236915d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 98.50967583804561d);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1775042804), (-571311543));

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextGaussian(10.327401159520946d, 26.19989450026949d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var4.nextZipf((-86705920), 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 21.43212777588726d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    double var14 = var2.nextCauchy(1.3995975989718865d, 2456.934613457899d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var17 = var2.nextPermutation(1479867090, 1232268348);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-853.0935538935793d));

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var15, var19);
    double[][] var23 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var23);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var26 = null;
    double[] var30 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var31 = new double[] { };
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var26, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var34 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var30);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    long var9 = var4.nextLong(1L, 70L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var4.nextHexString((-1667859135));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35L);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var4.nextInt(104097891, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var4.nextInt(1479867090, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1232268348, (java.lang.Number)1.0f, true);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextLong(862908985188605553L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    var1.setSeed(1232268348);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(100L);
    int var11 = var9.nextInt(1);
    int[] var12 = new int[] { };
    var9.setSeed(var12);
    int[] var16 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    var1.setSeed(var12);
    long var20 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 4812634305967451571L);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextGaussian(10.327401159520946d, 26.19989450026949d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setSecureAlgorithm("hi!", "e00e09a64d73f8aa3868e7f7077c4d13c22e53b804c5f50c9ed892c7f22b41ea56dec226225195eeb21b5325a63c356b8cc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-23.756839919641102d));
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
//     double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var12 = new double[] { };
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var7, var14);
//     double[] var16 = null;
//     double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var21 = new double[] { };
//     boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
//     boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var16, var20);
//     double[][] var24 = new double[][] { var20};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var24);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var5);
//     double var27 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var5);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    boolean var4 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1L, (java.lang.Number)722500763, (java.lang.Number)59);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
//     double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var12 = new double[] { };
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
//     double[][] var14 = new double[][] { var11};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var7, var14);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var5);
//     double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var21 = new double[] { };
//     boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
//     double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var28 = new double[] { };
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
//     double[][] var30 = new double[][] { var27};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var23, var30);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var21);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var5, var21);
//     boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var5);
//     double[] var38 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var39 = new double[] { };
//     boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var39);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
//     double[] var45 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var46 = new double[] { };
//     boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var45, var46);
//     double[][] var48 = new double[][] { var45};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var39, var41, var48);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var39);
//     double[] var54 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var55 = new double[] { };
//     boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var55);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var57 = null;
//     double[] var61 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var62 = new double[] { };
//     boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var62);
//     double[][] var64 = new double[][] { var61};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var55, var57, var64);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var55);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var55);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var55);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var4 = var2.nextInt(1);
//     int[] var5 = new int[] { };
//     var2.setSeed(var5);
//     int[] var7 = null;
//     int var8 = org.apache.commons.math3.util.MathArrays.distance1(var5, var7);
//     int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var7);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(2.913539924093275d, 13.879672895408403d, 3.866719511476555d, 26.19989450026949d, 0.0d, (-23.657839919386703d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 141.746624376947d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var4.nextBeta(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(209.92922630488403d, (-1.4797286049067677d), (-0.08244612118583806d), 209.92922630488403d, 0.3098593374527597d, 2456.934613457899d, 3.3765767764299945d, 141.746624376947d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 911.976359897697d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    int var6 = var2.nextInt(225475469);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var7.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 63455071);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setSecureAlgorithm("9e7fb29970", "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    long[] var6 = null;
    long[][] var7 = new long[][] { var6};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var7);
    int var12 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1232268348);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextCauchy(1.0d, 100.96201588326613d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSecureAlgorithm("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [0.19, 1] range", "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-86.03939096591209d));

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "e00e09a64d73f8aa3868e7f7077c4d13c22e53b804c5f50c9ed892c7f22b41ea56dec226225195eeb21b5325a63c356b8cc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.169293996633155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-3.4319912929474614d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 100.5140253257657d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4.838038993570925d);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextCauchy(1.7965218799149243d, 5.271764897745934d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var12 = var2.nextHexString(941025974);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.958402655780544d));
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     var0.setSeed(4418713979230659041L);
//     var0.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-825071061));
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var4.nextZipf(1068662605, (-4.501282724201797d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 16L);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextSecureHexString((-260641056));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.439697798349456d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-23.640844484810035d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 103.49333325835423d);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var13 = var0.nextGaussian(352.6687922257784d, 0.05190356240941041d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.03709264688173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1.1012004570294223d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 99.97081874303055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.4808388048950236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 352.7369979895132d);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.4091400389977526d, 8.379633310485001d, 0.0d, 911.976359897697d, 0.4491217021290816d, 3.866719511476555d, (-1.4797286049067677d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 403.86667959045457d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var6 = null;
    int var7 = org.apache.commons.math3.util.MathArrays.distance1(var4, var6);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var6);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    double[][] var22 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var15, var22);
    double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var28 = new double[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var28);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    double[] var46 = null;
    double[] var50 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var51 = new double[] { };
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var51);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var46, var50);
    double[][] var54 = new double[][] { var50};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var54);
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var57 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var8, var28, var35);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextWeibull(10.327401159520946d, (-86.03939096591209d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 10.394946652629386d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-4.638054028849606d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 102.0433945302102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.0206291197906747d);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    long var9 = var4.nextLong(1L, 70L);
    double var11 = var4.nextT(209.92922630488403d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.1176853562419486d);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     int var6 = var0.nextPascal(100, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextLong(7258068567783673378L, 4418713979230659041L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9873821426958239d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, (-4.813652559906312d));
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     double var17 = var4.nextT(100.46448232710429d);
//     org.apache.commons.math3.distribution.IntegerDistribution var18 = null;
//     int var19 = var4.nextInversionDeviate(var18);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextSecureInt((-260641056), (-1816989844));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, (-1816989844));
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1816989844));

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     int var2 = var0.nextInt();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 295071075);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1180133107);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var4.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-355.06154021346896d));
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextF((-1.0d), (-86.03939096591209d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c();
//     int var2 = var1.nextInt();
//     long[] var3 = null;
//     long[][] var4 = new long[][] { var3};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var2, (java.lang.Object)var4);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var4);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1339451429);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextInt(445938823, 1232268348);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var10 = var4.nextPermutation(295071075, (-825071061));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1158845504);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextSecureInt(1045626652, 104097891);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0094898224362703d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var4.nextHypergeometric((-1), 63455071, (-852432388));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-825071061), (java.lang.Number)100.46448232710429d, false);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var4.nextSecureHexString((-86705920));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var4.nextZipf((-825071061), 3.742940940679912d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 56.60597730193911d);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (byte)10};
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setSecureAlgorithm("9e7fb29970", "e00e09a64d73f8aa3868e7f7077c4d13c22e53b804c5f50c9ed892c7f22b41ea56dec226225195eeb21b5325a63c356b8cc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-40.880349563922294d));
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)749227529, (java.lang.Number)(-852432388), true);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextF(97.80131830602635d, 73.45997103732067d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("5e7cb2ff82", "7e6950e144");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3322362569698891d);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double var2 = org.apache.commons.math3.util.MathArrays.distance(var0, var1);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var4.nextF(2.3189641425486904d, (-0.08244612118583806d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 295071075, (-1667859135));

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(byte)(-1));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Comparable[] var6 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var7, true);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)23.95389662180223d, (java.lang.Object[])var6);
    var1.addSuppressed((java.lang.Throwable)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextSecureInt(0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 13.820845330242161d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 68L);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    double var6 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.1538145516608364d));

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var11 = new double[] { };
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
//     double[] var17 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var18 = new double[] { };
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var18);
//     double[][] var20 = new double[][] { var17};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var11, var13, var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
//     double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var27 = new double[] { };
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
//     double[] var33 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var34 = new double[] { };
//     boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var34);
//     double[][] var36 = new double[][] { var33};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var29, var36);
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var11, var27);
//     double[] var39 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var5, var11);
//     double var40 = org.apache.commons.math3.util.MathArrays.distance(var0, var5);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    long var5 = var2.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4418713979230659041L);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.apache.commons.math3.util.Pair var0 = null;
//     org.apache.commons.math3.util.Pair var1 = new org.apache.commons.math3.util.Pair(var0);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)32.36871072544811d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var9 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var10 = new double[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var10);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    double[] var16 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var17 = new double[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var17);
    double[][] var19 = new double[][] { var16};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var10, var12, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    double[] var32 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var33 = new double[] { };
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var33);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var28, var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var10, var26);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var4, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var38);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8.027560136941847d);
    boolean var3 = var2.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    boolean var5 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     org.apache.commons.math3.distribution.RealDistribution var8 = null;
//     double var9 = var4.nextInversionDeviate(var8);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    long var9 = var4.nextLong(1L, 70L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var4.nextGamma(99.1282825505761d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35L);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var11);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var34 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var35 = new double[] { };
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var41 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var42 = new double[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var42);
    double[][] var44 = new double[][] { var41};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var37, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var35);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var46);
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)7.251598159864589d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    float var6 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.6501708f);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var3 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.327000036267693d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(63455071, (-1978339594));
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1978339594), (java.lang.Object)(-1978339594));
    java.lang.Object var5 = var4.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1978339594)+ "'", var5.equals((-1978339594)));

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var4.nextSample(var10, (-852432388));
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var32 = new int[] { 0, 100, 1};
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(100L);
    int var38 = var36.nextInt(1);
    int[] var39 = new int[] { };
    var36.setSeed(var39);
    int[] var43 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(var43);
    int var45 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
    int[] var49 = new int[] { (-1), 100, 100};
    double var50 = org.apache.commons.math3.util.MathArrays.distance(var39, var49);
    int var51 = org.apache.commons.math3.util.MathArrays.distance1(var20, var49);
    org.apache.commons.math3.random.Well19937c var52 = new org.apache.commons.math3.random.Well19937c(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var54 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1339451429);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 100);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)35L, (java.lang.Number)0.0f, (java.lang.Number)(-955090935));
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0f+ "'", var5.equals(0.0f));

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long[] var1 = null;
//     long[][] var2 = new long[][] { var1};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
//     org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, (java.lang.Object)var2);
//     long var6 = var0.nextPoisson(1.6973523005858913d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2L);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(1232268348);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-579798130), var1);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var7 = var4.nextPermutation((-472844068), 99);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    double var17 = var4.nextT(100.46448232710429d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = var4.nextInt((-134845391), (-260641056));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-0.8968620151317581d));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    double var17 = var4.nextT(100.46448232710429d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var19 = var4.nextPoisson((-29.002341201890335d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-0.8968620151317581d));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var18 = var4.nextLong(4418713979230659041L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5127948165466234d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    double var12 = var2.nextGamma(1.4808388048950236d, 5.279378583866268d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var2.nextUniform(11.656091933465596d, 1.4808388048950236d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 11.13208948913201d);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     float var2 = var1.nextFloat();
//     boolean var3 = var1.nextBoolean();
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var7 = var5.nextInt(1);
//     int[] var8 = new int[] { };
//     var5.setSeed(var8);
//     int[] var12 = new int[] { 1, 10};
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     int var14 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var18 = var16.nextInt(1);
//     int[] var19 = new int[] { };
//     var16.setSeed(var19);
//     int[] var24 = new int[] { 0, 100, 1};
//     int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var24);
//     int var26 = org.apache.commons.math3.util.MathArrays.distance1(var12, var24);
//     var1.setSeed(var24);
//     byte[] var28 = null;
//     var1.nextBytes(var28);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    double var17 = var4.nextT(100.46448232710429d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var20 = var4.nextPermutation(1339451429, (-1699419680));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-0.8968620151317581d));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var17 = org.apache.commons.math3.util.MathArrays.normalizeArray(var4, 11.13208948913201d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(5.271764897745934d, (-396.0582404126832d), 7.251598159864589d, 209.92922630488403d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-565.6035380963093d));

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    int[] var14 = new int[] { (-1), 100, 100};
    double var15 = org.apache.commons.math3.util.MathArrays.distance(var4, var14);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(100L);
    int var19 = var17.nextInt(1);
    int[] var20 = new int[] { };
    var17.setSeed(var20);
    int[] var24 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
    int var26 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var20);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var3.nextUniform(0.0d, 100.0d, false);
    var3.reSeedSecure();
    var3.reSeedSecure(10L);
    var3.reSeedSecure(70L);
    java.lang.Object[] var13 = new java.lang.Object[] { var3};
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.9346068085718677d, (java.lang.Number)(short)100, (java.lang.Number)0.4091400389977526d);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getLo();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     long[] var9 = null;
//     long[][] var10 = new long[][] { var9};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, (java.lang.Object[])var10);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var4 = new double[] { };
//     boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
//     double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var11 = new double[] { };
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
//     double[][] var13 = new double[][] { var10};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
//     double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var20 = new double[] { };
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
//     double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var27 = new double[] { };
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
//     double[][] var29 = new double[][] { var26};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var20);
//     double[][] var32 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var32);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)90.33170045287306d, (java.lang.Number)0.05190356240941041d, (java.lang.Number)32.36871072544811d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var4.nextChiSquare((-853.0935538935793d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextInt(445938823, 1232268348);
    double var10 = var4.nextUniform(0.7724109753531756d, 0.9967298592597413d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1158845504);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.8444156216806316d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var4.nextHexString((-86705920));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.015854286399873473d, 73.45997103732067d, 0.1176853562419486d, 100.14688685347892d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12.950477475625878d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    double var7 = var4.nextChiSquare(17.308134617107928d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var4.nextSecureInt(941025974, (-134845391));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.773005865746882d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)99.97081874303055d, (java.lang.Number)12.098177515297595d, (-1219036332));

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-134845391));
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var4.nextGamma(3.8744448346390348d, (-4.501282724201797d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextGamma(1.036975522396707d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(2456.934613457899d, (-23.657839919386703d), 99.97081874303055d, 23.95389662180223d, 0.0d, 11.656091933465596d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-55731.07512021974d));

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    long var4 = var1.nextLong();
    byte[] var7 = new byte[] { (byte)1, (byte)1};
    var1.nextBytes(var7);
    boolean var9 = var1.nextBoolean();
    int var10 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1946542504));

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     var4.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var4.nextWeibull((-86.03939096591209d), 141.746624376947d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.14855751401637957d);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.9841284616200225d), (java.lang.Number)(short)100, false);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     double var13 = var4.nextGaussian(19.42595685892877d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var4.nextSecureHexString((-1477247604));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 32.99676462441166d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19.5543750644504d);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)5L);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)0, 225475469);
    java.lang.Number var4 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, var5, false);
    var3.addSuppressed((java.lang.Throwable)var7);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var4.nextUniform(0.9967298592597413d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     long var4 = var1.nextLong();
//     byte[] var7 = new byte[] { (byte)1, (byte)1};
//     var1.nextBytes(var7);
//     boolean var9 = var1.nextBoolean();
//     java.util.List var10 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var11 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var14 = var0.nextUniform(11.656091933465596d, 102.09948570917526d, true);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextF(19.42595685892877d, (-1.1012004570294223d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.9045267986969865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-42.85493991049d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 101.73241692138177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.5302194684214405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 84.47612585324094d);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     double var8 = var0.nextBeta(209.92922630488403d, 0.5127948165466234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.117202351697582d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 65L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9985657395524848d);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var4.nextSecureLong(862908985188605553L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var4.nextInversionDeviate(var10);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(141.746624376947d, 100.14688685347892d, 5.583966082835649d, 6.117202351697582d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 14229.64140379441d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextBeta(193.69455105973202d, 911.976359897697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.18077375117531247d);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(2456.934613457899d, 0.0d, 3.8744448346390348d, (-853.0935538935793d), 4.359252164571766d, 7.251598159864589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-3273.652368371841d));

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    long var11 = var2.nextPoisson(3.0485679790325757d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2L);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    long var9 = var4.nextLong(1L, 70L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var4.nextSecureInt(0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35L);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     int[] var4 = new int[] { };
//     var1.setSeed(var4);
//     int[] var6 = null;
//     int var7 = org.apache.commons.math3.util.MathArrays.distance1(var4, var6);
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var6);
//     int var10 = var8.nextInt(280165598);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 85348210);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextZipf((-401038879), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8.802624466856825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-37.84446499073531d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 103.17809056289964d);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var1, (java.lang.Number)8.027560136941847d);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMin();
    var0.addSuppressed((java.lang.Throwable)var3);
    java.lang.Number var7 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0+ "'", var5.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0+ "'", var7.equals(0));

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextBeta(10.0d, (-4.813652559906312d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     int var13 = var0.nextBinomial(445938823, 0.5127948165466234d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial(1815146088, (-2495.812825115084d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.587786192075866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.9342468041887959d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 100.8748649966294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 228667646);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var17 = org.apache.commons.math3.util.MathArrays.normalizeArray(var4, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    boolean var3 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(100L);
    int var7 = var5.nextInt(1);
    int[] var8 = new int[] { };
    var5.setSeed(var8);
    int[] var12 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    int var14 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(100L);
    int var18 = var16.nextInt(1);
    int[] var19 = new int[] { };
    var16.setSeed(var19);
    int[] var24 = new int[] { 0, 100, 1};
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var24);
    int var26 = org.apache.commons.math3.util.MathArrays.distance1(var12, var24);
    var1.setSeed(var24);
    int[] var28 = new int[] { };
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(100L);
    int var32 = var30.nextInt(1);
    int[] var33 = new int[] { };
    var30.setSeed(var33);
    int[] var38 = new int[] { 0, 100, 1};
    int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance(var28, var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var41 = org.apache.commons.math3.util.MathArrays.distance1(var24, var28);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    int var6 = var2.nextInt(225475469);
    int var7 = var2.nextInt();
    var2.clear();
    var2.setSeed(5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 63455071);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-401038879));

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0L, (java.lang.Number)(-430674889), 1232268348);
    int var4 = var3.getIndex();
    int var5 = var3.getIndex();
    int var6 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1232268348);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1232268348);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1232268348);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    int var13 = var4.nextInt((-260641056), 445938823);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var17 = var4.nextPermutation((-1854505007), 225475469);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 264518552);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     long var10 = var0.nextLong(862908985188605553L, 3081282935693573632L);
//     double var13 = var0.nextUniform(1.6797400806850826d, 11.292796076075014d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform(6.698301288652692d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "ec68f0dc4b"+ "'", var3.equals("ec68f0dc4b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2827418827209859072L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.463264200122815d);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     double var8 = var0.nextBeta(17.308134617107928d, 0.1176853562419486d);
//     int var12 = var0.nextHypergeometric(1339451429, 59, 200911654);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.850654457304433d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 78L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9999999987778915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100L);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.9346068085718677d, (java.lang.Number)(short)100, (java.lang.Number)0.4091400389977526d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)100+ "'", var5.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.4091400389977526d+ "'", var7.equals(0.4091400389977526d));

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextHypergeometric((-1978339594), 0, (-825071061));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var32 = org.apache.commons.math3.util.MathArrays.normalizeArray(var4, 0.08971084836383868d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    double[] var0 = null;
    double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var5 = new double[] { };
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var4, (-852432388));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1477247604), 0);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.08971084836383868d, (java.lang.Number)4812634305967451571L, true);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)63455071);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(3.866719511476555d, 193.69455105973202d, 0.0d, 3.866719511476555d, 4.269328604906451d, 1.4808388048950236d, 5.271764897745934d, 24.92858751525751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 886.7023399316736d);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    java.lang.Object var5 = var4.getValue();
    java.lang.Object var6 = var4.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 'a'+ "'", var6.equals('a'));

  }

//  public void test312() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
//
//
//    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//    int var3 = var1.nextInt(1);
//    int[] var4 = new int[] { };
//    var1.setSeed(var4);
//    int[] var8 = new int[] { 1, 10};
//    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
//    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
//    int var14 = var12.nextInt(1);
//    int[] var15 = new int[] { };
//    var12.setSeed(var15);
//    int[] var20 = new int[] { 0, 100, 1};
//    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
//    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
//    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
//    int var26 = var24.nextInt(1);
//    int[] var27 = new int[] { };
//    var24.setSeed(var27);
//    int[] var32 = new int[] { 0, 100, 1};
//    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
//    int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
//    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(100L);
//    int var38 = var36.nextInt(1);
//    int[] var39 = new int[] { };
//    var36.setSeed(var39);
//    int[] var43 = new int[] { 1, 10};
//    org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(var43);
//    int var45 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
//    int[] var49 = new int[] { (-1), 100, 100};
//    double var50 = org.apache.commons.math3.util.MathArrays.distance(var39, var49);
//    int var51 = org.apache.commons.math3.util.MathArrays.distance1(var20, var49);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 527625194);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var3 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var4);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var8);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var10 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var14 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var15);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var20);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var21 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var22 == 91);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var26 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var27);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var32);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var33 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var34 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var38 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var39);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var43);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var45 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var49);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var50 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var51 == 100);
//
//  }
//
  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextInt(445938823, 1232268348);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var4.nextHypergeometric(55901590, (-1477247604), (-2102199606));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.23953891f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1158845504);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
//     int var4 = var3.nextInt();
//     long[] var5 = null;
//     long[][] var6 = new long[][] { var5};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1), (java.lang.Object[])var6);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(6.03709264688173d, (-0.08244612118583806d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "a5ef74885a"+ "'", var3.equals("a5ef74885a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    float[] var0 = new float[] { };
    float[] var2 = new float[] { 0.0f};
    float[] var5 = new float[] { 100.0f, 100.0f};
    float[] var7 = new float[] { 100.0f};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var5, var7);
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var7);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)452229905, (java.lang.Number)0.049864014567367256d, (java.lang.Number)(-1775042804));

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(445938823, 1741975207);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextSecureLong(4812634305967451571L, 7L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1390365177);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var10 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(100L);
    int var16 = var14.nextInt(1);
    int[] var17 = new int[] { };
    var14.setSeed(var17);
    int[] var22 = new int[] { 0, 100, 1};
    int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distance1(var10, var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(100L);
    int var28 = var26.nextInt(1);
    int[] var29 = new int[] { };
    var26.setSeed(var29);
    int[] var34 = new int[] { 0, 100, 1};
    int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var34);
    int var36 = org.apache.commons.math3.util.MathArrays.distance1(var22, var34);
    org.apache.commons.math3.random.Well19937c var38 = new org.apache.commons.math3.random.Well19937c(100L);
    int var40 = var38.nextInt(1);
    int[] var41 = new int[] { };
    var38.setSeed(var41);
    int[] var45 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var46 = new org.apache.commons.math3.random.Well19937c(var45);
    int var47 = org.apache.commons.math3.util.MathArrays.distance1(var41, var45);
    int[] var51 = new int[] { (-1), 100, 100};
    double var52 = org.apache.commons.math3.util.MathArrays.distance(var41, var51);
    int var53 = org.apache.commons.math3.util.MathArrays.distance1(var22, var51);
    var1.setSeed(var22);
    boolean var55 = var1.nextBoolean();
    double var56 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.057868214927578876d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    double var7 = var4.nextChiSquare(17.308134617107928d);
    double var9 = var4.nextT(0.049864014567367256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.773005865746882d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.05636459668382493d));

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    var1.setSeed(1L);
    float var4 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.07277703f);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     double var12 = var4.nextCauchy(3.8744448346390348d, 0.016151381368146953d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var4.nextPermutation(1790344579, 487874150);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 19L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.877736389519879d);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextZipf((-571311543), 0.016151381368146953d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(8.773005865746882d, (-3273.652368371841d), 4.269328604906451d, 0.0d, (-55731.07512021974d), (-3273.652368371841d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.8241544628778622E8d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var20);
    java.lang.Comparable[] var36 = new java.lang.Comparable[] { 11.656091933465596d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = var40.getDirection();
    boolean var43 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var36, var41, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var45 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.15562109371395244d, (java.lang.Number)0.9967298592597413d, 1790344579, var41, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var20, var41, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(55901590, 0);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    boolean var3 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(100L);
    int var7 = var5.nextInt(1);
    int[] var8 = new int[] { };
    var5.setSeed(var8);
    int[] var12 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    int var14 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(100L);
    int var18 = var16.nextInt(1);
    int[] var19 = new int[] { };
    var16.setSeed(var19);
    int[] var24 = new int[] { 0, 100, 1};
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var24);
    int var26 = org.apache.commons.math3.util.MathArrays.distance1(var12, var24);
    var1.setSeed(var24);
    org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(var24);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 91);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var11 = var0.nextBeta(3.9346068085718677d, 4.359252164571766d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial((-134845391), 352.6687922257784d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6623387840122756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 27.79641563185496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 96.89507500454198d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6119542118504137d);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var4.nextPascal(0, (-4.813652559906312d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var20);
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var37);
    double[] var43 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var44 = new double[] { };
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var44);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var37, var44);
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var44, var51);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var4, var55);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.15053642f, (java.lang.Number)(byte)(-1), false);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)209.92922630488403d, (java.lang.Number)2146598351, (java.lang.Number)0.15053642f);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 209.92922630488403d+ "'", var4.equals(209.92922630488403d));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(99.3294376204589d, 1.6797400806850826d, 0.017541421748480102d, (-853.0935538935793d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 151.8831637432365d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3081282935693573632L);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    long var9 = var4.nextLong(1L, 70L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var12 = var4.nextPermutation(1158845504, (-1946542504));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35L);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    double var12 = var2.nextGamma(1.4808388048950236d, 5.279378583866268d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var2.nextBinomial(0, 18.53376222628223d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 11.13208948913201d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var9 = var6.nextBeta(4.917623451873656d, 100.49939010820418d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var6.nextGaussian(25.606519169958414d, (-1.4797286049067677d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05190356240941041d);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-825071061), (-579798130));
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.08971084836383868d, (java.lang.Number)4812634305967451571L, true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var4.nextPermutation((-401038879), 1790344579);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7.158042691152743d);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
//     java.lang.String var2 = var1.toString();
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c();
//     int var9 = var8.nextInt();
//     long[] var10 = null;
//     long[][] var11 = new long[][] { var10};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
//     org.apache.commons.math3.util.Pair var13 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, (java.lang.Object)var11);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var11);
//     java.lang.Throwable[] var16 = var15.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var16);
//     var1.addSuppressed((java.lang.Throwable)var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1236725234);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(63455071, (-1978339594));
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
    org.apache.commons.math3.exception.DimensionMismatchException var6 = new org.apache.commons.math3.exception.DimensionMismatchException(63455071, (-1978339594));
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    var2.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var4 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     var0.reSeed((-1L));
//     double var13 = var0.nextGaussian(1.6797400806850826d, 911.976359897697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.5865133480106643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 31.067130348919022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 103.49740362234981d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 83.49391301487294d);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     var0.reSeed();
//     double var10 = var0.nextUniform(0.8683854052034767d, 8.012870143369822d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextZipf((-1946542504), 0.1176853562419486d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 17.320868889920856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 54L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7.530198033683427d);
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long[] var1 = null;
//     long[][] var2 = new long[][] { var1};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
//     org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, (java.lang.Object)var2);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextCauchy(1.0d, 100.96201588326613d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var4.nextPascal(1180133107, (-0.08244612118583806d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-86.03939096591209d));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    double[] var0 = null;
    double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var5 = new double[] { };
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var12 = new double[] { };
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    double[][] var14 = new double[][] { var11};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var7, var14);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var20);
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    double[] var33 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var34 = new double[] { };
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var34);
    double[][] var36 = new double[][] { var33};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var29, var36);
    double[] var38 = null;
    double[] var42 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var43 = new double[] { };
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var38, var42);
    double[][] var46 = new double[][] { var42};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var27, var46);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var46);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(3.0695121427802095d, 3.7501312412905117d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.19153321607781723d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10, (java.lang.Number)23.95389662180223d, false);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.9295883561064747d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair(var10);
//     java.lang.Object var12 = var11.getSecond();
//     float[] var16 = new float[] { 10.0f, 0.0f, 100.0f};
//     float[] var20 = new float[] { 1.0f, 100.0f, 100.0f};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var20);
//     boolean var22 = var11.equals((java.lang.Object)var20);
//     java.lang.Object var23 = var11.getFirst();
//     org.apache.commons.math3.util.Pair var24 = new org.apache.commons.math3.util.Pair(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1943075992);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 1943075992+ "'", var6.equals(1943075992));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + 1943075992+ "'", var23.equals(1943075992));
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var4.nextGamma(0.9999977358410781d, (-396.0582404126832d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.005348147503453d);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.6973523005858913d, (java.lang.Number)0, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0+ "'", var5.equals(0));

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     long var5 = var0.nextLong(10L, 78L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextF(0.0d, 11.292796076075014d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.254312096741846d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 32L);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    var4.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var4.nextSecureLong(872029271940837376L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)91);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)15);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.23953891f);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)32.36871072544811d, (java.lang.Number)1697424459525688832L, true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 32.36871072544811d+ "'", var5.equals(32.36871072544811d));

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    boolean var3 = var1.nextBoolean();
    int var5 = var1.nextInt(825523605);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 111145379);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c();
//     int var2 = var1.nextInt();
//     long[] var3 = null;
//     long[][] var4 = new long[][] { var3};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)var2, (java.lang.Object)var4);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 999324317);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = null;
    long[][] var2 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var2, (java.lang.Object)(-86705920));
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var4 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var4);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeedSecure(100L);
//     var4.reSeed(0L);
//     int var13 = var4.nextInt((-260641056), 445938823);
//     var4.reSeedSecure();
//     org.apache.commons.math3.distribution.RealDistribution var15 = null;
//     double var16 = var4.nextInversionDeviate(var15);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeedSecure(100L);
//     var4.reSeed(0L);
//     int var13 = var4.nextInt((-260641056), 445938823);
//     long var16 = var4.nextSecureLong(26L, 7258068567783673378L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var4.nextSecureInt(452229905, 59);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 264518552);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4588050027094913536L);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeedSecure();
    var2.reSeedSecure(10L);
    var2.reSeedSecure(70L);
    double var14 = var2.nextCauchy(1.3995975989718865d, 2456.934613457899d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var17 = var2.nextSecureLong(3200796353914668032L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-853.0935538935793d));

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var15, var19);
    double[][] var23 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var23);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var29 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var30 = new double[] { };
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var30);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    double[][] var39 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var32, var39);
    double[] var44 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var45 = new double[] { };
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var45);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    double[][] var54 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var45, var47, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var45);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var45);
    java.lang.Comparable[] var62 = new java.lang.Comparable[] { 11.656091933465596d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var66 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var67 = var66.getDirection();
    boolean var69 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var62, var67, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var71 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.15562109371395244d, (java.lang.Number)0.9967298592597413d, 1790344579, var67, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var57, var67, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1500349861), (java.lang.Number)59, false);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    double var9 = var2.nextUniform(0.0d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextPascal(452229905, 3.8439213970347454d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.9346068085718677d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure();
//     int var8 = var4.nextSecureInt((-1854640921), 527625194);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var4.nextSample(var9, 10);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     int var9 = var4.nextSecureInt((-1477247604), 749227529);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var4.nextZipf(0, 0.049864014567367256d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1077276555));
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSecureAlgorithm("c9f93270dd", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 225,475,468 and 225,475,469 are not strictly increasing (0 >= 100)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     int var18 = var4.nextZipf(59, 0.05190356240941041d);
//     long var20 = var4.nextPoisson(141.746624376947d);
//     double var22 = var4.nextChiSquare(1.6797400806850826d);
//     org.apache.commons.math3.distribution.RealDistribution var23 = null;
//     double var24 = var4.nextInversionDeviate(var23);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { 1L};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.0d, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextWeibull(3.8744448346390348d, 11.656091933465596d);
//     long var12 = var2.nextPoisson(0.1504224218416993d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var2.nextHypergeometric(1781983652, 1790344579, (-1854505007));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 11.278054986877786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.1176853562419486d, (-55731.07512021974d), 0.9985657395524848d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-55651.14224347731d));

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c();
//     int var11 = var10.nextInt();
//     long[] var12 = null;
//     long[][] var13 = new long[][] { var12};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
//     org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair((java.lang.Object)var11, (java.lang.Object)var13);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
//     org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var13);
//     java.lang.Throwable[] var18 = var17.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var19 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var18);
//     boolean var22 = var3.getBoundIsAllowed();
//     boolean var23 = var3.getBoundIsAllowed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1827962647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var4.nextInversionDeviate(var13);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1816989844), 722500763);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)2074555787, false);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.049864014567367256d, 99.97081874303055d, 0.022073983658682416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.206754219278758d);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     var4.reSeed();
//     long var13 = var4.nextLong(2L, 3200796353914668032L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var4.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.15729986341650276d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 831013230989314816L);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c();
//     int var3 = var2.nextInt();
//     long[] var4 = null;
//     long[][] var5 = new long[][] { var4};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)403.86667959045457d, (java.lang.Number)6.850654457304433d, 527625194);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 403.86667959045457d+ "'", var4.equals(403.86667959045457d));

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     double var13 = var4.nextGaussian(19.42595685892877d, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var4.nextPascal((-134845391), 4.917623451873656d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.6784383596760835d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21.388005082220662d);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     long var4 = var0.nextLong((-1L), 3081282935693573632L);
//     double var8 = var0.nextUniform(0.8444156216806316d, 1.542290759080808d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 1,232,268,347 and 1,232,268,348 are not strictly increasing (-430,674,889 >= 0)", "5e7cb2ff82");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 759341688487646976L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8917061504935858d);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-2102199606), 225475469);
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    double[] var26 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var27 = new double[] { };
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var27);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var22, var29);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var20);
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    double[] var43 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var44 = new double[] { };
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var44);
    double[][] var46 = new double[][] { var43};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var37, var39, var46);
    double[] var48 = null;
    double[] var52 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var53 = new double[] { };
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var48, var52);
    double[][] var56 = new double[][] { var52};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var37, var56);
    double[] var61 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var62 = new double[] { };
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var62);
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = null;
    double[] var68 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var69 = new double[] { };
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var69);
    double[][] var71 = new double[][] { var68};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var62, var64, var71);
    double[] var76 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var77 = new double[] { };
    boolean var78 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var76, var77);
    double var79 = org.apache.commons.math3.util.MathArrays.distanceInf(var62, var77);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var37, var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var81 = org.apache.commons.math3.util.MathArrays.linearCombination(var20, var80);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     long var9 = var4.nextLong(1L, 70L);
//     int var12 = var4.nextZipf(59, 4.269328604906451d);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var4.nextInversionDeviate(var13);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var3 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 312574995);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     double var12 = var4.nextCauchy(10.327401159520946d, 0.953266988202223d);
//     double var14 = var4.nextT(4.359252164571766d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var4.nextBinomial(0, 10.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 31L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11.392837480812473d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.46098604453009834d);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)'a', (java.lang.Object)var2);
    java.lang.Object var5 = var4.getKey();
    java.lang.Object var6 = var4.getSecond();
    java.lang.Object var7 = null;
    boolean var8 = var4.equals(var7);
    java.lang.Object var9 = var4.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 'a'+ "'", var5.equals('a'));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     long var10 = var0.nextLong(862908985188605553L, 3081282935693573632L);
//     long var13 = var0.nextLong(88L, 1697424459525688832L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextSecureInt(228667646, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "dff850eaa9"+ "'", var3.equals("dff850eaa9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2251866801019814912L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 296139473791017664L);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-430674889), (java.lang.Number)(-19.02928815170223d), (-1219036332));

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     int var9 = var4.nextSecureInt((-1477247604), 749227529);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var4.nextCauchy(0.9999977358410781d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-535267216));
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c();
//     int var11 = var10.nextInt();
//     long[] var12 = null;
//     long[][] var13 = new long[][] { var12};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
//     org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair((java.lang.Object)var11, (java.lang.Object)var13);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
//     org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var9, (java.lang.Object[])var13);
//     java.lang.Throwable[] var18 = var17.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var19 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var7, (java.lang.Object[])var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var18);
//     java.lang.Number var22 = var3.getMax();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1521029328));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + 4418713979230659041L+ "'", var22.equals(4418713979230659041L));
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt((-1298863262));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var4.nextZipf((-260641056), 5.279378583866268d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var15, var19);
    double[][] var23 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var23);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var29 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var30 = new double[] { };
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var30);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    double[][] var39 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var32, var39);
    double[] var44 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var45 = new double[] { };
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var45);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    double[][] var54 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var45, var47, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var45);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var45);
    java.lang.Comparable[] var59 = new java.lang.Comparable[] { 11.656091933465596d};
    org.apache.commons.math3.exception.NonMonotonicSequenceException var63 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var64 = var63.getDirection();
    boolean var66 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var59, var64, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var70 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = var70.getDirection();
    boolean var73 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var59, var71, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var76 = org.apache.commons.math3.util.MathArrays.checkOrder(var57, var71, false, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    double[][] var28 = new double[][] { var25};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var21, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var19);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 104097891, 85348210);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1161789910412373248L, (java.lang.Number)22.50273808498238d, false);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var4);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var11 = new int[] { 0, 100, 1};
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var11);
    var1.setSeed(var6);
    double var14 = var1.nextGaussian();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.8371016669875919d));

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextF(97.80131830602635d, 73.45997103732067d);
//     long var8 = var2.nextPoisson(1.7965218799149243d);
//     var2.reSeed();
//     var2.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.1250108292257317d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     long var9 = var4.nextPoisson(19.42595685892877d);
//     double var12 = var4.nextCauchy(3.8744448346390348d, 0.016151381368146953d);
//     var4.reSeedSecure(88L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setSecureAlgorithm("7e6950e144", "e00e09a64d73f8aa3868e7f7077c4d13c22e53b804c5f50c9ed892c7f22b41ea56dec226225195eeb21b5325a63c356b8cc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3.8847641669589095d);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     var0.reSeed();
//     double var10 = var0.nextUniform(0.8683854052034767d, 8.012870143369822d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextLong(2405083887710097920L, 72L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.810703594361428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 70L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.5581207326251372d);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(445938823, 1741975207);
//     long var5 = var0.nextPoisson(1.4808388048950236d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var0.nextPermutation(15, (-1521029328));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1131660252);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
// 
//   }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
//     double[] var11 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var12 = new double[] { };
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var12);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var12);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var16);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(55901590, 1781983652);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
//     int var19 = var4.nextHypergeometric(722500763, 91, 1);
//     org.apache.commons.math3.distribution.RealDistribution var20 = null;
//     double var21 = var4.nextInversionDeviate(var20);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextGamma(3.8744448346390348d, 10.0d);
//     double var5 = var0.nextExponential(141.746624376947d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextZipf((-134845391), 2.3189641425486904d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 23.387970125710794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 187.12311723082584d);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeedSecure(100L);
    var4.reSeed(0L);
    int var13 = var4.nextInt((-260641056), 445938823);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var4.nextBeta(0.0d, 3.8584457592882444d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 264518552);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     double var10 = var0.nextF(1.3995975989718865d, 1.542290759080808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "746dd4329f"+ "'", var3.equals("746dd4329f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7068623656369407d);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(100L);
    int var26 = var24.nextInt(1);
    int[] var27 = new int[] { };
    var24.setSeed(var27);
    int[] var32 = new int[] { 0, 100, 1};
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distance1(var20, var32);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(100L);
    int var38 = var36.nextInt(1);
    int[] var39 = new int[] { };
    var36.setSeed(var39);
    int[] var43 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(var43);
    int var45 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
    int[] var49 = new int[] { (-1), 100, 100};
    double var50 = org.apache.commons.math3.util.MathArrays.distance(var39, var49);
    int var51 = org.apache.commons.math3.util.MathArrays.distance1(var20, var49);
    org.apache.commons.math3.random.Well19937c var52 = new org.apache.commons.math3.random.Well19937c(var20);
    double var53 = var52.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == (-1.862699599714098d));

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    long var4 = var1.nextLong();
    byte[] var7 = new byte[] { (byte)1, (byte)1};
    var1.nextBytes(var7);
    long var9 = var1.nextLong();
    var1.setSeed(4812634305967451571L);
    double var12 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4523942956662907304L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5147835921413739d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    long var4 = var1.nextLong();
    byte[] var7 = new byte[] { (byte)1, (byte)1};
    var1.nextBytes(var7);
    var1.setSeed((-1177355880));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 862908985188605553L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextF(97.80131830602635d, 73.45997103732067d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var2.nextHypergeometric(1068662605, (-1923973809), 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8911168658729981d);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextBeta(3.9346068085718677d, 23.95389662180223d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.nextGamma(4.917623451873656d, (-23.657839919386703d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.049864014567367256d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-4.813652559906312d), (java.lang.Number)4418713979230659041L, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-4.813652559906312d)+ "'", var6.equals((-4.813652559906312d)));

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c();
//     int var3 = var2.nextInt();
//     long[] var4 = null;
//     long[][] var5 = new long[][] { var4};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var5);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1141446620));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { (byte)1};
    double[] var5 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var6 = new double[] { };
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var13);
    double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var21 = new double[] { };
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var28 = new double[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    double[][] var30 = new double[][] { var27};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var23, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var21);
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    double[] var43 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var44 = new double[] { };
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var44);
    double[][] var46 = new double[][] { var43};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var37, var39, var46);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var37);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var48);
    double[] var53 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var54 = new double[] { };
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var54);
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var48, var56);
    double[] var61 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var62 = new double[] { };
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var62);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var70 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = var70.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var73 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var71, false);
    boolean var75 = org.apache.commons.math3.util.MathArrays.isMonotonic(var61, var71, false);
    double[] var79 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var80 = new double[] { };
    boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var79, var80);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = null;
    double[] var86 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var87 = new double[] { };
    boolean var88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var86, var87);
    double[][] var89 = new double[][] { var86};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var80, var82, var89);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var48, var71, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var71, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(byte)(-1));
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 2146598351);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    float var2 = var1.nextFloat();
    var1.setSeed(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var1.nextInt((-1462141839));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { (-458435062)};
    double[] var5 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var6 = new double[] { };
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    double[] var12 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var13 = new double[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var13);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var13);
    double[] var20 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var21 = new double[] { };
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    double[] var27 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var28 = new double[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    double[][] var30 = new double[][] { var27};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var21, var23, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var21);
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    double[] var43 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var44 = new double[] { };
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var44);
    double[][] var46 = new double[][] { var43};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var37, var39, var46);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var21, var37);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var48);
    double[] var53 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var54 = new double[] { };
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var54);
    double var57 = org.apache.commons.math3.util.MathArrays.distance(var48, var56);
    double[] var61 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var62 = new double[] { };
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var62);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var70 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = var70.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var73 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var71, false);
    boolean var75 = org.apache.commons.math3.util.MathArrays.isMonotonic(var61, var71, false);
    double[] var79 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var80 = new double[] { };
    boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var79, var80);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = null;
    double[] var86 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var87 = new double[] { };
    boolean var88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var86, var87);
    double[][] var89 = new double[][] { var86};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var80, var82, var89);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var48, var71, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var71, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1978339594));
    java.lang.String var2 = var1.toString();
    java.lang.Number var3 = var1.getMin();
    boolean var4 = var1.getBoundIsAllowed();
    java.lang.Number var5 = var1.getArgument();
    java.lang.Number var6 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1978339594)+ "'", var5.equals((-1978339594)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0+ "'", var6.equals(0));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    long[] var0 = null;
    long[][] var1 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var1);
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)(-86705920));
    java.lang.Object var5 = var4.getKey();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var4.nextCauchy(193.69455105973202d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.031059655798400494d);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)90.43193939599433d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (byte)10};
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var3);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)11.656091933465596d, (java.lang.Number)(-0.08244612118583806d), false);
    var5.addSuppressed((java.lang.Throwable)var10);
    boolean var12 = var10.getBoundIsAllowed();
    java.lang.Number var13 = var10.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (-0.08244612118583806d)+ "'", var13.equals((-0.08244612118583806d)));

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     long var10 = var0.nextLong(862908985188605553L, 3081282935693573632L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextInt(527625194, (-1219036332));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "01fdd65059"+ "'", var3.equals("01fdd65059"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1826334639773021440L);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    int var18 = var4.nextZipf(59, 0.05190356240941041d);
    long var20 = var4.nextPoisson(141.746624376947d);
    double var22 = var4.nextChiSquare(1.6797400806850826d);
    double var24 = var4.nextT(1.036975522396707d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var28 = var4.nextUniform(1.4808388048950236d, (-4.813652559906312d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 166L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.6052934619394505d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-10.5184672894674d));

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     double var8 = var0.nextBeta(17.308134617107928d, 0.1176853562419486d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextSecureHexString((-825071061));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 16.15235809267286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 69L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9955864367281843d);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var14 = var0.nextUniform(11.656091933465596d, 102.09948570917526d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextPascal((-134845391), 3.7501312412905117d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4806298164687368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-16.169994328388622d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 99.73476910415354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.6112970636013655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 81.9047819341638d);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextSecureInt(1815146088, 1217592732);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var3 = var0.nextChiSquare(10.0d);
//     long var5 = var0.nextPoisson(73.45997103732067d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextHypergeometric(1045626652, 1180133107, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 14.617807534036091d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 84L);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1213169957));

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     double var15 = var4.nextCauchy(1.0d, 100.96201588326613d);
//     org.apache.commons.math3.distribution.RealDistribution var16 = null;
//     double var17 = var4.nextInversionDeviate(var16);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)10.24834333371038d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-1477247604), 0);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var15 = null;
    double[] var19 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var20 = new double[] { };
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var15, var19);
    double[][] var23 = new double[][] { var19};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var23);
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var29 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var30 = new double[] { };
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var30);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    double[] var36 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var37 = new double[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    double[][] var39 = new double[][] { var36};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var32, var39);
    double[] var44 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var45 = new double[] { };
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var45);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    double[] var51 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var52 = new double[] { };
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var52);
    double[][] var54 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var45, var47, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var45);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var45);
    double[] var58 = null;
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var57, var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    var1.setSeed(1232268348);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(100L);
    int var11 = var9.nextInt(1);
    int[] var12 = new int[] { };
    var9.setSeed(var12);
    int[] var16 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    var1.setSeed(var12);
    org.apache.commons.math3.random.RandomDataImpl var20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     double var4 = var0.nextF(1.7965218799149243d, 5.271764897745934d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextLong(579504999478877568L, 2L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.08724614873103914d);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)8.027560136941847d, (java.lang.Number)(short)100, true);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1161789910412373248L);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int[] var12 = new int[] { };
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(100L);
    int var16 = var14.nextInt(1);
    int[] var17 = new int[] { };
    var14.setSeed(var17);
    int[] var22 = new int[] { 0, 100, 1};
    int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var17, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var12, var22);
    double var25 = org.apache.commons.math3.util.MathArrays.distance(var11, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
    double var17 = var4.nextExponential(1.4636684439841448d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = var4.nextBinomial((-1854640921), 1.1250108292257317d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5127948165466234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.7429747933972144d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    int var15 = var4.nextInt(0, 59);
    int var18 = var4.nextZipf(59, 0.05190356240941041d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var20 = var4.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 11);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
    double var17 = var4.nextExponential(1.4636684439841448d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var4.nextUniform(24.92858751525751d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5127948165466234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.7429747933972144d);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     double var14 = var0.nextUniform(11.656091933465596d, 102.09948570917526d, true);
//     var0.reSeedSecure();
//     double var18 = var0.nextGaussian(24.87003775369207d, 0.5147835921413739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.8642377162259853d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 630.5577219319574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 89.8843325929254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.407139629739897d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 65.09175302980526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 24.34812647271368d);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     int var13 = var0.nextSecureInt((-1923973809), 1045626652);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.557320499621304d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.2033197805238967d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 100.7941743858271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.9986611519194435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-380348068));
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     var0.reSeedSecure(2405083887710097920L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.7352702461876515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-63.070338506413165d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 98.92117070511586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.2550942871493342d);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var9 = var4.nextExponential(0.2149917709512965d);
//     double var12 = var4.nextCauchy(911.976359897697d, 0.08928819504170851d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var4.nextSecureInt(0, (-472844068));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.007049350068696673d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 911.7983186038156d);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(byte)10);
//     boolean var3 = var2.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var2.nextUniform(0.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextBinomial(1827962647, 151.8831637432365d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 23.95389662180223d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var4.nextHypergeometric(2146598351, (-380348068), (-1500349861));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     int var6 = var0.nextPascal(100, 0.0d);
//     var0.reSeedSecure(4812634305967451571L);
//     double var11 = var0.nextBeta(2.7821939432840614d, 11.38364603395183d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9507047658344296d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.20410638552042384d);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextWeibull(23.95389662180223d, 1.0d);
//     int var6 = var0.nextPascal(100, 0.0d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0429625641369598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-430674889));
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.40734155824061874d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.6541685f);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.9346068085718677d, (java.lang.Number)(short)100, (java.lang.Number)0.4091400389977526d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    java.lang.Number var7 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)100+ "'", var5.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.4091400389977526d+ "'", var7.equals(0.4091400389977526d));

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.util.Pair var10 = new org.apache.commons.math3.util.Pair(var5);
//     java.lang.Object var11 = var10.getFirst();
//     boolean var13 = var10.equals((java.lang.Object)"e00e09a64d73f8aa3868e7f7077c4d13c22e53b804c5f50c9ed892c7f22b41ea56dec226225195eeb21b5325a63c356b8cc");
//     java.lang.Object var14 = var10.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-1072502360));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-1072502360)+ "'", var6.equals((-1072502360)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + (-1072502360)+ "'", var11.equals((-1072502360)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(100L);
    int var14 = var12.nextInt(1);
    int[] var15 = new int[] { };
    var12.setSeed(var15);
    int[] var20 = new int[] { 0, 100, 1};
    int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var20);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var8, var20);
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-942348126), 1781983652);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    double[] var6 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var7 = new double[] { };
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var7);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)10, (java.lang.Number)862908985188605553L, (-852432388));
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = var15.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)70L, (java.lang.Number)(-1.0d), 716369212, var16, false);
    boolean var20 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var16, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)72L, (java.lang.Number)12.098177515297595d, (-1667859135), var16, false);
    float[] var24 = new float[] { 0.0f};
    float[] var27 = new float[] { 100.0f, 100.0f};
    float[] var29 = new float[] { 100.0f};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var27, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var29);
    float[] var34 = new float[] { 100.0f, 100.0f};
    float[] var36 = new float[] { 100.0f};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var34, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var24, var34);
    org.apache.commons.math3.util.Pair var39 = new org.apache.commons.math3.util.Pair((java.lang.Object)false, (java.lang.Object)var38);
    java.lang.Object var40 = var39.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + false+ "'", var40.equals(false));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(100L);
    int var5 = var3.nextInt(1);
    int[] var6 = new int[] { };
    var3.setSeed(var6);
    int[] var11 = new int[] { 0, 100, 1};
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var11);
    var1.setSeed(var6);
    double var14 = var1.nextGaussian();
    float var15 = var1.nextFloat();
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(100L);
    int var19 = var17.nextInt(1);
    int[] var20 = new int[] { };
    var17.setSeed(var20);
    int[] var22 = null;
    int var23 = org.apache.commons.math3.util.MathArrays.distance1(var20, var22);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var22);
    byte[] var28 = new byte[] { (byte)0, (byte)10, (byte)(-1)};
    var24.nextBytes(var28);
    var1.nextBytes(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.8371016669875919d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.604216f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)7.33117135760314d, (java.lang.Number)21211.24799995728d, (java.lang.Number)7.33117135760314d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 21211.24799995728d+ "'", var4.equals(21211.24799995728d));

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     int var10 = var4.nextInt((-1223526183), 941025974);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var4.nextInt(312574995, 59);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 70757115);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var2.nextUniform(0.0d, 100.0d, false);
//     var2.reSeed();
//     double var10 = var2.nextCauchy(1.7965218799149243d, 5.271764897745934d);
//     double var13 = var2.nextBeta(0.05190356240941041d, 0.9999977358410781d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 23.95389662180223d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.258149920815963d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.8528901868138914E-9d);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextHypergeometric(0, 716369212, (-1213169957));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.236523476471506d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-3.82013829667001d));
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    var1.setSeed(1L);
    var1.setSeed(1L);
    var1.setSeed(10L);
    int var8 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1755678109);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 1.0d, (-1.0d)};
//     double[] var5 = new double[] { };
//     boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var5);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var5);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var5);
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var5);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1462141839), (java.lang.Number)10.0f, (java.lang.Number)0.9861807351340854d);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var10 = var0.nextExponential(3.9346068085718677d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextZipf((-1223526183), 0.9295883561064747d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7.278411997912395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-28.333857686521313d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 142.181728188587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10.555129197726838d);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure(1L);
    var4.reSeed();
    var4.reSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     var0.reSeedSecure();
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var0.nextSample(var7, 225475469);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    double[] var10 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var11 = new double[] { };
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    double[][] var13 = new double[][] { var10};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var6, var13);
    double[] var18 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var19 = new double[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var19);
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    double[] var32 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var33 = new double[] { };
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var33);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var28, var35);
    double[] var40 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var41 = new double[] { };
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var41);
    double[] var47 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var48 = new double[] { };
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var48);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    double[] var54 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var55 = new double[] { };
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var55);
    double[][] var57 = new double[][] { var54};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var48, var50, var57);
    double[] var62 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var63 = new double[] { };
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var63);
    org.apache.commons.math3.util.MathArrays.OrderDirection var65 = null;
    double[] var69 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var70 = new double[] { };
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var69, var70);
    double[][] var72 = new double[][] { var69};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var63, var65, var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var63);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var26, var74);
    double var76 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var26);
    double[] var78 = new double[] { 1.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var26, var78);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1462141839), 1685515552);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     int[] var4 = new int[] { };
//     var1.setSeed(var4);
//     var1.setSeed(1232268348);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var11 = var9.nextInt(1);
//     int[] var12 = new int[] { };
//     var9.setSeed(var12);
//     int[] var16 = new int[] { 1, 10};
//     org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
//     int var18 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
//     var1.setSeed(var12);
//     double var20 = var1.nextGaussian();
//     java.util.List var21 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var22 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var21);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     long[] var2 = null;
//     long[][] var3 = new long[][] { var2};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var3);
//     java.lang.Object var6 = var5.getKey();
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c();
//     int var11 = var10.nextInt();
//     long[] var12 = null;
//     long[][] var13 = new long[][] { var12};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
//     org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair((java.lang.Object)var11, (java.lang.Object)var13);
//     java.lang.Object var16 = var15.getKey();
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(100L);
//     boolean var19 = var15.equals((java.lang.Object)var18);
//     org.apache.commons.math3.util.Pair var20 = new org.apache.commons.math3.util.Pair(var15);
//     org.apache.commons.math3.util.Pair var21 = new org.apache.commons.math3.util.Pair(var20);
//     java.lang.Object var22 = var20.getSecond();
//     boolean var23 = var5.equals(var22);
//     java.lang.Object var24 = var5.getFirst();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-273646263));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (-273646263)+ "'", var6.equals((-273646263)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1634309337));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + (-1634309337)+ "'", var16.equals((-1634309337)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + (-273646263)+ "'", var24.equals((-273646263)));
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(5.271764897745934d);
//     double var5 = var0.nextCauchy((-1.0d), 10.0d);
//     double var8 = var0.nextCauchy(100.0d, 1.0d);
//     double var11 = var0.nextCauchy(0.8444156216806316d, 0.2550536339465285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.816193535071593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-6.823093198153258d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 122.82744585851604d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7430367776274643d);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     int[] var2 = new int[] { 1, 10};
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
//     java.util.List var4 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var5 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var3, var4);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    var4.reSeed(166L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var10 = var4.nextHexString(1741975207);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(0L, 4418713979230659041L);
//     int var6 = var0.nextSecureInt(941025974, 2146598351);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5e7cb2ff82", "org.apache.commons.math3.exception.NotStrictlyPositiveException: -1,978,339,594 is smaller than, or equal to, the minimum (0)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3103734508603144192L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1373912980);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(100L);
    int var4 = var2.nextInt(1);
    int[] var5 = new int[] { };
    var2.setSeed(var5);
    int[] var10 = new int[] { 0, 100, 1};
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var10);
    double var12 = org.apache.commons.math3.util.MathArrays.distance(var0, var10);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(100L);
    float var15 = var14.nextFloat();
    boolean var16 = var14.nextBoolean();
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(100L);
    int var20 = var18.nextInt(1);
    int[] var21 = new int[] { };
    var18.setSeed(var21);
    int[] var25 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var25);
    int var27 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(100L);
    int var31 = var29.nextInt(1);
    int[] var32 = new int[] { };
    var29.setSeed(var32);
    int[] var37 = new int[] { 0, 100, 1};
    int var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var37);
    int var39 = org.apache.commons.math3.util.MathArrays.distance1(var25, var37);
    var14.setSeed(var37);
    int var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var37);
    org.apache.commons.math3.random.Well19937c var43 = new org.apache.commons.math3.random.Well19937c(100L);
    int var45 = var43.nextInt(1);
    int[] var46 = new int[] { };
    var43.setSeed(var46);
    var43.setSeed(1232268348);
    org.apache.commons.math3.random.Well19937c var51 = new org.apache.commons.math3.random.Well19937c(100L);
    int var53 = var51.nextInt(1);
    int[] var54 = new int[] { };
    var51.setSeed(var54);
    int[] var58 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var59 = new org.apache.commons.math3.random.Well19937c(var58);
    int var60 = org.apache.commons.math3.util.MathArrays.distance1(var54, var58);
    var43.setSeed(var54);
    org.apache.commons.math3.random.Well19937c var63 = new org.apache.commons.math3.random.Well19937c(100L);
    int var65 = var63.nextInt(1);
    int[] var66 = new int[] { };
    var63.setSeed(var66);
    int[] var70 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var71 = new org.apache.commons.math3.random.Well19937c(var70);
    int var72 = org.apache.commons.math3.util.MathArrays.distance1(var66, var70);
    int[] var76 = new int[] { (-1), 100, 100};
    double var77 = org.apache.commons.math3.util.MathArrays.distance(var66, var76);
    org.apache.commons.math3.random.Well19937c var78 = new org.apache.commons.math3.random.Well19937c(var66);
    org.apache.commons.math3.random.Well19937c var79 = new org.apache.commons.math3.random.Well19937c(var66);
    int var80 = org.apache.commons.math3.util.MathArrays.distance1(var54, var66);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var81 = org.apache.commons.math3.util.MathArrays.distance(var10, var54);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextChiSquare(2.913539924093275d);
    double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
    int var12 = var4.nextInt(10, 99);
    double var15 = var4.nextF(3.9346068085718677d, 8.027560136941847d);
    int var19 = var4.nextHypergeometric(722500763, 91, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var4.nextF((-55731.07512021974d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3098593374527597d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.08244612118583806d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5127948165466234d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.8444156216806316d, (-565.6035380963093d), 6.03709264688173d, 3.5865133480106643d, 1.9986611519194435d, 0.9614486620846391d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-3407.43273599201d));

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var6 = var4.nextChiSquare(2.913539924093275d);
//     double var9 = var4.nextCauchy(0.0d, 4.359252164571766d);
//     int var12 = var4.nextInt(10, 99);
//     int var15 = var4.nextInt(0, 59);
//     int var18 = var4.nextZipf(59, 0.05190356240941041d);
//     long var20 = var4.nextPoisson(141.746624376947d);
//     org.apache.commons.math3.distribution.IntegerDistribution var21 = null;
//     int var22 = var4.nextInversionDeviate(var21);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    double[] var3 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var4 = new double[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var4);
    double[] var9 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var10 = new double[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var10);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    double[] var16 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var17 = new double[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var17);
    double[][] var19 = new double[][] { var16};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var10, var12, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
    double[] var25 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var26 = new double[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var26);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    double[] var32 = new double[] { 10.0d, 1.0d, (-1.0d)};
    double[] var33 = new double[] { };
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var33);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var28, var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var10, var26);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var4, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var10, 90.43193939599433d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    int var3 = var1.nextInt(1);
    int[] var4 = new int[] { };
    var1.setSeed(var4);
    int[] var8 = new int[] { 1, 10};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    int var10 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c();
//     int var4 = var3.nextInt();
//     long[] var5 = null;
//     long[][] var6 = new long[][] { var5};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair((java.lang.Object)var4, (java.lang.Object)var6);
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1265566754));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure();
//     java.lang.String var3 = var0.nextHexString(10);
//     int var7 = var0.nextHypergeometric(104097891, 100, 1);
//     long var10 = var0.nextLong(862908985188605553L, 3081282935693573632L);
//     long var13 = var0.nextLong(88L, 1697424459525688832L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextHypergeometric((-1298863262), 1781983652, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "55fed434f1"+ "'", var3.equals("55fed434f1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1776741068844473088L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 768900596108048512L);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     int var3 = var1.nextInt(1);
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeedSecure(1L);
//     var4.reSeed();
//     double var10 = var4.nextCauchy(3.866719511476555d, 8.027560136941847d);
//     double var13 = var4.nextGaussian(19.42595685892877d, 1.0d);
//     double var16 = var4.nextWeibull(10.24834333371038d, 209.92922630488403d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var4.nextZipf((-260641056), 32.36871072544811d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 202.87641919246877d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 18.96981550447031d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 213.8536836349021d);
// 
//   }

}
