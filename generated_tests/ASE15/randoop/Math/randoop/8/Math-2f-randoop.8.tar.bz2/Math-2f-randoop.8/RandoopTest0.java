
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.141592653589793d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6321205588285577d));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(10, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(3.141592653589793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.141592653589793d, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.283185307179586d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10L);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(6.283185307179586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1096622711232151d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(100.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var7.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.141592653589793d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.982441812995697E30d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var7.nextInt(100, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(6.283185307179586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.537297501373361d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0f);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(3.141592653589793d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 93648.04747608298d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var0.nextSample(var4, 1);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(12.236902640271552d, 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2058461.314264962d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var7.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextGamma(2058461.314264962d, (-0.6321205588285577d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.1096622711232151d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.33115294219320335d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    double var13 = var7.nextGaussian(0.0d, 2.220446049250313E-16d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var7.nextUniform(100.0d, 2.220446049250313E-16d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.4597135858742798E-16d));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform(5.804641090815146d, 3.141592653589793d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var1.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextCauchy(2.537297501373361d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.9562223577239215d);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var7.nextCauchy(2058461.314264962d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 3.141592653589793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.1096622711232151d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9939931165725187d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var7.nextLong(1L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(93648.04747608298d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 93648.04747608298d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1L);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(10.0d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.6321205588285577d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6321205588285576d));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var7.nextBinomial(100, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(93648.04747608298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(100.0d, 2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 99.99999999999999d);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-1.0d), Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var7.nextUniform(99.99999999999999d, 0.1096622711232151d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2058461.314264962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.3135427094879235d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-36.04365338911715d));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var7.nextBinomial((-118603794), 0.9939931165725187d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var7.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(25.21435585163038d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.9209536856213183d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(93648.04747608298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 306.0196847852814d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.87731868091954d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     double var0 = org.apache.commons.math3.util.FastMath.random();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == 0.27045149498596743d);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    double var13 = var7.nextGaussian(0.0d, 2.220446049250313E-16d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var16 = var7.nextLong(100L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.4597135858742798E-16d));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.6321205588285577d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7449400628223749d));

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, var2, true);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0d, (java.lang.Number)6.3135427094879235d, false);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextBeta((-1.0d), 10.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.7449400628223749d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2905389698182939d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100.0d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.141592653589793d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.expm1(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.7449400628223749d), (-36.04365338911715d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-36.04365338911715d));

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var7.nextInversionDeviate(var11);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 4.9E-324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var8 = new int[] { 1, 0, 1};
//     var4.setSeed(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
//     java.lang.Object[] var11 = new java.lang.Object[] { var4};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var11);
//     org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)10, var11);
//     java.lang.String var14 = var13.toString();
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)4.9E-324d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(25.68447716417873d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5318819596985707d);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextCauchy(2.220446049250313E-16d, (-1.4597135858742798E-16d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 59L);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.2905389698182939d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2905389698182939d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(2058461.314264962d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3283064365386963E-10d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(6.7727635120911645d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8307659113974537d);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextF(1.0d, (-0.6321205588285576d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 12L);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 25.68447716417873d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var7.nextInt(10, (-118603794));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.7449400628223749d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.537297501373361d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b", "774e5780dc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.299984268748976d);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("", "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.220446049250313E-16d);
    java.lang.Number var2 = var1.getMin();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 2.220446049250313E-16d+ "'", var3.equals(2.220446049250313E-16d));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var16 = var7.nextPermutation(0, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextInt(1, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3309483193355235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3447.2715412507027d);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2058461.314264962d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2058461.314289252d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var7.nextUniform(2058461.314289252d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5440211108893698d));

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    int var7 = var0.nextZipf(10, 2147.432395050844d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var0.nextSecureLong(100L, 93L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var7.nextUniform(3.982441812995697E30d, 93648.04747608298d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var0.nextPermutation(1, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(93649.84672246638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.140465251696156d);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var6 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7169636292746049d);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     boolean var5 = var4.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.27045149498596743d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var7.nextBeta(0.0d, 0.33115294219320335d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var7.nextSample(var14, 4);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextZipf(0, 0.9292273298132443d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000001f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(93L, 74L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 74L);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     java.lang.Number var5 = var4.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     var4.addSuppressed((java.lang.Throwable)var10);
//     org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
//     org.apache.commons.math3.exception.util.ExceptionContext var13 = var10.getContext();
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.exception.util.Localizable var18 = null;
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var24 = new int[] { 1, 0, 1};
//     var20.setSeed(var24);
//     org.apache.commons.math3.random.RandomDataImpl var26 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var20);
//     java.lang.Object[] var27 = new java.lang.Object[] { var20};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var28 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var18, var27);
//     org.apache.commons.math3.exception.NotFiniteNumberException var29 = new org.apache.commons.math3.exception.NotFiniteNumberException(var16, (java.lang.Number)10, var27);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var30 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var15, var27);
//     org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var14, var27);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.9209536856213183d, 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.07710609037881033d));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(7, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("hi!", "774e5780dc");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(93648.04747608298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(7.552633489589084d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2058461.314264962d, 99.99999999999999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2058461.3166939607d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var17 = var7.nextSecureLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var7.nextBinomial(1, (-0.5440211108893698d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)5.804641090815146d, (java.lang.Number)Double.POSITIVE_INFINITY, (java.lang.Number)3.9209536856213183d);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextSecureLong(100L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 22L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.6577892136676118d);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     int var5 = var0.nextSecureInt(1, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(99.99999999999999d, 1.1935683377421018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 243.85781350670376d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var7.nextBinomial(1, 99.99999999999999d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var7.nextWeibull(0.0d, (-36.04365338911715d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var7.nextGaussian(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2058461.3166939607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var7.nextWeibull(243.85781350670376d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.27045149498596743d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6466904717391735d);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGamma(2.2891073680063085d, (-0.6321205588285576d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 41L);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var4 = var0.nextT(4.9E-324d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.0730154820901265d));
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2058461.314289252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.5816635108956087d));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3010299956639812d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.5440211108893698d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4195903379527587d));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    int var7 = var0.nextZipf(10, 2147.432395050844d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var0.nextPascal((-118603794), 3.141592653589793d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextSecureLong(32L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 10.67196189568329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "fec5ee794d"+ "'", var4.equals("fec5ee794d"));
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int[] var4 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    var1.setSeed(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, (-118603794), 7, (-118603794));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var7.nextInversionDeviate(var8);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8813735870195429d));

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.4E-45f, (-1.4597135858742798E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.4195903379527587d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.882579444988825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7378028177813758d));

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     long var15 = var7.nextPoisson(Double.NaN);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(3.141592653589793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22.140692632779267d);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     var7.reSeedSecure();
//     org.apache.commons.math3.distribution.RealDistribution var16 = null;
//     double var17 = var7.nextInversionDeviate(var16);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(42, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9939931165725187d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.6321205588285576d), 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.01611384709729009d));

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2058461.314289252d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2058461.314289252d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform((-0.6321205588285576d), (-0.7449400628223749d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(99.99999999999999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.641588833612778d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.6466904717391735d, (java.lang.Number)26.468397517010732d, false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(406.4705924790716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6861855915722702E176d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(4, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(32L);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)(-1));
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    long var13 = var7.nextLong(3L, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 9L);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.01611384709729009d), 0.33115294219320335d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.016113847097290086d));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    int var7 = var0.nextZipf(10, 2147.432395050844d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var10 = var0.nextPermutation(0, 8);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.4195903379527587d), (java.lang.Number)1, false);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(306.0196847852814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.726911865353372d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextChiSquare(Double.NaN);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.6489672442845977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2434467.448898326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.9396337447806558d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var7.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextGaussian(5.804641090815146d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.596809240798458d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "4a9c69904e"+ "'", var4.equals("4a9c69904e"));
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.908642352606886d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextBeta((-0.07710609037881033d), 1.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var4 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.1317424470877964d));
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(9L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var7.nextLong(85L, 10L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 90L);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextZipf(0, 4.9E-324d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextZipf((-1), 0.9939931165725187d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 70L);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.4683048930644915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3514488136855796d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var7.nextUniform(1.0763035517091262E30d, 22.140692632779267d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)9L);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    var2.setSeed((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextLong(74L, 9L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var7.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(14.94806722174175d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7693376445680227d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-1.0f), 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(48.10826499572976d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 48.108264995729755d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3327.545661366997d, 1.8482997974150024d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3327.5461746900623d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(48.10826499572976d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.819050563341387E20d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.setSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(3.2150924088272843d, (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.6151022117286396E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var7.nextF(Double.POSITIVE_INFINITY, (-0.27096157230053536d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2L);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.3010299956639812d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2147.432395050844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.365175298942184d);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeedSecure(100L);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0018891184526169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7438403.856169353d);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    int var7 = var0.nextZipf(10, 2147.432395050844d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var0.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.01611384709729009d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.016245086893048467d));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.33115294219320335d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3253809740926889d);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var2 = var0.nextInt(10);
//     long var3 = var0.nextLong();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var5 = var0.nextLong((-414028722650554365L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1464819685225425289L));
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var0.nextSample(var10, 4);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextT((-0.016245086893048467d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 31L);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var0.nextSecureLong(32L, 3L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    byte[] var17 = new byte[] { (byte)10};
    var9.nextBytes(var17);
    var1.nextBytes(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var23 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 8, 3, (-96398574));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("774e5780dc", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextHexString(9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "6a6972a6a"+ "'", var2.equals("6a6972a6a"));
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.3283064365386963E-10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3283064365386963E-10d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var7.nextLong(3L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 87L);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextBinomial(0, 26.468397517010732d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 12.136802749142017d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 19315.498188720718d);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(93649.84672246638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 93648.04747608298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)12.236902640271552d, (java.lang.Number)1.4E-45f, false);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure((-1L));
//     double var11 = var7.nextExponential(0.15015415474359342d);
//     org.apache.commons.math3.distribution.IntegerDistribution var12 = null;
//     int var13 = var7.nextInversionDeviate(var12);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.2891073680063085d, 3327.545661366997d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2891073680063085d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.0d), 6840.77334039907d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0d));

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, 10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(16.853135916639044d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5115296784115013d);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric(1, 4, 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 100L);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(3.9209536856213183d, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 60.28026284097294d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.nextGaussian(0.9999997600389442d, (-0.6321205588285577d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     double var8 = var0.nextChiSquare(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextZipf((-118603794), 0.341345202615279d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.325208032554803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7.126378369665809E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.213565155102463d);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.76195765f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.6321205588285577d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2065299964591305d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)(-1));
    java.lang.Number var3 = var2.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.setSeed(0);
    double var5 = var2.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.908642352606886d);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure((-1L));
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var7.nextInversionDeviate(var10);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextUniform(1.3514488136855796d, 2.3283064365386963E-10d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.4825607627693726d));
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(6840.77334039907d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.016245086893048467d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6));

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.4E-45f, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.8E-45f);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var10 = var0.nextHexString((-6));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 30.24849807983542d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.1104727395982765E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8.64957949645183d);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     double var22 = var7.nextCauchy(2.93710385249215d, 0.33115294219320335d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var26 = var7.nextUniform(2.2560527698684258E29d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.932837380465428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.1755291984960703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.1373481553894536d);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    int var14 = var7.nextZipf(9, 93649.84672246638d);
    double var16 = var7.nextChiSquare(1.3514488136855796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.3628228738271679d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextF(12.332151351658016d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(9, 42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 42);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.001129876315267469d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-10));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1), (java.lang.Number)6.3135427094879235d, false);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 6.3135427094879235d+ "'", var4.equals(6.3135427094879235d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.47355289240887427d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     java.lang.String var14 = var7.nextHexString(100);
//     org.apache.commons.math3.distribution.RealDistribution var15 = null;
//     double var16 = var7.nextInversionDeviate(var15);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(4.284201251169182d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100.0d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var13 = new int[] { 1, 0, 1};
//     var9.setSeed(var13);
//     org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
//     java.lang.Object[] var16 = new java.lang.Object[] { var9};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
//     org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10, var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var16);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.497498709678805d, 2.2891073680063085d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.127037209198646d);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextHypergeometric(0, 13, (-118603794));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 46605.32411778309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.0305598407099867d);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.016113847097290086d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.016113149763313152d));

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 1.5115296784115013d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var7.nextHypergeometric((-194062463), 8, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)100L, (java.lang.Number)(-6116618998156505929L), true);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(99.99999999999999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5607966601082315d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.6466904717391735d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.4E-45f, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.794E-43f);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, 10, 42);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.4574326092991893d, var2, false);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.000001f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var12 = var7.nextChiSquare(0.33115294219320335d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var7.nextSecureLong(74L, 55L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.31834230895305893d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, (-118603794), 0, (-118603794));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var16 = var7.nextChiSquare(5.804641090815146d);
//     org.apache.commons.math3.distribution.RealDistribution var17 = null;
//     double var18 = var7.nextInversionDeviate(var17);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     var0.reSeedSecure(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextZipf(0, 26.468397517010732d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 26.156907386593048d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9193.739139842832d);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextGamma(2.726066212978514E-4d, (-0.016113847097290086d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 58772.78481033282d);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(short)1, (java.lang.Number)10.0f, (java.lang.Number)(-0.6321205588285576d));
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.6321205588285576d)+ "'", var5.equals((-0.6321205588285576d)));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(4.60890860857409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2327048838369965d);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(93649.84672246638d, 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     java.lang.String var7 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(3.982441812995697E30d, 2.537297501373361d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "3"+ "'", var7.equals("3"));
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     var0.reSeedSecure(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextZipf((-118603794), 0.341345202615279d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7.449642818641963d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5264421205836732d);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.5440211108893698d), 93649.84672246638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 93649.84672246638d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    float var8 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0997566f);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var7.nextF((-1.189520633886725d), 3.9209536856213183d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.267434191074838d);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    int var21 = var18.nextZipf(10, 3.141592653589793d);
    double var24 = var18.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var27 = var18.nextPermutation(100, 100);
    var1.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var32 = new int[] { 10};
    var30.setSeed(var32);
    org.apache.commons.math3.random.Well19937c var35 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var39 = new int[] { 1, 0, 1};
    var35.setSeed(var39);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var44 = new int[] { 10};
    var42.setSeed(var44);
    var35.setSeed(var44);
    var30.setSeed(var44);
    var1.setSeed(var44);
    var1.setSeed((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.9999997600389442d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5701035626714024d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-1L), 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var3 = new int[] { 10};
    var1.setSeed(var3);
    long var6 = var1.nextLong(3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2L);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.4E-45f, 10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     int var5 = var0.nextSecureInt(4, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextCauchy(5.93502618160048d, (-1.189520633886725d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.8280636119789326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 54);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     long var7 = var0.nextSecureLong(10L, 93L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGaussian(4.641588833612778d, (-1.189520633886725d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.10102388908352061d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 89L);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.01611384709729009d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)(-1));
//     java.lang.Number var3 = var2.getMin();
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var15 = new int[] { 1, 0, 1};
//     var11.setSeed(var15);
//     org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     java.lang.Object[] var18 = new java.lang.Object[] { var11};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, var18);
//     org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)10, var18);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var18);
//     org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.6321205588285576d), var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, var18);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(short)1, (java.lang.Number)10.0f, (java.lang.Number)(-0.6321205588285576d));
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    org.apache.commons.math3.exception.NotPositiveException var9 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var9);
    var4.addSuppressed((java.lang.Throwable)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0f+ "'", var5.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0f+ "'", var6.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0f+ "'", var7.equals(10.0f));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.09347294900676971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     double var22 = var7.nextCauchy(2.93710385249215d, 0.33115294219320335d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var7.nextBinomial(65, 14.94806722174175d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6.26320950635226d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.14294692728149405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.4161790594156507d);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8E-45f);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    double var4 = var2.nextGaussian();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, (-118603794), 42, 13);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.908642352606886d);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeedSecure(100L);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextChiSquare((-1.189520633886725d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21.074995435471436d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.5845619626618702E7d);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextExponential((-0.6321205588285577d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 25.76138400574338d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3004788.256516452d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 20.291458547423307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.2712856473959901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.26482072689552133d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.0997566f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.26460785404894344d));

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     org.apache.commons.math3.distribution.RealDistribution var5 = null;
//     double var6 = var4.nextInversionDeviate(var5);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     long var7 = var0.nextSecureLong(10L, 93L);
//     java.lang.String var9 = var0.nextSecureHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var0.nextPermutation(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.922168118447509d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 76L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "ac71"+ "'", var9.equals("ac71"));
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(10.201158186626492d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 584.4833102390261d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var0, 61, (-6), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var0.nextSample(var3, 8);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, (-6116618998156505929L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6116618998156505929L));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    long var4 = var2.nextLong();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextInt((-118603794));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.07710609037881033d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.07718251686616505d));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22026.465794806718d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(55L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 55L);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.5701035626714024d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.3088437356800404E29d, 0.9999993243506345d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3088437356800402E29d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.47355289240887427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8899536081879631d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22025.465794806718d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(4.641588833612778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    byte[] var17 = new byte[] { (byte)10};
    var9.nextBytes(var17);
    var1.nextBytes(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var1.nextInt((-810646614));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    double var18 = var7.nextF(89880.15295851197d, 6840.77334039907d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var21 = var7.nextPermutation(9, 13);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0103627457703912d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-2.085860893902951d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-119.51102587202428d));

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(3.286292495855155d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2754044995723817d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.635938953296214d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(10.0f, 1.794E-43f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.7449400628223749d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var7.nextPascal((-4), 1.908642352606886d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    double var13 = var7.nextGaussian(0.0d, 2.220446049250313E-16d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("08a8be8f", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.4597135858742798E-16d));

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.027851898363248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    double var14 = var7.nextBeta(7.552633489589084d, 0.9995149440000322d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var7.nextBeta(1.5701035626714024d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.9672751717291171d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var0.nextPermutation(2, (-4));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.99999994f));

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2404374004543741d);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     int var5 = var0.nextInt(4, 65);
//     var0.reSeed(74L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt(0, (-4));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.104714470438652d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 26);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.31834230895305893d, 1.2404374004543741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.24175283435836448d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(100.0f, 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920929E-7f);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var10 = new int[] { 10};
    var8.setSeed(var10);
    var1.setSeed(var10);
    double var13 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.761957659063951d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var12 = var7.nextChiSquare(0.33115294219320335d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var7.nextT((-0.5440211108893698d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.31834230895305893d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    int var21 = var18.nextZipf(10, 3.141592653589793d);
    double var24 = var18.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var27 = var18.nextPermutation(100, 100);
    var1.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var32 = new int[] { 10};
    var30.setSeed(var32);
    org.apache.commons.math3.random.Well19937c var35 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var39 = new int[] { 1, 0, 1};
    var35.setSeed(var39);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var44 = new int[] { 10};
    var42.setSeed(var44);
    var35.setSeed(var44);
    var30.setSeed(var44);
    var1.setSeed(var44);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     java.lang.String var7 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "4"+ "'", var7.equals("4"));
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    double var19 = var7.nextExponential(1.87731868091954d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var22 = var7.nextInt(4, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.9964021940844213d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.0305861449896165d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextGamma(100.0d, 1.0763035517091262E30d);
//     var0.reSeedSecure(2876919108950029338L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt(42, 5);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 20.021375485677027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.1018139498089566E32d);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    double var3 = var2.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.908642352606886d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    long var4 = var2.nextLong();
    long var5 = var2.nextLong();
    var2.setSeed((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2876919108950029338L);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(20.583749267742867d, 406.4705924790716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.986281309696751d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    java.lang.Number var5 = var4.getArgument();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    var4.addSuppressed((java.lang.Throwable)var10);
    boolean var12 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)(-1)+ "'", var5.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5063656411097588d));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.986281309696751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.2667103256235044d));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(406.4705924790716d, 0.8307659113974537d);
//     double var5 = var0.nextExponential(8.365175298942184d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextHypergeometric((-118603794), 428451470, (-118603794));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2577.637482677721d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.848590949056273d);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(48.108264995729755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 49.0d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    boolean var5 = var2.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(4.284201251169182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4549341288792002d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.8482997974150024d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 105.89977766676469d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.4574326092991893d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    long var4 = var2.nextLong();
    long var5 = var2.nextLong();
    var2.setSeed(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2876919108950029338L);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var7.nextGamma((-0.27096157230053536d), 2.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(89880.15295851197d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.4683048930644915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1858699313494176d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-0.7449400628223749d));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.286292495855155d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var19 = var11.probability((-6));
    int var20 = var11.getPopulationSize();
    int var21 = var11.getNumberOfSuccesses();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var11.cumulativeProbability(3, (-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 4);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.341345202615279d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.10429317151917769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.10429317151917769d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(243.85781350670376d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.496585323909292d);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextHypergeometric(42, 7, (-4));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     var0.reSeedSecure(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextCauchy(0.3628228738271679d, (-0.5063656411097588d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.943118929599698d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.8175142898874655E7d);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-96398574), 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)3.141592653589793d);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     java.lang.Number var9 = var8.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var10, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     var8.addSuppressed((java.lang.Throwable)var14);
//     org.apache.commons.math3.exception.util.ExceptionContext var16 = var14.getContext();
//     var3.addSuppressed((java.lang.Throwable)var14);
//     java.lang.Throwable var18 = null;
//     var3.addSuppressed(var18);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     double var13 = var7.nextGaussian(0.0d, 2.220446049250313E-16d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var7.nextSample(var14, 428451470);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var7.nextBinomial(8, 6.929625337259191d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.24175283435836448d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var11.inverseCumulativeProbability(22.511131074500152d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextHypergeometric(8, (-6), 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 17.05018493182507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 362697.2847263726d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-6.853056998203911d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy((-0.6321205588285576d), 1.2895855093964026d);
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var0.nextSample(var4, 1);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, (-0.26460785404894344d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.26460785404894344d));

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     double var13 = var7.nextGaussian(0.0d, 2.220446049250313E-16d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var7.nextSample(var14, 7);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(61L, 11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 61L);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4574326092991893d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.4066076797520086d, (java.lang.Number)9, true);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(4.284201251169182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 245.46665027666086d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var11.inverseCumulativeProbability(1.181547729533909d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var7.nextSample(var11, 8);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     double var6 = var0.nextBeta(0.24d, 3.328704913108978d);
//     double var9 = var0.nextGamma(0.8899536081879631d, 0.8825395169829675d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(0.26482072689552133d, (-0.6321205588285577d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2185952657176529d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.12751642200883798d);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.1096622711232151d, (-1.4597135858742798E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.638820928472139E-17d);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextGamma(100.0d, 1.0763035517091262E30d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextSecureLong(9L, 9L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.296654456097059d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.077684750578161E32d);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     int var5 = var0.nextInt(4, 65);
//     var0.reSeed(74L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextLong(9L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.34040430192032173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 50);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.189520633886725d));

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var3 = new int[] { 10};
    var1.setSeed(var3);
    float var5 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var6.nextWeibull(1.4869035278007987d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.76195765f);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.007758104443520159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.088080102426826d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.001129876315267469d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.001129876315267469d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var12 = var7.nextChiSquare(0.33115294219320335d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("735479ac58", "0008");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.31834230895305893d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.1649950720257549d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.0197670739888333E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 65.18510402677708d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var11.inverseCumulativeProbability(3.6151022117286396E29d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var12 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.09975663986204619d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(3.141592653589793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var4.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 22.511131074500152d);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var5 = var0.nextUniform(0.27045149498596743d, 6840.77334039907d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal(30, 243.85781350670376d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7250967144836794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5358.502589160289d);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(22026.465794806718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextBinomial(65, 43.19990300454566d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.2864296153403627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.456451010748363E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-69.50191206004229d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.setSeed(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, (-118603794), 100, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.986281309696751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.712792388468654d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(3.027851898363248d, 5.496585323909292d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.496585323909292d);

  }

//  public void test416() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
//
//
//    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//    var0.reSeed();
//    int var5 = var0.nextHypergeometric(4, 1, 1);
//    int var8 = var0.nextZipf(4, 8.97308641465062d);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int var11 = var0.nextPascal((-1), 24329.65241188829d);
//      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == 1);
//
//  }
//
  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.337903735516005E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var8 = new int[] { 1, 0, 1};
    var4.setSeed(var8);
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
    java.lang.Object[] var11 = new java.lang.Object[] { var4};
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(26.94414842759192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.0d);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(4, 1, 1);
//     int var8 = var0.nextZipf(4, 8.97308641465062d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("b23", "b23");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var9 = new int[] { 1, 0, 1};
//     var5.setSeed(var9);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
//     java.lang.Object[] var12 = new java.lang.Object[] { var5};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var12);
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)10, var12);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var12);
//     java.lang.String var16 = var15.toString();
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.794E-43f, 0.0997566f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.794E-43f);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.016113847097290086d), 2.93710385249215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.016113847097290086d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed(10L);
    double var6 = var0.nextGamma(0.1096622711232151d, 25.21435585163038d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.010362048038259351d);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)0.9995149440000322d, (java.lang.Number)12.236902640271552d);
//     java.lang.Number var5 = var4.getHi();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var11.cumulativeProbability(61, 14);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)71L);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(61, (-4), 65);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.1754447373271675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07020221590414388d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.5826716629917943d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.9292273298132443d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8304341776476892d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)0, (java.lang.Number)1.908642352606886d, true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     double var15 = var7.nextExponential(0.27045149498596743d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var17 = var7.nextSecureHexString((-194062463));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 48L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.15015415474359342d);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.26460785404894344d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.26460785404894344d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextGamma(144.26931954487853d, 7.552633489589084d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1269.3739277026489d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 5148.282084813554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.016113847097290086d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.016114544521814232d));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.7311752765839155E30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.731175276583916E30d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var11 = new int[] { 1, 0, 1};
    var7.setSeed(var11);
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
    java.lang.Object[] var14 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10, var14);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var2, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1), var14);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     double var9 = var0.nextExponential(1.2905389698182939d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextInt(61, (-810646614));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.22210041242538464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999999520716468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.342808831473179d);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     double var25 = var7.nextCauchy(26.468397517010732d, 0.7816736683885532d);
//     org.apache.commons.math3.distribution.RealDistribution var26 = null;
//     double var27 = var7.nextInversionDeviate(var26);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     long var8 = var0.nextSecureLong((-6116618998156505929L), 32L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-432485425446058487L));
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var11 = var7.nextPoisson((-0.016113847097290086d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(89880.15295851197d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7262566507187045d));

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.1858699313494176d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02069733480244646d);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     java.lang.String var6 = var0.nextHexString(10);
//     double var9 = var0.nextCauchy(7.819050563341387E20d, 3327.5461746900623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.093721944405666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "3f002a4923"+ "'", var4.equals("3f002a4923"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "6a9a6861b0"+ "'", var6.equals("6a9a6861b0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.819050563341387E20d);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeedSecure(100L);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 35.64601019521908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.7867568469229713E7d);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     int var5 = var0.nextSecureInt(4, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal(13, (-0.7378028177813758d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9640408802423961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 19);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1066552245953152d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1041.37115449346d, (-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 65.08569715584125d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    int var14 = var7.nextZipf(9, 93649.84672246638d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var7.nextBinomial(6, 68.34266005659136d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(55L);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.4066076797520086d, (java.lang.Number)0.054973020182809376d, false);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextPascal((-96398574), (-0.016245086893048467d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 42808.474726096276d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.059667519569901d);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(2.0453921118134297d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    int var3 = var1.nextInt();
    boolean var4 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var10 = new int[] { 1, 0, 1};
    var6.setSeed(var10);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var18 = new int[] { 1, 0, 1};
    var14.setSeed(var18);
    org.apache.commons.math3.random.RandomDataImpl var20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var14);
    byte[] var22 = new byte[] { (byte)10};
    var14.nextBytes(var22);
    var6.nextBytes(var22);
    var1.nextBytes(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-194062463));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var3 = new int[] { 10};
    var1.setSeed(var3);
    var1.setSeed(1L);
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 61, 13, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000001f);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(3.328704913108978d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.969011016549919d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.5885161306767546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9415740839056164d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-23));

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     double var8 = var0.nextChiSquare(10.0d);
//     int var11 = var0.nextZipf(10, 1.1858699313494176d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal(428451470, 2.8176795340571648d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.454993013930145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0172561773496497E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.589110003947088d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.8825395169829675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8825395169829676d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var11 = new int[] { 1, 0, 1};
    var7.setSeed(var11);
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
    java.lang.Object[] var14 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10, var14);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var2, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1), var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)3.286292495855155d, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(9.754247826527576d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.968212069455292d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)105.89977766676469d, (java.lang.Number)12.236902640271552d, false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.09975663986204619d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.09942769605832733d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(5.726911865353372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.537297501373361d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2633630179028634d);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeedSecure(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "08a8be8f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 55.433720654644254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.9960131572689386E-7d);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    double var18 = var7.nextF(89880.15295851197d, 6840.77334039907d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var21 = var7.nextSecureLong(2L, (-414028722650554365L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0103627457703912d);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var7.nextPascal(5, (-0.016114544521814232d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.642132165355758d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 40.621751179735185d);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2058461.3166939607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2058461.0d);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextGamma(0.0d, 4.284201251169182d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9273.786179060195d);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-119.51102587202428d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.925715506645026d));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(3.4447996764224045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 30.337005276849467d);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(406.4705924790716d, 0.8307659113974537d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextZipf((-2), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.3389720087234123d);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(5.726911865353372d, 2.133692144043651d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.726911865353372d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.24175283435836448d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.32662446455161d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(9L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9L);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 1.794E-43f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(406.4705924790716d, 0.8307659113974537d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextHypergeometric(15, 7, 428451470);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.272520489749509d);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.1935683377421018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var7.nextHypergeometric(30, 61, 4);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.316079678623155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.15331552262806594d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.7262566507187045d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    int[] var12 = var7.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    long var15 = var13.nextLong(55L);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var19 = new int[] { 10};
    var17.setSeed(var19);
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var26 = new int[] { 1, 0, 1};
    var22.setSeed(var26);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var31 = new int[] { 10};
    var29.setSeed(var31);
    var22.setSeed(var31);
    var17.setSeed(var31);
    var13.setSeed(var31);
    var13.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9569712468720478d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.1920929E-7f, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00390625f);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.731175276583916E30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 70.08228481062106d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 1930906741579263412L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1930906741579263412L);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(7.819050563341387E20d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.819050563341387E20d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.9999996064388104d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1752005863472421d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    var1.setSeed(100);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.76195765f, 9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    double var19 = var7.nextGaussian(14.94806722174175d, 38.42983716254903d);
    int var23 = var7.nextHypergeometric(42, 6, 6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var26 = var7.nextBeta(0.0d, 8.365175298942184d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-7.879966881943199d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);

  }

}
